# MIS Genius AI

**Universal AI-powered MIS, BI and analytics platform.** Upload any Excel or CSV file — sales, expenses,
attendance, stock, payroll, certificates, hospital registers, government MIS sheets — and MIS Genius AI
understands its structure, checks data quality, builds KPIs and an interactive dashboard, answers questions
in English, Hindi or Hinglish, and writes executive reports. Every number is computed from your data and
can be traced back to the query that produced it.

One codebase runs as a **Windows desktop app**, a **localhost app**, an **office LAN server**, a **cloud SaaS**
(multi-tenant, PostgreSQL + S3), an installable **PWA**, and an **Android/iOS** app shell.

```
UPLOAD → INSPECT (sheets, tables, headers) → PROFILE (types, roles, quality) → SCHEMA → KPIs → DASHBOARD
      → FILTERS / CROSS-FILTERS → RAW DATA EXPLORER → AI INSIGHTS → AI QUESTIONS → REPORT → EXPORT
```

## Quick start

| I want to… | Do this |
|---|---|
| Use it on my Windows PC | Run `MISGeniusAI-Setup-1.0.0.exe` (built by `apps/desktop/build_windows.ps1`, or the *windows-installer* CI artifact). Double-click the desktop icon. |
| Run from source (any OS) | `pip install -r services/api/requirements.txt` · `cd apps/web && npm ci && npm run build` · `scripts/start_local.sh` → http://127.0.0.1:8765 |
| Share on the office network | `scripts/start_lan.sh` (or the “office network” shortcut on Windows) → colleagues open `http://<server-ip>:8765` — see [docs/LAN.md](docs/LAN.md) |
| Deploy to the cloud | `cp .env.example .env` (edit) · `docker compose up -d --build` — see [docs/CLOUD.md](docs/CLOUD.md) |
| Develop | `scripts/dev.sh` (API with reload on :8765 + Vite on :5173) |
| Try without data | Click **Sample sales data** or **Sample attendance data** on the home screen (clearly marked DEMO) |

The first person to open a new installation creates the **owner** account.

### हिन्दी में शुरुआत
1. Windows पर इंस्टॉलर चलाएँ और डेस्कटॉप आइकन पर डबल-क्लिक करें (या `scripts/start_local.bat`)।
2. पहली बार खोलने पर अपना owner अकाउंट बनाएँ।
3. होम पेज पर Excel/CSV फ़ाइल छोड़ें — डैशबोर्ड अपने आप बनेगा।
4. “AI से पूछें” में हिन्दी में सवाल पूछें, जैसे “इस महीने सबसे ज्यादा बिक्री किस क्षेत्र में हुई?”
5. ऊपर “हिन्दी” बटन से पूरा इंटरफ़ेस हिन्दी में बदलें। AI key के बिना भी सब कुछ काम करता है।

## What is implemented

* **Universal ingestion** — XLSX, XLS, CSV/TSV (encoding + delimiter sniffing), JSON; multiple sheets and multiple
  tables per sheet; title rows, merged two-row headers, repeated headers, “Grand Total” rows, missing headers,
  duplicate column names; Indian numbers (1,00,000), ₹/Rs./INR/$/€/£, `(500)` and `500-` negatives, Dr/Cr, %,
  lakh/crore/K/M suffixes, text-formatted numbers, 12+ date formats and Excel serial dates with DD/MM vs MM/DD
  detection. Zip-bomb, size, row and column limits. One bad sheet never breaks the upload.
* **Semantic schema** — type, role (measure/dimension/time/identifier/attribute), confidence, semantic tags,
  currency/percentage detection, PII detection, hierarchies (City→State), correlations, derived columns
  (Sales = Cost + Profit), primary keys, domain guess. Manual correction of type, role, label, date order.
* **Data quality engine** — missing, duplicates, invalid values, inconsistent formats, case variants, whitespace,
  skew-aware outliers, constant/empty columns, future dates, suspicious negatives; bilingual explanations and
  suggested fixes.
* **Non-destructive cleaning** — 14 operations; each run creates a new dataset version; originals are immutable.
* **Query engine** — DuckDB over Parquet; safe structured queries (no SQL from users or AI), 15 filter operators,
  11 aggregations, safe calculated-metric formulas, date grains incl. Indian financial year.
* **Dynamic KPIs, charts, pivots, dashboards** — KPIs chosen from the actual data (records, totals, margin, status %,
  distinct entities), period-over-period comparison with partial-period handling, 15 chart types with
  recommendations, pivot with exact totals, auto-generated dashboards, drag/resize designer, cross-filtering,
  saved filter views, semantic templates that work across files with different column names.
* **AI layer** — provider abstraction for Anthropic Claude, OpenAI, Google Gemini and any OpenAI-compatible local
  LLM; insights, natural-language questions and reports are grounded in computed facts, AI numbers are validated,
  and everything falls back to deterministic analytics without a key.
* **Platform** — JWT auth with refresh rotation, organizations/workspaces, owner/admin/analyst/viewer roles,
  tenant isolation, API keys, audit log, usage metering and plan limits, Stripe-ready billing abstraction,
  connectors (HTTP JSON/CSV, Google Sheets link, SQL databases) with scheduled refresh, KPI alerts with in-app /
  email / webhook notifications, global search, backup/restore, CSV/Excel/PDF/HTML exports that respect filters.

## Repository

```
apps/web        React + TypeScript web app (also the PWA and the mobile/desktop UI)
apps/desktop    Windows launcher, PyInstaller spec, Inno Setup installer, build script
apps/mobile     Capacitor shell (Android project generated), same backend API
services/api    FastAPI service: misgenius/{ingestion,schema,cleaning,analytics,dashboard,ai,export,
                connectors,notifications,auth,billing,jobs,storage,services,api}, migrations, tests
packages/shared-types   OpenAPI contract (openapi.json) for typed clients
database/       migration notes and seed script
infrastructure/ Dockerfile, nginx, deployment notes
scripts/        start/LAN/dev/test/backup/firewall scripts
tests/e2e       real-browser end-to-end test
examples/       demo workbook (2 sheets + notes) and CSV
docs/           architecture, API, database, AI, security, deployment, Windows, LAN, cloud, mobile, dev, troubleshooting
```

## Verified

163 backend tests pass on SQLite **and** PostgreSQL 16; web app typechecks and builds; the Playwright browser
E2E test passes; the PyInstaller build was produced and exercised (start, migrate, upload, dashboard, PDF export);
production topology (PostgreSQL + external worker + plan limits) was run. See [docs/DEVELOPMENT.md](docs/DEVELOPMENT.md).

Documentation: [Architecture](docs/ARCHITECTURE.md) · [API](docs/API.md) · [Database](docs/DATABASE.md) · [AI](docs/AI.md) ·
[Security](docs/SECURITY.md) · [Deployment](docs/DEPLOYMENT.md) · [Windows](docs/WINDOWS.md) · [LAN](docs/LAN.md) ·
[Cloud](docs/CLOUD.md) · [Mobile](docs/MOBILE.md) · [Development](docs/DEVELOPMENT.md) · [Troubleshooting](docs/TROUBLESHOOTING.md)
