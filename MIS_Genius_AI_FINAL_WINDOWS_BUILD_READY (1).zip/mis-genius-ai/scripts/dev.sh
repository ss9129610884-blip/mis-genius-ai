#!/usr/bin/env bash
# Development: API with auto-reload on :8765 and Vite dev server on :5173 (proxying /api).
set -euo pipefail
cd "$(dirname "$0")/.."
(cd services/api && APP_ENV=development MIS_DATA_DIR=../../data python -m uvicorn misgenius.api.main:app --reload --port 8765) &
API=$!
trap "kill $API" EXIT
cd apps/web && npm run dev
