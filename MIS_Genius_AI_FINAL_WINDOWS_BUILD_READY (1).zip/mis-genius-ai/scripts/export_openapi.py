"""Writes the OpenAPI schema to packages/shared-types/openapi.json (source for typed API clients)."""
import json
import os
import sys
import tempfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "services" / "api"))
os.environ.setdefault("MIS_DATA_DIR", tempfile.mkdtemp())
os.environ.setdefault("SERVE_WEB", "false")
from misgenius.api.main import create_app  # noqa: E402

out = ROOT / "packages" / "shared-types" / "openapi.json"
out.parent.mkdir(parents=True, exist_ok=True)
out.write_text(json.dumps(create_app().openapi(), indent=1))
print("wrote", out)
