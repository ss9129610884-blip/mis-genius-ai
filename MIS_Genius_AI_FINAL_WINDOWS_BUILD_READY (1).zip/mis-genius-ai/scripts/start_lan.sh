#!/usr/bin/env bash
# Share MIS Genius AI on the office network: other PCs open http://<this-PC-IP>:8765
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f apps/web/dist/index.html ] || (cd apps/web && npm ci && npm run build)
cd services/api
export APP_ENV=lan MIS_DATA_DIR=${MIS_DATA_DIR:-$(pwd)/../../data} JOB_MODE=thread
echo "Other computers can open:"; hostname -I 2>/dev/null | tr ' ' '\n' | grep -v '^$' | sed "s/.*/  http:\/\/&:${PORT:-8765}/"
exec python -m uvicorn misgenius.api.main:app --host 0.0.0.0 --port "${PORT:-8765}"
