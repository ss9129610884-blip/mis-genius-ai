#!/usr/bin/env bash
# Start MIS Genius AI on this computer (localhost only). Data: ./data (override with MIS_DATA_DIR).
set -euo pipefail
cd "$(dirname "$0")/.."
[ -f apps/web/dist/index.html ] || (cd apps/web && npm ci && npm run build)
cd services/api
export APP_ENV=${APP_ENV:-local} MIS_DATA_DIR=${MIS_DATA_DIR:-$(pwd)/../../data} JOB_MODE=${JOB_MODE:-thread}
exec python -m uvicorn misgenius.api.main:app --host 127.0.0.1 --port "${PORT:-8765}"
