# Run as Administrator. Allows other PCs on private/domain networks to reach MIS Genius AI on TCP 8765.
param([int]$Port = 8765)
New-NetFirewallRule -DisplayName "MIS Genius AI" -Direction Inbound -Protocol TCP -LocalPort $Port -Action Allow -Profile Private,Domain | Out-Null
Write-Host "Firewall rule added for TCP $Port (private and domain networks only)."
Write-Host "Addresses other computers can use:"
Get-NetIPAddress -AddressFamily IPv4 | Where-Object { $_.IPAddress -notlike '127.*' -and $_.PrefixOrigin -ne 'WellKnown' } | ForEach-Object { "  http://$($_.IPAddress):$Port" }
