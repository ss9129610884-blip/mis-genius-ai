"""Full backup / restore of a local or LAN installation (SQLite database + stored files).

  python scripts/backup.py backup  --dest D:\\Backups
  python scripts/backup.py restore --file D:\\Backups\\mis-genius-backup-20260101-0900.zip [--force]

Set MIS_DATA_DIR if the data folder is not the default. PostgreSQL deployments use pg_dump
(see docs/DEPLOYMENT.md); per-organization backups are also available in Settings → Backup.
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "services" / "api"))

from misgenius.services.backup import full_local_backup, full_local_restore  # noqa: E402

p = argparse.ArgumentParser()
sub = p.add_subparsers(dest="cmd", required=True)
b = sub.add_parser("backup")
b.add_argument("--dest", default="backups")
r = sub.add_parser("restore")
r.add_argument("--file", required=True)
r.add_argument("--force", action="store_true")
a = p.parse_args()
if a.cmd == "backup":
    print("Backup written to", full_local_backup(Path(a.dest)))
else:
    full_local_restore(Path(a.file), force=a.force)
    print("Restored. Start MIS Genius AI again.")
