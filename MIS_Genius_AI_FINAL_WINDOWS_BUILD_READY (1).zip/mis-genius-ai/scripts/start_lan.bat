@echo off
REM Share MIS Genius AI on the office network. Run scripts\windows\open-firewall.ps1 once as Administrator.
call "%~dp0start_local.bat" --lan
