@echo off
REM Start MIS Genius AI from source on Windows (the installer is the easier option for end users).
cd /d %~dp0\..
if not exist apps\web\dist\index.html (cd apps\web && call npm ci && call npm run build && cd ..\..)
cd services\api
set APP_ENV=local
if "%MIS_DATA_DIR%"=="" set MIS_DATA_DIR=%LOCALAPPDATA%\MISGeniusAI
set JOB_MODE=thread
python ..\..\apps\desktop\launcher.py %*
