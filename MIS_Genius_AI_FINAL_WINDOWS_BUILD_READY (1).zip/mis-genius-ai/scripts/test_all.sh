#!/usr/bin/env bash
# Runs everything CI runs: backend tests (SQLite and, if TEST_DATABASE_URL is set, PostgreSQL), web build, browser E2E.
set -euo pipefail
cd "$(dirname "$0")/.."
(cd services/api && python -m pytest -q)
if [ -n "${TEST_DATABASE_URL:-}" ]; then (cd services/api && python -m pytest -q); fi
(cd apps/web && npm run build)
python tests/e2e/run_browser_e2e.py
