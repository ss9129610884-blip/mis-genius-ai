"""Browser end-to-end test (real Chromium via Playwright) against a freshly started server.

Flow: first-run setup → upload multi-sheet Excel → choose sheet → auto dashboard → apply filter →
KPI changes → evidence drawer → data explorer → AI question (English + Hindi) → report → mobile layout.

  pip install playwright && python -m playwright install chromium
  cd apps/web && npm run build && cd ../..
  python tests/e2e/run_browser_e2e.py [--shots DIR]
"""
from __future__ import annotations

import argparse
import os
import re
import socket
import subprocess
import sys
import tempfile
import time
import urllib.request
from pathlib import Path

from playwright.sync_api import expect, sync_playwright

ROOT = Path(__file__).resolve().parents[2]


def free_port() -> int:
    with socket.socket() as s:
        s.bind(("127.0.0.1", 0))
        return s.getsockname()[1]


def main() -> None:
    ap = argparse.ArgumentParser()
    ap.add_argument("--shots", default=None)
    args = ap.parse_args()
    shots = Path(args.shots) if args.shots else None
    if shots:
        shots.mkdir(parents=True, exist_ok=True)
    data = tempfile.mkdtemp(prefix="mis-e2e-")
    sys.path.insert(0, str(ROOT / "services" / "api"))
    from misgenius.demo.demo_data import write_examples

    xlsx = write_examples(Path(data) / "examples")[0]
    port = free_port()
    env = {**os.environ, "APP_ENV": "local", "MIS_DATA_DIR": data, "JOB_MODE": "thread", "LOG_JSON": "false"}
    srv = subprocess.Popen([sys.executable, "-m", "uvicorn", "misgenius.api.main:app", "--port", str(port)], cwd=ROOT / "services" / "api", env=env,
                           stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL)
    base = f"http://127.0.0.1:{port}"
    try:
        for _ in range(120):
            try:
                urllib.request.urlopen(base + "/api/v1/health", timeout=1)
                break
            except Exception:  # noqa: BLE001
                time.sleep(0.5)
        errors: list[str] = []
        with sync_playwright() as p:
            b = p.chromium.launch()
            page = b.new_page(viewport={"width": 1440, "height": 900})
            page.on("pageerror", lambda e: errors.append(str(e)))
            shot = lambda name: shots and page.screenshot(path=str(shots / f"{name}.png"), full_page=True)  # noqa: E731

            page.goto(base)
            page.wait_for_url(re.compile(r".*/setup$"))
            page.fill("input[autocomplete=name]", "E2E Owner")
            page.fill("input[placeholder='e.g. Sharma Traders']", "E2E Traders")
            page.fill("input[type=email]", "e2e@example.com")
            page.fill("input[type=password]", "E2ePassw0rd")
            page.click("button[type=submit]")
            page.wait_for_url(base + "/")

            page.set_input_files("input[type=file]", xlsx)
            expect(page.get_by_text("Choose the tables to analyse")).to_be_visible(timeout=30_000)
            shot("sheets")
            page.click(".sheet-card:has-text('Attendance')")
            page.click(".sheet-card:has-text('Sales')")
            page.click("button:has-text('Analyse selected')")
            page.wait_for_url(re.compile(r".*/dashboards/.*"), timeout=60_000)
            expect(page.locator(".kpi-title", has_text="Total Sales Amount")).to_be_visible(timeout=20_000)
            dash_url = page.url.split("?")[0]
            kpi = page.locator(".kpi:has(.kpi-title:text-is('Total Sales Amount')) .kpi-value")
            before = kpi.inner_text()
            shot("dashboard")

            page.click("button:has-text('Region')")
            page.click("label.check:has-text('North')")
            page.click("button:has-text('Done')")
            expect(page.get_by_text("Region: North")).to_be_visible()
            expect(kpi).not_to_have_text(before, timeout=15_000)
            assert "355 of 1,200" in page.inner_text("body"), "row counter did not update"

            page.locator(".kpi:has(.kpi-title:text-is('Total Sales Amount'))").get_by_text("How is this calculated?").click()
            expect(page.locator(".drawer pre")).to_contain_text("SUM(\"Sales Amount\")")
            page.keyboard.press("Escape")

            page.click("button[aria-label='More actions']")
            page.click("text=Open in data explorer")
            expect(page.get_by_text("Region: North")).to_be_visible()
            expect(page.get_by_text("355 rows")).to_be_visible(timeout=15_000)
            shot("explorer")

            page.goto(base + "/ask")
            page.fill("input[aria-label=Question]", "Which region has the highest revenue?")
            page.click("button:has-text('Ask')")
            expect(page.locator(".answer").first).to_contain_text("West has the highest", timeout=20_000)
            page.fill("input[aria-label=Question]", "पिछले महीने की तुलना में क्या बदला?")
            page.click("button:has-text('Ask')")
            expect(page.locator(".answer").nth(1)).to_contain_text("में", timeout=20_000)
            shot("ask")

            page.goto(base + "/reports")
            page.click("button:has-text('Generate report')")
            page.wait_for_url(re.compile(r".*/reports/.*"), timeout=30_000)
            expect(page.get_by_text("Executive Summary")).to_be_visible()

            m = b.new_page(viewport={"width": 390, "height": 844}, is_mobile=True)
            m.goto(base + "/login")
            m.fill("input[type=email]", "e2e@example.com")
            m.fill("input[type=password]", "E2ePassw0rd")
            m.click("button[type=submit]")
            m.wait_for_url(base + "/")
            m.goto(dash_url)
            expect(m.locator(".mobile-nav")).to_be_visible()
            expect(m.locator(".kpi-title").first).to_be_visible(timeout=20_000)
            if shots:
                m.screenshot(path=str(shots / "mobile.png"))
            b.close()
        if errors:
            raise SystemExit("Browser errors: " + "; ".join(errors))
        print("Browser E2E passed")
    finally:
        srv.terminate()


if __name__ == "__main__":
    main()
