import type { CapacitorConfig } from "@capacitor/cli";

// Two ways to run the mobile app (see docs/MOBILE.md):
//  1. Bundled UI  — the web build is packaged in the app and calls MIS_SERVER_URL (set at build time).
//  2. Remote UI   — set MIS_REMOTE_UI=1 to load the web app straight from the server (always up to date).
const server = process.env.MIS_SERVER_URL;

const config: CapacitorConfig = {
  appId: "ai.misgenius.app",
  appName: "MIS Genius AI",
  webDir: "../web/dist",
  backgroundColor: "#f3f5f8",
  server: process.env.MIS_REMOTE_UI && server ? { url: server, cleartext: server.startsWith("http://") } : { androidScheme: "https" },
  android: { allowMixedContent: false },
};

export default config;
