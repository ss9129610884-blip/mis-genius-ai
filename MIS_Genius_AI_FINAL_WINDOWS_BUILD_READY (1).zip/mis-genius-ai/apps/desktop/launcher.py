"""MIS Genius AI desktop launcher (Windows, also runs on Linux/macOS).

Double-click → starts the local server on 127.0.0.1, waits until it is healthy,
then opens the app in an app-style browser window (Edge/Chrome --app, else the
default browser). A small control window lets the user reopen or stop it.

Data lives in %LOCALAPPDATA%\\MISGeniusAI (Windows) — never inside Program Files —
so upgrades and uninstalls do not touch user data.

Flags:
  --lan          serve on all network interfaces (office LAN mode, see docs/LAN.md)
  --port N       preferred port (default 8765)
  --no-browser   do not open a browser (headless / service use)
  --no-window    no control window (used by services and tests)
"""
from __future__ import annotations

import argparse
import os
import shutil
import socket
import subprocess
import sys
import threading
import time
import urllib.request
import webbrowser
from pathlib import Path

APP = "MIS Genius AI"

# When launched directly from the source tree (or by a simple installer),
# make the backend package importable. A frozen PyInstaller build already
# bundles this package, so this is harmless there.
ROOT_DIR = Path(__file__).resolve().parents[2]
API_DIR = ROOT_DIR / "services" / "api"
if API_DIR.exists() and str(API_DIR) not in sys.path:
    sys.path.insert(0, str(API_DIR))


def data_dir() -> Path:
    if os.name == "nt":
        base = Path(os.environ.get("LOCALAPPDATA", Path.home() / "AppData" / "Local"))
    elif sys.platform == "darwin":
        base = Path.home() / "Library" / "Application Support"
    else:
        base = Path(os.environ.get("XDG_DATA_HOME", Path.home() / ".local" / "share"))
    d = base / "MISGeniusAI"
    d.mkdir(parents=True, exist_ok=True)
    return d


def port_free(host: str, port: int) -> bool:
    with socket.socket(socket.AF_INET, socket.SOCK_STREAM) as s:
        s.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        try:
            s.bind((host, port))
            return True
        except OSError:
            return False


def already_running(port: int) -> bool:
    try:
        with urllib.request.urlopen(f"http://127.0.0.1:{port}/api/v1/health", timeout=1.5) as r:
            return b"MIS" in r.read() or r.status == 200
    except Exception:  # noqa: BLE001
        return False


def pick_port(host: str, preferred: int) -> int:
    for p in [preferred] + list(range(preferred + 1, preferred + 50)):
        if port_free(host, p):
            return p
    with socket.socket() as s:
        s.bind((host, 0))
        return s.getsockname()[1]


def open_app_window(url: str) -> None:
    """Prefer a chrome-less app window; fall back to the default browser."""
    candidates = []
    if os.name == "nt":
        pf = [os.environ.get("PROGRAMFILES(X86)", ""), os.environ.get("PROGRAMFILES", ""), os.environ.get("LOCALAPPDATA", "")]
        for base in pf:
            if base:
                candidates += [Path(base) / "Microsoft/Edge/Application/msedge.exe", Path(base) / "Google/Chrome/Application/chrome.exe"]
    else:
        for name in ("microsoft-edge", "google-chrome", "chromium", "chromium-browser"):
            p = shutil.which(name)
            if p:
                candidates.append(Path(p))
    for exe in candidates:
        if exe.exists():
            try:
                subprocess.Popen([str(exe), f"--app={url}", "--new-window"], close_fds=True)
                return
            except OSError:
                continue
    webbrowser.open(url)


def lan_addresses() -> list[str]:
    out = set()
    try:
        with socket.socket(socket.AF_INET, socket.SOCK_DGRAM) as s:
            s.connect(("10.255.255.255", 1))
            out.add(s.getsockname()[0])
    except OSError:
        pass
    return sorted(a for a in out if not a.startswith("127."))


def main() -> None:
    ap = argparse.ArgumentParser(description=APP)
    ap.add_argument("--lan", action="store_true")
    ap.add_argument("--port", type=int, default=int(os.environ.get("PORT", 8765)))
    ap.add_argument("--no-browser", action="store_true")
    ap.add_argument("--no-window", action="store_true")
    args = ap.parse_args()

    host = "0.0.0.0" if args.lan else "127.0.0.1"
    if not args.lan and already_running(args.port):
        if not args.no_browser:
            open_app_window(f"http://127.0.0.1:{args.port}/")
        return

    ddir = data_dir()
    os.environ.setdefault("APP_ENV", "lan" if args.lan else "local")
    os.environ.setdefault("MIS_DATA_DIR", str(ddir))
    os.environ.setdefault("JOB_MODE", "thread")
    os.environ.setdefault("LOG_JSON", "true")
    env_file = ddir / "settings.env"  # optional user configuration (AI keys, SMTP, …)
    if env_file.exists():
        for line in env_file.read_text(encoding="utf-8").splitlines():
            if line.strip() and not line.strip().startswith("#") and "=" in line:
                k, v = line.split("=", 1)
                os.environ.setdefault(k.strip(), v.strip().strip('"'))

    port = pick_port(host, args.port)
    os.environ["PORT"] = str(port)
    os.environ["HOST"] = host

    import uvicorn

    from misgenius.api.main import create_app

    config = uvicorn.Config(create_app(), host=host, port=port, log_level="warning", access_log=False)
    server = uvicorn.Server(config)
    t = threading.Thread(target=server.run, daemon=True)
    t.start()

    url = f"http://127.0.0.1:{port}/"
    for _ in range(240):
        if already_running(port):
            break
        time.sleep(0.25)
    else:
        print("The server did not start. See the logs in", ddir / "logs")
        server.should_exit = True
        sys.exit(1)

    lan_urls = [f"http://{ip}:{port}/" for ip in lan_addresses()] if args.lan else []
    print(f"{APP} is running at {url}" + (f"  (LAN: {', '.join(lan_urls)})" if lan_urls else ""))
    print(f"Data folder: {ddir}")
    if not args.no_browser:
        open_app_window(url)

    if args.no_window:
        try:
            while t.is_alive():
                time.sleep(0.5)
        except KeyboardInterrupt:
            server.should_exit = True
        return
    control_window(server, url, ddir, lan_urls)


def control_window(server, url: str, ddir: Path, lan_urls: list[str]) -> None:
    try:
        import tkinter as tk
    except ImportError:
        try:
            while True:
                time.sleep(1)
        except KeyboardInterrupt:
            server.should_exit = True
        return
    root = tk.Tk()
    root.title(APP)
    root.geometry("420x220")
    root.resizable(False, False)
    tk.Label(root, text=f"{APP} is running", font=("Segoe UI", 13, "bold")).pack(pady=(16, 4))
    tk.Label(root, text=url, fg="#0E7A6D").pack()
    if lan_urls:
        tk.Label(root, text="Office network: " + ", ".join(lan_urls), fg="#4A5468").pack()
    tk.Label(root, text="Keep this window open while you use the app.", fg="#4A5468").pack(pady=(4, 10))
    row = tk.Frame(root)
    row.pack()
    tk.Button(row, text="Open MIS Genius AI", width=18, command=lambda: open_app_window(url)).pack(side="left", padx=4)
    tk.Button(row, text="Open data folder", width=16, command=lambda: _open_folder(ddir)).pack(side="left", padx=4)

    def stop() -> None:
        server.should_exit = True
        root.after(600, root.destroy)

    tk.Button(root, text="Stop and exit", width=18, command=stop).pack(pady=10)
    root.protocol("WM_DELETE_WINDOW", stop)
    root.mainloop()


def _open_folder(p: Path) -> None:
    if os.name == "nt":
        os.startfile(p)  # type: ignore[attr-defined]  # noqa: S606
    elif sys.platform == "darwin":
        subprocess.Popen(["open", str(p)])
    else:
        subprocess.Popen(["xdg-open", str(p)])


if __name__ == "__main__":
    main()
