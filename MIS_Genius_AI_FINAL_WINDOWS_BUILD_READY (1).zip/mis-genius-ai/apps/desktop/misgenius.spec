# PyInstaller spec — one-folder build (fast start, antivirus-friendly).
# Build:  pyinstaller --noconfirm apps/desktop/misgenius.spec   (run from the repository root)
# Output: dist/MISGeniusAI/MISGeniusAI(.exe)
import os
from pathlib import Path
from PyInstaller.utils.hooks import collect_data_files, collect_submodules

ROOT = Path(SPECPATH).resolve().parents[1]
API = ROOT / "services" / "api"
WEB = ROOT / "apps" / "web" / "dist"
if not (WEB / "index.html").exists():
    raise SystemExit("Build the web app first: cd apps/web && npm ci && npm run build")

datas = [
    (str(API / "migrations"), "migrations"),
    (str(WEB), "misgenius/web_dist"),
]
datas += collect_data_files("matplotlib", includes=["mpl-data/fonts/ttf/DejaVuSans*.ttf", "mpl-data/matplotlibrc"])
datas += collect_data_files("reportlab")
datas += collect_data_files("alembic")

hidden = (
    collect_submodules("misgenius")
    + collect_submodules("uvicorn")
    + ["duckdb", "pyarrow", "pyarrow.parquet", "openpyxl", "xlrd", "xlsxwriter", "defusedxml", "bcrypt", "jwt", "cryptography",
       "multipart", "python_multipart", "matplotlib.backends.backend_agg", "sqlalchemy.dialects.sqlite", "sqlalchemy.dialects.postgresql",
       "psycopg", "alembic.runtime.migration", "alembic.ddl.sqlite", "alembic.ddl.postgresql", "tkinter"]
)

icon = str(ROOT / "apps" / "web" / "public" / "icons" / "icon.ico")

a = Analysis(
    [str(ROOT / "apps" / "desktop" / "launcher.py")],
    pathex=[str(API)],
    datas=datas,
    hiddenimports=hidden,
    excludes=["pytest", "IPython", "notebook", "PyQt5", "PySide6", "scipy", "boto3"],
    noarchive=False,
)
pyz = PYZ(a.pure)
exe = EXE(
    pyz, a.scripts, [], exclude_binaries=True, name="MISGeniusAI", console=False,
    icon=icon if os.path.exists(icon) else None, version=None,
)
coll = COLLECT(exe, a.binaries, a.datas, name="MISGeniusAI")
