; Inno Setup script — builds MISGeniusAI-Setup-<version>.exe
; Compile with:  iscc /DAppVersion=1.0.0 apps\desktop\installer.iss   (after the PyInstaller build)
#ifndef AppVersion
  #define AppVersion "1.0.0"
#endif

[Setup]
AppId={{6F3C1C2B-8E2A-4E9B-9A57-4D1B7C0E5A11}
AppName=MIS Genius AI
AppVersion={#AppVersion}
AppPublisher=MIS Genius AI
DefaultDirName={autopf}\MIS Genius AI
DefaultGroupName=MIS Genius AI
DisableProgramGroupPage=yes
OutputDir=..\..\dist\installer
OutputBaseFilename=MISGeniusAI-Setup-{#AppVersion}
SetupIconFile=..\web\public\icons\icon.ico
UninstallDisplayIcon={app}\MISGeniusAI.exe
Compression=lzma2/max
SolidCompression=yes
ArchitecturesAllowed=x64compatible
ArchitecturesInstallIn64BitMode=x64compatible
MinVersion=10.0
PrivilegesRequiredOverridesAllowed=dialog
WizardStyle=modern

[Languages]
Name: "english"; MessagesFile: "compiler:Default.isl"

[Tasks]
Name: "desktopicon"; Description: "Create a &desktop shortcut"; GroupDescription: "Shortcuts:"
Name: "lanshortcut"; Description: "Add a shortcut to share on the office network (LAN mode)"; GroupDescription: "Shortcuts:"; Flags: unchecked
Name: "firewall"; Description: "Allow other computers on the office network to connect (Windows Firewall rule, port 8765)"; GroupDescription: "Office network:"; Flags: unchecked

[Files]
Source: "..\..\dist\MISGeniusAI\*"; DestDir: "{app}"; Flags: ignoreversion recursesubdirs createallsubdirs

[Icons]
Name: "{group}\MIS Genius AI"; Filename: "{app}\MISGeniusAI.exe"
Name: "{group}\MIS Genius AI (office network)"; Filename: "{app}\MISGeniusAI.exe"; Parameters: "--lan"; Tasks: lanshortcut
Name: "{group}\Uninstall MIS Genius AI"; Filename: "{uninstallexe}"
Name: "{autodesktop}\MIS Genius AI"; Filename: "{app}\MISGeniusAI.exe"; Tasks: desktopicon

[Run]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall add rule name=""MIS Genius AI"" dir=in action=allow protocol=TCP localport=8765 profile=private,domain"; Flags: runhidden; Tasks: firewall
Filename: "{app}\MISGeniusAI.exe"; Description: "Start MIS Genius AI"; Flags: nowait postinstall skipifsilent

[UninstallRun]
Filename: "{sys}\netsh.exe"; Parameters: "advfirewall firewall delete rule name=""MIS Genius AI"""; Flags: runhidden; RunOnceId: "RemoveFirewallRule"

; User data in %LOCALAPPDATA%\MISGeniusAI is intentionally NOT removed on uninstall.
