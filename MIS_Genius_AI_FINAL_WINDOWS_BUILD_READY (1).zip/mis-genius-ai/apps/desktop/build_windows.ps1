# Builds the Windows installer and portable ZIP.
# Needs (build machine only — end users need nothing): Python 3.11 x64, Node.js 20+, Inno Setup 6 (iscc on PATH).
# Usage (from repository root):  powershell -ExecutionPolicy Bypass -File apps\desktop\build_windows.ps1
$ErrorActionPreference = "Stop"
$Root = Resolve-Path "$PSScriptRoot\..\.."
Set-Location $Root
$Version = (Get-Content services\api\misgenius\config.py | Select-String 'APP_VERSION: str = "(.*)"').Matches[0].Groups[1].Value

Write-Host "==> Building web app"
Push-Location apps\web
npm ci
npm run build
Pop-Location

Write-Host "==> Creating isolated Python build environment"
py -3.11 -m venv .build-venv
.\.build-venv\Scripts\python -m pip install --upgrade pip
# prebuilt wheels only — no Visual Studio Build Tools required
.\.build-venv\Scripts\python -m pip install --only-binary=:all: -r services\api\requirements.txt pyinstaller==6.22.3

Write-Host "==> Running tests"
.\.build-venv\Scripts\python -m pip install --only-binary=:all: pytest==9.1.1
Push-Location services\api
..\..\.build-venv\Scripts\python -m pytest -q
Pop-Location

Write-Host "==> Freezing application"
.\.build-venv\Scripts\pyinstaller --noconfirm --clean apps\desktop\misgenius.spec

Write-Host "==> Portable ZIP"
New-Item -ItemType Directory -Force -Path dist\installer | Out-Null
Compress-Archive -Path dist\MISGeniusAI\* -DestinationPath "dist\installer\MISGeniusAI-Portable-$Version.zip" -Force

Write-Host "==> Installer"
iscc /DAppVersion=$Version apps\desktop\installer.iss
Write-Host "Done: dist\installer"
