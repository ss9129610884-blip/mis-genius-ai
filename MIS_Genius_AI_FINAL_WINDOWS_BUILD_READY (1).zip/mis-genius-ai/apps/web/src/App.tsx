import type { ReactElement } from "react";
import { Navigate, Route, Routes, useLocation, useParams } from "react-router-dom";
import { useAuth } from "./lib/auth";
import { AppShell } from "./components/AppShell";
import { Loading } from "./components/ui";
import { LoginPage, RegisterPage } from "./pages/Auth";
import { HomePage } from "./pages/Home";
import { DashboardView } from "./pages/DashboardView";
import { DatasetDetail, DatasetsPage } from "./pages/Datasets";
import { AskPage, DashboardsPage, ReportView, ReportsPage, TemplatesPage, UploadPage } from "./pages/Workspace";
import { SettingsPage, SourcesPage } from "./pages/Settings";

function Protected({ children }: { children: ReactElement }) {
  const { ready, user } = useAuth();
  const loc = useLocation();
  if (!ready) return <Loading label="Starting MIS Genius AI…" />;
  if (!user) return <Navigate to="/login" replace state={{ from: loc.pathname }} />;
  return children;
}

function ReportRoute() {
  const { id = "" } = useParams();
  return <ReportView id={id} />;
}

function NotFound() {
  return <div className="empty"><h3>Page not found</h3><p className="muted">The link may be old or the item was deleted.</p><a className="btn" href="/">Go home</a></div>;
}

export default function App() {
  const { ready } = useAuth();
  if (!ready) return <Loading label="Starting MIS Genius AI…" />;
  return (
    <Routes>
      <Route path="/login" element={<LoginPage />} />
      <Route path="/register" element={<RegisterPage />} />
      <Route path="/setup" element={<RegisterPage firstRun />} />
      <Route element={<Protected><AppShell /></Protected>}>
        <Route index element={<HomePage />} />
        <Route path="upload" element={<UploadPage />} />
        <Route path="datasets" element={<DatasetsPage />} />
        <Route path="datasets/:id" element={<DatasetDetail />} />
        <Route path="dashboards" element={<DashboardsPage />} />
        <Route path="dashboards/:id" element={<DashboardView />} />
        <Route path="ask" element={<AskPage />} />
        <Route path="reports" element={<ReportsPage />} />
        <Route path="reports/:id" element={<ReportRoute />} />
        <Route path="templates" element={<TemplatesPage />} />
        <Route path="sources" element={<SourcesPage />} />
        <Route path="settings" element={<SettingsPage />} />
        <Route path="*" element={<NotFound />} />
      </Route>
    </Routes>
  );
}
