import { useState } from "react";
import { useNavigate, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Copy, Download, KeyRound, Link2, Plus, Trash2, Upload } from "lucide-react";
import { api, download, pollJob } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { errMsg, useTheme, useToast } from "../lib/ui";
import { relTime } from "../lib/format";
import { ErrorBox, Loading, Spinner, Tabs } from "../components/ui";

type Tab = "profile" | "organization" | "members" | "ai" | "plan" | "apikeys" | "audit" | "backup";

export function SettingsPage() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [sp, setSp] = useSearchParams();
  const tab = (sp.get("tab") as Tab) || "profile";
  const tabs: { id: Tab; label: string; show: boolean }[] = [
    { id: "profile", label: "Profile", show: true },
    { id: "organization", label: "Organization", show: true },
    { id: "members", label: "Members & workspaces", show: true },
    { id: "ai", label: "AI provider", show: can("settings.manage") },
    { id: "plan", label: "Plan & usage", show: true },
    { id: "apikeys", label: "API keys", show: can("apikeys.manage") },
    { id: "audit", label: "Audit log", show: can("audit.read") },
    { id: "backup", label: "Backup", show: can("backup.manage") },
  ];
  return (
    <div style={{ maxWidth: 1100 }}>
      <div className="page-head"><div><h1>{t("settings.title")}</h1></div></div>
      <Tabs<Tab> value={tab} onChange={(x) => setSp({ tab: x })} tabs={tabs.filter((x) => x.show)} />
      {tab === "profile" && <Profile />}
      {tab === "organization" && <Organization />}
      {tab === "members" && <Members />}
      {tab === "ai" && <AISettings />}
      {tab === "plan" && <Plan />}
      {tab === "apikeys" && <ApiKeys />}
      {tab === "audit" && <Audit />}
      {tab === "backup" && <Backup />}
    </div>
  );
}

function Profile() {
  const { user, reload } = useAuth();
  const { lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const toast = useToast();
  const [name, setName] = useState(user?.full_name ?? "");
  const [pw, setPw] = useState({ current_password: "", new_password: "" });
  const save = useMutation({ mutationFn: () => api.patch("/auth/me", { full_name: name, language: lang }), onSuccess: () => { reload(); toast.show("Profile saved"); } });
  const change = useMutation({ mutationFn: () => api.post("/auth/change-password", pw), onSuccess: () => { setPw({ current_password: "", new_password: "" }); toast.show("Password changed. Other sessions were signed out."); } });
  return (
    <div className="grid-2" style={{ alignItems: "start" }}>
      <div className="panel panel-body stack-4">
        <h3>Profile</h3>
        <label className="field"><span>Name</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label>
        <label className="field"><span>Email</span><input className="input" value={user?.email ?? ""} disabled /></label>
        <label className="field"><span>Language</span><select className="input" value={lang} onChange={(e) => setLang(e.target.value as "en" | "hi")}><option value="en">English</option><option value="hi">हिन्दी</option></select></label>
        <label className="field"><span>Theme</span><select className="input" value={theme} onChange={(e) => setTheme(e.target.value as any)}><option value="system">Match system</option><option value="light">Light</option><option value="dark">Dark</option></select></label>
        <button className="btn primary" onClick={() => save.mutate()}>Save</button>
      </div>
      <div className="panel panel-body stack-4">
        <h3>Change password</h3>
        {change.error && <ErrorBox error={change.error} />}
        <label className="field"><span>Current password</span><input className="input" type="password" autoComplete="current-password" value={pw.current_password} onChange={(e) => setPw({ ...pw, current_password: e.target.value })} /></label>
        <label className="field"><span>New password</span><input className="input" type="password" autoComplete="new-password" value={pw.new_password} onChange={(e) => setPw({ ...pw, new_password: e.target.value })} /></label>
        <button className="btn" disabled={!pw.current_password || pw.new_password.length < 8} onClick={() => change.mutate()}>Change password</button>
      </div>
    </div>
  );
}

function Organization() {
  const { org, can, reload } = useAuth();
  const toast = useToast();
  const nav = useNavigate();
  const [f, setF] = useState({ name: org?.name ?? "", currency: org?.settings?.currency ?? "INR", locale: org?.settings?.locale ?? "en-IN", fiscal: String(org?.settings?.fiscal_year_start_month ?? 4) });
  const [newOrg, setNewOrg] = useState("");
  const save = useMutation({ mutationFn: () => api.patch("/orgs/current", { name: f.name, settings: { currency: f.currency, locale: f.locale, fiscal_year_start_month: Number(f.fiscal) } }),
    onSuccess: () => { reload(); toast.show("Organization saved"); }, onError: (e) => toast.show(errMsg(e), "error") });
  const create = useMutation({ mutationFn: () => api.post("/orgs", { name: newOrg }), onSuccess: async () => { await reload(); toast.show("Organization created — switch to it from the top bar."); setNewOrg(""); nav("/"); } });
  const editable = can("settings.manage");
  return (
    <div className="grid-2" style={{ alignItems: "start" }}>
      <div className="panel panel-body stack-4">
        <h3>{org?.name}</h3>
        <label className="field"><span>Name</span><input className="input" value={f.name} disabled={!editable} onChange={(e) => setF({ ...f, name: e.target.value })} /></label>
        <div className="form-grid">
          <label className="field"><span>Currency shown</span><select className="input" disabled={!editable} value={f.currency} onChange={(e) => setF({ ...f, currency: e.target.value })}>{["INR", "USD", "EUR", "GBP", "AED", "SAR"].map((c) => <option key={c}>{c}</option>)}</select></label>
          <label className="field"><span>Number style</span><select className="input" disabled={!editable} value={f.locale} onChange={(e) => setF({ ...f, locale: e.target.value })}><option value="en-IN">Indian (1,00,000 · L · Cr)</option><option value="en-US">International (100,000 · K · M)</option></select></label>
          <label className="field"><span>Financial year starts</span><select className="input" disabled={!editable} value={f.fiscal} onChange={(e) => setF({ ...f, fiscal: e.target.value })}>{["1", "4", "7", "10"].map((m) => <option key={m} value={m}>{["", "January", "", "", "April", "", "", "July", "", "", "October"][Number(m)]}</option>)}</select></label>
        </div>
        <p className="subtle">Currency only changes how amounts are displayed; values are never converted.</p>
        {editable && <button className="btn primary" onClick={() => save.mutate()}>Save</button>}
      </div>
      <div className="panel panel-body stack-4">
        <h3>Another organization</h3>
        <p className="muted small">Keep a separate set of datasets, members and settings — for example a second company or department. Data never mixes between organizations.</p>
        <div className="row"><input className="input" placeholder="Organization name" value={newOrg} onChange={(e) => setNewOrg(e.target.value)} /><button className="btn" disabled={!newOrg || create.isPending} onClick={() => create.mutate()}><Plus />Create</button></div>
      </div>
    </div>
  );
}

function Members() {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const members = useQuery({ queryKey: ["members"], queryFn: () => api.get("/orgs/current/members") });
  const ws = useQuery({ queryKey: ["workspaces"], queryFn: () => api.get("/workspaces") });
  const [f, setF] = useState({ email: "", role: "viewer", full_name: "", password: "" });
  const [wsName, setWsName] = useState("");
  const add = useMutation({ mutationFn: () => api.post("/orgs/current/members", { ...f, password: f.password || null }), onSuccess: () => { qc.invalidateQueries({ queryKey: ["members"] }); setF({ email: "", role: "viewer", full_name: "", password: "" }); toast.show("Member added"); }, onError: (e) => toast.show(errMsg(e), "error") });
  const manage = can("members.manage");
  return (
    <div className="stack-5">
      <div className="table-wrap"><table className="data">
        <thead><tr><th>Name</th><th>Email</th><th>Role</th><th>Last sign-in</th><th /></tr></thead>
        <tbody>{members.data?.map((m: any) => (
          <tr key={m.membership_id}><td>{m.full_name || "—"}</td><td>{m.email}</td>
            <td>{manage ? <select className="input small" style={{ width: 120 }} value={m.role} onChange={async (e) => { try { await api.patch(`/orgs/current/members/${m.membership_id}`, { role: e.target.value }); qc.invalidateQueries({ queryKey: ["members"] }); } catch (x) { toast.show(errMsg(x), "error"); } }}>
              {["owner", "admin", "analyst", "viewer"].map((r) => <option key={r}>{r}</option>)}</select> : m.role}</td>
            <td>{relTime(m.last_login_at) || "never"}</td>
            <td className="n">{manage && <button className="btn ghost icon small" aria-label={`Remove ${m.email}`} onClick={async () => { if (confirm(`Remove ${m.email} from this organization?`)) { try { await api.del(`/orgs/current/members/${m.membership_id}`); qc.invalidateQueries({ queryKey: ["members"] }); } catch (x) { toast.show(errMsg(x), "error"); } } }}><Trash2 /></button>}</td></tr>
        ))}</tbody></table></div>
      <p className="subtle">Owner: everything incl. billing · Admin: members, settings, AI, audit, deletion · Analyst: upload, clean, build dashboards and reports · Viewer: view, filter, ask and export.</p>
      {manage && (
        <div className="panel panel-body stack-4">
          <h3>Add a member</h3>
          <div className="form-grid">
            <label className="field"><span>Email</span><input className="input" type="email" value={f.email} onChange={(e) => setF({ ...f, email: e.target.value })} /></label>
            <label className="field"><span>Name</span><input className="input" value={f.full_name} onChange={(e) => setF({ ...f, full_name: e.target.value })} /></label>
            <label className="field"><span>Role</span><select className="input" value={f.role} onChange={(e) => setF({ ...f, role: e.target.value })}>{["viewer", "analyst", "admin", "owner"].map((r) => <option key={r}>{r}</option>)}</select></label>
            <label className="field"><span>Initial password</span><input className="input" type="password" value={f.password} onChange={(e) => setF({ ...f, password: e.target.value })} /><span className="hint">Needed only if they don't have an account yet.</span></label>
          </div>
          <button className="btn primary" disabled={!f.email || add.isPending} onClick={() => add.mutate()}><Plus />Add member</button>
        </div>
      )}
      <div className="panel panel-body stack-4">
        <h3>Workspaces</h3>
        <div className="row wrap">{ws.data?.map((w: any) => <span key={w.id} className="badge">{w.name}</span>)}</div>
        {can("dashboard.write") && <div className="row"><input className="input" placeholder="New workspace, e.g. Finance" value={wsName} onChange={(e) => setWsName(e.target.value)} />
          <button className="btn" disabled={!wsName} onClick={async () => { await api.post("/workspaces", { name: wsName }); setWsName(""); qc.invalidateQueries({ queryKey: ["workspaces"] }); }}><Plus />Add</button></div>}
      </div>
    </div>
  );
}

function AISettings() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["ai-settings"], queryFn: () => api.get("/settings/ai") });
  const [f, setF] = useState<any>(null);
  const cur = f ?? (q.data ? { provider: q.data.provider, model: q.data.model ?? "", base_url: q.data.base_url ?? "", api_key: "", enabled: q.data.enabled } : null);
  const save = useMutation({ mutationFn: () => api.put("/settings/ai", { ...cur, model: cur.model || null, base_url: cur.base_url || null, api_key: cur.api_key || null }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["ai-settings"] }); qc.invalidateQueries({ queryKey: ["ai-status"] }); setF(null); toast.show("AI settings saved"); }, onError: (e) => toast.show(errMsg(e), "error") });
  const test = useMutation({ mutationFn: () => api.post("/settings/ai/test") });
  if (q.isLoading || !cur) return <Loading />;
  const set = (k: string, v: unknown) => setF({ ...cur, [k]: v });
  return (
    <div className="grid-2" style={{ alignItems: "start" }}>
      <div className="panel panel-body stack-4">
        <h3>AI provider</h3>
        <p className="muted small">MIS Genius AI works fully without AI: KPIs, charts, insights and question answering are computed from your data. A provider adds natural-language narratives and a smarter question planner. Keys are encrypted on the server and never sent to the browser.</p>
        <label className="field"><span>Provider</span>
          <select className="input" value={cur.provider} onChange={(e) => set("provider", e.target.value)}>
            <option value="none">None — deterministic analytics only</option><option value="anthropic">Anthropic Claude</option><option value="openai">OpenAI</option>
            <option value="gemini">Google Gemini</option><option value="openai_compatible">Local / OpenAI-compatible (Ollama, LM Studio, vLLM)</option>
          </select></label>
        {cur.provider !== "none" && <>
          <label className="field"><span>Model</span><input className="input" value={cur.model} onChange={(e) => set("model", e.target.value)} placeholder={{ anthropic: "claude-sonnet-5", openai: "gpt-4.1-mini", gemini: "gemini-2.5-flash", openai_compatible: "llama3.1" }[cur.provider as string]} /></label>
          {cur.provider === "openai_compatible" && <label className="field"><span>Base URL</span><input className="input" value={cur.base_url} onChange={(e) => set("base_url", e.target.value)} placeholder="http://localhost:11434/v1" /></label>}
          <label className="field"><span>API key {q.data.api_key_hint && <span className="subtle">(saved: {q.data.api_key_hint})</span>}</span>
            <input className="input" type="password" autoComplete="off" value={cur.api_key} onChange={(e) => set("api_key", e.target.value)} placeholder={q.data.has_api_key ? "Leave blank to keep the saved key" : "Paste the key"} /></label>
          <label className="check"><input type="checkbox" checked={cur.enabled} onChange={(e) => set("enabled", e.target.checked)} />Enabled</label>
        </>}
        <div className="row">
          <button className="btn primary" onClick={() => save.mutate()} disabled={save.isPending}>Save</button>
          <button className="btn" onClick={() => test.mutate()} disabled={test.isPending}>{test.isPending && <Spinner />}Test connection</button>
          {q.data.has_api_key && <button className="btn ghost" onClick={() => { setF({ ...cur }); api.put("/settings/ai", { ...cur, api_key: null, clear_api_key: true }).then(() => qc.invalidateQueries({ queryKey: ["ai-settings"] })); }}>Remove saved key</button>}
        </div>
        {test.data && <div className={test.data.ok ? "note" : "error-box"}>{test.data.message}</div>}
      </div>
      <div className="panel panel-body stack-4">
        <h3>How AI output is kept honest</h3>
        <ul className="insight-list">
          <li><KeyRound /><span>The analytics engine computes every number first. The AI only receives those computed facts, never raw rows.</span></li>
          <li><KeyRound /><span>Each AI sentence must cite the facts it uses. Any number that does not match a computed value is rejected.</span></li>
          <li><KeyRound /><span>If the provider is down, slow, or its answer fails validation, the computed insights are shown instead.</span></li>
          <li><KeyRound /><span>Questions are turned into a structured plan that is checked against the dataset's columns before it runs.</span></li>
        </ul>
        <p className="subtle">Source now: {q.data.source === "organization" ? "organization setting" : `server environment (${q.data.environment.provider})`}.</p>
      </div>
    </div>
  );
}

function Plan() {
  const { can, reload } = useAuth();
  const toast = useToast();
  const usage = useQuery({ queryKey: ["usage"], queryFn: () => api.get("/billing/usage") });
  const plans = useQuery({ queryKey: ["plans"], queryFn: () => api.get("/billing/plans") });
  if (usage.isLoading || plans.isLoading) return <Loading />;
  const u = usage.data;
  const rows: [string, string][] = [["datasets", "Datasets"], ["dashboards", "Dashboards"], ["users", "Members"], ["ai_requests_month", "AI requests this month"], ["storage_mb", "Storage (MB)"], ["api_calls_day", "API calls today"]];
  const choose = async (key: string) => {
    try {
      if (u.payment_provider === "stripe") {
        const r = await api.post("/billing/checkout", { plan: key, success_url: location.href, cancel_url: location.href });
        location.href = r.url;
      } else {
        await api.put("/billing/plan", { plan: key });
        await reload();
        usage.refetch();
        toast.show(`Plan changed to ${key}`);
      }
    } catch (e) { toast.show(errMsg(e), "error"); }
  };
  return (
    <div className="stack-5">
      <div className="panel panel-body">
        <h3>{u.plan.name} plan {!u.enforced && <span className="badge accent">limits not enforced on this installation</span>}</h3>
        <div className="grid-3" style={{ marginTop: 16 }}>
          {rows.map(([k, label]) => {
            const lim = u.plan[k];
            const used = u.used[k] ?? 0;
            return (
              <div key={k}>
                <div className="row between small"><span>{label}</span><span className="num">{Number(used).toLocaleString("en-IN")}{lim ? ` / ${lim.toLocaleString("en-IN")}` : ""}</span></div>
                <div className="bar-meter" style={{ marginTop: 6 }}><span style={{ width: lim ? `${Math.min(100, (used / lim) * 100)}%` : "0%" }} /></div>
              </div>
            );
          })}
        </div>
      </div>
      <div className="grid-auto">
        {plans.data.map((p: any) => (
          <div key={p.key} className="list-card">
            <div className="row between"><h3>{p.name}</h3>{u.plan.key === p.key && <span className="badge accent">current</span>}</div>
            <strong className="num" style={{ fontSize: 22 }}>{p.price_inr_month === null ? "Custom" : p.price_inr_month === 0 ? "Free" : `₹${p.price_inr_month.toLocaleString("en-IN")}/mo`}</strong>
            <ul className="small muted" style={{ margin: 0, paddingLeft: 18 }}>
              <li>{p.datasets ?? "Unlimited"} datasets · {p.dashboards ?? "unlimited"} dashboards</li>
              <li>{p.users ?? "Unlimited"} members · files up to {p.max_file_mb ?? "server limit"} MB</li>
              <li>{p.ai_requests_month?.toLocaleString("en-IN") ?? "Unlimited"} AI requests / month</li>
            </ul>
            {can("billing.manage") && u.plan.key !== p.key && <button className="btn small" onClick={() => choose(p.key)}>Switch to {p.name}</button>}
          </div>
        ))}
      </div>
    </div>
  );
}

function ApiKeys() {
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["apikeys"], queryFn: () => api.get("/api-keys") });
  const [name, setName] = useState("");
  const [role, setRole] = useState("viewer");
  const [created, setCreated] = useState<any>(null);
  const create = useMutation({ mutationFn: () => api.post("/api-keys", { name, role }), onSuccess: (r) => { setCreated(r); setName(""); qc.invalidateQueries({ queryKey: ["apikeys"] }); } });
  return (
    <div className="stack-4">
      <p className="muted">Use API keys for scripts and integrations: send the key in the <code>X-API-Key</code> header. Full API reference: <a href="/api/docs" target="_blank" rel="noreferrer">/api/docs</a>.</p>
      {created && <div className="note stack-4"><strong>Copy this key now — it will not be shown again.</strong>
        <div className="row"><code style={{ wordBreak: "break-all" }}>{created.key}</code><button className="btn small" onClick={() => { navigator.clipboard.writeText(created.key); toast.show("Copied"); }}><Copy />Copy</button></div></div>}
      <div className="row wrap">
        <input className="input" style={{ maxWidth: 260 }} placeholder="Key name, e.g. Power BI refresh" value={name} onChange={(e) => setName(e.target.value)} />
        <select className="input" style={{ width: 140 }} value={role} onChange={(e) => setRole(e.target.value)}><option value="viewer">viewer</option><option value="analyst">analyst</option><option value="admin">admin</option></select>
        <button className="btn primary" disabled={!name} onClick={() => create.mutate()}><Plus />Create key</button>
      </div>
      <div className="table-wrap"><table className="data"><thead><tr><th>Name</th><th>Key</th><th>Role</th><th>Created</th><th>Last used</th><th /></tr></thead>
        <tbody>{q.data?.map((k: any) => <tr key={k.id} style={{ opacity: k.revoked ? 0.5 : 1 }}><td>{k.name}</td><td><code>{k.prefix}…</code></td><td>{k.role}</td><td>{relTime(k.created_at)}</td><td>{relTime(k.last_used_at) || "never"}</td>
          <td className="n">{!k.revoked ? <button className="btn small danger" onClick={async () => { await api.del(`/api-keys/${k.id}`); qc.invalidateQueries({ queryKey: ["apikeys"] }); }}>Revoke</button> : "revoked"}</td></tr>)}</tbody></table></div>
    </div>
  );
}

function Audit() {
  const [page, setPage] = useState(0);
  const [action, setAction] = useState("");
  const q = useQuery({ queryKey: ["audit", page, action], queryFn: () => api.get(`/audit?limit=50&offset=${page * 50}${action ? `&action=${encodeURIComponent(action)}` : ""}`) });
  return (
    <div className="stack-4">
      <div className="row"><input className="input" style={{ maxWidth: 260 }} placeholder="Filter by action, e.g. export" value={action} onChange={(e) => { setAction(e.target.value); setPage(0); }} /><span className="subtle">{q.data?.total ?? 0} events</span></div>
      <div className="table-wrap"><table className="data"><thead><tr><th>When</th><th>User</th><th>Action</th><th>Details</th><th>IP</th></tr></thead>
        <tbody>{q.data?.items.map((a: any) => <tr key={a.id}><td className="nowrap">{new Date(a.created_at).toLocaleString("en-IN")}</td><td>{a.user ?? "system"}</td><td><code>{a.action}</code></td>
          <td className="small" style={{ maxWidth: 420 }}>{Object.entries(a.details ?? {}).map(([k, v]) => `${k}: ${typeof v === "object" ? JSON.stringify(v) : v}`).join(" · ")}</td><td className="small">{a.ip}</td></tr>)}</tbody></table></div>
      <div className="row"><button className="btn small" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Newer</button><button className="btn small" disabled={(q.data?.items.length ?? 0) < 50} onClick={() => setPage((p) => p + 1)}>Older</button></div>
    </div>
  );
}

function Backup() {
  const toast = useToast();
  const qc = useQueryClient();
  const [busy, setBusy] = useState(false);
  const imp = async (f: File) => {
    setBusy(true);
    const form = new FormData();
    form.append("file", f);
    try { const r = await api.upload("/backup/import", form); qc.invalidateQueries(); toast.show(`Imported ${r.datasets} datasets, ${r.dashboards} dashboards, ${r.templates} templates, ${r.reports} reports`); }
    catch (e) { toast.show(errMsg(e), "error"); } finally { setBusy(false); }
  };
  return (
    <div className="grid-2" style={{ alignItems: "start" }}>
      <div className="panel panel-body stack-4">
        <h3>Export organization backup</h3>
        <p className="muted small">A ZIP with dashboards, templates, reports and every dataset's data. Import it into any MIS Genius AI installation — for example to move from the desktop app to the cloud.</p>
        <div className="row">
          <button className="btn primary" onClick={() => download("/backup/export?include_data=true", { method: "POST" }, "backup.zip").catch((e) => toast.show(errMsg(e), "error"))}><Download />With data</button>
          <button className="btn" onClick={() => download("/backup/export?include_data=false", { method: "POST" }, "backup.zip").catch((e) => toast.show(errMsg(e), "error"))}>Configuration only</button>
        </div>
        <p className="subtle">Full-installation backups (database + files) are made with <code>scripts/backup.py</code>; see the documentation.</p>
      </div>
      <div className="panel panel-body stack-4">
        <h3>Import a backup</h3>
        <p className="muted small">Imported items are added next to what you have; nothing existing is replaced or deleted.</p>
        <label className="btn">{busy ? <Spinner /> : <Upload />}Choose backup ZIP<input type="file" accept=".zip" hidden onChange={(e) => e.target.files?.[0] && imp(e.target.files[0])} /></label>
      </div>
    </div>
  );
}

// ---------------------------------------------------------------- data sources
export function SourcesPage() {
  const { can } = useAuth();
  const nav = useNavigate();
  const toast = useToast();
  const q = useQuery({ queryKey: ["connectors"], queryFn: () => api.get("/connectors") });
  const [type, setType] = useState("google_sheets");
  const [cfg, setCfg] = useState<Record<string, string>>({});
  const [name, setName] = useState("");
  const [refresh, setRefresh] = useState("");
  const [tested, setTested] = useState<any>(null);
  const conn = q.data?.available.find((c: any) => c.type === type);
  const config = () => {
    const out: Record<string, unknown> = { ...cfg };
    if (typeof out.headers === "string" && out.headers) { try { out.headers = JSON.parse(out.headers as string); } catch { throw new Error("Headers must be valid JSON"); } }
    return out;
  };
  const test = useMutation({ mutationFn: () => api.post("/connectors/test", { type, config: config() }), onSuccess: setTested, onError: (e) => { setTested(null); toast.show(errMsg(e), "error"); } });
  const imp = useMutation({
    mutationFn: async () => { const r = await api.post("/datasets/from-connector", { type, config: config(), name: name || "Imported data", refresh_minutes: refresh ? Number(refresh) : null });
      const j = r.job.status === "done" || r.job.status === "failed" ? r.job : await pollJob(r.job.id); if (j.status === "failed") throw new Error(j.error); return j; },
    onSuccess: (j) => nav(`/dashboards/${j.result.dashboard_id}`),
    onError: (e) => toast.show(errMsg(e), "error"),
  });
  if (q.isLoading) return <Loading />;
  return (
    <div style={{ maxWidth: 1000 }}>
      <div className="page-head"><div><h1>Data sources</h1><p>Bring data in from a file, a web URL, a shared Google Sheet or a database. Connected sources can refresh on a schedule; each refresh creates a new version.</p></div></div>
      <div className="grid-2" style={{ alignItems: "start" }}>
        <div className="panel panel-body stack-4">
          <label className="field"><span>Source</span>
            <select className="input" value={type} onChange={(e) => { setType(e.target.value); setCfg({}); setTested(null); if (e.target.value === "file") nav("/upload"); }}>
              {q.data.available.map((c: any) => <option key={c.type} value={c.type} disabled={c.admin_only && !can("connector.manage")}>{c.label}{c.admin_only ? " (admins)" : ""}</option>)}
            </select></label>
          {conn?.description && <p className="muted small">{conn.description}</p>}
          {conn?.fields?.map((f: any) => (
            <label key={f.name} className="field"><span>{f.label}</span>
              {f.type === "textarea" || f.type === "json" ? <textarea className="input" rows={f.type === "json" ? 3 : 5} value={cfg[f.name] ?? ""} onChange={(e) => setCfg({ ...cfg, [f.name]: e.target.value })} placeholder={f.type === "json" ? '{"Authorization": "Bearer …"}' : "SELECT …"} />
                : <input className="input" type={f.type === "secret" ? "password" : "text"} value={cfg[f.name] ?? ""} onChange={(e) => setCfg({ ...cfg, [f.name]: e.target.value })} placeholder={f.placeholder ?? (f.type === "url" ? "https://…" : "")} />}
            </label>
          ))}
          <div className="form-grid">
            <label className="field"><span>Dataset name</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label>
            <label className="field"><span>Refresh every (minutes)</span><input className="input" type="number" min={15} value={refresh} onChange={(e) => setRefresh(e.target.value)} placeholder="Off" /></label>
          </div>
          <div className="row">
            <button className="btn" onClick={() => test.mutate()} disabled={test.isPending}>{test.isPending ? <Spinner /> : <Link2 />}Test</button>
            <button className="btn primary" onClick={() => imp.mutate()} disabled={imp.isPending || !can("data.write")}>{imp.isPending && <Spinner />}Import and build dashboard</button>
          </div>
          {tested && <div className="note">Connected: {tested.sheets.map((s: any) => `${s.name} (${Math.max(0, s.rows - 1).toLocaleString("en-IN")} rows)`).join(", ")}</div>}
          <p className="subtle">Credentials are encrypted on the server. Private network addresses are blocked on cloud installations.</p>
        </div>
        <div className="panel panel-body stack-4">
          <h3>Coming later</h3>
          <p className="muted small">These integrations are designed for but not included yet — they are shown so you know what is planned.</p>
          <ul className="insight-list">{q.data.planned.map((p: any) => <li key={p.type}><Link2 /><span>{p.label}</span></li>)}</ul>
        </div>
      </div>
    </div>
  );
}
