import { useMemo, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowDown, ArrowUp, ChevronDown, Columns3, Download, Eye, EyeOff, LayoutDashboard, Play, Plus, RefreshCw, Sparkles, Trash2, Wand2 } from "lucide-react";
import { api, download, pollJob } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { errMsg, useToast } from "../lib/ui";
import { formatCell, relTime } from "../lib/format";
import type { ColumnInfo, Dataset, Dimension, Filter, Measure, Quality, Schema } from "../lib/types";
import { FilterBar, type ActiveFilters } from "../components/FilterBar";
import { QualitySummary } from "../components/Insights";
import { PivotView } from "../components/DataViews";
import { UploadFlow } from "../components/UploadFlow";
import { DatasetCard, DemoButtons } from "./Home";
import { DemoBanner, Empty, ErrorBox, Loading, Menu, Modal, QualityBadge, Spinner, Tabs } from "../components/ui";

const DATA_TYPES = ["integer", "decimal", "currency", "percentage", "date", "datetime", "boolean", "categorical", "text", "identifier", "empty"];
const ROLES = ["measure", "dimension", "time", "identifier", "attribute", "ignore"];

export function DatasetsPage() {
  const { t } = useI18n();
  const { can } = useAuth();
  const [trash, setTrash] = useState(false);
  const q = useQuery({ queryKey: ["datasets", trash], queryFn: () => api.get<Dataset[]>(`/datasets${trash ? "?include_deleted=true" : ""}`) });
  const qc = useQueryClient();
  return (
    <div>
      <div className="page-head">
        <div><h1>{t("nav.datasets")}</h1><p>Every upload, sheet, connector import and cleaned version lives here. Originals are never changed.</p></div>
        <div className="row">
          {can("data.delete") && <button className="btn" onClick={() => setTrash((x) => !x)}>{trash ? "Back to datasets" : "Trash"}</button>}
          {can("data.write") && <Link className="btn primary" to="/upload"><Plus />{t("action.upload")}</Link>}
        </div>
      </div>
      {q.isLoading ? <Loading /> : q.error ? <ErrorBox error={q.error} /> : !q.data?.length ? (
        trash ? <Empty title="Trash is empty" /> : <div className="panel"><Empty title={t("empty.datasets")} action={can("data.write") ? <div className="stack-4"><Link className="btn primary" to="/upload">{t("action.upload")}</Link><DemoButtons /></div> : undefined}>{t("empty.datasets.sub")}</Empty></div>
      ) : trash ? (
        <div className="table-wrap"><table className="data"><thead><tr><th>Name</th><th>Deleted</th><th /></tr></thead><tbody>
          {q.data.map((d) => <tr key={d.id}><td>{d.name}</td><td>{relTime(d.deleted_at)}</td><td className="n">
            <button className="btn small" onClick={async () => { await api.post(`/datasets/${d.id}/restore`); qc.invalidateQueries(); }}>Restore</button>{" "}
            <button className="btn small danger" onClick={async () => { if (confirm(`Permanently delete “${d.name}” and all its versions? This cannot be undone.`)) { await api.del(`/datasets/${d.id}?purge=true`); qc.invalidateQueries(); } }}>Delete forever</button>
          </td></tr>)}
        </tbody></table></div>
      ) : <div className="grid-auto">{q.data.map((d) => <DatasetCard key={d.id} d={d} />)}</div>}
    </div>
  );
}

type Tab = "schema" | "quality" | "explorer" | "pivot" | "versions" | "settings";

export function DatasetDetail() {
  const { id = "" } = useParams();
  const [sp, setSp] = useSearchParams();
  const tab = (sp.get("tab") as Tab) || "schema";
  const q = useQuery({ queryKey: ["dataset", id], queryFn: () => api.get(`/datasets/${id}`) });
  const { t } = useI18n();
  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorBox error={q.error} onRetry={() => q.refetch()} />;
  const d = q.data;
  const setTab = (x: Tab) => { const n = new URLSearchParams(sp); n.set("tab", x); n.delete("f"); setSp(n, { replace: true }); };
  return (
    <div>
      <div className="page-head">
        <div className="grow">
          <div className="row wrap"><h1>{d.name}</h1>{d.is_demo && <span className="badge demo">Demo</span>}<QualityBadge score={d.quality_score} /></div>
          <p className="num">{d.rows?.toLocaleString("en-IN")} {t("common.rows")} · {d.columns} {t("common.columns")} · {t("common.version")} {d.version_number}
            {d.domain && d.domain !== "general" ? ` · looks like ${d.domain.replace(/_/g, " ")} data` : ""}</p>
        </div>
        <div className="row wrap">
          {d.dashboards?.map((x: any) => <Link key={x.id} className="btn" to={`/dashboards/${x.id}`}><LayoutDashboard />{x.name.length > 28 ? x.name.slice(0, 27) + "…" : x.name}</Link>).slice(0, 2)}
          <Link className="btn primary" to={`/ask?dataset=${id}`}><Sparkles />{t("nav.ask")}</Link>
        </div>
      </div>
      {d.is_demo && <DemoBanner text={t("dash.demo")} />}
      <Tabs<Tab> value={tab} onChange={setTab} tabs={[
        { id: "schema", label: "Schema" }, { id: "quality", label: "Quality & cleaning" }, { id: "explorer", label: "Data explorer" },
        { id: "pivot", label: "Pivot" }, { id: "versions", label: "Versions" }, { id: "settings", label: "Settings & alerts" },
      ]} />
      {tab === "schema" && <SchemaTab id={id} schema={d.schema} />}
      {tab === "quality" && <QualityTab id={id} quality={d.quality} schema={d.schema} />}
      {tab === "explorer" && <Explorer id={id} schema={d.schema} />}
      {tab === "pivot" && <PivotTab id={id} schema={d.schema} />}
      {tab === "versions" && <VersionsTab ds={d} />}
      {tab === "settings" && <SettingsTab ds={d} />}
    </div>
  );
}

// ---------------------------------------------------------------- schema
function SchemaTab({ id, schema }: { id: string; schema: Schema }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [desc, setDesc] = useState<any>(null);
  const edit = useMutation({
    mutationFn: ({ col, body }: { col: string; body: Record<string, unknown> }) => api.patch(`/datasets/${id}/columns/${encodeURIComponent(col)}`, body),
    onSuccess: () => { qc.invalidateQueries(); toast.show("Column updated. KPIs and charts now use the new setting."); },
    onError: (e) => toast.show(errMsg(e), "error"),
  });
  const describe = useMutation({ mutationFn: () => api.post(`/datasets/${id}/describe-schema`), onSuccess: setDesc, onError: (e) => toast.show(errMsg(e), "error") });
  const descOf = (n: string) => desc?.columns?.find((c: any) => c.name === n)?.description;
  const editable = can("data.write");
  return (
    <div className="stack-4">
      <div className="grid-3">
        <div className="panel panel-body"><div className="subtle">Measures (numbers to add up)</div><strong>{schema.measures.join(", ") || "None found"}</strong></div>
        <div className="panel panel-body"><div className="subtle">Dimensions (to group and filter)</div><strong>{schema.dimensions.slice(0, 8).join(", ") || "None found"}</strong></div>
        <div className="panel panel-body"><div className="subtle">Main date column</div><strong>{schema.primary_date_column ?? "No dates found"}</strong></div>
      </div>
      <div className="row between wrap">
        <p className="muted">Types and roles were detected from the values. If something is wrong, change it — the original data is re-read, nothing is lost.</p>
        <button className="btn" onClick={() => describe.mutate()} disabled={describe.isPending}>{describe.isPending ? <Spinner /> : <Wand2 />}Describe columns</button>
      </div>
      {desc?.dataset_description && <div className="note">{desc.dataset_description}</div>}
      <div className="table-wrap">
        <table className="data">
          <thead><tr><th>Column</th><th>Type</th><th>Role</th><th className="n">Confidence</th><th className="n">Missing</th><th className="n">Distinct</th><th>Values / range</th></tr></thead>
          <tbody>
            {schema.columns.map((c) => (
              <tr key={c.name}>
                <td>
                  <strong>{c.label && c.label !== c.name ? c.label : c.name}</strong>{c.user_override && <span className="badge info" style={{ marginLeft: 6 }}>edited</span>}
                  {c.label && c.label !== c.name && <div className="subtle">{c.name}</div>}
                  {c.original_name && c.original_name !== c.name && <div className="subtle">in file: “{c.original_name}”</div>}
                  {descOf(c.name) && <div className="subtle" style={{ maxWidth: 360 }}>{descOf(c.name)}</div>}
                  <div className="row wrap" style={{ gap: 4, marginTop: 4 }}>{c.semantic_tags.filter((x) => !x.includes(":")).slice(0, 4).map((x) => <span key={x} className="type-chip">{x.replace(/_/g, " ")}</span>)}</div>
                </td>
                <td>{editable ? (
                  <select className="input small" value={c.data_type} onChange={(e) => edit.mutate({ col: c.name, body: { data_type: e.target.value } })}>
                    {DATA_TYPES.map((x) => <option key={x}>{x}</option>)}
                  </select>) : c.data_type}
                  {["date", "datetime"].includes(c.data_type) && editable && (
                    <select className="input small" style={{ marginTop: 4 }} value="" onChange={(e) => e.target.value && edit.mutate({ col: c.name, body: { dayfirst: e.target.value === "dmy" } })}>
                      <option value="">Date order…</option><option value="dmy">DD/MM/YYYY</option><option value="mdy">MM/DD/YYYY</option>
                    </select>
                  )}
                </td>
                <td>{editable ? (
                  <select className="input small" value={c.role} onChange={(e) => edit.mutate({ col: c.name, body: { role: e.target.value } })}>
                    {ROLES.map((x) => <option key={x}>{x}</option>)}
                  </select>) : c.role}
                  {c.user_override && editable && <button className="evidence-link" style={{ display: "block", marginTop: 4 }} onClick={() => edit.mutate({ col: c.name, body: { reset: true } })}>undo edits</button>}
                </td>
                <td className="n"><div className="bar-meter" style={{ width: 70, display: "inline-block", verticalAlign: "middle" }}><span style={{ width: `${Math.round(c.confidence * 100)}%` }} /></div> {Math.round(c.confidence * 100)}%</td>
                <td className="n">{c.stats.null_pct ?? 0}%</td>
                <td className="n">{(c.stats.distinct ?? 0).toLocaleString("en-IN")}</td>
                <td className="small">{colSummary(c)}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
      {schema.relationships?.length > 0 && (
        <div className="panel panel-body">
          <h3 style={{ marginBottom: 8 }}>Relationships found in the data</h3>
          <ul className="insight-list">{schema.relationships.map((r: any, i: number) => <li key={i}><Columns3 /><span>{r.description}</span></li>)}</ul>
        </div>
      )}
    </div>
  );
}

function colSummary(c: ColumnInfo): string {
  const s = c.stats;
  if (["integer", "decimal", "currency", "percentage"].includes(c.data_type) && s.min !== undefined) return `${formatCell(s.min, c.data_type)} – ${formatCell(s.max, c.data_type)} · avg ${formatCell(s.mean, c.data_type)}`;
  if (["date", "datetime"].includes(c.data_type) && s.min) return `${formatCell(s.min.slice(0, 10))} – ${formatCell(s.max.slice(0, 10))}`;
  if (s.top_values?.length) return s.top_values.slice(0, 4).map((t: any) => t.value).join(", ") + (s.distinct > 4 ? ", …" : "");
  return "";
}

// ---------------------------------------------------------------- quality & cleaning
const OPS: { op: string; label: string; params: { key: string; label: string; kind: "column" | "columns" | "text" | "select"; options?: string[] }[] }[] = [
  { op: "trim_whitespace", label: "Trim extra spaces", params: [] },
  { op: "standardize_case", label: "Standardise text case", params: [{ key: "columns", label: "Columns", kind: "columns" }, { key: "case", label: "Case", kind: "select", options: ["title", "upper", "lower"] }] },
  { op: "remove_duplicates", label: "Remove duplicate rows", params: [] },
  { op: "remove_empty_rows", label: "Remove empty rows", params: [] },
  { op: "remove_empty_columns", label: "Remove empty columns", params: [] },
  { op: "fill_missing", label: "Fill blank values", params: [{ key: "column", label: "Column", kind: "column" }, { key: "strategy", label: "With", kind: "select", options: ["value", "zero", "mean", "median", "mode", "ffill", "bfill"] }, { key: "value", label: "Value (if 'value')", kind: "text" }] },
  { op: "replace_values", label: "Replace values", params: [{ key: "column", label: "Column", kind: "column" }, { key: "find", label: "Find", kind: "text" }, { key: "replace", label: "Replace with", kind: "text" }, { key: "match", label: "Match", kind: "select", options: ["exact", "contains"] }] },
  { op: "rename_column", label: "Rename a column", params: [{ key: "column", label: "Column", kind: "column" }, { key: "new_name", label: "New name", kind: "text" }] },
  { op: "split_column", label: "Split a column", params: [{ key: "column", label: "Column", kind: "column" }, { key: "delimiter", label: "Split on", kind: "text" }] },
  { op: "merge_columns", label: "Merge columns", params: [{ key: "columns", label: "Columns", kind: "columns" }, { key: "new_name", label: "New column name", kind: "text" }, { key: "separator", label: "Separator", kind: "text" }] },
  { op: "standardize_numbers", label: "Clean number formats (₹, commas, brackets)", params: [{ key: "columns", label: "Columns", kind: "columns" }] },
  { op: "convert_type", label: "Change column type", params: [{ key: "column", label: "Column", kind: "column" }, { key: "data_type", label: "Type", kind: "select", options: DATA_TYPES }] },
  { op: "standardize_dates", label: "Set date order", params: [{ key: "column", label: "Column", kind: "column" }, { key: "dayfirst", label: "Order", kind: "select", options: ["true", "false"] }] },
  { op: "drop_columns", label: "Remove columns", params: [{ key: "columns", label: "Columns", kind: "columns" }] },
];

function QualityTab({ id, quality, schema }: { id: string; quality: Quality; schema: Schema }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const [steps, setSteps] = useState<{ op: string; params: Record<string, any> }[]>([]);
  const [adding, setAdding] = useState<string>("");
  const [preview, setPreview] = useState<any>(null);
  const cols = schema.columns.map((c) => c.name);
  const prev = useMutation({ mutationFn: () => api.post(`/datasets/${id}/clean/preview`, { steps }), onSuccess: setPreview, onError: (e) => toast.show(errMsg(e), "error") });
  const apply = useMutation({
    mutationFn: async () => { const r = await api.post(`/datasets/${id}/clean`, { steps }); const j = r.job.status === "done" || r.job.status === "failed" ? r.job : await pollJob(r.job.id); if (j.status === "failed") throw new Error(j.error); return j; },
    onSuccess: (j) => { qc.invalidateQueries(); setSteps([]); setPreview(null); toast.show(`Version ${j.result.version_number} created. The previous version is kept.`); },
    onError: (e) => toast.show(errMsg(e), "error"),
  });
  const addSuggested = (a: { op: string; params?: Record<string, unknown> }) => {
    if (["view_outliers", "replace_values"].includes(a.op)) return;
    setSteps((s) => [...s, { op: a.op, params: { ...(a.params ?? {}) } }]);
  };
  const def = OPS.find((o) => o.op === adding);
  return (
    <div className="grid-2" style={{ alignItems: "start" }}>
      <div className="panel panel-body stack-4">
        <h3>Data quality checks</h3>
        <QualitySummary quality={quality} datasetId={id} />
        {can("data.write") && quality.issues.some((i) => i.suggested_action && !["view_outliers", "replace_values"].includes(i.suggested_action.op)) && (
          <div>
            <h4 style={{ marginBottom: 6 }}>Suggested fixes</h4>
            <div className="suggestions">
              {quality.issues.filter((i) => i.suggested_action && !["view_outliers", "replace_values"].includes(i.suggested_action.op)).slice(0, 8).map((i, n) => (
                <button key={n} onClick={() => addSuggested(i.suggested_action!)}>+ {OPS.find((o) => o.op === i.suggested_action!.op)?.label ?? i.suggested_action!.op}{i.column ? ` (${i.column})` : ""}</button>
              ))}
            </div>
          </div>
        )}
      </div>
      {can("data.write") && (
        <div className="panel panel-body stack-4">
          <h3>Cleaning steps</h3>
          <p className="muted small">Steps create a new version of the dataset. The uploaded file and all earlier versions stay unchanged, so you can always go back.</p>
          {steps.length === 0 && <p className="subtle">No steps yet. Add one below or pick a suggested fix.</p>}
          <ol style={{ margin: 0, paddingLeft: 18 }}>
            {steps.map((s, i) => (
              <li key={i} style={{ marginBottom: 6 }}>
                <div className="row between"><span>{OPS.find((o) => o.op === s.op)?.label ?? s.op} <span className="subtle">{Object.entries(s.params).filter(([, v]) => v !== "" && v !== undefined).map(([k, v]) => `${k}: ${Array.isArray(v) ? v.join(", ") : v}`).join(" · ")}</span></span>
                  <button className="btn ghost icon small" aria-label="Remove step" onClick={() => setSteps((x) => x.filter((_, j) => j !== i))}><Trash2 /></button></div>
              </li>
            ))}
          </ol>
          <div className="row wrap" style={{ alignItems: "flex-end" }}>
            <label className="field grow"><span>Add a step</span>
              <select className="input" value={adding} onChange={(e) => setAdding(e.target.value)}><option value="">Choose an operation…</option>{OPS.map((o) => <option key={o.op} value={o.op}>{o.label}</option>)}</select>
            </label>
          </div>
          {def && <StepForm def={def} cols={cols} onAdd={(params) => { setSteps((s) => [...s, { op: def.op, params }]); setAdding(""); }} />}
          <div className="row">
            <button className="btn" disabled={!steps.length || prev.isPending} onClick={() => prev.mutate()}>{prev.isPending ? <Spinner /> : <Eye />}Preview</button>
            <button className="btn primary" disabled={!steps.length || apply.isPending} onClick={() => apply.mutate()}>{apply.isPending ? <Spinner /> : <Play />}Create cleaned version</button>
          </div>
          {preview && (
            <div className="stack-4">
              <div className="note">Preview on the first {preview.preview_rows.toLocaleString("en-IN")} rows: {preview.rows_before.toLocaleString("en-IN")} → {preview.rows_after.toLocaleString("en-IN")} rows · quality score {Math.round(preview.quality.score)}</div>
              <div className="table-wrap" style={{ maxHeight: 260 }}>
                <table className="data"><thead><tr>{preview.columns.map((c: string) => <th key={c}>{c}</th>)}</tr></thead>
                  <tbody>{preview.sample.map((r: unknown[], i: number) => <tr key={i}>{r.map((v, j) => <td key={j} className={v === null ? "null" : undefined}>{v === null ? "blank" : String(v)}</td>)}</tr>)}</tbody></table>
              </div>
            </div>
          )}
        </div>
      )}
    </div>
  );
}

function StepForm({ def, cols, onAdd }: { def: (typeof OPS)[number]; cols: string[]; onAdd: (p: Record<string, any>) => void }) {
  const [p, setP] = useState<Record<string, any>>(() => Object.fromEntries(def.params.map((x) => [x.key, x.kind === "columns" ? [] : x.kind === "column" ? cols[0] : x.options?.[0] ?? ""])));
  return (
    <div className="panel flat panel-body stack-4">
      <div className="form-grid">
        {def.params.map((x) => (
          <label key={x.key} className="field"><span>{x.label}</span>
            {x.kind === "column" ? <select className="input" value={p[x.key]} onChange={(e) => setP({ ...p, [x.key]: e.target.value })}>{cols.map((c) => <option key={c}>{c}</option>)}</select>
              : x.kind === "columns" ? <select className="input" multiple size={Math.min(6, cols.length)} value={p[x.key]} onChange={(e) => setP({ ...p, [x.key]: Array.from(e.target.selectedOptions).map((o) => o.value) })}>{cols.map((c) => <option key={c}>{c}</option>)}</select>
              : x.kind === "select" ? <select className="input" value={p[x.key]} onChange={(e) => setP({ ...p, [x.key]: e.target.value })}>{x.options!.map((o) => <option key={o} value={o}>{x.key === "dayfirst" ? (o === "true" ? "DD/MM/YYYY" : "MM/DD/YYYY") : o}</option>)}</select>
              : <input className="input" value={p[x.key]} onChange={(e) => setP({ ...p, [x.key]: e.target.value })} />}
          </label>
        ))}
      </div>
      <button className="btn small" onClick={() => {
        const out = { ...p };
        if ("dayfirst" in out) out.dayfirst = out.dayfirst === "true";
        if (Array.isArray(out.columns) && out.columns.length === 0) delete out.columns;
        onAdd(out);
      }}><Plus />Add step</button>
    </div>
  );
}

// ---------------------------------------------------------------- explorer
function Explorer({ id, schema }: { id: string; schema: Schema }) {
  const [sp] = useSearchParams();
  const toast = useToast();
  const [active, setActive] = useState<ActiveFilters>(() => { try { return JSON.parse(sp.get("f") || "{}"); } catch { return {}; } });
  const [order, setOrder] = useState<string[]>(() => schema.columns.map((c) => c.name));
  const [hidden, setHidden] = useState<Set<string>>(new Set());
  const [sort, setSort] = useState<{ by: string; desc: boolean } | null>(null);
  const [page, setPage] = useState(0);
  const [size, setSize] = useState(50);
  const [dups, setDups] = useState(false);
  const [blankCol, setBlankCol] = useState<string>("");
  const [colsOpen, setColsOpen] = useState(false);
  const filters: Filter[] = Object.values(active);
  const cols = order.filter((c) => !hidden.has(c));
  const types = useMemo(() => Object.fromEntries(schema.columns.map((c) => [c.name, c.data_type])), [schema]);
  const q = useQuery({
    queryKey: ["rows", id, filters, cols, sort, page, size, dups, blankCol],
    queryFn: () => api.post(`/datasets/${id}/rows`, { columns: cols, filters, sort: sort ? [sort] : [], limit: size, offset: page * size, duplicates_only: dups, nulls_in: blankCol || null }),
    placeholderData: (p) => p,
  });
  const exp = (format: "csv" | "xlsx", scope: "filtered" | "all") =>
    download(`/datasets/${id}/export`, { method: "POST", json: { format, scope, filters, columns: cols, sort: sort ? [sort] : [] } }, `data.${format}`).catch((e) => toast.show(errMsg(e), "error"));
  const total = q.data?.total ?? 0;
  const pages = Math.max(1, Math.ceil(total / size));
  const numeric = (c: string) => ["integer", "decimal", "currency", "percentage"].includes(types[c]);
  return (
    <div className="stack-4">
      <FilterBar defs={[{ id: "search", column: null, type: "search", label: "Search" }]} schema={schema} datasetId={id} active={active} onChange={(a) => { setActive(a); setPage(0); }} />
      <div className="row wrap between">
        <div className="row wrap">
          <button className="btn small" onClick={() => setColsOpen(true)}><Columns3 />Columns ({cols.length}/{order.length})</button>
          <label className="check small"><input type="checkbox" checked={dups} onChange={(e) => { setDups(e.target.checked); setPage(0); }} />Only duplicate rows</label>
          <select className="input small" style={{ width: 200 }} value={blankCol} onChange={(e) => { setBlankCol(e.target.value); setPage(0); }} aria-label="Show rows with blanks in">
            <option value="">Rows with blanks in…</option>{order.map((c) => <option key={c}>{c}</option>)}
          </select>
        </div>
        <div className="row">
          <span className="subtle num">{total.toLocaleString("en-IN")} rows</span>
          <Menu trigger={(tg) => <button className="btn small" onClick={tg}><Download />Export<ChevronDown /></button>}>
            {(close) => (<>
              <button onClick={() => { close(); exp("xlsx", "filtered"); }}>Filtered rows · Excel</button>
              <button onClick={() => { close(); exp("csv", "filtered"); }}>Filtered rows · CSV</button>
              <hr />
              <button onClick={() => { close(); exp("xlsx", "all"); }}>All rows · Excel</button>
              <button onClick={() => { close(); exp("csv", "all"); }}>All rows · CSV</button>
            </>)}
          </Menu>
        </div>
      </div>
      {q.error ? <ErrorBox error={q.error} /> : (
        <div className="table-wrap" style={{ maxHeight: "65vh" }}>
          <table className="data">
            <thead><tr>{cols.map((c) => (
              <th key={c} className={numeric(c) ? "n" : undefined} aria-sort={sort?.by === c ? (sort.desc ? "descending" : "ascending") : "none"}>
                <button className="sort" onClick={() => setSort((s) => (s?.by === c ? (s.desc ? { by: c, desc: false } : null) : { by: c, desc: true }))}>
                  {c}{sort?.by === c && (sort.desc ? <ArrowDown size={12} /> : <ArrowUp size={12} />)}
                </button>
                <div><span className="type-chip">{types[c]}</span></div>
              </th>))}</tr></thead>
            <tbody>
              {q.isLoading && <tr><td colSpan={cols.length}><Spinner /></td></tr>}
              {q.data?.rows.map((r: unknown[], i: number) => (
                <tr key={i}>{r.map((v, j) => <td key={j} className={v === null ? "null" : numeric(cols[j]) ? "n" : undefined}>{v === null ? "blank" : formatCell(v, types[cols[j]])}</td>)}</tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
      <div className="row between wrap">
        <div className="row"><span className="subtle">Rows per page</span>
          <select className="input small" style={{ width: 80 }} value={size} onChange={(e) => { setSize(Number(e.target.value)); setPage(0); }}>{[25, 50, 100, 250, 500].map((n) => <option key={n}>{n}</option>)}</select></div>
        <div className="row">
          <button className="btn small" disabled={page === 0} onClick={() => setPage((p) => p - 1)}>Previous</button>
          <span className="subtle num">Page {page + 1} of {pages.toLocaleString("en-IN")}</span>
          <button className="btn small" disabled={page + 1 >= pages} onClick={() => setPage((p) => p + 1)}>Next</button>
        </div>
      </div>
      {colsOpen && (
        <Modal title="Choose and order columns" onClose={() => setColsOpen(false)} footer={<button className="btn primary" onClick={() => setColsOpen(false)}>Done</button>}>
          <div className="col" style={{ gap: 4 }}>
            {order.map((c, i) => (
              <div key={c} className="row" style={{ padding: "4px 0", borderBottom: "1px solid var(--line)" }}>
                <button className="btn ghost icon small" aria-label={hidden.has(c) ? `Show ${c}` : `Hide ${c}`} onClick={() => setHidden((h) => { const n = new Set(h); if (n.has(c)) n.delete(c); else n.add(c); return n; })}>{hidden.has(c) ? <EyeOff /> : <Eye />}</button>
                <span className="grow" style={{ opacity: hidden.has(c) ? 0.5 : 1 }}>{c} <span className="type-chip">{types[c]}</span></span>
                <button className="btn ghost icon small" aria-label="Move up" disabled={i === 0} onClick={() => setOrder((o) => { const n = [...o]; [n[i - 1], n[i]] = [n[i], n[i - 1]]; return n; })}><ArrowUp /></button>
                <button className="btn ghost icon small" aria-label="Move down" disabled={i === order.length - 1} onClick={() => setOrder((o) => { const n = [...o]; [n[i + 1], n[i]] = [n[i], n[i + 1]]; return n; })}><ArrowDown /></button>
              </div>
            ))}
          </div>
        </Modal>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- pivot
function PivotTab({ id, schema }: { id: string; schema: Schema }) {
  const dims = schema.columns.filter((c) => c.role !== "measure" && c.data_type !== "empty" && c.data_type !== "text");
  const [rows, setRows] = useState<string[]>(schema.dimensions.slice(0, 1));
  const [column, setColumn] = useState<string>(schema.dimensions[1] ?? "");
  const [valueCol, setValueCol] = useState<string>(schema.measures[0] ?? "");
  const [agg, setAgg] = useState<Measure["agg"]>(schema.measures[0] ? "sum" : "count_rows");
  const dim = (c: string): Dimension => ({ column: c, granularity: ["date", "datetime"].includes(schema.columns.find((x) => x.name === c)?.data_type ?? "") ? "month" : null });
  const q = useQuery({
    queryKey: ["pivot", id, rows, column, valueCol, agg],
    queryFn: () => api.post(`/datasets/${id}/analytics/pivot`, { rows: rows.filter(Boolean).map(dim), column: column ? dim(column) : null,
      values: [agg === "count_rows" ? { agg: "count_rows" } : { column: valueCol, agg }] }),
    enabled: rows.length > 0,
  });
  return (
    <div className="stack-4">
      <div className="panel panel-body form-grid">
        {[0, 1].map((i) => (
          <label key={i} className="field"><span>{i === 0 ? "Rows" : "Then by (optional)"}</span>
            <select className="input" value={rows[i] ?? ""} onChange={(e) => setRows((r) => { const n = [...r]; n[i] = e.target.value; return n.filter(Boolean); })}>
              {i > 0 && <option value="">None</option>}{dims.map((c) => <option key={c.name}>{c.name}</option>)}
            </select>
          </label>
        ))}
        <label className="field"><span>Columns</span><select className="input" value={column} onChange={(e) => setColumn(e.target.value)}><option value="">None</option>{dims.map((c) => <option key={c.name}>{c.name}</option>)}</select></label>
        <label className="field"><span>Values</span>
          <select className="input" value={agg} onChange={(e) => setAgg(e.target.value as Measure["agg"])}>
            {["sum", "avg", "min", "max", "count_distinct", "count_rows"].map((a) => <option key={a} value={a}>{({ sum: "Sum", avg: "Average", min: "Min", max: "Max", count_distinct: "Distinct count", count_rows: "Count of rows" } as any)[a]}</option>)}
          </select>
        </label>
        {agg !== "count_rows" && <label className="field"><span>of</span>
          <select className="input" value={valueCol} onChange={(e) => setValueCol(e.target.value)}>
            {schema.columns.filter((c) => agg === "count_distinct" || ["integer", "decimal", "currency", "percentage"].includes(c.data_type)).map((c) => <option key={c.name}>{c.name}</option>)}
          </select></label>}
      </div>
      {q.isLoading ? <Loading /> : q.error ? <ErrorBox error={q.error} /> : q.data ? <PivotView p={q.data} /> : null}
    </div>
  );
}

// ---------------------------------------------------------------- versions
function VersionsTab({ ds }: { ds: any }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["versions", ds.id], queryFn: () => api.get(`/datasets/${ds.id}/versions`) });
  const [cmp, setCmp] = useState<string[]>([]);
  const [newVer, setNewVer] = useState(false);
  const diff = useQuery({ queryKey: ["vcmp", cmp], queryFn: () => api.get(`/datasets/${ds.id}/versions/compare?a=${cmp[0]}&b=${cmp[1]}`), enabled: cmp.length === 2 });
  const refresh = useMutation({
    mutationFn: async () => { const r = await api.post(`/datasets/${ds.id}/refresh`); const j = await pollJob(r.job.id); if (j.status === "failed") throw new Error(j.error); return j; },
    onSuccess: () => { qc.invalidateQueries(); toast.show("Refreshed — a new version was created."); }, onError: (e) => toast.show(errMsg(e), "error"),
  });
  return (
    <div className="stack-4">
      <div className="row wrap">
        {can("data.write") && ["http", "google_sheets", "sql"].includes(ds.source_type) && <button className="btn" onClick={() => refresh.mutate()} disabled={refresh.isPending}>{refresh.isPending ? <Spinner /> : <RefreshCw />}Refresh from source</button>}
        {can("data.write") && <button className="btn" onClick={() => setNewVer((x) => !x)}><Plus />Upload a new version</button>}
        <span className="subtle">Select two versions to compare them.</span>
      </div>
      {newVer && <UploadFlow datasetId={ds.id} />}
      {q.isLoading ? <Loading /> : (
        <div className="table-wrap"><table className="data">
          <thead><tr><th /><th>Version</th><th>Kind</th><th className="n">Rows</th><th className="n">Quality</th><th>What happened</th><th>When</th><th /></tr></thead>
          <tbody>{q.data?.map((v: any) => (
            <tr key={v.id}>
              <td><input type="checkbox" aria-label={`Compare version ${v.version_number}`} checked={cmp.includes(v.id)} onChange={(e) => setCmp((c) => e.target.checked ? [...c, v.id].slice(-2) : c.filter((x) => x !== v.id))} /></td>
              <td><strong>v{v.version_number}</strong> {v.current && <span className="badge accent">current</span>}</td>
              <td>{v.kind}</td><td className="n">{v.rows.toLocaleString("en-IN")}</td><td className="n">{v.quality_score ?? "—"}</td>
              <td className="small" style={{ maxWidth: 420 }}>{v.note}</td><td className="small">{relTime(v.created_at)}</td>
              <td className="n">{!v.current && can("data.write") && <button className="btn small" onClick={async () => { await api.post(`/datasets/${ds.id}/versions/${v.id}/activate`); qc.invalidateQueries(); toast.show(`Version ${v.version_number} is now current`); }}>Make current</button>}</td>
            </tr>))}</tbody>
        </table></div>
      )}
      {diff.data && (
        <div className="panel panel-body stack-4">
          <h3>v{diff.data.from.version} → v{diff.data.to.version}</h3>
          <div className="grid-3">
            <div><div className="subtle">Rows</div><strong className="num">{diff.data.rows_change >= 0 ? "+" : ""}{diff.data.rows_change.toLocaleString("en-IN")}</strong></div>
            <div><div className="subtle">Quality score</div><strong>{diff.data.quality.score_before} → {diff.data.quality.score_after}</strong></div>
            <div><div className="subtle">Columns</div><span>{diff.data.added_columns.length ? `Added: ${diff.data.added_columns.join(", ")}. ` : ""}{diff.data.removed_columns.length ? `Removed: ${diff.data.removed_columns.join(", ")}.` : ""}{!diff.data.added_columns.length && !diff.data.removed_columns.length ? "Unchanged" : ""}</span></div>
          </div>
          {diff.data.measure_totals.length > 0 && (
            <div className="table-wrap"><table className="data"><thead><tr><th>Measure</th><th className="n">Total before</th><th className="n">Total after</th><th className="n">Change</th></tr></thead>
              <tbody>{diff.data.measure_totals.map((m: any) => <tr key={m.column}><td>{m.column}</td><td className="n">{formatCell(m.sum_before)}</td><td className="n">{formatCell(m.sum_after)}</td>
                <td className="n">{m.change_pct === null ? formatCell(m.change) : `${m.change_pct >= 0 ? "+" : ""}${m.change_pct.toFixed(1)}%`}</td></tr>)}</tbody></table></div>
          )}
        </div>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- settings / alerts
function SettingsTab({ ds }: { ds: any }) {
  const { can } = useAuth();
  const qc = useQueryClient();
  const toast = useToast();
  const nav = useNavigate();
  const [name, setName] = useState(ds.name);
  const [desc, setDesc] = useState(ds.description ?? "");
  const [refresh, setRefresh] = useState<string>(ds.refresh_minutes ? String(ds.refresh_minutes) : "");
  const alerts = useQuery({ queryKey: ["alerts", ds.id], queryFn: () => api.get(`/alerts?dataset_id=${ds.id}`) });
  const save = useMutation({
    mutationFn: () => api.patch(`/datasets/${ds.id}`, { name, description: desc, ...(["http", "google_sheets", "sql"].includes(ds.source_type) ? { refresh_minutes: refresh ? Number(refresh) : null } : {}) }),
    onSuccess: () => { qc.invalidateQueries(); toast.show("Saved"); }, onError: (e) => toast.show(errMsg(e), "error"),
  });
  const [alert, setAlert] = useState({ name: "", column: ds.schema?.measures?.[0] ?? "", agg: "sum", operator: "<", threshold: "" });
  const addAlert = useMutation({
    mutationFn: () => api.post("/alerts", { dataset_id: ds.id, name: alert.name || `${alert.agg} of ${alert.column} ${alert.operator} ${alert.threshold}`,
      kpi: { title: `${alert.agg} of ${alert.column}`, measure: alert.agg === "count_rows" ? { agg: "count_rows" } : { column: alert.column, agg: alert.agg } },
      operator: alert.operator, threshold: Number(alert.threshold) }),
    onSuccess: () => { qc.invalidateQueries({ queryKey: ["alerts", ds.id] }); toast.show("Alert created. It is checked whenever this dataset gets a new version or refresh."); },
    onError: (e) => toast.show(errMsg(e), "error"),
  });
  return (
    <div className="grid-2" style={{ alignItems: "start" }}>
      <div className="panel panel-body stack-4">
        <h3>Details</h3>
        <label className="field"><span>Name</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} disabled={!can("data.write")} /></label>
        <label className="field"><span>Description</span><textarea className="input" rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} disabled={!can("data.write")} /></label>
        {["http", "google_sheets", "sql"].includes(ds.source_type) && (
          <label className="field"><span>Refresh automatically every (minutes)</span><input className="input" type="number" min={15} value={refresh} onChange={(e) => setRefresh(e.target.value)} placeholder="Off" />
            <span className="hint">Each refresh creates a new version and checks alerts.</span></label>
        )}
        <p className="subtle">Source: {ds.source_type}{ds.last_refreshed_at ? ` · last refreshed ${relTime(ds.last_refreshed_at)}` : ""}</p>
        {can("data.write") && <button className="btn primary" onClick={() => save.mutate()} disabled={save.isPending}>Save</button>}
        {can("data.delete") && (
          <div style={{ borderTop: "1px solid var(--line)", paddingTop: 16 }}>
            <button className="btn danger" onClick={async () => { if (confirm(`Move “${ds.name}” to trash? Dashboards stop working until it is restored.`)) { await api.del(`/datasets/${ds.id}`); qc.invalidateQueries(); nav("/datasets"); } }}><Trash2 />Move to trash</button>
          </div>
        )}
      </div>
      <div className="panel panel-body stack-4">
        <h3>KPI alerts</h3>
        <p className="muted small">Get notified when a number crosses a threshold (in the app; by email or webhook when configured).</p>
        {alerts.data?.length ? (
          <ul className="insight-list">{alerts.data.map((a: any) => (
            <li key={a.id}><Sparkles /><div className="row between"><span>{a.name}{a.last_triggered_at ? <span className="subtle"> · last fired {relTime(a.last_triggered_at)}</span> : null}</span>
              {can("alert.write") && <button className="btn ghost icon small" aria-label="Delete alert" onClick={async () => { await api.del(`/alerts/${a.id}`); qc.invalidateQueries({ queryKey: ["alerts", ds.id] }); }}><Trash2 /></button>}</div></li>))}</ul>
        ) : <p className="subtle">No alerts yet.</p>}
        {can("alert.write") && (
          <div className="form-grid">
            <label className="field"><span>Measure</span>
              <select className="input" value={alert.agg} onChange={(e) => setAlert({ ...alert, agg: e.target.value })}>
                <option value="sum">Sum</option><option value="avg">Average</option><option value="count_rows">Row count</option><option value="max">Maximum</option><option value="min">Minimum</option>
              </select></label>
            {alert.agg !== "count_rows" && <label className="field"><span>of</span><select className="input" value={alert.column} onChange={(e) => setAlert({ ...alert, column: e.target.value })}>{(ds.schema?.measures ?? []).map((m: string) => <option key={m}>{m}</option>)}</select></label>}
            <label className="field"><span>is</span><select className="input" value={alert.operator} onChange={(e) => setAlert({ ...alert, operator: e.target.value })}>{["<", "<=", ">", ">=", "==", "!="].map((o) => <option key={o}>{o}</option>)}</select></label>
            <label className="field"><span>Threshold</span><input className="input" type="number" value={alert.threshold} onChange={(e) => setAlert({ ...alert, threshold: e.target.value })} /></label>
            <label className="field"><span>Alert name</span><input className="input" value={alert.name} onChange={(e) => setAlert({ ...alert, name: e.target.value })} placeholder="optional" /></label>
            <button className="btn" style={{ alignSelf: "end" }} disabled={alert.threshold === "" || addAlert.isPending} onClick={() => addAlert.mutate()}><Plus />Add alert</button>
          </div>
        )}
      </div>
    </div>
  );
}
