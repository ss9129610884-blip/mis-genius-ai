import { useState, type FormEvent } from "react";
import { Link, Navigate, useNavigate } from "react-router-dom";
import { useQuery } from "@tanstack/react-query";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { BrandMark, ErrorBox, Spinner } from "../components/ui";

function Aside() {
  const { lang } = useI18n();
  return (
    <aside className="auth-aside">
      <div className="row" style={{ gap: 12 }}><BrandMark size={36} /><strong style={{ fontSize: 18 }}>MIS Genius AI</strong></div>
      <div>
        <h1>{lang === "hi" ? "आपकी स्प्रेडशीट, पूरी MIS रिपोर्ट के साथ।" : "Your spreadsheet, read like an accountant would."}</h1>
        <p style={{ marginTop: 16, opacity: 0.8, maxWidth: 52 + "ch", fontSize: 16 }}>
          {lang === "hi"
            ? "सेल्स, खर्च, उपस्थिति, स्टॉक या कोई भी रजिस्टर — डेटा अपलोड करें और हर संख्या के स्रोत के साथ डैशबोर्ड पाएँ।"
            : "Sales, expenses, attendance, stock or any other register — upload it and get a dashboard where every number shows where it came from."}
        </p>
      </div>
      <div className="ledger" aria-hidden>
        <div><span>Rows read</span><span>12,480</span></div>
        <div><span>Blank values found</span><span>214</span></div>
        <div><span>Duplicates flagged</span><span>9</span></div>
        <div className="total"><span>Ready for analysis</span><span>12,471</span></div>
      </div>
    </aside>
  );
}

export function LoginPage() {
  const { user, login } = useAuth();
  const { t } = useI18n();
  const nav = useNavigate();
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [err, setErr] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  const setup = useQuery({ queryKey: ["setup"], queryFn: () => api.get("/auth/setup-status") });
  if (user) return <Navigate to="/" replace />;
  if (setup.data?.needs_setup) return <Navigate to="/setup" replace />;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try { await login(email, password); nav("/"); } catch (x) { setErr(x); } finally { setBusy(false); }
  };
  return (
    <div className="auth">
      <Aside />
      <form className="auth-form" onSubmit={submit}>
        <div><h2 style={{ fontSize: 24 }}>Sign in</h2><p className="muted" style={{ marginTop: 4 }}>Use the account your administrator created, or the one you registered.</p></div>
        {err ? <ErrorBox error={err} /> : null}
        <label className="field"><span>Email</span><input className="input" type="email" autoComplete="username" required value={email} onChange={(e) => setEmail(e.target.value)} /></label>
        <label className="field"><span>Password</span><input className="input" type="password" autoComplete="current-password" required value={password} onChange={(e) => setPassword(e.target.value)} /></label>
        <button className="btn primary" type="submit" disabled={busy}>{busy ? <Spinner /> : null}Sign in</button>
        {setup.data?.registration_open && <p className="muted small">New organization? <Link to="/register">Create an account</Link></p>}
        <p className="subtle">{setup.data ? `${setup.data.mode} mode · v${setup.data.version}` : ""} · {t("common.language")}: <LangSwitch /></p>
      </form>
    </div>
  );
}

function LangSwitch() {
  const { lang, setLang } = useI18n();
  return <button type="button" className="evidence-link" onClick={() => setLang(lang === "en" ? "hi" : "en")}>{lang === "en" ? "हिन्दी" : "English"}</button>;
}

export function RegisterPage({ firstRun = false }: { firstRun?: boolean }) {
  const { user, register } = useAuth();
  const { lang } = useI18n();
  const nav = useNavigate();
  const [f, setF] = useState({ full_name: "", email: "", password: "", org_name: "" });
  const [err, setErr] = useState<unknown>(null);
  const [busy, setBusy] = useState(false);
  if (user) return <Navigate to="/" replace />;
  const submit = async (e: FormEvent) => {
    e.preventDefault();
    setBusy(true);
    setErr(null);
    try {
      await register({ ...f, org_name: f.org_name || "My Organization", language: lang });
      nav("/");
    } catch (x) { setErr(x); } finally { setBusy(false); }
  };
  const set = (k: keyof typeof f) => (e: React.ChangeEvent<HTMLInputElement>) => setF({ ...f, [k]: e.target.value });
  return (
    <div className="auth">
      <Aside />
      <form className="auth-form" onSubmit={submit}>
        <div>
          <h2 style={{ fontSize: 24 }}>{firstRun ? "Set up MIS Genius AI" : "Create your organization"}</h2>
          <p className="muted" style={{ marginTop: 4 }}>{firstRun ? "This first account becomes the owner of this installation. Your data stays on this computer or server." : "You will be the owner and can invite your team later."}</p>
        </div>
        {err ? <ErrorBox error={err} /> : null}
        <label className="field"><span>Your name</span><input className="input" required value={f.full_name} onChange={set("full_name")} autoComplete="name" /></label>
        <label className="field"><span>Organization</span><input className="input" required placeholder="e.g. Sharma Traders" value={f.org_name} onChange={set("org_name")} /></label>
        <label className="field"><span>Email</span><input className="input" type="email" required value={f.email} onChange={set("email")} autoComplete="username" /></label>
        <label className="field"><span>Password</span><input className="input" type="password" required minLength={8} value={f.password} onChange={set("password")} autoComplete="new-password" />
          <span className="hint">At least 8 characters with a letter and a number.</span></label>
        <button className="btn primary" type="submit" disabled={busy}>{busy ? <Spinner /> : null}{firstRun ? "Create owner account" : "Create account"}</button>
        {!firstRun && <p className="muted small">Already have an account? <Link to="/login">Sign in</Link></p>}
      </form>
    </div>
  );
}
