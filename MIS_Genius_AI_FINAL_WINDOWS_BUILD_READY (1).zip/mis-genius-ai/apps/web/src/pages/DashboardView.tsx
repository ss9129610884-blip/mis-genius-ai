import { useCallback, useEffect, useMemo, useRef, useState } from "react";
import { Link, useNavigate, useParams, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { Responsive, WidthProvider, type Layout } from "react-grid-layout";
import "react-grid-layout/css/styles.css";
import "react-resizable/css/styles.css";
import {
  BarChart3, Bookmark, Copy, Download, Eye, EyeOff, FileText, LayoutTemplate, MoreHorizontal, Pencil, Plus, RotateCcw, Table2, Trash2,
} from "lucide-react";
import { api, download } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { errMsg, useToast } from "../lib/ui";
import type { ChartType, Dashboard, Filter, Widget } from "../lib/types";
import { Chart } from "../components/Chart";
import { Evidence, KpiCard, PivotView, ResultTable } from "../components/DataViews";
import { FilterBar, type ActiveFilters } from "../components/FilterBar";
import { InsightsPanel, QualitySummary } from "../components/Insights";
import { WidgetDesigner } from "../components/WidgetDesigner";
import { DemoBanner, Drawer, ErrorBox, Loading, Menu, Modal, Spinner } from "../components/ui";

const Grid = WidthProvider(Responsive);
const QUICK_TYPES: ChartType[] = ["bar", "hbar", "line", "area", "donut", "pie", "stacked_bar", "combo", "heatmap"];

function periodRange(iso: string, g?: string | null): [string, string] | null {
  const d = new Date(iso.slice(0, 10) + "T00:00:00");
  if (Number.isNaN(d.getTime())) return null;
  const pad = (n: number) => String(n).padStart(2, "0");
  const f = (x: Date) => `${x.getFullYear()}-${pad(x.getMonth() + 1)}-${pad(x.getDate())}`;
  const end = new Date(d);
  if (g === "month") end.setMonth(end.getMonth() + 1, 0);
  else if (g === "quarter") end.setMonth(end.getMonth() + 3, 0);
  else if (g === "year") end.setFullYear(end.getFullYear(), 11, 31);
  else if (g === "week") end.setDate(end.getDate() + 6);
  return [f(d), f(end)];
}

function filtersFromUrl(sp: URLSearchParams): ActiveFilters {
  try { return JSON.parse(sp.get("f") || "{}"); } catch { return {}; }
}

export function DashboardView() {
  const { id = "" } = useParams();
  const [sp, setSp] = useSearchParams();
  const nav = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const { t } = useI18n();
  const { can, org } = useAuth();
  const [active, setActive] = useState<ActiveFilters>(() => filtersFromUrl(sp));
  const [editing, setEditing] = useState(false);
  const [designer, setDesigner] = useState<{ widget?: Widget | null } | null>(null);
  const [evidence, setEvidence] = useState<{ title: string; sql?: string } | null>(null);
  const [tmplOpen, setTmplOpen] = useState(false);
  const canEdit = can("dashboard.write");

  const dash = useQuery({ queryKey: ["dashboard", id], queryFn: () => api.get<Dashboard>(`/dashboards/${id}`) });
  const filters: Filter[] = useMemo(() => Object.values(active), [active]);
  const data = useQuery({
    queryKey: ["dashboard-data", id, filters],
    queryFn: () => api.post(`/dashboards/${id}/data`, { filters }),
    enabled: !!dash.data,
    placeholderData: (prev) => prev,
  });

  useEffect(() => {
    const next = new URLSearchParams(sp);
    if (Object.keys(active).length) next.set("f", JSON.stringify(active));
    else next.delete("f");
    next.delete("new");
    setSp(next, { replace: true });
  }, [active]); // eslint-disable-line react-hooks/exhaustive-deps

  const d = dash.data;
  const prefs = useMemo(() => ({ currency: d?.config?.number_format?.currency || org?.settings?.currency || "INR", locale: org?.settings?.locale || "en-IN",
    compact: d?.config?.number_format?.compact ?? true }), [d, org]);
  const colTypes = useMemo(() => Object.fromEntries((d?.schema?.columns ?? []).map((c) => [c.name, c.data_type])), [d]);

  const refresh = () => { qc.invalidateQueries({ queryKey: ["dashboard", id] }); qc.invalidateQueries({ queryKey: ["dashboard-data", id] }); };
  const mutate = useMutation({
    mutationFn: async (fn: () => Promise<unknown>) => fn(),
    onSuccess: refresh,
    onError: (e) => toast.show(errMsg(e), "error"),
  });

  const saveLayout = useRef<ReturnType<typeof setTimeout>>(undefined);
  const onLayout = useCallback((layout: Layout[]) => {
    if (!editing) return;
    clearTimeout(saveLayout.current);
    saveLayout.current = setTimeout(() => {
      api.put(`/dashboards/${id}/layout`, { items: layout.map((l) => ({ id: l.i, x: l.x, y: l.y, w: l.w, h: l.h })) }).catch((e) => toast.show(errMsg(e), "error"));
    }, 600);
  }, [editing, id, toast]);

  const crossFilter = (w: Widget, category: unknown, series?: string) => {
    const cfg = w.config?.chart;
    const chartData = data.data?.widgets?.[w.id]?.chart;
    const dim = chartData?.dimension ?? cfg?.dimension;
    if (!dim?.column || category === "Other" || category === undefined) return;
    const next = { ...active };
    if (chartData?.is_time && typeof category === "string") {
      const r = periodRange(category, chartData.granularity);
      if (r) next[`x:${dim.column}`] = { column: dim.column, op: "date_range", values: r };
    } else {
      next[`x:${dim.column}`] = { column: dim.column, op: "in", values: [category === "(Blank)" ? null : category] };
    }
    const sdim = chartData?.series_dimension ?? cfg?.series_dimension;
    if (sdim?.column && series && series !== "Other" && !chartData?.is_time) next[`x:${sdim.column}`] = { column: sdim.column, op: "in", values: [series] };
    setActive(next);
    toast.show(`Filtered to ${String(category)}. Click the × on the filter chip to remove it.`);
  };

  if (dash.isLoading) return <Loading />;
  if (dash.error) return <ErrorBox error={dash.error} onRetry={() => dash.refetch()} />;
  if (!d) return null;

  const visible = d.widgets.filter((w) => !w.hidden);
  const hidden = d.widgets.filter((w) => w.hidden);
  const layouts = {
    lg: visible.map((w) => ({ i: w.id, x: w.layout.x ?? 0, y: w.layout.y ?? 0, w: w.layout.w ?? 6, h: w.layout.h ?? 5, minW: 2, minH: 2 })),
  };
  const rows = data.data?.row_count;

  const exportAs = async (format: "pdf" | "xlsx") => {
    try {
      toast.show(`Preparing ${format.toUpperCase()}…`);
      await download(`/dashboards/${id}/export`, { method: "POST", json: { format, filters } }, `dashboard.${format}`);
    } catch (e) { toast.show(errMsg(e), "error"); }
  };

  const renderBody = (w: Widget) => {
    const r = data.data?.widgets?.[w.id];
    if (w.widget_type === "insights") return <InsightsPanel datasetId={d.dataset_id} filters={filters} compact max={w.config?.max_items ?? 6} />;
    if (w.widget_type === "quality") return d.quality ? <QualitySummary quality={d.quality} datasetId={d.dataset_id} compact /> : null;
    if (w.widget_type === "text") return <p style={{ whiteSpace: "pre-wrap" }}>{w.config?.markdown}</p>;
    if (!r) return <div className="skeleton" style={{ height: "100%", minHeight: 60 }} />;
    if (r.error) return <ErrorBox error={r.error} />;
    if (r.kpi) return <KpiCard k={r.kpi} prefs={prefs} />;
    if (r.chart) {
      if (r.chart.type === "table") return <ResultTable data={r.chart} colTypes={colTypes} prefs={prefs} />;
      if (r.chart.type === "pivot") return <PivotView p={r.chart} prefs={prefs} />;
      const m0 = w.config?.chart?.measures?.[0];
      const col = d.schema?.columns.find((c) => c.name === m0?.column);
      const fmt = !m0 || ["count_rows", "count", "count_distinct"].includes(m0.agg) ? { kind: "number" as const }
        : col?.data_type === "currency" ? { kind: "currency" as const, currency: prefs.currency } : col?.data_type === "percentage" ? { kind: "percent" as const } : { kind: "number" as const };
      return <Chart data={r.chart} valueFormat={fmt} onSelect={editing ? undefined : (c, s) => crossFilter(w, c, s)} />;
    }
    return null;
  };

  return (
    <div>
      <div className="page-head">
        <div className="grow">
          <h1>{d.name}</h1>
          <p className="row wrap small" style={{ gap: 10 }}>
            <Link to={`/datasets/${d.dataset_id}`}>{d.dataset?.name}</Link>
            <span className="num">{rows !== undefined ? t("dash.showing", { n: rows.toLocaleString("en-IN"), total: (d.dataset?.rows ?? 0).toLocaleString("en-IN") }) : ""}</span>
            {data.isFetching && <Spinner />}
          </p>
        </div>
        <div className="dash-toolbar">
          {canEdit && <button className={`btn ${editing ? "primary" : ""}`} onClick={() => setEditing((e) => !e)}><Pencil />{editing ? t("dash.done") : t("dash.edit")}</button>}
          {canEdit && <button className="btn" onClick={() => setDesigner({ widget: null })}><Plus />{t("dash.addWidget")}</button>}
          <Menu trigger={(tg) => <button className="btn" onClick={tg}><Download />{t("action.export")}</button>}>
            {(close) => (<>
              <button onClick={() => { close(); exportAs("pdf"); }}><FileText />Dashboard as PDF</button>
              <button onClick={() => { close(); exportAs("xlsx"); }}><Table2 />Dashboard + filtered data (Excel)</button>
              <button onClick={() => { close(); download(`/datasets/${d.dataset_id}/export`, { method: "POST", json: { format: "csv", filters } }, "data.csv").catch((e) => toast.show(errMsg(e), "error")); }}><Download />Filtered rows (CSV)</button>
            </>)}
          </Menu>
          <Menu trigger={(tg) => <button className="btn icon" onClick={tg} aria-label="More actions"><MoreHorizontal /></button>}>
            {(close) => (<>
              <button onClick={() => { close(); nav(`/datasets/${d.dataset_id}?tab=explorer&f=${encodeURIComponent(JSON.stringify(active))}`); }}><Table2 />{t("dash.explore")}</button>
              <button onClick={() => { close(); nav(`/ask?dataset=${d.dataset_id}`); }}><BarChart3 />{t("nav.ask")}</button>
              <button onClick={() => { close(); nav(`/reports?dataset=${d.dataset_id}&dashboard=${d.id}&f=${encodeURIComponent(JSON.stringify(filters))}`); }}><FileText />{t("reports.generate")}</button>
              {canEdit && <>
                <hr />
                <button onClick={() => { close(); setTmplOpen(true); }}><LayoutTemplate />{t("dash.saveTemplate")}</button>
                <button onClick={() => { close(); mutate.mutate(async () => { const n = await api.post(`/dashboards/${id}/duplicate`); nav(`/dashboards/${n.id}`); }); }}><Copy />{t("action.duplicate")}</button>
                <button onClick={() => { close(); if (confirm("Rebuild this dashboard from the current data? Your widget changes will be replaced.")) mutate.mutate(() => api.post(`/dashboards/${id}/reset`)); }}><RotateCcw />{t("action.reset")}</button>
                <button onClick={() => { close(); const name = prompt("Dashboard name", d.name); if (name) mutate.mutate(() => api.patch(`/dashboards/${id}`, { name })); }}><Pencil />Rename</button>
                <button onClick={() => { close(); if (confirm(`Delete dashboard “${d.name}”? The dataset is kept.`)) api.del(`/dashboards/${id}`).then(() => { qc.invalidateQueries(); nav("/dashboards"); }); }}><Trash2 />{t("action.delete")}</button>
              </>}
            </>)}
          </Menu>
        </div>
      </div>

      {d.dataset?.is_demo && <DemoBanner text={t("dash.demo")} />}

      <div className="row" style={{ alignItems: "flex-start", gap: 8 }}>
        <div className="grow">
          <FilterBar defs={d.config?.filters ?? []} schema={d.schema} datasetId={d.dataset_id} active={active} onChange={setActive} />
        </div>
        <SavedFilters dashboardId={id} saved={d.saved_filters ?? []} active={active} onApply={setActive} onChanged={refresh} />
      </div>

      {editing && hidden.length > 0 && (
        <div className="note row wrap" style={{ marginBottom: 12 }}>
          Hidden widgets: {hidden.map((w) => <button key={w.id} className="btn small" onClick={() => mutate.mutate(() => api.patch(`/dashboards/${id}/widgets/${w.id}`, { hidden: false }))}><Eye />{w.title}</button>)}
        </div>
      )}

      {visible.length === 0 ? (
        <div className="panel"><div className="empty"><h3>This dashboard has no widgets</h3><p className="muted">Add KPIs and charts, or rebuild it automatically from the data.</p>
          {canEdit && <div className="row" style={{ justifyContent: "center", marginTop: 12 }}><button className="btn primary" onClick={() => setDesigner({ widget: null })}><Plus />{t("dash.addWidget")}</button>
            <button className="btn" onClick={() => mutate.mutate(() => api.post(`/dashboards/${id}/reset`))}><RotateCcw />Build automatically</button></div>}</div></div>
      ) : (
        <div className={editing ? "editing" : undefined}>
          <Grid className="layout" layouts={layouts} breakpoints={{ lg: 1000, md: 760, sm: 0 }} cols={{ lg: 12, md: 12, sm: 1 }} rowHeight={44} margin={[14, 14]}
            containerPadding={[0, 0]} isDraggable={editing} isResizable={editing} draggableHandle=".widget-head" onLayoutChange={(l) => onLayout(l)} compactType="vertical">
            {visible.map((w) => (
              <div key={w.id}>
                <section className={`widget ${w.widget_type === "kpi" ? "kpi-widget" : ""}`} aria-label={w.title}>
                  {(w.widget_type !== "kpi" || editing) && (
                    <div className="widget-head">
                      <h3 title={w.title}>{w.title}</h3>
                      {data.data?.widgets?.[w.id]?.chart?.meta?.truncated && <span className="subtle" title="Showing the top groups">top</span>}
                      <WidgetMenu w={w} canEdit={canEdit}
                        onEdit={() => setDesigner({ widget: w })}
                        onDuplicate={() => mutate.mutate(() => api.post(`/dashboards/${id}/widgets/${w.id}/duplicate`))}
                        onHide={() => mutate.mutate(() => api.patch(`/dashboards/${id}/widgets/${w.id}`, { hidden: true }))}
                        onDelete={() => confirm(`Remove “${w.title}”?`) && mutate.mutate(() => api.del(`/dashboards/${id}/widgets/${w.id}`))}
                        onType={(type) => mutate.mutate(() => api.patch(`/dashboards/${id}/widgets/${w.id}`, { config: { ...w.config, chart: { ...w.config.chart, type } } }))}
                        onEvidence={() => setEvidence({ title: w.title, sql: data.data?.widgets?.[w.id]?.chart?.evidence?.sql })}
                      />
                    </div>
                  )}
                  <div className="widget-body">{renderBody(w)}</div>
                </section>
              </div>
            ))}
          </Grid>
        </div>
      )}

      {designer && d.schema && (
        <WidgetDesigner dashboardId={id} datasetId={d.dataset_id} schema={d.schema} widget={designer.widget} onClose={() => setDesigner(null)} onSaved={refresh} />
      )}
      {evidence && (
        <Drawer title={evidence.title} onClose={() => setEvidence(null)}>
          <Evidence title="This chart is computed with the query below against the uploaded dataset (current filters applied)." items={[
            { label: "Active filters", value: filters.length ? filters.map((f) => `${f.column} ${f.op} ${JSON.stringify(f.values ?? f.value)}`).join("; ") : "None" },
            { label: "SQL", value: evidence.sql, code: true },
          ]} />
        </Drawer>
      )}
      {tmplOpen && <SaveTemplate dashboardId={id} name={d.name} onClose={() => setTmplOpen(false)} />}
    </div>
  );
}

function WidgetMenu({ w, canEdit, onEdit, onDuplicate, onHide, onDelete, onType, onEvidence }: {
  w: Widget; canEdit: boolean; onEdit: () => void; onDuplicate: () => void; onHide: () => void; onDelete: () => void; onType: (t: ChartType) => void; onEvidence: () => void;
}) {
  return (
    <Menu trigger={(tg) => <button className="btn ghost icon small widget-menu" onClick={tg} aria-label={`Actions for ${w.title}`}><MoreHorizontal /></button>}>
      {(close) => (<>
        {w.widget_type === "chart" && <button onClick={() => { close(); onEvidence(); }}><Eye />How is this calculated?</button>}
        {canEdit && <>
          <button onClick={() => { close(); onEdit(); }}><Pencil />Edit</button>
          {w.widget_type === "chart" && (
            <div style={{ padding: "4px 10px" }}>
              <div className="subtle" style={{ marginBottom: 4 }}>Change chart type</div>
              <div className="row wrap" style={{ gap: 4 }}>
                {QUICK_TYPES.map((t) => <button key={t} className={`btn small ${w.config?.chart?.type === t ? "primary" : ""}`} style={{ width: "auto" }} onClick={() => { close(); onType(t); }}>{t.replace(/_/g, " ")}</button>)}
              </div>
            </div>
          )}
          <button onClick={() => { close(); onDuplicate(); }}><Copy />Duplicate</button>
          <button onClick={() => { close(); onHide(); }}><EyeOff />Hide</button>
          <hr />
          <button onClick={() => { close(); onDelete(); }}><Trash2 />Remove</button>
        </>}
      </>)}
    </Menu>
  );
}

function SavedFilters({ dashboardId, saved, active, onApply, onChanged }: { dashboardId: string; saved: { id: string; name: string; filters: Filter[] }[];
  active: ActiveFilters; onApply: (a: ActiveFilters) => void; onChanged: () => void }) {
  const toast = useToast();
  return (
    <Menu trigger={(tg) => <button className="btn" onClick={tg} aria-label="Saved filters" title="Saved filters"><Bookmark /></button>}>
      {(close) => (
        <div style={{ width: 260 }}>
          {saved.length === 0 && <div className="subtle" style={{ padding: 8 }}>No saved views yet.</div>}
          {saved.map((s) => (
            <div key={s.id} className="row">
              <button className="grow" onClick={() => { close(); onApply(Object.fromEntries(s.filters.map((f, i) => [`s:${i}:${f.column}`, f]))); }}>{s.name}</button>
              <button style={{ width: 34 }} aria-label={`Delete ${s.name}`} onClick={async () => { await api.del(`/dashboards/${dashboardId}/saved-filters/${s.id}`); onChanged(); }}><Trash2 /></button>
            </div>
          ))}
          <hr />
          <button disabled={!Object.keys(active).length} onClick={async () => {
            close();
            const name = prompt("Name this filtered view");
            if (!name) return;
            try { await api.post(`/dashboards/${dashboardId}/saved-filters`, { name, filters: Object.values(active) }); onChanged(); toast.show("View saved"); }
            catch (e) { toast.show(errMsg(e), "error"); }
          }}><Plus />Save current filters</button>
        </div>
      )}
    </Menu>
  );
}

function SaveTemplate({ dashboardId, name, onClose }: { dashboardId: string; name: string; onClose: () => void }) {
  const toast = useToast();
  const [n, setN] = useState(`${name} template`);
  const [desc, setDesc] = useState("");
  const m = useMutation({
    mutationFn: () => api.post("/templates/from-dashboard", { dashboard_id: dashboardId, name: n, description: desc }),
    onSuccess: () => { toast.show("Template saved. Apply it to any dataset from the Templates page."); onClose(); },
  });
  return (
    <Modal title="Save as template" onClose={onClose} footer={<><button className="btn" onClick={onClose}>Cancel</button>
      <button className="btn primary" disabled={!n || m.isPending} onClick={() => m.mutate()}>Save template</button></>}>
      <div className="stack-4">
        <p className="muted">Templates remember what kind of column each widget needs (a date, a money amount, a category…), not the exact column names, so they work on other files too.</p>
        {m.error && <ErrorBox error={m.error} />}
        <label className="field"><span>Name</span><input className="input" value={n} onChange={(e) => setN(e.target.value)} /></label>
        <label className="field"><span>Description</span><textarea className="input" rows={3} value={desc} onChange={(e) => setDesc(e.target.value)} /></label>
      </div>
    </Modal>
  );
}
