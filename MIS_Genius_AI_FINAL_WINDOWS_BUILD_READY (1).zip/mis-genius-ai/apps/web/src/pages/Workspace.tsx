import { useState } from "react";
import { Link, useNavigate, useSearchParams } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { ArrowUpRight, Code2, LayoutDashboard, Plus, Send, Trash2, Upload } from "lucide-react";
import { api, download } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { errMsg, useToast } from "../lib/ui";
import { relTime } from "../lib/format";
import type { Dataset } from "../lib/types";
import { Chart } from "../components/Chart";
import { Evidence, ResultTable } from "../components/DataViews";
import { UploadFlow } from "../components/UploadFlow";
import { DemoButtons } from "./Home";
import { DemoBanner, Drawer, Empty, ErrorBox, Loading, Modal, Spinner } from "../components/ui";

// ---------------------------------------------------------------- dashboards list
export function DashboardsPage() {
  const { t } = useI18n();
  const { can } = useAuth();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ["dashboards"], queryFn: () => api.get("/dashboards") });
  const [creating, setCreating] = useState(false);
  return (
    <div>
      <div className="page-head">
        <div><h1>{t("nav.dashboards")}</h1><p>Each dataset gets an automatic dashboard. Add your own, duplicate them or build one from a template.</p></div>
        {can("dashboard.write") && <button className="btn primary" onClick={() => setCreating(true)}><Plus />New dashboard</button>}
      </div>
      {q.isLoading ? <Loading /> : !q.data?.length ? (
        <div className="panel"><Empty title={t("empty.dashboards")} action={<Link className="btn primary" to="/upload"><Upload />{t("action.upload")}</Link>}>Upload a file and a dashboard is built for it automatically.</Empty></div>
      ) : (
        <div className="grid-auto">
          {q.data.map((d: any) => (
            <Link key={d.id} to={`/dashboards/${d.id}`} className="list-card">
              <div className="row between" style={{ alignItems: "flex-start" }}><h3 className="ellipsis">{d.name}</h3>{d.is_demo && <span className="badge demo">Demo</span>}</div>
              <span className="muted small ellipsis">{d.dataset_name}</span>
              <div className="meta"><span>{d.widget_count} widgets</span>{d.auto_generated && <span>auto-generated</span>}<span>{relTime(d.updated_at)}</span></div>
            </Link>
          ))}
        </div>
      )}
      {creating && <NewDashboard onClose={() => setCreating(false)} onCreated={(id) => nav(`/dashboards/${id}`)} />}
    </div>
  );
}

export function NewDashboard({ onClose, onCreated, templateId }: { onClose: () => void; onCreated: (id: string) => void; templateId?: string }) {
  const datasets = useQuery({ queryKey: ["datasets"], queryFn: () => api.get<Dataset[]>("/datasets") });
  const templates = useQuery({ queryKey: ["templates"], queryFn: () => api.get("/templates") });
  const [ds, setDs] = useState("");
  const [mode, setMode] = useState<string>(templateId ? `t:${templateId}` : "auto");
  const [name, setName] = useState("");
  const [binding, setBinding] = useState<any>(null);
  const qc = useQueryClient();
  const dsId = ds || datasets.data?.[0]?.id || "";
  const tId = mode.startsWith("t:") ? mode.slice(2) : null;
  const preview = useQuery({ queryKey: ["binding", tId, dsId], queryFn: () => api.post(`/templates/${tId}/preview-binding`, { dataset_id: dsId }), enabled: !!tId && !!dsId });
  const create = useMutation({
    mutationFn: () => api.post("/dashboards", { dataset_id: dsId, name: name || null, auto: mode === "auto", template_id: tId, binding: binding ?? undefined }),
    onSuccess: (d) => { qc.invalidateQueries(); onCreated(d.id); },
  });
  const tmpl = templates.data?.find((x: any) => x.id === tId);
  return (
    <Modal title="New dashboard" onClose={onClose} footer={<><button className="btn" onClick={onClose}>Cancel</button>
      <button className="btn primary" disabled={!dsId || create.isPending} onClick={() => create.mutate()}>{create.isPending && <Spinner />}Create dashboard</button></>}>
      <div className="stack-4">
        {create.error && <ErrorBox error={create.error} />}
        <label className="field"><span>Dataset</span>
          <select className="input" value={dsId} onChange={(e) => setDs(e.target.value)}>{datasets.data?.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>
        <label className="field"><span>Start from</span>
          <select className="input" value={mode} onChange={(e) => { setMode(e.target.value); setBinding(null); }}>
            <option value="auto">Automatic dashboard (recommended)</option><option value="blank">Blank dashboard</option>
            {templates.data?.map((t: any) => <option key={t.id} value={`t:${t.id}`}>Template: {t.name}</option>)}
          </select></label>
        <label className="field"><span>Name (optional)</span><input className="input" value={name} onChange={(e) => setName(e.target.value)} /></label>
        {tId && preview.data && (
          <div className="stack-4">
            <p className="muted small">The template needs these kinds of columns. We matched them to your dataset; change any match that is wrong. Widgets without a match are left out — nothing is invented.</p>
            <div className="table-wrap"><table className="data"><thead><tr><th>Template needs</th><th>Your column</th></tr></thead><tbody>
              {preview.data.details.map((s: any) => {
                const slot = tmpl?.slots?.find((x: any) => x.id === s.slot);
                return (
                  <tr key={s.slot}><td>{s.label} <span className="subtle">({slot?.type_group})</span></td>
                    <td><select className="input small" value={(binding ?? {})[s.slot] ?? s.column ?? ""} onChange={(e) => setBinding({ ...(binding ?? Object.fromEntries(preview.data.details.filter((x: any) => x.column).map((x: any) => [x.slot, x.column]))), [s.slot]: e.target.value })}>
                      <option value="">No match — skip</option>
                      <ColumnOptions datasetId={dsId} />
                    </select></td></tr>
                );
              })}
            </tbody></table></div>
          </div>
        )}
      </div>
    </Modal>
  );
}

function ColumnOptions({ datasetId }: { datasetId: string }) {
  const q = useQuery({ queryKey: ["schema", datasetId], queryFn: () => api.get(`/datasets/${datasetId}/schema`), enabled: !!datasetId });
  return <>{q.data?.schema.columns.map((c: any) => <option key={c.name} value={c.name}>{c.name} ({c.data_type})</option>)}</>;
}

// ---------------------------------------------------------------- upload page
export function UploadPage() {
  const { t } = useI18n();
  const health = useQuery({ queryKey: ["health"], queryFn: () => api.get("/health") });
  const files = useQuery({ queryKey: ["files"], queryFn: () => api.get("/files") });
  return (
    <div className="stack-5">
      <div className="page-head"><div><h1>{t("nav.upload")}</h1><p>Excel workbooks with several sheets, title rows, merged headers, totals and Indian number formats are handled automatically.</p></div>
        <Link to="/sources" className="btn">Connect Google Sheets, a URL or a database</Link></div>
      <UploadFlow maxMb={health.data?.max_upload_mb ?? 100} />
      <DemoButtons />
      {files.data?.length > 0 && (
        <section>
          <div className="section-title"><h2>Recent uploads</h2></div>
          <div className="table-wrap"><table className="data"><thead><tr><th>File</th><th>Status</th><th className="n">Tables</th><th className="n">Size</th><th>When</th><th /></tr></thead>
            <tbody>{files.data.map((f: any) => (
              <tr key={f.id}><td>{f.name}</td><td>{f.status === "failed" ? <span className="badge bad" title={f.error}>failed</span> : <span className="badge good">{f.status}</span>}{f.error && <div className="subtle">{f.error}</div>}</td>
                <td className="n">{f.tables}</td><td className="n">{(f.size / 1024).toFixed(0)} KB</td><td>{relTime(f.created_at)}</td>
                <td className="n"><button className="btn small ghost" onClick={() => download(`/files/${f.id}/download`, {}, f.name)}>Original</button></td></tr>
            ))}</tbody></table></div>
        </section>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- ask AI
interface Turn { q: string; res?: any; error?: unknown; loading?: boolean }

export function AskPage() {
  const { t, lang } = useI18n();
  const [sp, setSp] = useSearchParams();
  const nav = useNavigate();
  const datasets = useQuery({ queryKey: ["datasets"], queryFn: () => api.get<Dataset[]>("/datasets") });
  const dsId = sp.get("dataset") || datasets.data?.[0]?.id || "";
  const ds = datasets.data?.find((d) => d.id === dsId);
  const sugg = useQuery({ queryKey: ["suggestions", dsId], queryFn: () => api.get(`/datasets/${dsId}/suggestions`), enabled: !!dsId });
  const status = useQuery({ queryKey: ["ai-status"], queryFn: () => api.get("/ai/status") });
  const [text, setText] = useState(sp.get("q") ?? "");
  const [turns, setTurns] = useState<Turn[]>([]);
  const [how, setHow] = useState<any>(null);
  const ask = async (question: string) => {
    if (!question.trim() || !dsId) return;
    setText("");
    setTurns((x) => [...x, { q: question, loading: true }]);
    try {
      const res = await api.post(`/datasets/${dsId}/ask`, { question, language: "auto" });
      setTurns((x) => x.map((tt, i) => (i === x.length - 1 ? { q: question, res } : tt)));
      if (res.dashboard_id) nav(`/dashboards/${res.dashboard_id}`);
    } catch (e) {
      setTurns((x) => x.map((tt, i) => (i === x.length - 1 ? { q: question, error: e } : tt)));
    }
  };
  if (datasets.isLoading) return <Loading />;
  if (!datasets.data?.length) return <div className="panel"><Empty title={t("empty.datasets")} action={<Link className="btn primary" to="/upload">{t("action.upload")}</Link>}>{t("empty.datasets.sub")}</Empty></div>;
  return (
    <div style={{ maxWidth: 980 }}>
      <div className="page-head">
        <div><h1>{t("ask.title")}</h1><p>{t("ask.sub")}</p></div>
        <div className="col" style={{ minWidth: 260 }}>
          <select className="input" aria-label="Dataset" value={dsId} onChange={(e) => { setSp({ dataset: e.target.value }); setTurns([]); }}>
            {datasets.data.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}
          </select>
          <span className="subtle">{status.data?.mode === "ai" ? `AI planner: ${status.data.provider} · answers verified against results` : "Rule-based planner (no AI key needed) · English, Hindi and Hinglish"}</span>
        </div>
      </div>
      {ds?.is_demo && <DemoBanner text={t("dash.demo")} />}
      <div className="chat">
        {turns.length === 0 && sugg.data && (
          <div className="stack-4">
            <p className="muted">{lang === "hi" ? "शुरू करने के लिए कुछ प्रश्न:" : "Try one of these:"}</p>
            <div className="suggestions">
              {[...sugg.data.questions.map((q: any) => (lang === "hi" ? q.hi : q.en)), lang === "hi" ? "पिछले महीने की तुलना में क्या बदला?" : "What changed compared with last month?",
                lang === "hi" ? "असामान्य लेन-देन दिखाओ" : "Find unusual records", lang === "hi" ? "कौन से KPI ट्रैक करने चाहिए?" : "Which KPIs should I track?"].slice(0, 7)
                .map((q: string) => <button key={q} onClick={() => ask(q)}>{q}</button>)}
            </div>
          </div>
        )}
        {turns.map((tt, i) => (
          <div key={i} className="col" style={{ gap: 10 }}>
            <div className="msg user">{tt.q}</div>
            <div className="msg bot panel panel-body stack-4">
              {tt.loading && <Spinner label="Working it out from your data…" />}
              {tt.error ? <ErrorBox error={tt.error} /> : null}
              {tt.res && (
                <>
                  <p className="answer">{tt.res.answer}</p>
                  {tt.res.chart && tt.res.chart.type !== "table" && <div style={{ height: 280 }}><Chart data={tt.res.chart} /></div>}
                  {tt.res.table && tt.res.table.rows.length > 0 && <div style={{ maxHeight: 320, overflow: "auto" }}><ResultTable data={tt.res.table} maxRows={100} /></div>}
                  {tt.res.kpis && <ul className="insight-list">{tt.res.kpis.map((k: any) => <li key={k.title}><ArrowUpRight /><span><strong>{k.title}</strong> {k.description && <span className="muted">— {k.description}</span>}</span></li>)}</ul>}
                  <div className="row wrap">
                    <button className="evidence-link" onClick={() => setHow(tt.res)}><Code2 size={12} style={{ verticalAlign: -2 }} /> {t("ask.how")}</button>
                    <span className="subtle">{tt.res.answer_source === "ai" ? "Worded by AI, numbers verified" : "Computed answer"} · intent: {tt.res.intent.replace(/_/g, " ")}</span>
                    {(tt.res.suggestions ?? []).map((s: string) => <button key={s} className="badge info" style={{ border: 0, cursor: "pointer" }} onClick={() => ask(s)}>{s}</button>)}
                  </div>
                </>
              )}
            </div>
          </div>
        ))}
      </div>
      <form className="composer" onSubmit={(e) => { e.preventDefault(); ask(text); }}>
        <input className="input" style={{ height: 44 }} value={text} onChange={(e) => setText(e.target.value)} placeholder={t("ask.placeholder")} aria-label="Question" />
        <button className="btn primary" style={{ height: 44 }} disabled={!text.trim()}><Send />{t("action.ask")}</button>
      </form>
      {how && (
        <Drawer title={t("ask.how")} onClose={() => setHow(null)}>
          <Evidence title="The question was converted into this plan and run on the dataset. No number in the answer comes from anywhere else." items={[
            { label: "Question", value: how.question },
            { label: "Understood as", value: how.plan?.reason || how.intent },
            { label: "Planner", value: how.plan?.source === "ai" ? "AI (validated against the schema)" : "Rule-based parser" },
            { label: "What was computed", value: how.explanation },
            { label: "Plan", value: JSON.stringify(how.plan, null, 2), code: true },
            { label: "SQL", value: how.sql, code: true },
            { label: "AI wording rejected", value: how.ai_answer_rejected ? `${how.ai_answer_rejected.text} (unsupported numbers: ${how.ai_answer_rejected.unsupported_numbers.join(", ")})` : undefined },
          ]} />
        </Drawer>
      )}
    </div>
  );
}

// ---------------------------------------------------------------- templates
export function TemplatesPage() {
  const { can } = useAuth();
  const nav = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const q = useQuery({ queryKey: ["templates"], queryFn: () => api.get("/templates") });
  const [applying, setApplying] = useState<string | null>(null);
  const importT = async (f: File) => {
    const form = new FormData();
    form.append("file", f);
    try { await api.upload("/templates/import", form); qc.invalidateQueries({ queryKey: ["templates"] }); toast.show("Template imported"); }
    catch (e) { toast.show(errMsg(e), "error"); }
  };
  return (
    <div>
      <div className="page-head">
        <div><h1>Templates</h1><p>Templates describe the kinds of columns they need (a date, a money amount, a category), so one template works across files with different column names.</p></div>
        {can("dashboard.write") && <label className="btn"><Upload />Import template<input type="file" accept=".json" hidden onChange={(e) => e.target.files?.[0] && importT(e.target.files[0])} /></label>}
      </div>
      {q.isLoading ? <Loading /> : (
        <div className="grid-auto">
          {q.data?.map((t: any) => (
            <div key={t.id} className="list-card">
              <div className="row between"><h3>{t.name}</h3>{t.builtin ? <span className="badge accent">built-in</span> : <span className="badge">{t.source}</span>}</div>
              <p className="muted small">{t.description}</p>
              <div className="row wrap" style={{ gap: 4 }}>{t.slots.slice(0, 6).map((s: any) => <span key={s.id} className="type-chip">{s.label}</span>)}</div>
              <div className="meta"><span>{t.widget_count} widgets</span></div>
              <div className="row">
                {can("dashboard.write") && <button className="btn small primary" onClick={() => setApplying(t.id)}><LayoutDashboard />Use template</button>}
                <button className="btn small" onClick={() => download(`/templates/${t.id}/export`, {}, `${t.name}.json`)}>Export</button>
                {!t.builtin && can("dashboard.write") && <button className="btn small ghost icon" aria-label="Delete template" onClick={async () => { if (confirm(`Delete template “${t.name}”?`)) { await api.del(`/templates/${t.id}`); qc.invalidateQueries({ queryKey: ["templates"] }); } }}><Trash2 /></button>}
              </div>
            </div>
          ))}
        </div>
      )}
      {applying && <NewDashboard templateId={applying} onClose={() => setApplying(null)} onCreated={(id) => nav(`/dashboards/${id}`)} />}
    </div>
  );
}

// ---------------------------------------------------------------- reports
export function ReportsPage() {
  const { t, lang } = useI18n();
  const { can } = useAuth();
  const [sp] = useSearchParams();
  const nav = useNavigate();
  const qc = useQueryClient();
  const datasets = useQuery({ queryKey: ["datasets"], queryFn: () => api.get<Dataset[]>("/datasets") });
  const reports = useQuery({ queryKey: ["reports"], queryFn: () => api.get("/reports") });
  const [ds, setDs] = useState(sp.get("dataset") ?? "");
  const [rl, setRl] = useState<string>(lang);
  const gen = useMutation({
    mutationFn: () => api.post("/reports", { dataset_id: ds || datasets.data?.[0]?.id, dashboard_id: sp.get("dashboard") || null, language: rl,
      filters: (() => { try { return JSON.parse(sp.get("f") || "[]"); } catch { return []; } })() }),
    onSuccess: (r) => { qc.invalidateQueries({ queryKey: ["reports"] }); nav(`/reports/${r.id}`); },
  });
  return (
    <div>
      <div className="page-head"><div><h1>{t("reports.title")}</h1><p>{t("reports.sub")}</p></div></div>
      {can("report.write") && datasets.data?.length ? (
        <div className="panel panel-body row wrap" style={{ alignItems: "flex-end", marginBottom: 24 }}>
          <label className="field" style={{ flex: "1 1 280px" }}><span>Dataset</span>
            <select className="input" value={ds || datasets.data[0].id} onChange={(e) => setDs(e.target.value)}>{datasets.data.map((d) => <option key={d.id} value={d.id}>{d.name}</option>)}</select></label>
          <label className="field" style={{ width: 160 }}><span>{t("common.language")}</span>
            <select className="input" value={rl} onChange={(e) => setRl(e.target.value)}><option value="en">English</option><option value="hi">हिन्दी</option></select></label>
          <button className="btn primary" disabled={gen.isPending} onClick={() => gen.mutate()}>{gen.isPending && <Spinner />}{t("reports.generate")}</button>
          {sp.get("f") && sp.get("f") !== "[]" && <span className="subtle">Dashboard filters will be applied.</span>}
          {gen.error && <ErrorBox error={gen.error} />}
        </div>
      ) : null}
      {reports.isLoading ? <Loading /> : !reports.data?.length ? <Empty title="No reports yet">Generate an executive report from any dataset.</Empty> : (
        <div className="table-wrap"><table className="data"><thead><tr><th>Report</th><th>Language</th><th>Written by</th><th>Created</th></tr></thead>
          <tbody>{reports.data.map((r: any) => <tr key={r.id}><td><Link to={`/reports/${r.id}`}>{r.title}</Link></td><td>{r.language === "hi" ? "हिन्दी" : "English"}</td>
            <td>{r.generated_by === "ai" ? "AI (grounded)" : "Computed"}</td><td>{relTime(r.created_at)}</td></tr>)}</tbody></table></div>
      )}
    </div>
  );
}

export function ReportView({ id }: { id: string }) {
  const toast = useToast();
  const nav = useNavigate();
  const { can } = useAuth();
  const q = useQuery({ queryKey: ["report", id], queryFn: () => api.get(`/reports/${id}`) });
  if (q.isLoading) return <Loading />;
  if (q.error) return <ErrorBox error={q.error} />;
  const r = q.data;
  const c = r.content;
  const dl = (fmt: string) => download(`/reports/${id}/download?format=${fmt}`, {}, `report.${fmt}`).catch((e) => toast.show(errMsg(e), "error"));
  return (
    <div style={{ maxWidth: 920 }}>
      <div className="page-head">
        <div><h1>{r.title}</h1><p className="num">{c.scope.dataset} · {c.scope.rows?.toLocaleString("en-IN")} records{c.scope.date_from ? ` · ${c.scope.date_from} to ${c.scope.date_to}` : ""} · {relTime(r.created_at)}</p></div>
        <div className="row wrap">
          <button className="btn primary" onClick={() => dl("pdf")}>PDF</button>
          <button className="btn" onClick={() => dl("xlsx")}>Excel</button>
          <button className="btn" onClick={() => dl("html")}>HTML</button>
          {can("report.write") && <button className="btn ghost icon" aria-label="Delete report" onClick={async () => { if (confirm("Delete this report?")) { await api.del(`/reports/${id}`); nav("/reports"); } }}><Trash2 /></button>}
        </div>
      </div>
      {c.scope.is_demo && <DemoBanner text="Demo data — synthetic records, not real business data." />}
      {r.language === "hi" && <p className="note" style={{ marginBottom: 16 }}>Hindi PDFs open as a print-ready page: use Print → Save as PDF for correct Devanagari rendering.</p>}
      <div className="stack-5">
        {c.sections.map((s: any) => (
          <section key={s.key} className="panel panel-body">
            <h2 style={{ marginBottom: 12 }}>{s.heading}</h2>
            {s.kpis && (
              <div className="table-wrap"><table className="data"><thead><tr><th>KPI</th><th className="n">Value</th><th className="n">Change</th><th>Period</th></tr></thead>
                <tbody>{s.kpis.map((k: any) => <tr key={k.title}><td>{k.title}<div className="subtle">{k.calculation}</div></td><td className="n"><strong>{k.display}</strong></td>
                  <td className="n" style={{ color: k.change_pct > 0 ? "var(--positive)" : k.change_pct < 0 ? "var(--danger)" : undefined }}>{k.change_pct === null || k.change_pct === undefined ? "" : `${k.change_pct >= 0 ? "+" : ""}${k.change_pct.toFixed(1)}%`}</td>
                  <td className="small">{k.period}</td></tr>)}</tbody></table></div>
            )}
            {s.items?.length > 0 && <ul style={{ margin: 0, paddingLeft: 20 }}>{s.items.map((it: any, i: number) => <li key={i} style={{ marginBottom: 6 }}>{it.text}</li>)}</ul>}
          </section>
        ))}
        <p className="subtle">{c.disclaimer} Generated by: {c.generated_by === "ai" ? `${c.provider} (every number checked against computed facts)` : "the analytics engine"}.</p>
      </div>
    </div>
  );
}
