import { Link, useNavigate } from "react-router-dom";
import { useMutation, useQuery, useQueryClient } from "@tanstack/react-query";
import { LayoutDashboard, Sparkles } from "lucide-react";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { relTime } from "../lib/format";
import { useToast, errMsg } from "../lib/ui";
import { UploadFlow } from "../components/UploadFlow";
import { QualityBadge, Spinner } from "../components/ui";
import type { Dataset } from "../lib/types";

export function DemoButtons() {
  const { t } = useI18n();
  const nav = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const m = useMutation({
    mutationFn: (which: string) => api.post(`/datasets/demo?which=${which}`),
    onSuccess: (r) => { qc.invalidateQueries(); nav(`/dashboards/${r.dashboard_id}?new=1`); },
    onError: (e) => toast.show(errMsg(e), "error"),
  });
  return (
    <div className="row wrap">
      <span className="muted">{t("home.demo")}</span>
      <button className="btn small" disabled={m.isPending} onClick={() => m.mutate("sales")}>{m.isPending && m.variables === "sales" ? <Spinner /> : <Sparkles />}{t("home.demo.sales")}</button>
      <button className="btn small" disabled={m.isPending} onClick={() => m.mutate("attendance")}>{m.isPending && m.variables === "attendance" ? <Spinner /> : <Sparkles />}{t("home.demo.attendance")}</button>
    </div>
  );
}

export function DatasetCard({ d }: { d: Dataset }) {
  return (
    <Link to={`/datasets/${d.id}`} className="list-card">
      <div className="row between" style={{ alignItems: "flex-start" }}>
        <h3 className="ellipsis">{d.name}</h3>
        {d.is_demo && <span className="badge demo">Demo</span>}
      </div>
      <div className="row wrap" style={{ gap: 6 }}>
        {d.domain && d.domain !== "general" && <span className="badge">{d.domain.replace(/_/g, " ")}</span>}
        <QualityBadge score={d.quality_score} />
      </div>
      <div className="meta num">
        <span>{d.rows?.toLocaleString("en-IN")} rows</span><span>{d.columns} columns</span><span>v{d.version_number}</span><span>{relTime(d.updated_at)}</span>
      </div>
    </Link>
  );
}

export function HomePage() {
  const { t } = useI18n();
  const { user, can } = useAuth();
  const datasets = useQuery({ queryKey: ["datasets"], queryFn: () => api.get<Dataset[]>("/datasets") });
  const dashboards = useQuery({ queryKey: ["dashboards"], queryFn: () => api.get("/dashboards") });
  const health = useQuery({ queryKey: ["health"], queryFn: () => api.get("/health"), staleTime: 300_000 });
  const first = (user?.full_name || "").split(" ")[0];
  return (
    <div className="stack-5">
      <div className="page-head">
        <div>
          <h1>{first ? `${first}, ` : ""}{t("home.title").charAt(0).toLowerCase() + t("home.title").slice(1)}</h1>
          <p>{t("home.sub")}</p>
        </div>
      </div>
      {can("data.write") ? (
        <div className="stack-4">
          <UploadFlow maxMb={health.data?.max_upload_mb ?? 100} />
          <DemoButtons />
        </div>
      ) : <div className="note">Your role can view and analyse dashboards. Ask an analyst or admin to upload data.</div>}

      {(dashboards.data?.length ?? 0) > 0 && (
        <section>
          <div className="section-title"><h2>{t("home.recent")}</h2><Link to="/dashboards">All dashboards</Link></div>
          <div className="grid-auto">
            {dashboards.data.slice(0, 6).map((d: any) => (
              <Link key={d.id} to={`/dashboards/${d.id}`} className="list-card">
                <div className="row between" style={{ alignItems: "flex-start" }}>
                  <h3 className="ellipsis">{d.name}</h3>{d.is_demo && <span className="badge demo">Demo</span>}
                </div>
                <span className="muted small ellipsis"><LayoutDashboard size={13} style={{ verticalAlign: -2 }} /> {d.dataset_name}</span>
                <div className="meta"><span>{d.widget_count} widgets</span><span>{relTime(d.updated_at)}</span></div>
              </Link>
            ))}
          </div>
        </section>
      )}
      {(datasets.data?.length ?? 0) > 0 && (
        <section>
          <div className="section-title"><h2>{t("home.datasets")}</h2><Link to="/datasets">All datasets</Link></div>
          <div className="grid-auto">{datasets.data!.slice(0, 6).map((d) => <DatasetCard key={d.id} d={d} />)}</div>
        </section>
      )}
    </div>
  );
}
