import { useEffect, useRef, useState, type ReactNode } from "react";
import { X } from "lucide-react";
import clsx from "clsx";

export function Spinner({ label }: { label?: string }) {
  return <span className="row"><span className="spinner" aria-hidden />{label && <span className="muted">{label}</span>}</span>;
}

export function Loading({ label = "Loading…" }: { label?: string }) {
  return <div className="empty"><Spinner label={label} /></div>;
}

export function ErrorBox({ error, onRetry }: { error: unknown; onRetry?: () => void }) {
  const msg = error instanceof Error ? error.message : String(error);
  return (
    <div className="error-box row between" role="alert">
      <span>{msg}</span>
      {onRetry && <button className="btn small" onClick={onRetry}>Try again</button>}
    </div>
  );
}

export function Empty({ title, children, action }: { title: string; children?: ReactNode; action?: ReactNode }) {
  return (
    <div className="empty">
      <h3>{title}</h3>
      {children && <p className="muted">{children}</p>}
      {action}
    </div>
  );
}

export function Modal({ title, onClose, children, footer, wide }: { title: ReactNode; onClose: () => void; children: ReactNode; footer?: ReactNode; wide?: boolean }) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [onClose]);
  return (
    <div className="overlay" onMouseDown={(e) => e.target === e.currentTarget && onClose()}>
      <div className={clsx("modal", wide && "wide")} role="dialog" aria-modal="true">
        <div className="modal-head">
          <h2 style={{ fontSize: 18 }}>{title}</h2>
          <button className="btn ghost icon" onClick={onClose} aria-label="Close"><X /></button>
        </div>
        <div className="modal-body">{children}</div>
        {footer && <div className="modal-foot">{footer}</div>}
      </div>
    </div>
  );
}

export function Drawer({ title, onClose, children }: { title: ReactNode; onClose: () => void; children: ReactNode }) {
  useEffect(() => {
    const fn = (e: KeyboardEvent) => e.key === "Escape" && onClose();
    window.addEventListener("keydown", fn);
    return () => window.removeEventListener("keydown", fn);
  }, [onClose]);
  return (
    <>
      <div className="overlay" style={{ background: "transparent" }} onMouseDown={onClose} />
      <aside className="drawer" role="dialog" aria-modal="true">
        <div className="modal-head">
          <h2 style={{ fontSize: 17 }}>{title}</h2>
          <button className="btn ghost icon" onClick={onClose} aria-label="Close"><X /></button>
        </div>
        <div className="modal-body">{children}</div>
      </aside>
    </>
  );
}

export function Tabs<T extends string>({ tabs, value, onChange }: { tabs: { id: T; label: ReactNode }[]; value: T; onChange: (v: T) => void }) {
  return (
    <div className="tabs" role="tablist">
      {tabs.map((t) => (
        <button key={t.id} role="tab" aria-selected={t.id === value} className={clsx(t.id === value && "active")} onClick={() => onChange(t.id)}>{t.label}</button>
      ))}
    </div>
  );
}

export function Menu({ trigger, children, align = "right" }: { trigger: (open: () => void) => ReactNode; children: (close: () => void) => ReactNode; align?: "left" | "right" }) {
  const [open, setOpen] = useState(false);
  const ref = useRef<HTMLDivElement>(null);
  useEffect(() => {
    if (!open) return;
    const fn = (e: MouseEvent) => { if (ref.current && !ref.current.contains(e.target as Node)) setOpen(false); };
    const key = (e: KeyboardEvent) => e.key === "Escape" && setOpen(false);
    document.addEventListener("mousedown", fn);
    document.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", fn); document.removeEventListener("keydown", key); };
  }, [open]);
  return (
    <div className="popover-wrap" ref={ref}>
      {trigger(() => setOpen((o) => !o))}
      {open && <div className="menu" style={{ [align]: 0, top: "calc(100% + 4px)" }} role="menu">{children(() => setOpen(false))}</div>}
    </div>
  );
}

export function Field({ label, hint, children }: { label: ReactNode; hint?: ReactNode; children: ReactNode }) {
  return <label className="field"><span>{label}</span>{children}{hint && <span className="hint">{hint}</span>}</label>;
}

export function BrandMark({ size = 30 }: { size?: number }) {
  // A ledger page: two ruled lines and a rising bar — the product in one glyph.
  return (
    <svg className="brand-mark" width={size} height={size} viewBox="0 0 32 32" aria-hidden>
      <rect x="1" y="1" width="30" height="30" rx="7" fill="var(--accent)" />
      <path d="M7 24.5h18M7 27h18" stroke="var(--accent-ink)" strokeWidth="1.4" opacity=".9" />
      <rect x="8" y="15" width="3.6" height="7" rx="1" fill="var(--accent-ink)" />
      <rect x="14.2" y="11" width="3.6" height="11" rx="1" fill="var(--accent-ink)" />
      <rect x="20.4" y="6" width="3.6" height="16" rx="1" fill="var(--accent-ink)" />
    </svg>
  );
}

export function DemoBanner({ text }: { text: string }) {
  return (
    <div className="demo-banner" role="note">
      <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><path d="M12 9v4M12 17h.01M10.3 3.9 1.8 18a2 2 0 0 0 1.7 3h17a2 2 0 0 0 1.7-3L13.7 3.9a2 2 0 0 0-3.4 0Z" /></svg>
      <span>{text}</span>
    </div>
  );
}

export function QualityBadge({ score }: { score?: number | null }) {
  if (score === null || score === undefined) return null;
  const cls = score >= 90 ? "good" : score >= 70 ? "warn" : "bad";
  return <span className={`badge ${cls}`} title="Data quality score">Quality {Math.round(score)}</span>;
}
