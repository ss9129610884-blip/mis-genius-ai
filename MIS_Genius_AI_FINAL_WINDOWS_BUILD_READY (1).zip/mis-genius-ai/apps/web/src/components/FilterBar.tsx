import { useEffect, useMemo, useState } from "react";
import { useQuery } from "@tanstack/react-query";
import { ChevronDown, Filter as FilterIcon, Plus, Search, X } from "lucide-react";
import { api } from "../lib/api";
import type { DashFilterDef, Filter, Schema } from "../lib/types";
import { formatCell, formatDate } from "../lib/format";
import { useI18n } from "../lib/i18n";
import { Modal } from "./ui";

export type ActiveFilters = Record<string, Filter>; // key → filter (slicer id or "x:<column>" for ad-hoc/cross filters)

export function describeFilter(f: Filter): string {
  if (f.column === "*") return `“${String(f.value)}”`;
  if (f.op === "in") return `${f.column}: ${(f.values ?? []).map((v) => String(v ?? "(Blank)")).join(", ")}`;
  if (f.op === "date_range" || f.op === "between") {
    const [a, b] = (f.values ?? []) as (string | number | null)[];
    const fa = typeof a === "string" ? formatDate(a) : a;
    const fb = typeof b === "string" ? formatDate(b) : b;
    return `${f.column}: ${fa ?? "…"} – ${fb ?? "…"}`;
  }
  const sym: Record<string, string> = { eq: "=", neq: "≠", gt: ">", gte: "≥", lt: "<", lte: "≤", contains: "contains", not_contains: "does not contain", is_null: "is blank", not_null: "is not blank" };
  return `${f.column} ${sym[f.op] ?? f.op} ${f.value ?? ""}`.trim();
}

function MultiSelect({ datasetId, column, label, selected, others, onChange }: {
  datasetId: string; column: string; label: string; selected: unknown[]; others: Filter[]; onChange: (vals: unknown[]) => void;
}) {
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState("");
  const vals = useQuery({
    queryKey: ["distinct", datasetId, column, others, q],
    queryFn: () => api.post(`/datasets/${datasetId}/distinct`, { column, filters: others, search: q || null, limit: 300 }),
    enabled: open,
  });
  const sel = new Set(selected.map((v) => String(v)));
  return (
    <div className="popover-wrap">
      <button className={`btn small ${selected.length ? "primary" : ""}`} onClick={() => setOpen((o) => !o)} aria-expanded={open}>
        {label}{selected.length ? ` (${selected.length})` : ""} <ChevronDown />
      </button>
      {open && (
        <div className="menu" style={{ left: 0, top: "calc(100% + 4px)", width: 280, maxHeight: 360, display: "flex", flexDirection: "column" }}>
          <div style={{ padding: 6 }}><input className="input small" autoFocus placeholder={`Search ${label}`} value={q} onChange={(e) => setQ(e.target.value)} /></div>
          <div style={{ overflow: "auto", flex: 1 }}>
            {vals.isLoading && <div className="subtle" style={{ padding: 8 }}>Loading…</div>}
            {vals.data?.values.map((v: any) => {
              const key = String(v.value);
              return (
                <label key={key} className="check" style={{ padding: "6px 10px", width: "100%" }}>
                  <input type="checkbox" checked={sel.has(key)} onChange={(e) => {
                    const next = e.target.checked ? [...selected, v.value] : selected.filter((x) => String(x) !== key);
                    onChange(next);
                  }} />
                  <span className="grow ellipsis">{v.value === null ? "(Blank)" : formatCell(v.value)}</span>
                  <span className="subtle num">{v.count.toLocaleString("en-IN")}</span>
                </label>
              );
            })}
            {vals.data && vals.data.total_distinct > vals.data.values.length && <div className="subtle" style={{ padding: 8 }}>Type to search {vals.data.total_distinct.toLocaleString("en-IN")} values</div>}
          </div>
          <div className="row between" style={{ padding: 6, borderTop: "1px solid var(--line)" }}>
            <button className="btn small ghost" onClick={() => onChange([])}>Clear</button>
            <button className="btn small primary" onClick={() => setOpen(false)}>Done</button>
          </div>
        </div>
      )}
    </div>
  );
}

function AddFilter({ schema, onAdd, onClose }: { schema: Schema; onAdd: (f: Filter) => void; onClose: () => void }) {
  const cols = schema.columns.filter((c) => c.data_type !== "empty");
  const [column, setColumn] = useState(cols[0]?.name ?? "");
  const col = cols.find((c) => c.name === column);
  const numeric = ["integer", "decimal", "currency", "percentage"].includes(col?.data_type ?? "");
  const dateish = ["date", "datetime"].includes(col?.data_type ?? "");
  const ops = numeric ? ["between", "gt", "gte", "lt", "lte", "eq", "neq", "is_null", "not_null"] : dateish ? ["date_range", "is_null", "not_null"] : ["contains", "eq", "neq", "not_contains", "is_null", "not_null"];
  const [op, setOp] = useState(ops[0]);
  const [a, setA] = useState("");
  const [b, setB] = useState("");
  useEffect(() => setOp(ops[0]), [column]); // eslint-disable-line react-hooks/exhaustive-deps
  const build = (): Filter => {
    if (op === "between" || op === "date_range") return { column, op: op as Filter["op"], values: [a === "" ? null : numeric ? Number(a) : a, b === "" ? null : numeric ? Number(b) : b] };
    if (op === "is_null" || op === "not_null") return { column, op: op as Filter["op"] };
    return { column, op: op as Filter["op"], value: numeric ? Number(a) : a };
  };
  const two = op === "between" || op === "date_range";
  const none = op === "is_null" || op === "not_null";
  return (
    <Modal title="Add a filter" onClose={onClose} footer={<>
      <button className="btn" onClick={onClose}>Cancel</button>
      <button className="btn primary" disabled={!none && a === "" && b === ""} onClick={() => { onAdd(build()); onClose(); }}>Apply filter</button>
    </>}>
      <div className="form-grid">
        <label className="field"><span>Column</span>
          <select className="input" value={column} onChange={(e) => setColumn(e.target.value)}>{cols.map((c) => <option key={c.name}>{c.name}</option>)}</select>
        </label>
        <label className="field"><span>Condition</span>
          <select className="input" value={op} onChange={(e) => setOp(e.target.value)}>
            {ops.map((o) => <option key={o} value={o}>{({ between: "between", date_range: "between dates", gt: "greater than", gte: "at least", lt: "less than", lte: "at most", eq: "equals", neq: "is not", contains: "contains", not_contains: "does not contain", is_null: "is blank", not_null: "is not blank" } as Record<string, string>)[o]}</option>)}
          </select>
        </label>
        {!none && <label className="field"><span>{two ? "From" : "Value"}</span><input className="input" type={dateish ? "date" : numeric ? "number" : "text"} value={a} onChange={(e) => setA(e.target.value)} /></label>}
        {two && <label className="field"><span>To</span><input className="input" type={dateish ? "date" : "number"} value={b} onChange={(e) => setB(e.target.value)} /></label>}
      </div>
    </Modal>
  );
}

export function FilterBar({ defs, schema, datasetId, active, onChange }: {
  defs: DashFilterDef[]; schema?: Schema; datasetId: string; active: ActiveFilters; onChange: (a: ActiveFilters) => void;
}) {
  const { t } = useI18n();
  const [adding, setAdding] = useState(false);
  const [search, setSearch] = useState(() => String(active["search"]?.value ?? ""));
  const colMap = useMemo(() => Object.fromEntries((schema?.columns ?? []).map((c) => [c.name, c])), [schema]);
  useEffect(() => {
    const id = setTimeout(() => {
      const cur = String(active["search"]?.value ?? "");
      if (search.trim() === cur) return;
      const next = { ...active };
      if (search.trim()) next["search"] = { column: "*", op: "contains", value: search.trim() };
      else delete next["search"];
      onChange(next);
    }, 400);
    return () => clearTimeout(id);
  }, [search]); // eslint-disable-line react-hooks/exhaustive-deps

  const set = (key: string, f: Filter | null) => {
    const next = { ...active };
    if (f) next[key] = f;
    else delete next[key];
    onChange(next);
  };
  const others = (key: string) => Object.entries(active).filter(([k]) => k !== key).map(([, f]) => f);

  return (
    <div className="panel filterbar">
      <FilterIcon size={16} className="muted" style={{ alignSelf: "center" }} aria-label={t("dash.filters")} />
      {defs.map((d) => {
        if (d.type === "search") {
          return (
            <div key={d.id} className="row" style={{ minWidth: 200, flex: "1 1 200px", maxWidth: 320 }}>
              <div className="popover-wrap grow">
                <Search size={14} style={{ position: "absolute", left: 9, top: 9, color: "var(--ink-3)" }} />
                <input className="input small" style={{ paddingLeft: 28 }} placeholder="Search all columns" value={search} onChange={(e) => setSearch(e.target.value)} aria-label="Search all columns" />
              </div>
            </div>
          );
        }
        if (!d.column || !colMap[d.column]) return null;
        const cur = active[d.id];
        if (d.type === "multi_select") {
          return <MultiSelect key={d.id} datasetId={datasetId} column={d.column} label={d.label} selected={(cur?.values as unknown[]) ?? []} others={others(d.id)}
            onChange={(vals) => set(d.id, vals.length ? { column: d.column!, op: "in", values: vals } : null)} />;
        }
        if (d.type === "date_range") {
          const st = colMap[d.column].stats ?? {};
          const [a, b] = ((cur?.values as (string | null)[]) ?? [null, null]);
          const upd = (i: number, v: string) => {
            const vals: (string | null)[] = [a ?? null, b ?? null];
            vals[i] = v || null;
            set(d.id, vals[0] || vals[1] ? { column: d.column!, op: "date_range", values: vals } : null);
          };
          return (
            <div key={d.id} className="row" style={{ gap: 4 }} title={d.label}>
              <input className="input small" type="date" style={{ width: 142 }} min={st.min?.slice(0, 10)} max={st.max?.slice(0, 10)} value={a ?? ""} onChange={(e) => upd(0, e.target.value)} aria-label={`${d.label} from`} />
              <span className="subtle">–</span>
              <input className="input small" type="date" style={{ width: 142 }} min={st.min?.slice(0, 10)} max={st.max?.slice(0, 10)} value={b ?? ""} onChange={(e) => upd(1, e.target.value)} aria-label={`${d.label} to`} />
            </div>
          );
        }
        if (d.type === "numeric_range") {
          const [a, b] = ((cur?.values as (number | null)[]) ?? [null, null]);
          const upd = (i: number, v: string) => {
            const vals = [a ?? null, b ?? null];
            vals[i] = v === "" ? null : Number(v);
            set(d.id, vals[0] !== null || vals[1] !== null ? { column: d.column!, op: "between", values: vals } : null);
          };
          return (
            <div key={d.id} className="row" style={{ gap: 4 }} title={d.label}>
              <input className="input small" type="number" style={{ width: 110 }} placeholder={`${d.label} min`} value={a ?? ""} onChange={(e) => upd(0, e.target.value)} />
              <input className="input small" type="number" style={{ width: 110 }} placeholder="max" value={b ?? ""} onChange={(e) => upd(1, e.target.value)} />
            </div>
          );
        }
        return null;
      })}
      {schema && <button className="btn small ghost" onClick={() => setAdding(true)}><Plus /> Filter</button>}
      {Object.keys(active).length > 0 && (
        <div className="row wrap" style={{ width: "100%", gap: 6 }}>
          {Object.entries(active).map(([k, f]) => (
            <span key={k} className="filter-chip">{describeFilter(f)}<button aria-label="Remove filter" onClick={() => { if (k === "search") setSearch(""); set(k, null); }}><X size={13} /></button></span>
          ))}
          <button className="btn small ghost" onClick={() => { setSearch(""); onChange({}); }}>{t("action.clear")}</button>
        </div>
      )}
      {adding && schema && <AddFilter schema={schema} onAdd={(f) => set(`x:${f.column}:${Date.now()}`, f)} onClose={() => setAdding(false)} />}
    </div>
  );
}
