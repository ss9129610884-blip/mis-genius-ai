import { useEffect, useRef, useState } from "react";
import { Link, NavLink, Outlet, useNavigate } from "react-router-dom";
import { useQuery, useQueryClient } from "@tanstack/react-query";
import {
  Bell, Building2, Database, FileText, Home, LayoutDashboard, LayoutTemplate, LogOut, MessageSquareText, Moon, Plug, Search, Settings, Sun, Upload, Monitor,
} from "lucide-react";
import { api } from "../lib/api";
import { useAuth } from "../lib/auth";
import { useI18n } from "../lib/i18n";
import { useTheme } from "../lib/ui";
import { relTime } from "../lib/format";
import { BrandMark, Menu } from "./ui";

function GlobalSearch() {
  const { t } = useI18n();
  const [q, setQ] = useState("");
  const [open, setOpen] = useState(false);
  const nav = useNavigate();
  const box = useRef<HTMLDivElement>(null);
  const res = useQuery({ queryKey: ["search", q], queryFn: () => api.get(`/search?q=${encodeURIComponent(q)}`), enabled: q.trim().length >= 2 });
  useEffect(() => {
    const fn = (e: MouseEvent) => box.current && !box.current.contains(e.target as Node) && setOpen(false);
    const key = (e: KeyboardEvent) => {
      if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "k") { e.preventDefault(); box.current?.querySelector("input")?.focus(); }
    };
    document.addEventListener("mousedown", fn);
    document.addEventListener("keydown", key);
    return () => { document.removeEventListener("mousedown", fn); document.removeEventListener("keydown", key); };
  }, []);
  const go = (to: string) => { setOpen(false); setQ(""); nav(to); };
  const d = res.data;
  const any = d && (d.datasets.length || d.dashboards.length || d.reports.length || d.columns.length || d.templates.length);
  return (
    <div className="popover-wrap grow" style={{ maxWidth: 460 }} ref={box}>
      <Search size={15} style={{ position: "absolute", left: 10, top: 10, color: "var(--ink-3)" }} />
      <input className="input" style={{ paddingLeft: 32 }} placeholder={t("common.search")} value={q} onFocus={() => setOpen(true)}
        onChange={(e) => { setQ(e.target.value); setOpen(true); }} aria-label="Search" />
      {open && q.trim().length >= 2 && (
        <div className="menu" style={{ left: 0, right: 0, top: "calc(100% + 4px)", maxHeight: 420, overflow: "auto" }}>
          {!any && <div className="subtle" style={{ padding: 10 }}>{res.isLoading ? "Searching…" : "No matches"}</div>}
          {d?.datasets.map((x: any) => <button key={x.id} onClick={() => go(`/datasets/${x.id}`)}><Database />{x.name}</button>)}
          {d?.dashboards.map((x: any) => <button key={x.id} onClick={() => go(`/dashboards/${x.id}`)}><LayoutDashboard />{x.name}</button>)}
          {d?.reports.map((x: any) => <button key={x.id} onClick={() => go(`/reports/${x.id}`)}><FileText />{x.title}</button>)}
          {d?.templates.map((x: any) => <button key={x.id} onClick={() => go(`/templates`)}><LayoutTemplate />{x.name}</button>)}
          {d?.columns.map((x: any, i: number) => <button key={i} onClick={() => go(`/datasets/${x.dataset_id}?tab=schema`)}><span className="type-chip">{x.data_type}</span>{x.name} <span className="subtle">in {x.dataset}</span></button>)}
        </div>
      )}
    </div>
  );
}

function Notifications() {
  const qc = useQueryClient();
  const nav = useNavigate();
  const q = useQuery({ queryKey: ["notifications"], queryFn: () => api.get("/notifications"), refetchInterval: 30_000 });
  const unread = q.data?.unread ?? 0;
  return (
    <Menu trigger={(toggle) => (
      <button className="btn ghost icon" onClick={toggle} aria-label={`Notifications${unread ? ` (${unread} unread)` : ""}`} style={{ position: "relative" }}>
        <Bell />{unread > 0 && <span style={{ position: "absolute", top: 6, right: 6, width: 8, height: 8, borderRadius: 4, background: "var(--saffron)" }} />}
      </button>
    )}>
      {(close) => (
        <div style={{ width: 340, maxHeight: 420, overflow: "auto" }}>
          <div className="row between" style={{ padding: "6px 10px" }}>
            <strong>Notifications</strong>
            {unread > 0 && <button className="btn small ghost" style={{ width: "auto" }} onClick={async () => { await api.post("/notifications/read-all"); qc.invalidateQueries({ queryKey: ["notifications"] }); }}>Mark all read</button>}
          </div>
          {(q.data?.items ?? []).length === 0 && <div className="subtle" style={{ padding: 10 }}>You are all caught up.</div>}
          {(q.data?.items ?? []).map((n: any) => (
            <button key={n.id} onClick={async () => { close(); if (!n.read) await api.post(`/notifications/${n.id}/read`); qc.invalidateQueries({ queryKey: ["notifications"] }); if (n.link) nav(n.link); }}
              style={{ flexDirection: "column", alignItems: "flex-start", gap: 2, opacity: n.read ? 0.65 : 1 }}>
              <span style={{ fontWeight: n.read ? 400 : 600 }}>{n.title}</span>
              {n.body && <span className="subtle">{n.body}</span>}
              <span className="subtle">{relTime(n.created_at)}</span>
            </button>
          ))}
        </div>
      )}
    </Menu>
  );
}

export function AppShell() {
  const { t, lang, setLang } = useI18n();
  const { theme, setTheme } = useTheme();
  const { user, orgs, org, switchOrg, logout, can } = useAuth();
  const qc = useQueryClient();
  const nav = useNavigate();
  const main = [
    { to: "/", icon: <Home />, label: t("nav.home"), end: true },
    { to: "/upload", icon: <Upload />, label: t("nav.upload") },
    { to: "/datasets", icon: <Database />, label: t("nav.datasets") },
    { to: "/dashboards", icon: <LayoutDashboard />, label: t("nav.dashboards") },
    { to: "/ask", icon: <MessageSquareText />, label: t("nav.ask") },
    { to: "/reports", icon: <FileText />, label: t("nav.reports") },
  ];
  const manage = [
    { to: "/templates", icon: <LayoutTemplate />, label: t("nav.templates") },
    { to: "/sources", icon: <Plug />, label: t("nav.sources") },
    { to: "/settings", icon: <Settings />, label: t("nav.settings") },
  ];
  return (
    <div className="shell">
      <aside className="sidebar" aria-label="Main navigation">
        <Link to="/" className="brand" style={{ textDecoration: "none" }}><BrandMark /><span className="brand-name">MIS Genius AI<small>{org?.name}</small></span></Link>
        <nav className="nav">
          {main.map((n) => <NavLink key={n.to} to={n.to} end={Boolean(n.end)}>{n.icon}{n.label}</NavLink>)}
          <div className="nav-group">{t("nav.admin")}</div>
          {manage.map((n) => <NavLink key={n.to} to={n.to}>{n.icon}{n.label}</NavLink>)}
        </nav>
        <div className="sidebar-foot subtle" style={{ padding: "0 10px" }}>
          {org && <div className="ellipsis" title={org.name}>{org.plan === "enterprise" ? "Unlimited" : `${org.plan} plan`} · {org.role}</div>}
        </div>
      </aside>
      <div className="main">
        <header className="topbar">
          <span className="hide-desktop" style={{ display: "none" }} />
          <GlobalSearch />
          <span className="grow" />
          {orgs.length > 1 && (
            <Menu trigger={(toggle) => <button className="btn ghost small hide-mobile" onClick={toggle}><Building2 />{org?.name}</button>}>
              {(close) => orgs.map((o) => (
                <button key={o.id} onClick={async () => { close(); await switchOrg(o.id); qc.clear(); nav("/"); }}>{o.name} <span className="subtle">{o.role}</span></button>
              ))}
            </Menu>
          )}
          <button className="btn ghost small" onClick={() => setLang(lang === "en" ? "hi" : "en")} aria-label={t("common.language")} title={t("common.language")}>{lang === "en" ? "हिन्दी" : "English"}</button>
          <button className="btn ghost icon" aria-label={t("common.theme")} title={`${t("common.theme")}: ${theme}`}
            onClick={() => setTheme(theme === "light" ? "dark" : theme === "dark" ? "system" : "light")}>
            {theme === "light" ? <Sun /> : theme === "dark" ? <Moon /> : <Monitor />}
          </button>
          <Notifications />
          <Menu trigger={(toggle) => (
            <button className="btn ghost icon" onClick={toggle} aria-label="Account" style={{ borderRadius: "50%", background: "var(--accent-soft)", color: "var(--accent)", fontWeight: 600 }}>
              {(user?.full_name || user?.email || "?").slice(0, 1).toUpperCase()}
            </button>
          )}>
            {(close) => (
              <>
                <div style={{ padding: "6px 10px" }}><div style={{ fontWeight: 600 }}>{user?.full_name || "Account"}</div><div className="subtle">{user?.email}</div></div>
                <hr />
                <button onClick={() => { close(); nav("/settings"); }}><Settings />{t("nav.settings")}</button>
                {can("settings.manage") && <button onClick={() => { close(); nav("/settings?tab=ai"); }}><MessageSquareText />AI provider</button>}
                <hr />
                <button onClick={async () => { close(); await logout(); qc.clear(); nav("/login"); }}><LogOut />{t("action.signout")}</button>
              </>
            )}
          </Menu>
        </header>
        <main className="content" id="main"><Outlet /></main>
      </div>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {[main[0], main[1], main[3], main[4], manage[2]].map((n) => <NavLink key={n.to} to={n.to} end={"end" in n ? Boolean(n.end) : false}>{n.icon}<span>{n.label}</span></NavLink>)}
      </nav>
    </div>
  );
}
