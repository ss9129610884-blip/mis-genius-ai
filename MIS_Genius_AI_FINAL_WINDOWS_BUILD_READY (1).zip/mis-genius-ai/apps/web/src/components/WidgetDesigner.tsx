import { useEffect, useMemo, useState } from "react";
import { useMutation } from "@tanstack/react-query";
import { Plus, Trash2 } from "lucide-react";
import { api } from "../lib/api";
import type { Agg, ChartSpec, ChartType, Dimension, Filter, Granularity, KPISpec, Measure, Schema, Widget } from "../lib/types";
import { Chart } from "./Chart";
import { KpiCard, PivotView, ResultTable } from "./DataViews";
import { ErrorBox, Modal, Spinner } from "./ui";

const NUMERIC = ["integer", "decimal", "currency", "percentage"];
const CHART_TYPES: { id: ChartType; label: string }[] = [
  { id: "bar", label: "Bar" }, { id: "hbar", label: "Horizontal bar" }, { id: "line", label: "Line" }, { id: "area", label: "Area" },
  { id: "combo", label: "Combo (bar + line)" }, { id: "stacked_bar", label: "Stacked bar" }, { id: "stacked_bar_100", label: "100% stacked bar" },
  { id: "pie", label: "Pie" }, { id: "donut", label: "Donut" }, { id: "scatter", label: "Scatter" }, { id: "histogram", label: "Histogram" },
  { id: "heatmap", label: "Heatmap" },
];
const AGGS: { id: Agg; label: string; numeric: boolean }[] = [
  { id: "sum", label: "Sum", numeric: true }, { id: "avg", label: "Average", numeric: true }, { id: "median", label: "Median", numeric: true },
  { id: "min", label: "Minimum", numeric: true }, { id: "max", label: "Maximum", numeric: true }, { id: "count", label: "Count (non-blank)", numeric: false },
  { id: "count_distinct", label: "Distinct count", numeric: false }, { id: "count_rows", label: "Number of rows", numeric: false },
  { id: "stddev", label: "Std deviation", numeric: true }, { id: "variance", label: "Variance", numeric: true },
];
const GRANS: Granularity[] = ["day", "week", "month", "quarter", "year", "fy", "day_of_week", "month_of_year"];

type Kind = "kpi" | "chart" | "table" | "pivot" | "text" | "insights" | "quality";

function MeasureEditor({ m, onChange, schema, allowFormula = true, onRemove }: { m: Measure; onChange: (m: Measure) => void; schema: Schema; allowFormula?: boolean; onRemove?: () => void }) {
  const cols = schema.columns.filter((c) => c.data_type !== "empty");
  const isFormula = m.formula !== undefined && m.formula !== null;
  const col = cols.find((c) => c.name === m.column);
  const aggs = AGGS.filter((a) => !a.numeric || !col || NUMERIC.includes(col.data_type));
  return (
    <div className="row wrap" style={{ gap: 8, alignItems: "flex-end" }}>
      {allowFormula && (
        <label className="field" style={{ width: 120 }}><span>Type</span>
          <select className="input" value={isFormula ? "formula" : "column"} onChange={(e) => onChange(e.target.value === "formula" ? { agg: "sum", formula: "SUM([" + (schema.measures[0] ?? cols[0]?.name) + "])", alias: m.alias } : { column: schema.measures[0] ?? cols[0]?.name, agg: "sum", alias: m.alias })}>
            <option value="column">Column</option><option value="formula">Formula</option>
          </select>
        </label>
      )}
      {isFormula ? (
        <label className="field grow"><span>Formula</span>
          <input className="input" value={m.formula ?? ""} onChange={(e) => onChange({ ...m, formula: e.target.value })} placeholder="(SUM([Revenue]) - SUM([Cost])) / SUM([Revenue]) * 100" />
        </label>
      ) : (
        <>
          <label className="field" style={{ flex: "1 1 180px" }}><span>Aggregation</span>
            <select className="input" value={m.agg} onChange={(e) => onChange({ ...m, agg: e.target.value as Agg })}>{aggs.map((a) => <option key={a.id} value={a.id}>{a.label}</option>)}</select>
          </label>
          {m.agg !== "count_rows" && (
            <label className="field" style={{ flex: "1 1 200px" }}><span>Column</span>
              <select className="input" value={m.column ?? ""} onChange={(e) => onChange({ ...m, column: e.target.value })}>
                {cols.filter((c) => AGGS.find((a) => a.id === m.agg)?.numeric ? NUMERIC.includes(c.data_type) : true).map((c) => <option key={c.name}>{c.name}</option>)}
              </select>
            </label>
          )}
        </>
      )}
      <label className="field" style={{ flex: "1 1 150px" }}><span>Label (optional)</span><input className="input" value={m.alias ?? ""} onChange={(e) => onChange({ ...m, alias: e.target.value || null })} /></label>
      {onRemove && <button className="btn icon ghost" aria-label="Remove measure" onClick={onRemove}><Trash2 /></button>}
    </div>
  );
}

function DimEditor({ label, d, onChange, schema, optional }: { label: string; d?: Dimension | null; onChange: (d: Dimension | null) => void; schema: Schema; optional?: boolean }) {
  const cols = schema.columns.filter((c) => !NUMERIC.includes(c.data_type) || c.role !== "measure").filter((c) => c.data_type !== "empty");
  const col = cols.find((c) => c.name === d?.column);
  const isDate = ["date", "datetime"].includes(col?.data_type ?? "");
  return (
    <div className="row wrap" style={{ gap: 8, alignItems: "flex-end" }}>
      <label className="field" style={{ flex: "1 1 220px" }}><span>{label}</span>
        <select className="input" value={d?.column ?? ""} onChange={(e) => onChange(e.target.value ? { column: e.target.value } : null)}>
          {optional && <option value="">None</option>}
          {cols.map((c) => <option key={c.name} value={c.name}>{c.name} · {c.data_type}</option>)}
        </select>
      </label>
      {isDate && d && (
        <label className="field" style={{ width: 170 }}><span>Group dates by</span>
          <select className="input" value={d.granularity ?? ""} onChange={(e) => onChange({ ...d, granularity: (e.target.value || null) as Granularity | null })}>
            <option value="">Automatic</option>{GRANS.map((g) => <option key={g} value={g}>{g.replace(/_/g, " ")}</option>)}
          </select>
        </label>
      )}
    </div>
  );
}

function defaultChart(schema: Schema): ChartSpec {
  const dim = schema.dimensions[0] ?? schema.primary_date_column ?? schema.columns[0]?.name;
  return { type: "bar", dimension: dim ? { column: dim } : null, measures: [schema.measures[0] ? { column: schema.measures[0], agg: "sum" } : { agg: "count_rows" }], top_n: 12, other: true, sort: "natural", transform: "none" };
}

function defaultKpi(schema: Schema): KPISpec {
  const m = schema.measures[0];
  return { title: m ? `Total ${m}` : "Total records", measure: m ? { column: m, agg: "sum" } : { agg: "count_rows" }, format: { kind: "number", compact: true },
    comparison: { enabled: !!schema.primary_date_column, date_column: schema.primary_date_column }, sparkline: true };
}

export function WidgetDesigner({ dashboardId, datasetId, schema, widget, onClose, onSaved }: {
  dashboardId: string; datasetId: string; schema: Schema; widget?: Widget | null; onClose: () => void; onSaved: () => void;
}) {
  const initialKind: Kind = (widget?.widget_type as Kind) ?? "chart";
  const [kind, setKind] = useState<Kind>(initialKind);
  const [title, setTitle] = useState(widget?.title ?? "");
  const [chart, setChart] = useState<ChartSpec>(() => widget?.config?.chart ?? defaultChart(schema));
  const [kpi, setKpi] = useState<KPISpec>(() => widget?.config?.kpi ?? defaultKpi(schema));
  const [text, setText] = useState<string>(widget?.config?.markdown ?? "");
  const [wFilter, setWFilter] = useState<Filter | null>(() => (widget?.config?.chart?.filters?.[0] ?? widget?.config?.kpi?.filters?.[0] ?? null));
  const [preview, setPreview] = useState<any>(null);
  const [recs, setRecs] = useState<{ type: string; reason: string }[]>([]);

  const effectiveChart = useMemo<ChartSpec>(() => {
    const base = { ...chart, filters: wFilter ? [wFilter] : [] };
    if (kind === "table") return { ...base, type: "table" };
    if (kind === "pivot") return { ...base, type: "pivot" };
    return base;
  }, [chart, kind, wFilter]);
  const effectiveKpi = useMemo<KPISpec>(() => ({ ...kpi, title: title || kpi.title, filters: wFilter ? [wFilter] : [] }), [kpi, title, wFilter]);

  const config = useMemo(() => {
    if (kind === "kpi") return { kpi: effectiveKpi };
    if (kind === "chart" || kind === "table" || kind === "pivot") return { chart: effectiveChart };
    if (kind === "text") return { markdown: text };
    return {};
  }, [kind, effectiveKpi, effectiveChart, text]);

  const previewM = useMutation({
    mutationFn: () => api.post(`/dashboards/${dashboardId}/preview-widget`, { widget_type: kind, title: title || "Preview", config, filters: [] }),
    onSuccess: setPreview,
  });
  useEffect(() => {
    if (!["kpi", "chart", "table", "pivot"].includes(kind)) return;
    const id = setTimeout(() => previewM.mutate(), 350);
    return () => clearTimeout(id);
  }, [JSON.stringify(config), kind]); // eslint-disable-line react-hooks/exhaustive-deps

  useEffect(() => {
    if (kind !== "chart") return;
    const dims = [chart.dimension?.column, chart.series_dimension?.column].filter(Boolean);
    const meas = (chart.measures ?? []).map((m) => m.column).filter(Boolean);
    api.post(`/datasets/${datasetId}/analytics/recommend`, { dimensions: dims, measures: meas }).then(setRecs).catch(() => setRecs([]));
  }, [kind, chart.dimension?.column, chart.series_dimension?.column, JSON.stringify(chart.measures)]); // eslint-disable-line react-hooks/exhaustive-deps

  const save = useMutation({
    mutationFn: () => {
      const body = { widget_type: kind, title: title || (kind === "kpi" ? kpi.title : chart.type), config };
      return widget ? api.patch(`/dashboards/${dashboardId}/widgets/${widget.id}`, body) : api.post(`/dashboards/${dashboardId}/widgets`, body);
    },
    onSuccess: () => { onSaved(); onClose(); },
  });

  const setMeasure = (i: number, m: Measure) => setChart((c) => ({ ...c, measures: (c.measures ?? []).map((x, j) => (j === i ? m : x)) }));
  const t = chart.type;
  const colsAll = schema.columns.filter((c) => c.data_type !== "empty");

  return (
    <Modal wide title={widget ? "Edit widget" : "Add widget"} onClose={onClose} footer={<>
      {save.error && <span className="error-box grow">{(save.error as Error).message}</span>}
      <button className="btn" onClick={onClose}>Cancel</button>
      <button className="btn primary" onClick={() => save.mutate()} disabled={save.isPending}>{save.isPending ? <Spinner /> : null}Save widget</button>
    </>}>
      <div className="grid-2" style={{ alignItems: "start" }}>
        <div className="stack-4">
          <div className="form-grid">
            <label className="field"><span>Widget</span>
              <select className="input" value={kind} onChange={(e) => setKind(e.target.value as Kind)} disabled={!!widget}>
                <option value="kpi">KPI card</option><option value="chart">Chart</option><option value="table">Table / ranking</option>
                <option value="pivot">Pivot table</option><option value="insights">AI insights</option><option value="quality">Data quality</option><option value="text">Text note</option>
              </select>
            </label>
            <label className="field"><span>Title</span><input className="input" value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Shown on the dashboard" /></label>
          </div>

          {kind === "kpi" && (
            <div className="stack-4">
              <label className="field"><span>Calculation</span>
                <select className="input" value={kpi.ratio ? "ratio" : "measure"} onChange={(e) => setKpi((k) => e.target.value === "ratio"
                  ? { ...k, measure: null, ratio: { numerator: { agg: "count_rows", filters: [] }, denominator: { agg: "count_rows" }, as_percent: true }, format: { ...k.format, kind: "percent" } as any }
                  : { ...k, ratio: null, measure: k.measure ?? { agg: "count_rows" } })}>
                  <option value="measure">Single measure or formula</option><option value="ratio">Ratio / percentage (A ÷ B)</option>
                </select>
              </label>
              {kpi.ratio ? (
                <>
                  <h4>Numerator</h4>
                  <MeasureEditor m={kpi.ratio.numerator} schema={schema} allowFormula={false} onChange={(m) => setKpi((k) => ({ ...k, ratio: { ...k.ratio!, numerator: m } }))} />
                  <SimpleFilter schema={schema} f={kpi.ratio.numerator.filters?.[0] ?? null} onChange={(f) => setKpi((k) => ({ ...k, ratio: { ...k.ratio!, numerator: { ...k.ratio!.numerator, filters: f ? [f] : [] } } }))} label="Only count rows where (optional)" />
                  <h4>Denominator</h4>
                  <MeasureEditor m={kpi.ratio.denominator} schema={schema} allowFormula={false} onChange={(m) => setKpi((k) => ({ ...k, ratio: { ...k.ratio!, denominator: m } }))} />
                </>
              ) : (
                <MeasureEditor m={kpi.measure ?? { agg: "count_rows" }} schema={schema} onChange={(m) => setKpi((k) => ({ ...k, measure: m }))} />
              )}
              <div className="form-grid">
                <label className="field"><span>Format</span>
                  <select className="input" value={kpi.format?.kind ?? "number"} onChange={(e) => setKpi((k) => ({ ...k, format: { ...(k.format ?? { kind: "number" }), kind: e.target.value as any } }))}>
                    <option value="number">Number</option><option value="currency">Currency</option><option value="percent">Percentage</option>
                  </select>
                </label>
                {kpi.format?.kind === "currency" && (
                  <label className="field"><span>Currency</span>
                    <select className="input" value={kpi.format?.currency ?? "INR"} onChange={(e) => setKpi((k) => ({ ...k, format: { ...k.format!, currency: e.target.value } }))}>
                      {["INR", "USD", "EUR", "GBP", "AED"].map((c) => <option key={c}>{c}</option>)}
                    </select>
                  </label>
                )}
                <label className="field"><span>Decimals</span>
                  <input className="input" type="number" min={0} max={6} value={kpi.format?.decimals ?? ""} placeholder="auto" onChange={(e) => setKpi((k) => ({ ...k, format: { ...(k.format ?? { kind: "number" }), decimals: e.target.value === "" ? null : Number(e.target.value) } }))} />
                </label>
                <label className="field"><span>Target (optional)</span>
                  <input className="input" type="number" value={kpi.target ?? ""} onChange={(e) => setKpi((k) => ({ ...k, target: e.target.value === "" ? null : Number(e.target.value) }))} />
                </label>
              </div>
              <div className="row wrap" style={{ gap: 16 }}>
                <label className="check"><input type="checkbox" checked={kpi.format?.compact !== false} onChange={(e) => setKpi((k) => ({ ...k, format: { ...(k.format ?? { kind: "number" }), compact: e.target.checked } }))} />Compact numbers (L / Cr)</label>
                <label className="check"><input type="checkbox" disabled={!schema.primary_date_column} checked={!!kpi.comparison?.enabled} onChange={(e) => setKpi((k) => ({ ...k, comparison: { enabled: e.target.checked, date_column: schema.primary_date_column } }))} />Compare with previous period</label>
                <label className="check"><input type="checkbox" checked={kpi.higher_is_better !== false} onChange={(e) => setKpi((k) => ({ ...k, higher_is_better: e.target.checked }))} />Higher is better</label>
              </div>
            </div>
          )}

          {(kind === "chart" || kind === "table" || kind === "pivot") && (
            <div className="stack-4">
              {kind === "chart" && (
                <label className="field"><span>Chart type</span>
                  <select className="input" value={t} onChange={(e) => setChart((c) => ({ ...c, type: e.target.value as ChartType }))}>
                    {CHART_TYPES.map((c) => <option key={c.id} value={c.id}>{c.label}{recs[0]?.type === c.id ? " (recommended)" : ""}</option>)}
                  </select>
                  {recs[0] && <span className="hint">Suggested: {recs.slice(0, 3).map((r) => r.type.replace(/_/g, " ")).join(", ")} — {recs[0].reason}</span>}
                </label>
              )}
              {kind === "chart" && t === "scatter" ? (
                <>
                  <MeasureEditor m={chart.x_measure ?? { column: schema.measures[0], agg: "sum" }} schema={schema} allowFormula={false} onChange={(m) => setChart((c) => ({ ...c, x_measure: m }))} />
                  <MeasureEditor m={chart.y_measure ?? { column: schema.measures[1] ?? schema.measures[0], agg: "sum" }} schema={schema} allowFormula={false} onChange={(m) => setChart((c) => ({ ...c, y_measure: m }))} />
                  <DimEditor label="One point per (optional — blank = individual rows)" d={chart.dimension} optional schema={schema} onChange={(d) => setChart((c) => ({ ...c, dimension: d }))} />
                </>
              ) : kind === "chart" && t === "histogram" ? (
                <div className="form-grid">
                  <label className="field"><span>Numeric column</span>
                    <select className="input" value={chart.histogram_column ?? schema.measures[0] ?? ""} onChange={(e) => setChart((c) => ({ ...c, histogram_column: e.target.value }))}>
                      {colsAll.filter((c) => NUMERIC.includes(c.data_type)).map((c) => <option key={c.name}>{c.name}</option>)}
                    </select>
                  </label>
                  <label className="field"><span>Bins</span><input className="input" type="number" min={5} max={60} value={chart.bins ?? 20} onChange={(e) => setChart((c) => ({ ...c, bins: Number(e.target.value) }))} /></label>
                </div>
              ) : (
                <>
                  {!(kind === "table" && !chart.dimension && chart.columns) && (
                    <DimEditor label={kind === "pivot" ? "Rows" : "Group by (dimension)"} d={chart.dimension} optional={kind === "table"} schema={schema} onChange={(d) => setChart((c) => ({ ...c, dimension: d }))} />
                  )}
                  {(kind === "pivot" || ["stacked_bar", "stacked_bar_100", "heatmap", "line", "area"].includes(t)) && (
                    <DimEditor label={kind === "pivot" ? "Columns" : "Split by (series)"} d={chart.series_dimension} optional schema={schema} onChange={(d) => setChart((c) => ({ ...c, series_dimension: d }))} />
                  )}
                  {(kind !== "table" || chart.dimension) && (
                    <div className="stack-4">
                      {(chart.measures ?? []).map((m, i) => (
                        <MeasureEditor key={i} m={m} schema={schema} onChange={(mm) => setMeasure(i, mm)} onRemove={(chart.measures ?? []).length > 1 ? () => setChart((c) => ({ ...c, measures: (c.measures ?? []).filter((_, j) => j !== i) })) : undefined} />
                      ))}
                      {(chart.measures ?? []).length < (kind === "chart" && !["combo", "bar", "line", "area", "hbar"].includes(t) ? 1 : 4) && (
                        <button className="btn small" onClick={() => setChart((c) => ({ ...c, measures: [...(c.measures ?? []), { column: schema.measures[0], agg: "sum" }] }))}><Plus /> Add measure</button>
                      )}
                    </div>
                  )}
                  {kind === "table" && !chart.dimension && (
                    <label className="field"><span>Columns to list</span>
                      <select className="input" multiple size={6} value={chart.columns ?? []} onChange={(e) => setChart((c) => ({ ...c, columns: Array.from(e.target.selectedOptions).map((o) => o.value) }))}>
                        {colsAll.map((c) => <option key={c.name}>{c.name}</option>)}
                      </select>
                    </label>
                  )}
                  {kind !== "pivot" && (
                    <div className="form-grid">
                      <label className="field"><span>Show top</span><input className="input" type="number" min={1} max={200} value={chart.top_n ?? 12} onChange={(e) => setChart((c) => ({ ...c, top_n: Number(e.target.value), limit: Number(e.target.value) }))} /></label>
                      <label className="field"><span>Sort</span>
                        <select className="input" value={chart.sort ?? "natural"} onChange={(e) => setChart((c) => ({ ...c, sort: e.target.value as ChartSpec["sort"] }))}>
                          <option value="natural">Automatic</option><option value="value_desc">Highest first</option><option value="value_asc">Lowest first</option><option value="label">Alphabetical</option>
                        </select>
                      </label>
                      {kind === "chart" && (
                        <label className="field"><span>Show values as</span>
                          <select className="input" value={chart.transform ?? "none"} onChange={(e) => setChart((c) => ({ ...c, transform: e.target.value as ChartSpec["transform"] }))}>
                            <option value="none">Values</option><option value="running_total">Running total</option><option value="moving_average">Moving average</option><option value="contribution">Contribution %</option>
                          </select>
                        </label>
                      )}
                      {kind === "chart" && <label className="check" style={{ alignSelf: "end", height: 36 }}><input type="checkbox" checked={chart.other !== false} onChange={(e) => setChart((c) => ({ ...c, other: e.target.checked }))} />Group the rest as “Other”</label>}
                    </div>
                  )}
                </>
              )}
            </div>
          )}

          {["kpi", "chart", "table", "pivot"].includes(kind) && <SimpleFilter schema={schema} f={wFilter} onChange={setWFilter} label="Widget filter (optional, applied on top of dashboard filters)" />}

          {kind === "text" && (
            <label className="field"><span>Text</span><textarea className="input" rows={6} value={text} onChange={(e) => setText(e.target.value)} /></label>
          )}
          {(kind === "insights" || kind === "quality") && <p className="muted">This widget updates automatically with the dashboard filters.</p>}
        </div>

        <div className="panel flat" style={{ minHeight: 320, display: "flex", flexDirection: "column" }}>
          <div className="panel-head"><h4>Preview</h4>{previewM.isPending && <Spinner />}</div>
          <div className="panel-body" style={{ flex: 1, minHeight: 280 }}>
            {previewM.error && <ErrorBox error={previewM.error} />}
            {preview?.error && <ErrorBox error={preview.error} />}
            {kind === "kpi" && preview?.kpi && <KpiCard k={preview.kpi} />}
            {preview?.chart && !preview.error && (preview.chart.type === "table" ? <ResultTable data={preview.chart} /> : preview.chart.type === "pivot" ? <PivotView p={preview.chart} /> : <div style={{ height: 300 }}><Chart data={preview.chart} /></div>)}
            {!["kpi", "chart", "table", "pivot"].includes(kind) && <p className="muted">No preview for this widget type.</p>}
          </div>
        </div>
      </div>
    </Modal>
  );
}

function SimpleFilter({ schema, f, onChange, label }: { schema: Schema; f: Filter | null; onChange: (f: Filter | null) => void; label: string }) {
  const cols = schema.columns.filter((c) => c.data_type !== "empty");
  const col = cols.find((c) => c.name === f?.column);
  const numeric = NUMERIC.includes(col?.data_type ?? "");
  return (
    <div className="stack-4">
      <label className="check"><input type="checkbox" checked={!!f} onChange={(e) => onChange(e.target.checked ? { column: schema.dimensions[0] ?? cols[0].name, op: "eq", value: "" } : null)} />{label}</label>
      {f && (
        <div className="row wrap" style={{ gap: 8 }}>
          <select className="input" style={{ flex: "1 1 160px" }} value={f.column} onChange={(e) => onChange({ ...f, column: e.target.value })}>{cols.map((c) => <option key={c.name}>{c.name}</option>)}</select>
          <select className="input" style={{ width: 150 }} value={f.op} onChange={(e) => onChange({ ...f, op: e.target.value as Filter["op"] })}>
            <option value="eq">equals</option><option value="neq">is not</option><option value="contains">contains</option>
            {numeric && <><option value="gt">greater than</option><option value="lt">less than</option></>}
          </select>
          <input className="input" style={{ flex: "1 1 140px" }} type={numeric ? "number" : "text"} value={String(f.value ?? "")} onChange={(e) => onChange({ ...f, value: numeric ? Number(e.target.value) : e.target.value })} />
        </div>
      )}
    </div>
  );
}
