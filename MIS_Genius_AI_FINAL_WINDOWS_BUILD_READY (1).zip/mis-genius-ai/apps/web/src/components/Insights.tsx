import { useQuery } from "@tanstack/react-query";
import { useState } from "react";
import { Link } from "react-router-dom";
import { AlertTriangle, CheckCircle2, Lightbulb, RefreshCw, Sparkles, TrendingUp } from "lucide-react";
import { api } from "../lib/api";
import { useI18n } from "../lib/i18n";
import type { Filter, Quality } from "../lib/types";
import { Evidence } from "./DataViews";
import { Drawer, ErrorBox, Spinner } from "./ui";

const SECTION_LABEL: Record<string, { en: string; hi: string }> = {
  executive_summary: { en: "Summary", hi: "सारांश" },
  key_trends: { en: "Trends", hi: "रुझान" },
  period_changes: { en: "What changed", hi: "क्या बदला" },
  anomalies: { en: "Unusual", hi: "असामान्य" },
  top_contributors: { en: "Top contributors", hi: "शीर्ष योगदान" },
  bottom_contributors: { en: "Lowest contributors", hi: "सबसे कम योगदान" },
  possible_explanations: { en: "Possible explanations", hi: "संभावित कारण" },
  actions: { en: "Suggested actions", hi: "सुझाए गए कदम" },
  data_quality: { en: "Data quality", hi: "डेटा गुणवत्ता" },
};

export function InsightsPanel({ datasetId, filters, compact = false, max = 6 }: { datasetId: string; filters: Filter[]; compact?: boolean; max?: number }) {
  const { lang } = useI18n();
  const [section, setSection] = useState("executive_summary");
  const [ev, setEv] = useState<any>(null);
  const q = useQuery({
    queryKey: ["insights", datasetId, filters, lang],
    queryFn: () => api.post(`/datasets/${datasetId}/insights`, { filters, language: lang }),
    staleTime: 60_000,
  });
  if (q.isLoading) return <div className="col" style={{ gap: 10 }}>{[0, 1, 2].map((i) => <div key={i} className="skeleton" style={{ height: 18 }} />)}</div>;
  if (q.error) return <ErrorBox error={q.error} onRetry={() => q.refetch()} />;
  const data = q.data;
  const sections = Object.keys(SECTION_LABEL).filter((s) => data[s]?.length);
  const items: any[] = (data[section] ?? []).slice(0, compact ? max : 50);
  const icon = (s: string) => (s === "anomalies" ? <AlertTriangle /> : s === "data_quality" ? <AlertTriangle /> : s === "key_trends" || s === "period_changes" ? <TrendingUp /> : s === "actions" ? <Lightbulb /> : <CheckCircle2 />);
  return (
    <div className="col" style={{ gap: 12 }}>
      <div className="row wrap" style={{ gap: 6 }}>
        {sections.map((s) => (
          <button key={s} className={`btn small ${s === section ? "primary" : "ghost"}`} onClick={() => setSection(s)}>{SECTION_LABEL[s][lang]}</button>
        ))}
        <span className="grow" />
        <span className="badge" title={data.meta.generated_by === "ai" ? `Written by ${data.meta.provider}; every number was checked against the computed facts.` : "Computed directly from the data (no AI provider configured)."}>
          <Sparkles size={12} /> {data.meta.generated_by === "ai" ? "AI · grounded" : "Computed"}
        </span>
        <button className="btn ghost icon small" aria-label="Refresh insights" onClick={() => q.refetch()}>{q.isFetching ? <Spinner /> : <RefreshCw />}</button>
      </div>
      {items.length === 0 ? <p className="muted">Nothing notable in this section for the current selection.</p> : (
        <ul className="insight-list">
          {items.map((it, i) => (
            <li key={i} className={section === "anomalies" ? "anomaly" : section === "data_quality" ? "quality" : undefined}>
              {icon(section)}
              <div>
                <span>{it.text}</span>
                {(it.evidence || it.fact_ids?.length) ? <button className="evidence-link" style={{ marginLeft: 8 }} onClick={() => setEv(it)}>evidence</button> : null}
              </div>
            </li>
          ))}
        </ul>
      )}
      {!compact && data.questions?.length > 0 && (
        <div>
          <h4 style={{ marginBottom: 8 }}>{lang === "hi" ? "आगे पूछने लायक प्रश्न" : "Questions worth asking next"}</h4>
          <div className="suggestions">
            {data.questions.map((qq: any, i: number) => <Link key={i} to={`/ask?dataset=${datasetId}&q=${encodeURIComponent(qq.text)}`} className="badge info">{qq.text}</Link>)}
          </div>
        </div>
      )}
      {data.meta.grounding?.rejected > 0 && (
        <p className="subtle">{data.meta.grounding.rejected} AI statement(s) were discarded because their numbers could not be verified against the data.</p>
      )}
      {ev && (
        <Drawer title="Evidence" onClose={() => setEv(null)}>
          <p style={{ marginBottom: 12 }}>{ev.text}</p>
          <Evidence title="This statement was produced from the following computation(s)." items={[
            { label: "Calculation", value: ev.evidence?.calculation },
            { label: "Facts cited", value: (ev.fact_ids ?? []).map((id: string) => {
              const f = data.facts.find((x: any) => x.id === id);
              return f ? `${id}: ${f.text[lang] ?? f.text.en}` : id;
            }).join("\n") },
            { label: "Source", value: ev.source === "ai" ? `AI wording (${data.meta.provider}), verified against computed facts` : "Computed by the analytics engine" },
            { label: "SQL", value: ev.evidence?.sql, code: true },
          ]} />
        </Drawer>
      )}
    </div>
  );
}

export function QualitySummary({ quality, datasetId, compact = false }: { quality: Quality; datasetId: string; compact?: boolean }) {
  const { lang } = useI18n();
  const s = quality.summary;
  const issues = quality.issues.slice(0, compact ? 4 : 100);
  return (
    <div className="col" style={{ gap: 12 }}>
      <div className="row between wrap">
        <div className="quality-score"><strong>{Math.round(s.score)}</strong><span className="muted">/ 100 · grade {s.grade}</span></div>
        <div className="row wrap small muted" style={{ gap: 14 }}>
          <span className="num">{s.rows?.toLocaleString("en-IN")} rows</span>
          <span className="num">{s.missing_cells?.toLocaleString("en-IN")} missing ({s.missing_pct}%)</span>
          <span className="num">{s.duplicate_rows?.toLocaleString("en-IN")} duplicates</span>
          <span className="num">{s.invalid_values?.toLocaleString("en-IN")} invalid</span>
        </div>
      </div>
      <div className="bar-meter"><span style={{ width: `${s.score}%`, background: s.score >= 90 ? "var(--positive)" : s.score >= 70 ? "var(--saffron)" : "var(--danger)" }} /></div>
      {issues.length === 0 ? <p className="muted">No data-quality issues found.</p> : (
        <ul className="insight-list">
          {issues.map((i, n) => (
            <li key={n} className={i.severity === "info" ? undefined : "anomaly"}>
              {i.severity === "info" ? <CheckCircle2 /> : <AlertTriangle />}
              <span>{lang === "hi" ? i.message_hi : i.message}</span>
            </li>
          ))}
        </ul>
      )}
      {compact && quality.issues.length > issues.length && <Link to={`/datasets/${datasetId}?tab=quality`} className="small">See all {quality.issues.length} checks and cleaning tools</Link>}
    </div>
  );
}
