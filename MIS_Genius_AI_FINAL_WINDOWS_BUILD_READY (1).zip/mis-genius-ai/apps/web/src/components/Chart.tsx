import { useEffect, useMemo, useRef } from "react";
import * as echarts from "echarts/core";
import { BarChart, HeatmapChart, LineChart, PieChart, ScatterChart } from "echarts/charts";
import { GridComponent, LegendComponent, TooltipComponent, VisualMapComponent } from "echarts/components";
import { CanvasRenderer } from "echarts/renderers";
import type { ChartResult, KPIFormat } from "../lib/types";
import { compact, formatPeriod, formatValue } from "../lib/format";
import { useTheme } from "../lib/ui";

echarts.use([BarChart, LineChart, PieChart, ScatterChart, HeatmapChart, GridComponent, TooltipComponent, LegendComponent, VisualMapComponent, CanvasRenderer]);

export const PALETTE = ["#0E7A6D", "#2F5DA8", "#C98100", "#B3446C", "#5B8C2A", "#7A5BA8", "#C0612B", "#2A8FB3", "#8C6D2A", "#6B7486"];
export const PALETTE_DARK = ["#2BB39F", "#7AA2E8", "#E7A93A", "#E07FA4", "#8CC152", "#A98BE0", "#EE8A55", "#5BC0E0", "#C9A45A", "#9AA3B5"];

function cssVar(name: string): string {
  return getComputedStyle(document.documentElement).getPropertyValue(name).trim();
}

export interface ChartProps {
  data: ChartResult;
  valueFormat?: Partial<KPIFormat>;
  onSelect?: (category: unknown, series?: string) => void;
  height?: number | string;
  sparkline?: boolean;
}

export function buildOption(d: ChartResult, fmt: Partial<KPIFormat> | undefined, dark: boolean): echarts.EChartsCoreOption {
  const ink = cssVar("--ink") || "#16213e";
  const ink3 = cssVar("--ink-3") || "#7a8396";
  const line = cssVar("--line") || "#dce1e9";
  const surface = cssVar("--surface") || "#fff";
  const palette = dark ? PALETTE_DARK : PALETTE;
  const vf = (v: unknown) => (typeof v === "number" ? formatValue(v, fmt?.kind === "percent" || d.series?.[0]?.transform === "contribution" ? { kind: "percent" } : fmt ?? { kind: "number" }) : String(v ?? "—"));
  const axisNum = (v: number) => (d.type === "stacked_bar_100" || d.series?.[0]?.transform === "contribution" ? `${v}%` : compact(v));
  const cats = (d.categories ?? []).map((c) => (d.is_time ? formatPeriod(c, d.granularity) : String(c ?? "(Blank)")));
  const base = {
    color: palette,
    textStyle: { fontFamily: "IBM Plex Sans, IBM Plex Sans Devanagari, sans-serif", color: ink },
    animationDuration: 350,
    tooltip: {
      trigger: "axis" as const, backgroundColor: surface, borderColor: line, textStyle: { color: ink, fontSize: 12 },
      valueFormatter: vf,
    },
    grid: { left: 8, right: 16, top: 28, bottom: 8, containLabel: true },
  };
  const catAxis = {
    type: "category" as const, data: cats, axisLine: { lineStyle: { color: line } }, axisTick: { show: false },
    axisLabel: { color: ink3, fontSize: 11, hideOverlap: true, formatter: (s: string) => (s.length > 18 ? s.slice(0, 17) + "…" : s) },
  };
  const valAxis = { type: "value" as const, splitLine: { lineStyle: { color: line, type: "dashed" as const } }, axisLabel: { color: ink3, fontSize: 11, formatter: axisNum } };
  const legend = (n: number) => (n > 1 ? { legend: { top: 0, type: "scroll" as const, textStyle: { color: ink3, fontSize: 11 }, itemWidth: 12, itemHeight: 8 } } : {});
  const series = d.series ?? [];

  switch (d.type) {
    case "line":
    case "area":
      return { ...base, ...legend(series.length), xAxis: { ...catAxis, boundaryGap: false }, yAxis: valAxis,
        series: series.map((s) => ({ type: "line", name: s.name, data: s.data, smooth: 0.25, symbolSize: cats.length > 40 ? 0 : 5, connectNulls: true,
          areaStyle: d.type === "area" ? { opacity: 0.18 } : undefined, lineStyle: { width: 2 } })) };
    case "combo":
      return { ...base, ...legend(series.length), xAxis: catAxis,
        yAxis: [valAxis, { ...valAxis, splitLine: { show: false } }],
        series: series.map((s, i) => (i === 0 || s.kind !== "line"
          ? { type: "bar", name: s.name, data: s.data, barMaxWidth: 36, itemStyle: { borderRadius: [3, 3, 0, 0] } }
          : { type: "line", name: s.name, data: s.data, yAxisIndex: series.length === 2 ? 0 : 1, smooth: 0.25, symbolSize: 5 })) };
    case "hbar":
      return { ...base, tooltip: { ...base.tooltip, trigger: "axis", axisPointer: { type: "shadow" } }, ...legend(series.length),
        yAxis: { ...catAxis, inverse: true }, xAxis: valAxis,
        series: series.map((s) => ({ type: "bar", name: s.name, data: s.data, barMaxWidth: 22, itemStyle: { borderRadius: [0, 3, 3, 0] },
          label: { show: cats.length <= 12, position: "right", color: ink3, fontSize: 11, formatter: (p: any) => (typeof p.value === "number" ? compact(p.value) : "") } })) };
    case "stacked_bar":
    case "stacked_bar_100":
      return { ...base, tooltip: { ...base.tooltip, axisPointer: { type: "shadow" } }, ...legend(series.length), xAxis: catAxis,
        yAxis: { ...valAxis, max: d.type === "stacked_bar_100" ? 100 : undefined },
        series: series.map((s) => ({ type: "bar", name: s.name, data: s.data, stack: "total", barMaxWidth: 40, emphasis: { focus: "series" } })) };
    case "pie":
    case "donut": {
      const s = series[0];
      return { ...base, tooltip: { trigger: "item", backgroundColor: surface, borderColor: line, textStyle: { color: ink },
        formatter: (p: any) => `${p.name}<br/><b>${vf(p.value)}</b> (${p.percent}%)` },
        legend: { type: "scroll", bottom: 0, textStyle: { color: ink3, fontSize: 11 }, itemWidth: 10, itemHeight: 10 },
        series: [{ type: "pie", radius: d.type === "donut" ? ["46%", "72%"] : "70%", center: ["50%", "46%"], avoidLabelOverlap: true,
          itemStyle: { borderColor: surface, borderWidth: 2 }, label: { color: ink3, fontSize: 11, formatter: "{d}%" },
          data: cats.map((c, i) => ({ name: c, value: s?.data[i] ?? 0 })) }] };
    }
    case "histogram":
      return { ...base, tooltip: { ...base.tooltip, valueFormatter: (v: unknown) => `${v} rows` }, xAxis: { ...catAxis, axisLabel: { ...catAxis.axisLabel, rotate: 30 } },
        yAxis: { ...valAxis, axisLabel: { color: ink3, fontSize: 11 } },
        series: [{ type: "bar", name: "Rows", data: series[0]?.data ?? [], barCategoryGap: "4%" }] };
    case "scatter": {
      const pts = d.points ?? [];
      return { ...base, tooltip: { trigger: "item", backgroundColor: surface, borderColor: line, textStyle: { color: ink },
        formatter: (p: any) => `${p.data[2] ? p.data[2] + "<br/>" : ""}${d.x_name}: <b>${compact(p.data[0])}</b><br/>${d.y_name}: <b>${compact(p.data[1])}</b>` },
        xAxis: { ...valAxis, name: d.x_name, nameLocation: "middle", nameGap: 26, nameTextStyle: { color: ink3 } },
        yAxis: { ...valAxis, name: d.y_name, nameTextStyle: { color: ink3 } },
        series: [{ type: "scatter", symbolSize: pts.length > 500 ? 4 : 7, itemStyle: { opacity: 0.7 },
          data: pts.map((p) => [p.x, p.y, p.label !== undefined ? String(p.label) : ""]) }] };
    }
    case "heatmap": {
      const vals = (d.data ?? []).map((x) => x[2] ?? 0);
      return { ...base, tooltip: { trigger: "item", backgroundColor: surface, borderColor: line, textStyle: { color: ink },
        formatter: (p: any) => `${(d.x ?? [])[p.data[0]]} × ${(d.y ?? [])[p.data[1]]}<br/><b>${vf(p.data[2])}</b>` },
        grid: { ...base.grid, bottom: 40 },
        xAxis: { type: "category", data: (d.x ?? []).map((x) => String(x)), axisLabel: { color: ink3, fontSize: 11, rotate: 30 }, splitArea: { show: true } },
        yAxis: { type: "category", data: (d.y ?? []).map((y) => String(y)), axisLabel: { color: ink3, fontSize: 11 }, splitArea: { show: true } },
        visualMap: { min: Math.min(0, ...vals), max: Math.max(1, ...vals), calculable: false, orient: "horizontal", left: "center", bottom: 0, itemHeight: 120,
          textStyle: { color: ink3, fontSize: 10 }, inRange: { color: dark ? ["#172033", palette[0]] : ["#EEF7F5", palette[0]] }, formatter: (v: number) => compact(v) },
        series: [{ type: "heatmap", data: d.data ?? [], label: { show: (d.x?.length ?? 0) * (d.y?.length ?? 0) <= 60, fontSize: 10, formatter: (p: any) => compact(p.data[2] ?? 0) } }] };
    }
    case "kpi":
      return {};
    default: // bar
      return { ...base, tooltip: { ...base.tooltip, axisPointer: { type: "shadow" } }, ...legend(series.length), xAxis: catAxis, yAxis: valAxis,
        series: series.map((s) => ({ type: "bar", name: s.name, data: s.data, barMaxWidth: 44, itemStyle: { borderRadius: [3, 3, 0, 0] } })) };
  }
}

export function Chart({ data, valueFormat, onSelect, height = "100%" }: ChartProps) {
  const el = useRef<HTMLDivElement>(null);
  const inst = useRef<echarts.ECharts | null>(null);
  const { resolved } = useTheme();
  const option = useMemo(() => buildOption(data, valueFormat, resolved === "dark"), [data, valueFormat, resolved]);

  useEffect(() => {
    if (!el.current) return;
    inst.current = echarts.init(el.current, undefined, { renderer: "canvas" });
    const ro = new ResizeObserver(() => inst.current?.resize());
    ro.observe(el.current);
    return () => { ro.disconnect(); inst.current?.dispose(); inst.current = null; };
  }, [resolved]);

  useEffect(() => {
    inst.current?.setOption(option, true);
  }, [option, resolved]);

  useEffect(() => {
    const c = inst.current;
    if (!c || !onSelect) return;
    const handler = (p: any) => {
      if (data.type === "heatmap") return onSelect((data.x ?? [])[p.data?.[0]], String((data.y ?? [])[p.data?.[1]]));
      if (data.type === "scatter") return;
      const raw = (data.categories ?? [])[p.dataIndex];
      onSelect(raw, p.seriesName);
    };
    c.on("click", handler);
    return () => { c.off("click", handler); };
  }, [onSelect, data, resolved]);

  return <div ref={el} className="chart-box" style={{ height }} role="img" aria-label={`${data.type} chart`} />;
}

export function Sparkline({ values }: { values: (number | null)[] }) {
  const el = useRef<HTMLDivElement>(null);
  const { resolved } = useTheme();
  useEffect(() => {
    if (!el.current) return;
    const c = echarts.init(el.current);
    const color = resolved === "dark" ? PALETTE_DARK[0] : PALETTE[0];
    c.setOption({ grid: { left: 0, right: 0, top: 2, bottom: 2 }, xAxis: { type: "category", show: false, data: values.map((_, i) => i) },
      yAxis: { type: "value", show: false, scale: true }, animation: false,
      series: [{ type: "line", data: values, symbol: "none", smooth: 0.3, lineStyle: { width: 1.6, color }, areaStyle: { color, opacity: 0.1 } }] });
    const ro = new ResizeObserver(() => c.resize());
    ro.observe(el.current);
    return () => { ro.disconnect(); c.dispose(); };
  }, [values, resolved]);
  return <div ref={el} className="kpi-spark" aria-hidden />;
}
