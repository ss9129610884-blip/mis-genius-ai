import { useState } from "react";
import { ArrowDownRight, ArrowUpRight, Minus } from "lucide-react";
import type { ChartResult, KPIResult } from "../lib/types";
import { formatCell, formatValue, type NumPrefs } from "../lib/format";
import { useI18n } from "../lib/i18n";
import { Sparkline } from "./Chart";
import { Drawer } from "./ui";

export function Evidence({ title, items }: { title: string; items: { label: string; value: unknown; code?: boolean }[] }) {
  return (
    <dl className="evidence">
      <p className="muted" style={{ marginBottom: 8 }}>{title}</p>
      {items.filter((i) => i.value !== undefined && i.value !== null && i.value !== "").map((i) => (
        <div key={i.label}>
          <dt>{i.label}</dt>
          <dd>{i.code ? <pre>{String(i.value)}</pre> : String(i.value)}</dd>
        </div>
      ))}
    </dl>
  );
}

export function KpiCard({ k, prefs }: { k: KPIResult; prefs?: NumPrefs }) {
  const { t } = useI18n();
  const [open, setOpen] = useState(false);
  if (!k.available) {
    return (
      <div className="kpi">
        <div className="kpi-title">{k.title}</div>
        <div className="kpi-value unavailable">{t("kpi.unavailable")}</div>
        <div className="subtle">{k.reason}</div>
      </div>
    );
  }
  const c = k.comparison;
  const pct = c?.available ? c.change_pct : null;
  const isPercent = k.format?.kind === "percent";
  const good = pct === null || pct === undefined ? null : (pct >= 0) === (k.higher_is_better !== false);
  const delta = c?.available
    ? isPercent && typeof c.change === "number" ? `${c.change >= 0 ? "+" : ""}${c.change.toFixed(1)} pts` : pct !== null && pct !== undefined ? `${pct >= 0 ? "+" : ""}${pct.toFixed(1)}%` : null
    : null;
  return (
    <div className="kpi">
      <div className="kpi-title">{k.title}</div>
      <div className="kpi-value" title={typeof k.value === "number" ? k.value.toLocaleString("en-IN") : undefined}>{formatValue(k.value, k.format, prefs)}</div>
      {delta && c && (
        <div className="kpi-delta">
          <span className={good ? "up" : "down"} style={{ display: "inline-flex", alignItems: "center" }}>
            {pct === 0 ? <Minus size={14} /> : (pct ?? 0) > 0 ? <ArrowUpRight size={14} /> : <ArrowDownRight size={14} />}{delta}
          </span>
          <span className="subtle">{c.current_period} {t("kpi.vs", { period: c.previous_period ?? "" })}</span>
        </div>
      )}
      {k.sparkline && k.sparkline.length > 2 && <Sparkline values={k.sparkline.map((s) => s.value)} />}
      <div className="row between">
        <button className="evidence-link" onClick={() => setOpen(true)}>{t("kpi.how")}</button>
        {typeof k.target_pct === "number" && <span className="subtle">{k.target_pct.toFixed(0)}% of target</span>}
      </div>
      {open && (
        <Drawer title={k.title} onClose={() => setOpen(false)}>
          <Evidence title="Every KPI is calculated directly from the dataset with the query below." items={[
            { label: "Value", value: formatValue(k.value, k.format, prefs) + (typeof k.value === "number" ? `  (exact: ${k.value.toLocaleString("en-IN", { maximumFractionDigits: 6 })})` : "") },
            { label: "Calculation", value: k.evidence?.calculation },
            { label: "Rows considered", value: k.evidence?.rows_considered?.toLocaleString("en-IN") },
            { label: "Numerator / denominator", value: k.evidence?.numerator !== undefined ? `${k.evidence.numerator} / ${k.evidence.denominator}` : undefined },
            { label: "Filters", value: k.evidence?.filters?.length ? k.evidence.filters.map((f) => `${f.column} ${f.op} ${JSON.stringify(f.values ?? f.value)}`).join("; ") : "None" },
            { label: "Period comparison", value: c?.available ? `${c.current_period}: ${formatValue(c.current_value, k.format, prefs)} vs ${c.previous_period}: ${formatValue(c.previous_value, k.format, prefs)} — ${c.calculation}` : c?.reason },
            { label: "Note", value: c?.note },
            { label: "Description", value: k.description },
            { label: "SQL", value: k.evidence?.sql, code: true },
          ]} />
        </Drawer>
      )}
    </div>
  );
}

export function ResultTable({ data, colTypes, prefs, maxRows = 500 }: { data: { columns: string[]; rows: unknown[][]; totals?: unknown[] | null }; colTypes?: Record<string, string>; prefs?: NumPrefs; maxRows?: number }) {
  const numeric = data.columns.map((_, i) => data.rows.some((r) => typeof r[i] === "number"));
  return (
    <div className="table-wrap" style={{ maxHeight: "100%" }}>
      <table className="data">
        <thead><tr>{data.columns.map((c, i) => <th key={c + i} className={numeric[i] ? "n" : undefined}>{c}</th>)}</tr></thead>
        <tbody>
          {data.rows.slice(0, maxRows).map((r, ri) => (
            <tr key={ri}>{r.map((v, ci) => <td key={ci} className={numeric[ci] ? "n" : v === null ? "null" : undefined}>{v === null ? "blank" : formatCell(v, colTypes?.[data.columns[ci]], prefs)}</td>)}</tr>
          ))}
          {data.totals && (
            <tr className="total">{data.totals.map((v, i) => <td key={i} className={numeric[i] ? "n" : undefined}>{formatCell(v, colTypes?.[data.columns[i]], prefs)}</td>)}</tr>
          )}
        </tbody>
      </table>
    </div>
  );
}

export function PivotView({ p, prefs }: { p: ChartResult; prefs?: NumPrefs }) {
  const cols = p.column_keys ?? [];
  const single = cols.length === 1 && cols[0] === "__all__";
  const vals = p.values ?? [];
  const fmt = (v: unknown) => formatCell(v, undefined, prefs);
  return (
    <div className="table-wrap" style={{ maxHeight: "100%" }}>
      <table className="data pivot">
        <thead>
          <tr>
            {(p.row_fields ?? []).map((f) => <th key={f}>{f}</th>)}
            {!single && cols.map((c) => <th key={c} className="n">{c}</th>)}
            <th className="n total">{single ? vals[0] : "Total"}</th>
          </tr>
        </thead>
        <tbody>
          {(p.rows as any[] | undefined)?.map((r, i) => (
            <tr key={i}>
              {r.keys.map((k: unknown, j: number) => <td key={j}>{String(k)}</td>)}
              {!single && cols.map((c) => <td key={c} className="n">{fmt(r.cells[c]?.[0] ?? null)}</td>)}
              <td className="n total">{fmt(r.total?.[0] ?? (single ? r.cells["__all__"]?.[0] : null))}</td>
            </tr>
          ))}
          <tr className="total">
            <td colSpan={Math.max(1, (p.row_fields ?? []).length)}>Total</td>
            {!single && cols.map((c) => <td key={c} className="n">{fmt(p.column_totals?.[c]?.[0] ?? null)}</td>)}
            <td className="n">{fmt(p.grand_total?.[0] ?? null)}</td>
          </tr>
        </tbody>
      </table>
      {p.truncated_columns && <p className="subtle" style={{ padding: 8 }}>Only the first 60 columns are shown.</p>}
    </div>
  );
}
