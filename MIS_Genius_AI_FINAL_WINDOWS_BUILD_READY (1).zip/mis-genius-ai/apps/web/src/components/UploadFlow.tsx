import { useCallback, useRef, useState } from "react";
import { useNavigate } from "react-router-dom";
import { useQueryClient } from "@tanstack/react-query";
import { FileSpreadsheet, Layers, UploadCloud } from "lucide-react";
import clsx from "clsx";
import { api, pollJob, uploadWithProgress } from "../lib/api";
import { useI18n } from "../lib/i18n";
import { useToast } from "../lib/ui";
import { bytes } from "../lib/format";
import { ErrorBox, Spinner } from "./ui";

type Phase = "idle" | "uploading" | "processing" | "select" | "building" | "done" | "error";

export function Pipeline({ stage }: { stage: number }) {
  const { t } = useI18n();
  const labels = [t("upload.stage.upload"), t("upload.stage.inspect"), t("upload.stage.profile"), t("upload.stage.schema"), t("upload.stage.kpis"), t("upload.stage.dashboard")];
  return (
    <ol className="pipeline" aria-label="Processing steps">
      {labels.map((l, i) => <li key={l} className={clsx(i < stage && "done", i === stage && "active")}>{l}</li>)}
    </ol>
  );
}

interface SheetInfo { id: string; label: string; sheet_name: string; rows: number; cols: number; columns: string[]; preview: (string | null)[][]; notes: string | null; header_row: number | null }

function SheetPicker({ sheets, warnings, onCreate, busy }: { sheets: SheetInfo[]; warnings: string[]; onCreate: (ids: string[], combine: boolean) => void; busy: boolean }) {
  const { t } = useI18n();
  const largest = [...sheets].sort((a, b) => b.rows * b.cols - a.rows * a.cols)[0];
  const [sel, setSel] = useState<string[]>(largest ? [largest.id] : []);
  const [compat, setCompat] = useState<any>(null);
  const toggle = async (id: string) => {
    const next = sel.includes(id) ? sel.filter((x) => x !== id) : [...sel, id];
    setSel(next);
    setCompat(null);
    if (next.length >= 2) {
      try { setCompat(await api.post("/sheets/compare", { sheet_ids: next })); } catch { /* ignore */ }
    }
  };
  return (
    <div className="stack-4">
      <div>
        <h2>{t("upload.choose")}</h2>
        <p className="muted" style={{ marginTop: 4 }}>{t("upload.choose.sub")}</p>
      </div>
      {warnings.map((w, i) => <div key={i} className="note">{w}</div>)}
      <div className="grid-auto">
        {sheets.map((s) => (
          <div key={s.id} role="checkbox" aria-checked={sel.includes(s.id)} tabIndex={0} className={clsx("sheet-card", sel.includes(s.id) && "selected")}
            onClick={() => toggle(s.id)} onKeyDown={(e) => (e.key === " " || e.key === "Enter") && (e.preventDefault(), toggle(s.id))}>
            <div className="row between"><strong className="ellipsis">{s.label}</strong><input type="checkbox" readOnly checked={sel.includes(s.id)} tabIndex={-1} /></div>
            <div className="subtle num">{s.rows.toLocaleString("en-IN")} rows · {s.cols} columns{s.header_row ? ` · header on row ${s.header_row}` : ""}</div>
            <div className="mini-table table-wrap">
              <table className="data"><thead><tr>{s.columns.slice(0, 5).map((c) => <th key={c}>{c}</th>)}</tr></thead>
                <tbody>{s.preview.slice(0, 3).map((r, i) => <tr key={i}>{r.slice(0, 5).map((v, j) => <td key={j}>{v ?? ""}</td>)}</tr>)}</tbody></table>
            </div>
            {s.notes && <div className="subtle" style={{ marginTop: 6 }}>{s.notes}</div>}
          </div>
        ))}
      </div>
      {compat && (
        <div className={compat.compatible ? "note" : "error-box"}>
          {compat.compatible ? `These tables share ${compat.overlap_pct}% of their columns and can be combined into one dataset.` : `These tables share only ${compat.overlap_pct}% of their columns, so they will be analysed as separate datasets.`}
          {compat.possible_relationships?.length > 0 && <> Shared key: {compat.possible_relationships.map((r: any) => `${r.column} (${r.value_overlap_pct}% overlap)`).join(", ")}.</>}
        </div>
      )}
      <div className="row wrap">
        <button className="btn primary" disabled={!sel.length || busy} onClick={() => onCreate(sel, false)}>{busy ? <Spinner /> : <FileSpreadsheet />}{t("upload.analyse")} ({sel.length})</button>
        {sel.length >= 2 && <button className="btn" disabled={busy || compat?.compatible === false} onClick={() => onCreate(sel, true)}><Layers />{t("upload.combine")}</button>}
      </div>
    </div>
  );
}

export function UploadFlow({ maxMb = 100, datasetId }: { maxMb?: number; datasetId?: string }) {
  const { t } = useI18n();
  const nav = useNavigate();
  const qc = useQueryClient();
  const toast = useToast();
  const input = useRef<HTMLInputElement>(null);
  const [over, setOver] = useState(false);
  const [phase, setPhase] = useState<Phase>("idle");
  const [pct, setPct] = useState(0);
  const [file, setFile] = useState<File | null>(null);
  const [error, setError] = useState<unknown>(null);
  const [result, setResult] = useState<any>(null);

  const finish = useCallback((res: any) => {
    const c = res?.created?.[0];
    qc.invalidateQueries();
    setPhase("done");
    if (c?.dashboard_id) nav(`/dashboards/${c.dashboard_id}?new=1`);
    else if (c?.dataset_id) nav(`/datasets/${c.dataset_id}`);
    if ((res?.created?.length ?? 0) > 1) toast.show(`${res.created.length} datasets created`);
  }, [nav, qc, toast]);

  const start = async (f: File) => {
    setFile(f);
    setError(null);
    if (f.size > maxMb * 1024 * 1024) { setError(new Error(`This file is ${bytes(f.size)}; the limit is ${maxMb} MB.`)); setPhase("error"); return; }
    if (!/\.(xlsx|xlsm|xls|csv|tsv|txt|json)$/i.test(f.name)) { setError(new Error("Upload an Excel (.xlsx, .xls), CSV or JSON file.")); setPhase("error"); return; }
    const form = new FormData();
    form.append("file", f);
    if (datasetId) form.append("dataset_id", datasetId);
    try {
      setPhase("uploading");
      const res = await uploadWithProgress("/uploads", form, setPct);
      setPhase("processing");
      const job = res.job.status === "done" || res.job.status === "failed" ? res.job : await pollJob(res.job.id);
      if (job.status === "failed") throw new Error(job.error);
      if (job.result.status === "needs_selection") { setResult(job.result); setPhase("select"); return; }
      finish(job.result);
    } catch (e) {
      setError(e);
      setPhase("error");
    }
  };

  const create = async (ids: string[], combine: boolean) => {
    try {
      setPhase("building");
      const r = await api.post("/datasets/from-sheets", { sheet_ids: ids, combine, dataset_id: datasetId ?? null });
      const job = r.job.status === "done" || r.job.status === "failed" ? r.job : await pollJob(r.job.id);
      if (job.status === "failed") throw new Error(job.error);
      finish(job.result);
    } catch (e) {
      setError(e);
      setPhase("select");
    }
  };

  const stage = phase === "uploading" ? 0 : phase === "processing" ? 1 : phase === "building" ? 3 : phase === "done" ? 6 : phase === "select" ? 2 : 0;

  if (phase === "select" && result) {
    return (
      <div className="panel panel-body stack-4">
        {error ? <ErrorBox error={error} /> : null}
        <SheetPicker sheets={result.sheets} warnings={result.warnings ?? []} onCreate={create} busy={false} />
      </div>
    );
  }

  return (
    <div>
      <div
        className={clsx("dropzone", over && "over")}
        role="button"
        tabIndex={0}
        aria-label={t("upload.drop")}
        onClick={() => phase !== "uploading" && phase !== "processing" && input.current?.click()}
        onKeyDown={(e) => (e.key === "Enter" || e.key === " ") && input.current?.click()}
        onDragOver={(e) => { e.preventDefault(); setOver(true); }}
        onDragLeave={() => setOver(false)}
        onDrop={(e) => { e.preventDefault(); setOver(false); const f = e.dataTransfer.files?.[0]; if (f) start(f); }}
      >
        <UploadCloud size={36} strokeWidth={1.5} style={{ color: "var(--accent)" }} />
        <h2 style={{ marginTop: 10 }}>{file && phase !== "idle" && phase !== "error" ? file.name : t("upload.drop")}</h2>
        <p className="muted">{phase === "uploading" ? `Uploading… ${pct}%` : phase === "processing" ? "Reading the workbook, detecting tables and headers…" : phase === "building" ? "Profiling columns, building the schema, KPIs and dashboard…" : t("upload.or")}</p>
        <p className="formats">{t("upload.formats", { mb: maxMb })}</p>
        <input ref={input} type="file" hidden accept=".xlsx,.xlsm,.xls,.csv,.tsv,.txt,.json" onChange={(e) => { const f = e.target.files?.[0]; if (f) start(f); e.target.value = ""; }} />
      </div>
      {phase !== "idle" && phase !== "error" && <Pipeline stage={stage} />}
      {phase === "error" && <div style={{ marginTop: 12 }}><ErrorBox error={error} onRetry={() => { setPhase("idle"); setError(null); }} /></div>}
    </div>
  );
}
