// Thin API client. Access token lives in memory; the refresh token in localStorage so a
// reload keeps the session. Every request carries the active organization (tenant).

const BASE = (import.meta.env.VITE_API_BASE as string | undefined) || "";
const API = `${BASE}/api/v1`;
const REFRESH_KEY = "mis.refresh";
const ORG_KEY = "mis.org";

let accessToken: string | null = null;
let orgId: string | null = localStorage.getItem(ORG_KEY);
let refreshing: Promise<boolean> | null = null;
let onLogout: (() => void) | null = null;

export class ApiError extends Error {
  status: number;
  requestId?: string;
  constructor(status: number, message: string, requestId?: string) {
    super(message);
    this.status = status;
    this.requestId = requestId;
  }
}

export const session = {
  setTokens(access: string, refresh: string | null) {
    accessToken = access;
    if (refresh) localStorage.setItem(REFRESH_KEY, refresh);
  },
  setOrg(id: string | null) {
    orgId = id;
    if (id) localStorage.setItem(ORG_KEY, id);
    else localStorage.removeItem(ORG_KEY);
  },
  get org() { return orgId; },
  get hasRefresh() { return !!localStorage.getItem(REFRESH_KEY); },
  clear() {
    accessToken = null;
    localStorage.removeItem(REFRESH_KEY);
  },
  onLogout(fn: () => void) { onLogout = fn; },
};

function headers(extra?: HeadersInit, json = true): Headers {
  const h = new Headers(extra);
  if (json && !h.has("Content-Type")) h.set("Content-Type", "application/json");
  if (accessToken) h.set("Authorization", `Bearer ${accessToken}`);
  if (orgId) h.set("X-Org-Id", orgId);
  return h;
}

export async function refreshSession(): Promise<boolean> {
  const rt = localStorage.getItem(REFRESH_KEY);
  if (!rt) return false;
  if (!refreshing) {
    refreshing = (async () => {
      try {
        const r = await fetch(`${API}/auth/refresh`, { method: "POST", headers: headers(), body: JSON.stringify({ refresh_token: rt }) });
        if (!r.ok) return false;
        const data = await r.json();
        session.setTokens(data.access_token, data.refresh_token);
        if (!orgId || !data.organizations.some((o: { id: string }) => o.id === orgId)) session.setOrg(data.current_org_id);
        return true;
      } catch {
        return false;
      } finally {
        setTimeout(() => (refreshing = null), 0);
      }
    })();
  }
  return refreshing;
}

async function parseError(r: Response): Promise<ApiError> {
  let msg = `Request failed (${r.status})`;
  let rid: string | undefined;
  try {
    const body = await r.json();
    if (typeof body.detail === "string") msg = body.detail;
    else if (Array.isArray(body.detail)) msg = body.detail.map((d: any) => d.msg).join("; ");
    rid = body.request_id;
  } catch { /* not JSON */ }
  if (r.status === 0 || r.status >= 502) msg = "The server is not reachable. Check that MIS Genius AI is running.";
  return new ApiError(r.status, msg, rid);
}

export async function request<T = any>(path: string, init: RequestInit & { json?: unknown; raw?: boolean } = {}, retry = true): Promise<T> {
  const isForm = init.body instanceof FormData;
  const opts: RequestInit = { ...init, headers: headers(init.headers, !isForm) };
  if (init.json !== undefined) opts.body = JSON.stringify(init.json);
  let r: Response;
  try {
    r = await fetch(`${API}${path}`, opts);
  } catch {
    throw new ApiError(0, "The server is not reachable. Check your connection and that MIS Genius AI is running.");
  }
  if (r.status === 401 && retry && !path.startsWith("/auth/")) {
    if (await refreshSession()) return request<T>(path, init, false);
    onLogout?.();
  }
  if (!r.ok) throw await parseError(r);
  if (init.raw) return r as unknown as T;
  const ct = r.headers.get("content-type") || "";
  return (ct.includes("application/json") ? r.json() : r.text()) as Promise<T>;
}

export const api = {
  get: <T = any>(p: string) => request<T>(p),
  post: <T = any>(p: string, json?: unknown) => request<T>(p, { method: "POST", json: json ?? {} }),
  put: <T = any>(p: string, json?: unknown) => request<T>(p, { method: "PUT", json: json ?? {} }),
  patch: <T = any>(p: string, json?: unknown) => request<T>(p, { method: "PATCH", json: json ?? {} }),
  del: <T = any>(p: string) => request<T>(p, { method: "DELETE" }),
  upload: <T = any>(p: string, form: FormData) => request<T>(p, { method: "POST", body: form }),
};

/** Download a file produced by a POST/GET endpoint (keeps auth headers, respects server filename). */
export async function download(path: string, init: RequestInit & { json?: unknown } = {}, fallbackName = "download"): Promise<void> {
  const r = await request<Response>(path, { ...init, raw: true });
  const cd = r.headers.get("content-disposition") || "";
  const star = /filename\*=UTF-8''([^;]+)/i.exec(cd);
  const plain = /filename="([^"]+)"/i.exec(cd);
  const name = star ? decodeURIComponent(star[1]) : plain ? plain[1] : fallbackName;
  const blob = await r.blob();
  const url = URL.createObjectURL(blob);
  if ((r.headers.get("content-type") || "").startsWith("text/html")) {
    window.open(url, "_blank", "noopener");
  } else {
    const a = document.createElement("a");
    a.href = url;
    a.download = name;
    document.body.appendChild(a);
    a.click();
    a.remove();
  }
  setTimeout(() => URL.revokeObjectURL(url), 60_000);
}

export async function pollJob(id: string, onProgress?: (j: any) => void, timeoutMs = 15 * 60_000): Promise<any> {
  const start = Date.now();
  let delay = 500;
  for (;;) {
    const j = await api.get(`/jobs/${id}`);
    onProgress?.(j);
    if (j.status === "done" || j.status === "failed") return j;
    if (Date.now() - start > timeoutMs) throw new ApiError(408, "Processing is taking longer than expected. It continues in the background.");
    await new Promise((res) => setTimeout(res, delay));
    delay = Math.min(delay * 1.4, 3000);
  }
}

/** Multipart upload with progress (fetch cannot report upload progress). */
export function uploadWithProgress<T = any>(path: string, form: FormData, onProgress: (pct: number) => void, retry = true): Promise<T> {
  return new Promise((resolve, reject) => {
    const xhr = new XMLHttpRequest();
    xhr.open("POST", `${API}${path}`);
    if (accessToken) xhr.setRequestHeader("Authorization", `Bearer ${accessToken}`);
    if (orgId) xhr.setRequestHeader("X-Org-Id", orgId);
    xhr.upload.onprogress = (e) => e.lengthComputable && onProgress(Math.round((e.loaded / e.total) * 100));
    xhr.onerror = () => reject(new ApiError(0, "Upload failed: the server is not reachable."));
    xhr.onload = async () => {
      if (xhr.status === 401 && retry && (await refreshSession())) {
        uploadWithProgress<T>(path, form, onProgress, false).then(resolve, reject);
        return;
      }
      let body: any = null;
      try { body = JSON.parse(xhr.responseText); } catch { /* ignore */ }
      if (xhr.status >= 200 && xhr.status < 300) resolve(body as T);
      else reject(new ApiError(xhr.status, body?.detail ?? `Upload failed (${xhr.status})`, body?.request_id));
    };
    xhr.send(form);
  });
}
