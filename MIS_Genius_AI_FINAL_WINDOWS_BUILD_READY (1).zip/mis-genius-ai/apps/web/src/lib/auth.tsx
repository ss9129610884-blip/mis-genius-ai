import { createContext, useCallback, useContext, useEffect, useMemo, useState, type ReactNode } from "react";
import { api, refreshSession, session } from "./api";
import type { Org, User } from "./types";

interface AuthState {
  ready: boolean;
  user: User | null;
  orgs: Org[];
  org: Org | null;
  role: string | null;
  permissions: string[];
  can: (perm: string) => boolean;
  login: (email: string, password: string) => Promise<void>;
  register: (data: { email: string; password: string; full_name: string; org_name: string; language: string }) => Promise<void>;
  logout: () => Promise<void>;
  switchOrg: (id: string) => Promise<void>;
  reload: () => Promise<void>;
}

const Ctx = createContext<AuthState | null>(null);

export function AuthProvider({ children }: { children: ReactNode }) {
  const [ready, setReady] = useState(false);
  const [user, setUser] = useState<User | null>(null);
  const [orgs, setOrgs] = useState<Org[]>([]);
  const [role, setRole] = useState<string | null>(null);
  const [permissions, setPermissions] = useState<string[]>([]);

  const apply = useCallback((data: any) => {
    if (data.access_token) session.setTokens(data.access_token, data.refresh_token ?? null);
    const current = session.org && data.organizations.some((o: Org) => o.id === session.org) ? session.org : data.current_org_id;
    session.setOrg(current);
    setUser(data.user);
    setOrgs(data.organizations);
    const o = data.organizations.find((x: Org) => x.id === current);
    setRole(o?.role ?? data.role ?? null);
    setPermissions(data.permissions ?? []);
  }, []);

  const reload = useCallback(async () => {
    const me = await api.get("/auth/me");
    apply(me);
  }, [apply]);

  useEffect(() => {
    session.onLogout(() => {
      session.clear();
      setUser(null);
    });
    (async () => {
      try {
        if (session.hasRefresh && (await refreshSession())) await reload();
      } catch {
        session.clear();
      } finally {
        setReady(true);
      }
    })();
  }, [reload]);

  const value = useMemo<AuthState>(() => ({
    ready, user, orgs, role, permissions,
    org: orgs.find((o) => o.id === session.org) ?? null,
    can: (perm) => permissions.includes(perm),
    async login(email, password) {
      const data = await api.post("/auth/login", { email, password });
      apply(data);
      await reload();
    },
    async register(body) {
      const data = await api.post("/auth/register", body);
      session.setOrg(data.current_org_id);
      apply(data);
      await reload();
    },
    async logout() {
      const rt = localStorage.getItem("mis.refresh");
      try { if (rt) await api.post("/auth/logout", { refresh_token: rt }); } catch { /* ignore */ }
      session.clear();
      setUser(null);
    },
    async switchOrg(id) {
      session.setOrg(id);
      await reload();
    },
    reload,
  }), [ready, user, orgs, role, permissions, apply, reload]);

  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useAuth(): AuthState {
  const v = useContext(Ctx);
  if (!v) throw new Error("useAuth outside AuthProvider");
  return v;
}
