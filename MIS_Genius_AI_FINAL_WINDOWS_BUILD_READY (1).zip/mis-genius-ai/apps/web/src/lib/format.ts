import type { KPIFormat } from "./types";

const SYMBOL: Record<string, string> = { INR: "₹", USD: "$", EUR: "€", GBP: "£", JPY: "¥" };

export function compact(v: number, indian = true): string {
  const a = Math.abs(v);
  const sign = v < 0 ? "-" : "";
  const fmt = (x: number) => x.toLocaleString("en-IN", { maximumFractionDigits: 2 });
  if (indian) {
    if (a >= 1e7) return `${sign}${fmt(a / 1e7)} Cr`;
    if (a >= 1e5) return `${sign}${fmt(a / 1e5)} L`;
    if (a >= 1e3) return `${sign}${fmt(a / 1e3)}K`;
  } else {
    if (a >= 1e9) return `${sign}${fmt(a / 1e9)}B`;
    if (a >= 1e6) return `${sign}${fmt(a / 1e6)}M`;
    if (a >= 1e3) return `${sign}${fmt(a / 1e3)}K`;
  }
  return `${sign}${fmt(a)}`;
}

export interface NumPrefs { currency?: string; locale?: string; compact?: boolean }

export function formatValue(v: unknown, f?: Partial<KPIFormat> | null, prefs: NumPrefs = {}): string {
  if (v === null || v === undefined || v === "") return "—";
  if (typeof v !== "number") return String(v);
  if (!Number.isFinite(v)) return "—";
  const kind = f?.kind ?? "number";
  const locale = prefs.locale || "en-IN";
  const indian = locale === "en-IN" || locale === "hi-IN";
  if (kind === "percent") return `${v.toLocaleString(locale, { maximumFractionDigits: f?.decimals ?? 1, minimumFractionDigits: 0 })}%`;
  const cur = kind === "currency" ? (f?.currency || prefs.currency || "INR") : null;
  const sym = cur ? SYMBOL[cur.toUpperCase()] ?? `${cur} ` : "";
  const useCompact = (f?.compact ?? prefs.compact ?? true) && Math.abs(v) >= 100000;
  const body = useCompact
    ? compact(v, indian)
    : v.toLocaleString(locale, { maximumFractionDigits: f?.decimals ?? (Number.isInteger(v) ? 0 : 2) });
  return `${f?.prefix ?? ""}${sym}${body}${f?.suffix ?? ""}`;
}

export function formatCell(v: unknown, dataType?: string, prefs: NumPrefs = {}): string {
  if (v === null || v === undefined) return "";
  if (typeof v === "number") {
    if (dataType === "currency") return formatValue(v, { kind: "currency", compact: false }, prefs);
    if (dataType === "percentage") return formatValue(v, { kind: "percent" }, prefs);
    return v.toLocaleString(prefs.locale || "en-IN", { maximumFractionDigits: 4 });
  }
  if (typeof v === "boolean") return v ? "Yes" : "No";
  const s = String(v);
  if (/^\d{4}-\d{2}-\d{2}( 00:00:00)?$/.test(s)) return formatDate(s.slice(0, 10));
  return s;
}

export function formatDate(iso: string): string {
  const d = new Date(iso.length === 10 ? iso + "T00:00:00" : iso);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "numeric" });
}

export function formatPeriod(v: unknown, granularity?: string | null): string {
  if (typeof v !== "string") return String(v ?? "(Blank)");
  if (!/^\d{4}-\d{2}-\d{2}/.test(v)) return v;
  const d = new Date(v.slice(0, 10) + "T00:00:00");
  if (Number.isNaN(d.getTime())) return v;
  switch (granularity) {
    case "month": return d.toLocaleDateString("en-IN", { month: "short", year: "numeric" });
    case "quarter": return `Q${Math.floor(d.getMonth() / 3) + 1} ${d.getFullYear()}`;
    case "year": return String(d.getFullYear());
    case "week": return "Wk " + d.toLocaleDateString("en-IN", { day: "2-digit", month: "short" });
    default: return d.toLocaleDateString("en-IN", { day: "2-digit", month: "short", year: "2-digit" });
  }
}

export function relTime(iso?: string | null): string {
  if (!iso) return "";
  const s = (Date.now() - new Date(iso).getTime()) / 1000;
  if (s < 60) return "just now";
  if (s < 3600) return `${Math.floor(s / 60)} min ago`;
  if (s < 86400) return `${Math.floor(s / 3600)} h ago`;
  if (s < 86400 * 30) return `${Math.floor(s / 86400)} d ago`;
  return formatDate(iso.slice(0, 10));
}

export function bytes(n: number): string {
  if (n < 1024) return `${n} B`;
  if (n < 1024 ** 2) return `${(n / 1024).toFixed(1)} KB`;
  return `${(n / 1024 ** 2).toFixed(1)} MB`;
}
