import { createContext, useCallback, useContext, useEffect, useMemo, useRef, useState, type ReactNode } from "react";

// ---------------------------------------------------------------- theme
type Theme = "light" | "dark" | "system";
interface ThemeCtx { theme: Theme; resolved: "light" | "dark"; setTheme: (t: Theme) => void }
const TCtx = createContext<ThemeCtx | null>(null);

export function ThemeProvider({ children }: { children: ReactNode }) {
  const [theme, setThemeState] = useState<Theme>(() => (localStorage.getItem("mis.theme") as Theme) || "system");
  const [sysDark, setSysDark] = useState(() => window.matchMedia?.("(prefers-color-scheme: dark)").matches ?? false);
  useEffect(() => {
    const mq = window.matchMedia?.("(prefers-color-scheme: dark)");
    const fn = (e: MediaQueryListEvent) => setSysDark(e.matches);
    mq?.addEventListener?.("change", fn);
    return () => mq?.removeEventListener?.("change", fn);
  }, []);
  const resolved = theme === "system" ? (sysDark ? "dark" : "light") : theme;
  useEffect(() => { document.documentElement.dataset.theme = resolved; }, [resolved]);
  const setTheme = useCallback((t: Theme) => { localStorage.setItem("mis.theme", t); setThemeState(t); }, []);
  const value = useMemo(() => ({ theme, resolved, setTheme }), [theme, resolved, setTheme]);
  return <TCtx.Provider value={value}>{children}</TCtx.Provider>;
}

export function useTheme() {
  const v = useContext(TCtx);
  if (!v) throw new Error("useTheme outside provider");
  return v;
}

// ---------------------------------------------------------------- toasts
interface Toast { id: number; text: string; kind: "info" | "error" }
interface ToastCtx { show: (text: string, kind?: "info" | "error") => void }
const ToCtx = createContext<ToastCtx | null>(null);

export function ToastProvider({ children }: { children: ReactNode }) {
  const [items, setItems] = useState<Toast[]>([]);
  const n = useRef(0);
  const show = useCallback((text: string, kind: "info" | "error" = "info") => {
    const id = ++n.current;
    setItems((x) => [...x, { id, text, kind }]);
    setTimeout(() => setItems((x) => x.filter((t) => t.id !== id)), kind === "error" ? 7000 : 3500);
  }, []);
  const value = useMemo(() => ({ show }), [show]);
  return (
    <ToCtx.Provider value={value}>
      {children}
      <div className="toasts" role="status" aria-live="polite">
        {items.map((t) => <div key={t.id} className={`toast ${t.kind === "error" ? "error" : ""}`}>{t.text}</div>)}
      </div>
    </ToCtx.Provider>
  );
}

export function useToast() {
  const v = useContext(ToCtx);
  if (!v) throw new Error("useToast outside provider");
  return v;
}

export function errMsg(e: unknown): string {
  if (e instanceof Error) return e.message;
  return String(e);
}
