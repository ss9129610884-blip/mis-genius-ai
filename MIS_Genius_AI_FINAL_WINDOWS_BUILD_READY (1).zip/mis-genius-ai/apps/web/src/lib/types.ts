// Shared types mirroring the API (services/api/misgenius/api/schemas.py and analytics models).

export type FilterOp =
  | "eq" | "neq" | "in" | "not_in" | "gt" | "gte" | "lt" | "lte" | "between" | "contains" | "not_contains"
  | "starts_with" | "is_null" | "not_null" | "date_range" | "relative";

export interface Filter {
  column: string;
  op: FilterOp;
  value?: unknown;
  values?: unknown[] | null;
}

export type Agg = "count" | "count_rows" | "sum" | "avg" | "min" | "max" | "median" | "count_distinct" | "stddev" | "variance";
export type Granularity = "day" | "week" | "month" | "quarter" | "year" | "fy" | "day_of_week" | "month_of_year" | "hour";

export interface Measure { column?: string | null; agg: Agg; formula?: string | null; alias?: string | null; filters?: Filter[] }
export interface Dimension { column: string; granularity?: Granularity | null; alias?: string | null }

export type ChartType =
  | "bar" | "hbar" | "line" | "area" | "pie" | "donut" | "scatter" | "histogram" | "stacked_bar" | "stacked_bar_100"
  | "combo" | "kpi" | "table" | "pivot" | "heatmap";

export interface ChartSpec {
  type: ChartType;
  dimension?: Dimension | null;
  series_dimension?: Dimension | null;
  measures?: Measure[];
  x_measure?: Measure | null;
  y_measure?: Measure | null;
  histogram_column?: string | null;
  bins?: number;
  top_n?: number;
  other?: boolean;
  sort?: "value_desc" | "value_asc" | "label" | "natural";
  transform?: "none" | "running_total" | "moving_average" | "contribution";
  window?: number;
  filters?: Filter[];
  columns?: string[] | null;
  limit?: number;
}

export interface KPIFormat { kind: "number" | "currency" | "percent"; currency?: string | null; decimals?: number | null; compact?: boolean; prefix?: string | null; suffix?: string | null }
export interface KPISpec {
  id?: string | null;
  title: string;
  measure?: Measure | null;
  ratio?: { numerator: Measure; denominator: Measure; as_percent: boolean } | null;
  filters?: Filter[];
  format?: KPIFormat;
  comparison?: { enabled: boolean; date_column?: string | null; granularity?: string | null; mode?: string } | null;
  sparkline?: boolean;
  target?: number | null;
  description?: string | null;
  higher_is_better?: boolean;
}

export interface KPIResult {
  id?: string; title: string; value: number | null; available: boolean; reason?: string; format: KPIFormat; target?: number | null;
  higher_is_better?: boolean; description?: string | null;
  evidence?: { calculation: string; sql: string; rows_considered: number; numerator?: number; denominator?: number; filters: Filter[] };
  comparison?: { available: boolean; reason?: string; current_period?: string; previous_period?: string; current_value?: number; previous_value?: number;
    change?: number; change_pct?: number | null; granularity?: string; note?: string | null; calculation?: string; latest_period_partial?: boolean };
  sparkline?: { period: string; label: string; value: number | null }[];
  target_pct?: number;
}

export interface ChartResult {
  type: string;
  categories?: unknown[];
  series?: { name: string; data: (number | null)[]; kind?: string | null; transform?: string }[];
  dimension?: Dimension; series_dimension?: Dimension; is_time?: boolean; granularity?: string | null;
  points?: { x: number; y: number; label?: unknown }[]; x_name?: string; y_name?: string; correlation?: number | null;
  x?: unknown[]; y?: unknown[]; data?: [number, number, number | null][]; measure?: string;
  columns?: string[]; rows?: unknown[][]; totals?: unknown[] | null;
  meta?: Record<string, unknown>; evidence?: { sql?: string };
  // pivot
  row_fields?: string[]; column_field?: string | null; column_keys?: string[]; values?: string[];
  column_totals?: Record<string, unknown[]>; grand_total?: unknown[]; truncated_columns?: boolean;
  error?: string;
}

export interface ColumnInfo {
  name: string; original_name: string; position: number; data_type: string; role: string; confidence: number; semantic_tags: string[];
  stats: Record<string, any>; format: Record<string, any>; label: string; description?: string | null; user_override: boolean;
}

export interface Schema {
  row_count: number; column_count: number; columns: ColumnInfo[]; dimensions: string[]; measures: string[]; date_columns: string[];
  primary_date_column: string | null; categorical_columns: string[]; numeric_columns: string[]; text_columns: string[];
  identifier_columns: string[]; possible_currency_columns: string[]; possible_percentage_columns: string[];
  relationships: any[]; confidence: Record<string, number>; domain: { guess: string; candidates: { domain: string; confidence: number }[] };
  data_quality: Record<string, any>;
}

export interface QualityIssue { type: string; severity: "critical" | "warning" | "info"; column: string | null; message: string; message_hi: string;
  count?: number | null; percent?: number | null; examples: unknown[]; suggested_action?: { op: string; params?: Record<string, unknown> } | null }
export interface Quality { summary: Record<string, any>; issues: QualityIssue[]; per_column: Record<string, any> }

export interface Widget { id: string; widget_type: string; title: string; config: any; layout: { x: number; y: number; w: number; h: number }; position: number; hidden: boolean }
export interface DashFilterDef { id: string; column: string | null; type: "date_range" | "multi_select" | "numeric_range" | "search"; label: string }
export interface Dashboard {
  id: string; name: string; description: string; dataset_id: string; auto_generated: boolean; config: any; widgets: Widget[];
  dataset?: { id: string; name: string; is_demo: boolean; rows: number; version_number: number; primary_date_column: string | null };
  schema?: Schema; quality?: Quality; saved_filters?: { id: string; name: string; filters: Filter[] }[];
}

export interface Dataset {
  id: string; name: string; description: string; source_type: string; is_demo: boolean; rows?: number; columns?: number; version_number?: number;
  quality_score?: number; domain?: string; primary_date_column?: string | null; created_at: string; updated_at: string; dashboards?: any;
  current_version_id?: string | null; refresh_minutes?: number | null; last_refreshed_at?: string | null; deleted_at?: string | null;
}

export interface Job { id: string; kind: string; status: "queued" | "running" | "done" | "failed"; progress: number; result: any; error: string | null }

export interface Org { id: string; name: string; plan: string; role: string; settings: Record<string, any> }
export interface User { id: string; email: string; full_name: string; language: "en" | "hi" }
