import { createContext, useCallback, useContext, useMemo, useState, type ReactNode } from "react";

export type Lang = "en" | "hi";

// English-first, localisation-ready. Add a language by adding a dictionary with the same keys.
const en = {
  "nav.home": "Home", "nav.upload": "Upload data", "nav.datasets": "Datasets", "nav.dashboards": "Dashboards", "nav.ask": "Ask AI",
  "nav.reports": "Reports", "nav.templates": "Templates", "nav.sources": "Data sources", "nav.settings": "Settings", "nav.work": "Work", "nav.admin": "Manage",
  "action.upload": "Upload a file", "action.save": "Save", "action.cancel": "Cancel", "action.delete": "Delete", "action.edit": "Edit",
  "action.export": "Export", "action.duplicate": "Duplicate", "action.reset": "Reset", "action.add": "Add", "action.close": "Close",
  "action.apply": "Apply", "action.clear": "Clear all", "action.ask": "Ask", "action.generate": "Generate", "action.signout": "Sign out",
  "action.retry": "Try again", "action.open": "Open", "action.preview": "Preview", "action.download": "Download",
  "home.title": "Turn a spreadsheet into an MIS dashboard", "home.sub": "Upload any Excel or CSV file. MIS Genius AI reads its structure, checks the data, builds KPIs and charts, and explains what changed — using only your numbers.",
  "home.recent": "Recent dashboards", "home.datasets": "Your datasets", "home.demo": "No file handy? Explore with sample data",
  "home.demo.sales": "Sample sales data", "home.demo.attendance": "Sample attendance data",
  "upload.drop": "Drop an Excel or CSV file here", "upload.or": "or click to choose a file", "upload.formats": "XLSX, XLS, CSV or JSON · up to {mb} MB",
  "upload.stage.upload": "Upload", "upload.stage.inspect": "Inspect", "upload.stage.profile": "Profile", "upload.stage.schema": "Schema",
  "upload.stage.kpis": "KPIs", "upload.stage.dashboard": "Dashboard", "upload.choose": "Choose the tables to analyse",
  "upload.choose.sub": "This workbook has several tables. Pick one or more; compatible sheets can be combined into one dataset.",
  "upload.analyse": "Analyse selected", "upload.combine": "Combine into one dataset",
  "dash.filters": "Filters", "dash.edit": "Edit layout", "dash.done": "Done editing", "dash.addWidget": "Add widget", "dash.saveTemplate": "Save as template",
  "dash.explore": "Open in data explorer", "dash.insights": "AI insights", "dash.quality": "Data quality", "dash.demo": "Demo data — synthetic records for exploring the product. Not real business data.",
  "dash.showing": "Showing {n} of {total} records", "dash.noFilters": "No filters applied",
  "kpi.how": "How is this calculated?", "kpi.unavailable": "Cannot be determined from this dataset", "kpi.vs": "vs {period}",
  "ask.placeholder": "Ask about your data, e.g. “Which region has the highest sales?” or “पिछले महीने की तुलना में क्या बदला?”",
  "ask.title": "Ask your data", "ask.sub": "Questions are turned into safe queries on your dataset. Answers show exactly what was calculated.",
  "ask.how": "How this was answered",
  "reports.title": "Reports", "reports.sub": "Executive reports built from computed facts. Every number is traceable to your data.",
  "reports.generate": "Generate report",
  "common.loading": "Loading…", "common.rows": "rows", "common.columns": "columns", "common.version": "Version", "common.none": "None",
  "common.language": "Language", "common.theme": "Theme", "common.search": "Search datasets, dashboards, columns…",
  "settings.title": "Settings",
  "empty.datasets": "No datasets yet", "empty.datasets.sub": "Upload an Excel or CSV file to create your first dataset and dashboard.",
  "empty.dashboards": "No dashboards yet",
};

type Dict = Record<keyof typeof en, string>;

const hi: Dict = {
  "nav.home": "होम", "nav.upload": "डेटा अपलोड", "nav.datasets": "डेटासेट", "nav.dashboards": "डैशबोर्ड", "nav.ask": "AI से पूछें",
  "nav.reports": "रिपोर्ट", "nav.templates": "टेम्पलेट", "nav.sources": "डेटा स्रोत", "nav.settings": "सेटिंग्स", "nav.work": "काम", "nav.admin": "प्रबंधन",
  "action.upload": "फ़ाइल अपलोड करें", "action.save": "सेव करें", "action.cancel": "रद्द करें", "action.delete": "हटाएँ", "action.edit": "बदलें",
  "action.export": "एक्सपोर्ट", "action.duplicate": "कॉपी बनाएँ", "action.reset": "रीसेट", "action.add": "जोड़ें", "action.close": "बंद करें",
  "action.apply": "लागू करें", "action.clear": "सब हटाएँ", "action.ask": "पूछें", "action.generate": "बनाएँ", "action.signout": "साइन आउट",
  "action.retry": "फिर से कोशिश करें", "action.open": "खोलें", "action.preview": "पूर्वावलोकन", "action.download": "डाउनलोड",
  "home.title": "स्प्रेडशीट से MIS डैशबोर्ड बनाइए", "home.sub": "कोई भी Excel या CSV फ़ाइल अपलोड करें। MIS Genius AI उसकी संरचना पढ़ता है, डेटा जाँचता है, KPI और चार्ट बनाता है और बताता है कि क्या बदला — केवल आपके आँकड़ों से।",
  "home.recent": "हाल के डैशबोर्ड", "home.datasets": "आपके डेटासेट", "home.demo": "फ़ाइल नहीं है? सैंपल डेटा से देखें",
  "home.demo.sales": "सैंपल बिक्री डेटा", "home.demo.attendance": "सैंपल उपस्थिति डेटा",
  "upload.drop": "Excel या CSV फ़ाइल यहाँ छोड़ें", "upload.or": "या फ़ाइल चुनने के लिए क्लिक करें", "upload.formats": "XLSX, XLS, CSV या JSON · {mb} MB तक",
  "upload.stage.upload": "अपलोड", "upload.stage.inspect": "जाँच", "upload.stage.profile": "प्रोफ़ाइल", "upload.stage.schema": "स्कीमा",
  "upload.stage.kpis": "KPI", "upload.stage.dashboard": "डैशबोर्ड", "upload.choose": "विश्लेषण के लिए टेबल चुनें",
  "upload.choose.sub": "इस वर्कबुक में कई टेबल हैं। एक या अधिक चुनें; मिलती-जुलती शीट को एक डेटासेट में जोड़ा जा सकता है।",
  "upload.analyse": "चुनी हुई का विश्लेषण करें", "upload.combine": "एक डेटासेट में जोड़ें",
  "dash.filters": "फ़िल्टर", "dash.edit": "लेआउट बदलें", "dash.done": "बदलाव पूरे", "dash.addWidget": "विजेट जोड़ें", "dash.saveTemplate": "टेम्पलेट के रूप में सेव करें",
  "dash.explore": "डेटा एक्सप्लोरर में खोलें", "dash.insights": "AI इनसाइट", "dash.quality": "डेटा गुणवत्ता", "dash.demo": "डेमो डेटा — उत्पाद देखने के लिए कृत्रिम रिकॉर्ड। वास्तविक व्यावसायिक डेटा नहीं।",
  "dash.showing": "{total} में से {n} रिकॉर्ड", "dash.noFilters": "कोई फ़िल्टर नहीं",
  "kpi.how": "यह कैसे गणना हुआ?", "kpi.unavailable": "इस डेटा से तय नहीं किया जा सकता", "kpi.vs": "{period} की तुलना में",
  "ask.placeholder": "अपने डेटा के बारे में पूछें, जैसे “सबसे ज्यादा बिक्री किस क्षेत्र में हुई?”",
  "ask.title": "अपने डेटा से पूछें", "ask.sub": "प्रश्नों को आपके डेटा पर सुरक्षित क्वेरी में बदला जाता है। उत्तर में दिखता है कि क्या गणना हुई।",
  "ask.how": "उत्तर कैसे निकाला गया",
  "reports.title": "रिपोर्ट", "reports.sub": "गणना किए गए तथ्यों से बनी कार्यकारी रिपोर्ट। हर संख्या आपके डेटा से जुड़ी है।",
  "reports.generate": "रिपोर्ट बनाएँ",
  "common.loading": "लोड हो रहा है…", "common.rows": "पंक्तियाँ", "common.columns": "कॉलम", "common.version": "संस्करण", "common.none": "कोई नहीं",
  "common.language": "भाषा", "common.theme": "थीम", "common.search": "डेटासेट, डैशबोर्ड, कॉलम खोजें…",
  "settings.title": "सेटिंग्स",
  "empty.datasets": "अभी कोई डेटासेट नहीं", "empty.datasets.sub": "पहला डेटासेट और डैशबोर्ड बनाने के लिए Excel या CSV फ़ाइल अपलोड करें।",
  "empty.dashboards": "अभी कोई डैशबोर्ड नहीं",
};

const dicts: Record<Lang, Dict> = { en, hi };
export type TKey = keyof typeof en;

interface I18n { lang: Lang; setLang: (l: Lang) => void; t: (k: TKey, vars?: Record<string, string | number>) => string }
const Ctx = createContext<I18n | null>(null);

export function I18nProvider({ children }: { children: ReactNode }) {
  const [lang, setLangState] = useState<Lang>(() => (localStorage.getItem("mis.lang") as Lang) || "en");
  const setLang = useCallback((l: Lang) => {
    localStorage.setItem("mis.lang", l);
    document.documentElement.lang = l;
    setLangState(l);
  }, []);
  const value = useMemo<I18n>(() => ({
    lang, setLang,
    t: (k, vars) => {
      let s = dicts[lang][k] ?? en[k] ?? k;
      if (vars) for (const [a, b] of Object.entries(vars)) s = s.replace(`{${a}}`, String(b));
      return s;
    },
  }), [lang, setLang]);
  return <Ctx.Provider value={value}>{children}</Ctx.Provider>;
}

export function useI18n(): I18n {
  const v = useContext(Ctx);
  if (!v) throw new Error("useI18n outside provider");
  return v;
}
