# MIS Genius AI — Final Windows Installer Build

This project is now configured so the **end-user installer does not require Python, pip, Node.js, npm, Visual Studio, or Build Tools**.

The actual Windows installer must be built on Windows because PyInstaller produces a Windows executable and Inno Setup is Windows software.

## What was fixed

- `apps/desktop/launcher.py` now adds `services/api` to `sys.path` when run from the source tree, preventing `ModuleNotFoundError: misgenius` in source launches.
- The real distribution path is the PyInstaller frozen application; the installer must launch `MISGeniusAI.exe`, not raw `launcher.py`.
- `.github/workflows/windows-installer-final.yml` builds the Windows installer on a Windows runner and uploads the `.exe` as an artifact.

## End-user result

`MISGeniusAI-Setup-1.0.0.exe` installs the bundled Python runtime and all application dependencies inside the application package. The end-user does not install Python/pip/Node/npm/Visual Studio.

## Build

Use the GitHub Actions workflow **Build MIS Genius AI Windows Installer**. It builds on `windows-latest` and produces:

- `MISGeniusAI-Setup-<version>.exe`
- `MISGeniusAI-Portable-<version>.zip`
