# Mobile (PWA, Android, iOS)

The mobile experience reuses the same web app and the same backend API — there is no separate analytics
engine. The UI is responsive down to 360 px with a bottom navigation bar on phones.

## Option 1 — Progressive Web App (no app store)
Open your server URL on the phone (cloud or LAN) and choose **Add to Home screen / Install app**.
The PWA (`apps/web/public/manifest.webmanifest`, `sw.js`) opens full-screen, starts quickly from the cached app
shell and uses the live server for data. Business data is never cached on the device.

## Option 2 — Android / iOS app with Capacitor
`apps/mobile` contains the Capacitor 7 configuration and a generated Android project (`apps/mobile/android`).

Requirements: Node.js 20+, Android Studio (Android) or Xcode on macOS (iOS).

**Bundled UI** (app contains the UI, talks to your server):
```bash
cd apps/mobile
npm install
MIS_SERVER_URL=https://mis.example.com npm run android     # builds web with VITE_API_BASE, syncs, opens Android Studio
```
On the server allow the app's origins: `CORS_ORIGINS=https://localhost,capacitor://localhost`.

**Remote UI** (app loads the UI from the server; updates instantly):
```bash
MIS_REMOTE_UI=1 MIS_SERVER_URL=https://mis.example.com npx cap sync android
```

iOS: `npx cap add ios && MIS_SERVER_URL=… npm run ios` (macOS with Xcode).

In Android Studio: *Build → Generate Signed Bundle / APK*. App id: `ai.misgenius.app` (change in
`capacitor.config.ts` before publishing).

## Mobile features
Sign-in, organization switching, home and upload (from phone storage / Google Drive picker), dashboards with KPIs,
charts and filters (widgets stack in one column), cross-filtering by tapping chart items, AI insights, Ask AI in
English/Hindi, datasets and data explorer, reports (download PDF/Excel), notifications bell (in-app alerts).

## Notes
* The Android project was generated in this build; compiling an APK requires the Android SDK, which is part of
  Android Studio.
* Push notifications are not included: alerts appear in-app and by email/webhook. A push channel can be added in
  `notifications/service.py` using Firebase Cloud Messaging.
