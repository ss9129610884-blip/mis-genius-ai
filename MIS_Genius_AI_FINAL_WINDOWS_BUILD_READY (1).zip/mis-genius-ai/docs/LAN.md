# Office network (LAN) mode

One office PC runs MIS Genius AI; everyone else uses a browser — no installation on their PCs.

## Start the server
* **Windows installer:** use the Start-menu shortcut *MIS Genius AI (office network)*, or run
  `MISGeniusAI.exe --lan`. Tick “Allow other computers…” during installation to add the firewall rule, or run
  `scripts\windows\open-firewall.ps1` as Administrator later.
* **From source:** `scripts/start_lan.sh` (Linux/macOS) or `scripts\start_lan.bat` (Windows).

LAN mode sets `APP_ENV=lan` and binds to `0.0.0.0:8765`. The control window / console lists the addresses,
for example `http://192.168.1.20:8765`.

## Connect from other PCs, tablets or phones
Open `http://<server-ip>:8765` in any modern browser. On phones use “Add to Home screen” to install it as an app
(PWA). Each person signs in with their own account — the owner adds people in **Settings → Members** and
chooses their role (viewer, analyst, admin).

## Recommendations
* Give the server PC a fixed IP address (router DHCP reservation) or use its computer name
  (`http://ACCOUNTS-PC:8765`).
* Keep it running during office hours; disable sleep in Windows power settings.
* Schedule backups: `python scripts/backup.py backup --dest \\NAS\Backups` (or Settings → Backup).
* The firewall rule is limited to *private* and *domain* networks; do not expose port 8765 to the internet.
  For access outside the office use the cloud deployment (HTTPS) or a VPN.
* Up to a few dozen concurrent users is comfortable on SQLite. For more, point `DATABASE_URL` to PostgreSQL.

## Security in LAN mode
Authentication is always on; roles and audit logging work exactly as in the cloud. Traffic inside the LAN is plain
HTTP — put nginx with a certificate in front (see `infrastructure/docker/nginx.conf`) if your policy requires TLS
internally. Connectors may reach private addresses in LAN mode (useful for internal databases); disable with
`ALLOW_PRIVATE_NETWORK_CONNECTORS=false`.
