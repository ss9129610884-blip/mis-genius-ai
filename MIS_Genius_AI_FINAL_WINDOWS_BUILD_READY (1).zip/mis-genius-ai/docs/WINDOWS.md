# Windows desktop application

Target: Windows 10/11 x64. End users need **nothing pre-installed** — no Python, Node.js or Visual Studio.

## For end users
1. Run `MISGeniusAI-Setup-<version>.exe`. Options: desktop shortcut, office-network shortcut, firewall rule.
2. Double-click **MIS Genius AI**. A small window shows the address and opens the app in an app-style window
   (Microsoft Edge or Chrome in `--app` mode; otherwise the default browser).
3. The first time, create the owner account.
4. Keep the small window open while working; **Stop and exit** shuts the server down.

Data folder: `%LOCALAPPDATA%\MISGeniusAI` (database, uploaded files, logs). Uninstalling removes the program,
not this folder. Optional settings (AI key, SMTP…) go in `%LOCALAPPDATA%\MISGeniusAI\settings.env`, e.g.
```
AI_PROVIDER=anthropic
AI_API_KEY=sk-ant-...
```
(Or set the AI provider in the app: Settings → AI provider.)

Portable version: unzip `MISGeniusAI-Portable-<version>.zip` anywhere and run `MISGeniusAI.exe`.

Launcher options: `MISGeniusAI.exe --lan` (share on the network), `--port 9000`, `--no-browser`.
If the app is already running, starting it again just opens the window.

## How the package is built
* `apps/desktop/launcher.py` — sets `APP_ENV=local`, picks a free port (8765 by default), starts the FastAPI
  server in-process, waits for `/api/v1/health`, opens the window, shows the control window (tkinter).
* `apps/desktop/misgenius.spec` — PyInstaller one-folder build containing the Python runtime, all dependencies
  (prebuilt wheels), Alembic migrations and the built web app. Isolated from any system Python.
* `apps/desktop/installer.iss` — Inno Setup: Program Files install, Start-menu and desktop shortcuts,
  optional firewall rule, uninstaller (removes the firewall rule too).
* `apps/desktop/build_windows.ps1` — the whole pipeline.

### Build steps (on a Windows build machine)
Requirements: Python 3.11 x64, Node.js 20+, Inno Setup 6 (`iscc` on PATH).
```powershell
powershell -ExecutionPolicy Bypass -File apps\desktop\build_windows.ps1
```
It builds the web app, creates `.build-venv`, installs pinned dependencies with `--only-binary=:all:` (so no C
compiler / Build Tools are ever needed), runs the test suite, runs PyInstaller, and produces:
* `dist\installer\MISGeniusAI-Setup-<version>.exe`
* `dist\installer\MISGeniusAI-Portable-<version>.zip`

The GitHub Actions job `windows-installer` in `.github/workflows/ci.yml` runs the same script on
`windows-latest` and uploads both files as artifacts.

### Code signing (recommended for distribution)
Unsigned installers trigger Windows SmartScreen. Sign `dist\MISGeniusAI\MISGeniusAI.exe` and the setup file with
`signtool sign /fd sha256 /tr http://timestamp.digicert.com /td sha256 /a <file>` using your code-signing
certificate, or add `SignTool=` to `installer.iss`.

## Verified here
The PyInstaller spec was built and run (Linux build of the same spec): it started, created the database, served the
UI, registered a user, processed an uploaded CSV into a dashboard and exported a PDF. The Windows installer itself
must be built on Windows (Inno Setup is Windows-only) — use the script or the CI job.
