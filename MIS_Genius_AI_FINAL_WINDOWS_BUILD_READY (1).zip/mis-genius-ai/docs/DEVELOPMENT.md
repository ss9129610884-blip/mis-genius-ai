# Development

## Setup
```bash
python -m pip install -r services/api/requirements-dev.txt
cd apps/web && npm ci && cd ../..
scripts/dev.sh          # API (reload) on :8765, Vite dev server on :5173 with /api proxy
```
Open http://localhost:5173. The dev data folder is `./data`.

## Tests
| Suite | Command | What it covers |
|---|---|---|
| Backend unit + integration | `cd services/api && pytest` | 163 tests: value parsing, ingestion (CSV/XLSX/XLS/JSON, multi-sheet, duplicate columns, missing headers, merged headers, totals, zip bomb, corrupted files), type/date/numeric detection, missing data, duplicates, quality, relationships, cleaning immutability, filters, all aggregations, formulas & SQL-injection attempts, KPIs & period comparison, every chart type, pivot totals, dashboard generation for sales/attendance/inventory/medical/no-measure data, semantic templates, AI grounding and hallucination rejection, provider adapters (mocked HTTP), NL questions in English/Hindi, API endpoints, auth/refresh/logout, roles, tenant isolation, API keys, exports, reports, alerts, backup, SQL connector, security paths |
| Same on PostgreSQL | `TEST_DATABASE_URL=postgresql+psycopg://user:pass@localhost/test pytest` | |
| End-to-end (API) | `pytest tests/test_e2e.py` | upload Excel → schema → dashboard → filter → KPI & chart change → raw data → AI insight → filtered export; then a completely different (inventory) file adapts |
| End-to-end (browser) | `python tests/e2e/run_browser_e2e.py --shots /tmp/shots` | real Chromium: first-run setup, upload, sheet choice, dashboard, filter, KPI change, evidence, explorer, Ask AI (EN+HI), report, mobile layout |
| Web | `cd apps/web && npm run build` | TypeScript strict typecheck + production build |
| Everything | `scripts/test_all.sh` | |

## Build status in this delivery
* Backend: 163/163 passed on SQLite and on PostgreSQL 16; Alembic upgrade → downgrade → upgrade verified on both.
* Web: typecheck clean, production build OK.
* Browser E2E: passed.
* Desktop: PyInstaller build produced and exercised (Linux build of the same spec).
* Production topology: API (2 workers, PostgreSQL, production mode) + external worker processed an upload;
  plan limits and security headers active.
* Docker Compose file validated (`docker compose config`); the image build itself needs a Docker daemon.

## Code map
* Add an API route: `services/api/misgenius/api/routers/*.py` (use `require("<permission>")` for access control and
  filter every query by `ctx.org_id`).
* Add a cleaning operation: `cleaning/transforms.py` (`TRANSFORMS`), then the UI list in `apps/web/src/pages/Datasets.tsx`.
* Add a KPI rule for auto dashboards: `dashboard/generator.py::build_kpis`.
* Add an insight type: `ai/facts.py` (compute numbers + evidence; add EN and HI text).
* UI strings: `apps/web/src/lib/i18n.tsx` (English and Hindi dictionaries).
* Regenerate the API contract: `python scripts/export_openapi.py`.

## Conventions
Python 3.11, type hints, user-facing errors raised as domain exceptions (`IngestionError`, `QueryError`,
`TransformError`, `DatasetError`, `ConnectorError`, `LimitExceeded`) and converted to friendly HTTP responses.
Never compute a number in UI code that the API did not return.
