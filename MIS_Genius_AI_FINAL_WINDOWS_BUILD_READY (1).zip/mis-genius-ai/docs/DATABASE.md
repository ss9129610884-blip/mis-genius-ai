# Database

SQLAlchemy 2 models: `services/api/misgenius/db/models.py`. Migrations: Alembic, `services/api/migrations/`
(initial revision `0001`). Migrations run automatically on startup (API, worker and desktop app).

| Mode | Default database |
|---|---|
| desktop / localhost / LAN | SQLite file `misgenius.db` in the data folder (WAL mode, foreign keys on) |
| cloud / production | PostgreSQL 14+ via `DATABASE_URL` (`postgres://` and `postgresql://` URLs are accepted) |

Dataset *contents* are not stored in the database: each version is two Parquet files in object storage
(`raw.parquet` = exactly what was in the file, as text; `data.parquet` = typed values used for analysis).
This keeps the database small and lets DuckDB scan data without loading it into memory.

## Entities

| Table | Purpose | Key columns |
|---|---|---|
| `users` | accounts | email (unique), bcrypt `password_hash`, language |
| `organizations` | tenants | slug, `plan`, `settings` (currency, locale, fiscal year…) |
| `memberships` | user ↔ org with role | `role` owner/admin/analyst/viewer, unique (user, org) |
| `workspaces` | folders inside an org | org_id |
| `refresh_sessions` | refresh tokens (SHA-256 hashes) for logout/rotation | expires_at, revoked_at |
| `api_keys` | integration keys (hashed) | prefix, role, revoked_at |
| `files` | uploaded originals (immutable) | storage_key, sha256, status, `workbook` summary |
| `sheets` | detected tables inside a file | header_row, columns, preview, raw_key |
| `datasets` | logical datasets | source_type (upload/demo/sql/http/google_sheets/combined/joined), `is_demo`, current_version_id, refresh_minutes, deleted_at (soft delete) |
| `dataset_versions` | every upload/refresh/cleaning/join | version_number, kind, parent_version_id, `transforms`, raw_key, data_key, `schema`, `quality`, `overrides` |
| `columns` | per-version column metadata | data_type, role, confidence, semantic_tags, stats, label, user_override |
| `dashboards` | dashboards | dataset_id, `config` (filters, number format, metrics, theme), auto_generated |
| `dashboard_widgets` | widgets | widget_type, `config` (KPI/Chart spec), `layout` (x,y,w,h), hidden |
| `saved_filters` | named filter views | filters |
| `dashboard_templates` | semantic templates (org_id NULL = built-in) | `spec` with slots |
| `reports` | generated executive reports | language, `content`, filters, generated_by |
| `ai_insights` | insight runs and questions | kind, provider, question, content |
| `ai_settings` | per-org AI provider | provider, model, base_url, `api_key_encrypted` (Fernet), last4 |
| `jobs` | background job queue | kind, status, payload, result, error, progress |
| `audit_logs` | audit trail | action, entity, details (secrets stripped), ip |
| `usage` | metering | metric (ai_requests, uploads, exports, api_calls), quantity |
| `subscriptions` | plan state | plan, status, provider, external ids |
| `alert_rules` | KPI alerts | kpi spec, operator, threshold, channels |
| `notifications` | in-app notifications | user_id, kind, read_at |

## Versioning rules

* Upload to an existing dataset, connector refresh, cleaning, schema override on a new upload → **new version**;
  the dataset points to the newest one, older versions stay readable and can be made current again.
* Schema corrections (`PATCH /datasets/{id}/columns/{col}`) re-derive `data.parquet` of the current version from
  its immutable `raw.parquet` and record the override in `transforms`.
* Deleting a dataset is a soft delete (trash); permanent deletion is a separate, audited admin action.

## Operations

* New migration: `cd services/api && alembic revision --autogenerate -m "…"`, review, commit.
* Upgrade manually: `DATABASE_URL=… alembic upgrade head`; roll back: `alembic downgrade -1`.
* Backups: see [DEPLOYMENT.md](DEPLOYMENT.md#backup-and-restore).
