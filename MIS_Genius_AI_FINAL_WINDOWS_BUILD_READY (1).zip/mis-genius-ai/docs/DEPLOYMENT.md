# Deployment overview

| Mode | `APP_ENV` | Database | Storage | Jobs | Guide |
|---|---|---|---|---|---|
| Windows desktop | `local` | SQLite in `%LOCALAPPDATA%\MISGeniusAI` | local folder | thread | [WINDOWS.md](WINDOWS.md) |
| Localhost (any OS) | `local` | SQLite in `./data` | local folder | thread | `scripts/start_local.sh` |
| Office LAN | `lan` | SQLite (or PostgreSQL) | local folder | thread | [LAN.md](LAN.md) |
| Cloud / SaaS | `production` | PostgreSQL | S3-compatible | external workers | [CLOUD.md](CLOUD.md) |
| Development | `development` | SQLite | local | thread | [DEVELOPMENT.md](DEVELOPMENT.md) |
| Tests | `testing` | SQLite or `TEST_DATABASE_URL` | temp | inline | |

## Configuration reference

All settings are environment variables (or a `.env` file; the desktop app also reads
`%LOCALAPPDATA%\MISGeniusAI\settings.env`). See `.env.example` for the full list. Most important:

| Variable | Default | Notes |
|---|---|---|
| `APP_ENV` | development | enables production hardening (required secret, HSTS, plan limits, SSRF guard) |
| `HOST`, `PORT` | 127.0.0.1, 8765 | |
| `MIS_DATA_DIR` | `./data` (desktop: LOCALAPPDATA) | SQLite DB, local storage, logs, generated secret |
| `DATABASE_URL` | SQLite in data dir | `postgresql+psycopg://user:pass@host/db` |
| `SECRET_KEY` | generated locally | **required** in production |
| `STORAGE_PROVIDER` | local | `s3` with `S3_BUCKET`, `S3_ENDPOINT_URL`, `S3_REGION`, keys (needs `boto3`, included in `requirements-cloud.txt`) |
| `JOB_MODE` | thread | `external` = run `python -m misgenius.jobs.worker` separately |
| `MAX_UPLOAD_MB`, `MAX_ROWS`, `MAX_COLUMNS` | 100, 2,000,000, 500 | |
| `DATE_DAYFIRST` | true | default for ambiguous dates (DD/MM); detected per column when possible |
| `ALLOW_REGISTRATION` | true | the very first account can always be created |
| `CORS_ORIGINS`, `TRUSTED_HOSTS` | empty | comma separated |
| `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL` | none | see [AI.md](AI.md) |
| `SMTP_*` | empty | email alerts |
| `STRIPE_*` | empty | online payments |
| `ENFORCE_LIMITS` | on in production | plan limits |
| `ALLOW_PRIVATE_NETWORK_CONNECTORS` | on except production | connector SSRF guard |

## Health and monitoring
`GET /api/health` (no auth) returns database/storage status, mode and version — use it for load balancers,
Docker health checks and uptime monitors. Logs are JSON lines in `<data>/logs/` (and stdout).

## Backup and restore
* **Per organization (any mode, UI):** Settings → Backup → export ZIP (dashboards, templates, reports, dataset data);
  import into any installation. Imports never overwrite.
* **Full local/LAN installation:** `python scripts/backup.py backup --dest D:\Backups` (consistent SQLite online
  backup + storage folder); restore with `python scripts/backup.py restore --file … --force` (old data is kept
  as `*.before-restore-*`). Schedule it with Windows Task Scheduler or cron.
* **Cloud:** `pg_dump -Fc "$DATABASE_URL" > misgenius.dump` plus object-storage versioning/replication on the
  bucket. Restore with `pg_restore -d …`.

## Upgrades
Install the new version (desktop installer, `git pull` + rebuild, or new image). Database migrations run
automatically at startup. Back up first.
