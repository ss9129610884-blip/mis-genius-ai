# Architecture

## Principles

1. **The uploaded dataset is the source of truth.** Numbers are only ever produced by the query engine.
   The AI receives computed facts, never raw rows, and its output is validated against them.
2. **Universal, not sales-shaped.** No column name is required. Types, roles and statistics drive every
   choice; semantic keyword tags (English, Hinglish, Hindi) only improve naming and defaults.
3. **Immutable originals.** Uploaded files and each version's raw table are never modified. Cleaning, type
   corrections, refreshes, combines and joins create new versions or re-derive typed data from raw data.
4. **One core, many shells.** Desktop, localhost, LAN, cloud, PWA and mobile run the same API, analytics
   engine and web UI; only configuration and the outer shell differ.

## Components

```
                ┌──────────── apps/web (React SPA, PWA) ─────────────┐
 Browser / PWA ─┤  used as-is by apps/desktop (app window)           │
 Capacitor app ─┤  and apps/mobile (WebView)                         │
                └──────────────────────┬─────────────────────────────┘
                                       │  REST /api/v1  (Bearer JWT or X-API-Key, X-Org-Id)
                ┌──────────────────────▼─────────────────────────────┐
                │ services/api  (FastAPI)                            │
                │  api/        routers, deps (auth, tenant, roles),  │
                │              middleware (security headers, rate    │
                │              limit, request id, body size)         │
                │  services/   dataset lifecycle, dashboards, backup,│
                │              search, audit, job handlers           │
                │  ingestion/  readers → table detection → raw frame │
                │  schema/     profiler, quality, relationships,     │
                │              semantics                             │
                │  cleaning/   non-destructive transforms            │
                │  analytics/  QuerySpec→DuckDB SQL, formulas, KPIs, │
                │              charts, pivot, stats, formatting      │
                │  dashboard/  auto generator, semantic templates    │
                │  ai/         providers, prompts, facts, insights,  │
                │              NLQ, reports, schema interpreter,     │
                │              grounding validation                  │
                │  export/     CSV, Excel, PDF, HTML, chart images   │
                │  connectors/ HTTP, Google Sheets, SQL              │
                │  notifications/ in-app, email, webhook, alerts     │
                │  auth/ billing/ jobs/ storage/ db/                 │
                └──────┬───────────────┬───────────────┬─────────────┘
                       │               │               │
             SQLite / PostgreSQL   Object storage   Job queue (DB table)
             (metadata)            local dir / S3   thread | inline | external worker
                                   Parquet data
```

## Data flow

1. **Upload** (`POST /uploads`) stores the original bytes (`orgs/{org}/files/{id}/original.*`) and queues an
   `ingest_file` job.
2. **Inspect** — `ingestion.readers` safely reads the workbook into grids (format hints such as `0.0%` or `₹`
   formats are kept); `ingestion.tables` finds table regions, header rows, two-row headers, total rows and
   side-by-side tables. Each table becomes a `Sheet` row with a preview and an all-text Parquet copy.
3. **Select** — one table → dataset created automatically; several → the UI lets the user pick, compare and
   optionally combine compatible sheets.
4. **Profile** — `schema.profiler` infers type/role/confidence per column on a sample, converts the full column
   (vectorised with memoised fallbacks), computes stats, relationships and the quality report.
5. **Version** — `raw.parquet` (immutable text) and `data.parquet` (typed) are written per version together with
   the schema JSON and `ColumnMeta` rows.
6. **Dashboard** — `dashboard.generator` ranks measures/dimensions and builds KPIs, charts, tables, pivots,
   filters and layout.
7. **Query** — every KPI/chart/table is a validated spec compiled by `analytics.query.DataSource` to parameterised
   DuckDB SQL over the Parquet file; filters are applied in the query, not in the UI.
8. **AI** — `ai.facts` computes a fact sheet; `ai.insights`/`ai.nlq`/`ai.reports` optionally ask an LLM to phrase
   or plan, then validate (see [AI.md](AI.md)).

## Technology choices

| Area | Choice | Why |
|---|---|---|
| API | FastAPI + Pydantic v2 | typed validation, OpenAPI docs, async upload handling |
| Analytics | DuckDB over Parquet (+ pandas for profiling) | columnar SQL engine, reads files without loading them into RAM, embedded (works offline and on desktop), scales to millions of rows; the `DataSource` abstraction allows swapping to PostgreSQL/Polars later |
| Metadata DB | SQLAlchemy 2 + Alembic; SQLite locally, PostgreSQL in cloud | same models and migrations everywhere |
| Storage | `Storage` interface: local folder or S3-compatible | no hard dependency on the local filesystem |
| Jobs | DB-backed queue with thread / inline / external-worker modes | no Redis needed on a desktop; horizontal workers in cloud |
| Web | React 19 + Vite + TypeScript SPA | the same static bundle serves web, PWA, desktop and Capacitor; **Next.js was not used** because server-side rendering would require a Node server inside the Windows app and the mobile WebView — a static SPA served by the API is simpler and works offline |
| Charts | Apache ECharts (tree-shaken) | mature, all 15 chart types incl. heatmap, canvas performance |
| Grid | react-grid-layout | drag/resize dashboards |
| Desktop | Python launcher frozen with PyInstaller + Inno Setup | **Tauri/Electron were not used**: the backend is Python, so a frozen Python runtime plus the user's Edge/Chrome in `--app` mode gives an app window without shipping a second 150 MB browser runtime and without Rust or Visual Studio toolchains |
| Mobile | PWA + Capacitor 7 | one UI, same API |
| Fonts | IBM Plex Sans + Plex Sans Devanagari (self-hosted) | equal quality English/Hindi, works offline |

## Module / extension points

| Future feature | Extend here, without touching the dashboard engine |
|---|---|
| New data source (ERP, CRM, Tally) | subclass `connectors.base.Connector`, register in `REGISTRY` |
| New AI provider / local LLM | subclass `ai.providers.AIProvider`, add to `PROVIDERS` |
| Notification channel (WhatsApp) | add a channel in `notifications.service.notify` |
| Scheduled reports | add a job handler (`jobs.runner.handler`) and a schedule field |
| Larger-than-disk data | implement another `DataSource` backend (PostgreSQL / warehouse) exposing the same methods |
| Payment provider | subclass `billing.payments.PaymentProvider` |
| Chart type | add to `ChartType`, `charts.build_chart` and `apps/web/src/components/Chart.tsx` |

## Tenancy

Every tenant-owned row carries `org_id`; the request context resolves the user's membership for the `X-Org-Id`
header (or token org) and every service query filters by it. Object keys are prefixed with `orgs/{org_id}/`.
Cross-tenant access returns 404 (tested in `tests/test_api.py::test_tenant_isolation`).
