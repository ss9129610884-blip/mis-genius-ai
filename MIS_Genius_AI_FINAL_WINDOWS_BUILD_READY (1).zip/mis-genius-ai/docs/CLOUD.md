# Cloud / SaaS deployment

## Architecture
```
Internet ─► nginx (TLS) ─► api (uvicorn, N workers, stateless) ─┬─► PostgreSQL (metadata, jobs, audit)
                                                                ├─► S3 / MinIO (files, Parquet data)
                          worker (python -m misgenius.jobs.worker, scale ×N) ─┘
```
* API containers are stateless: scale horizontally behind a load balancer.
* Background work (file processing, cleaning, connector imports, scheduled refreshes) runs in workers
  (`JOB_MODE=external`) that claim jobs from the `jobs` table. Run 1–N workers.
* Local disk in containers is only a cache (Parquet files downloaded from S3 for DuckDB).

## Docker Compose (single VM)
```bash
cp .env.example .env         # set SECRET_KEY, POSTGRES_PASSWORD, S3_SECRET_KEY, TRUSTED_HOSTS, AI keys…
mkdir -p infrastructure/docker/certs   # fullchain.pem + privkey.pem for your domain
docker compose up -d --build
docker compose logs -f api worker
```
Services: `db` (PostgreSQL 16), `minio` + `minio-init` (bucket), `api`, `worker`, `nginx`. Without TLS for a quick
internal test: `docker compose up -d --build api worker` and open `http://localhost:8765`.

Using managed services instead: remove `db`/`minio` and set `DATABASE_URL` and `S3_*` to your managed PostgreSQL
and object storage. The image: `infrastructure/docker/Dockerfile` (multi-stage: builds the web app, then a slim
non-root Python runtime with a health check).

## Platform notes (no vendor lock-in)
| Platform | Database | Storage | Compute |
|---|---|---|---|
| AWS | RDS PostgreSQL | S3 (`S3_REGION`, no endpoint) | ECS/Fargate or EC2 with compose; ALB for TLS |
| Azure | Azure Database for PostgreSQL | any S3-compatible gateway, or MinIO | Container Apps / App Service for containers |
| Google Cloud | Cloud SQL | GCS with HMAC keys (`S3_ENDPOINT_URL=https://storage.googleapis.com`) | Cloud Run (api) + a Cloud Run job/VM for workers |
| DigitalOcean | Managed PostgreSQL | Spaces (`S3_ENDPOINT_URL=https://<region>.digitaloceanspaces.com`) | App Platform or Droplet |
| Indian hosting (E2E, CtrlS, …) | PostgreSQL VM | MinIO | Docker Compose on a VM |

Run the API with `web` process `uvicorn misgenius.api.main:app --host 0.0.0.0 --port $PORT` and the worker with
`python -m misgenius.jobs.worker`; both need the same environment.

## Multi-tenancy and SaaS features
* Self-service sign-up creates an organization (Free plan in production) with the user as owner.
  Set `ALLOW_REGISTRATION=false` for invite-only deployments.
* Plans and limits (`services/api/misgenius/billing/plans.py`): Free, Starter, Professional, Business, Enterprise —
  datasets, file size, AI requests/month, members, dashboards, storage, API calls/day. Enforced when
  `APP_ENV=production` (or `ENFORCE_LIMITS=true`); exceeding a limit returns HTTP 402 with a clear message.
* Payments: set `STRIPE_SECRET_KEY`, `STRIPE_WEBHOOK_SECRET` and `STRIPE_PRICE_<PLAN>` price IDs; point a Stripe
  webhook to `https://<domain>/api/v1/billing/webhook` (events: `checkout.session.completed`,
  `customer.subscription.updated`, `customer.subscription.deleted`). Without Stripe, owners change plans manually
  (enterprise invoicing).
* Usage is metered per organization (`usage` table); audit logs per organization.

## Operations checklist
- [ ] Strong `SECRET_KEY` (never change it after launch: it signs tokens and encrypts stored AI keys)
- [ ] `TRUSTED_HOSTS`, TLS certificates, `ALLOW_REGISTRATION` decided
- [ ] Nightly `pg_dump` + bucket versioning
- [ ] Monitor `/api/health` and the `error.log` / stdout JSON logs
- [ ] Shared rate limiting at the load balancer if running several API instances
