# API reference

Base URL: `/api/v1` (version prefix). Interactive docs: **`/api/docs`** (Swagger UI) and `/api/redoc`; machine-readable
contract: `/api/openapi.json` (also committed as `packages/shared-types/openapi.json`).

## Authentication

* `POST /auth/register`, `POST /auth/login` → `access_token` (JWT, 60 min) + `refresh_token` (30 days, rotated on every use, revocable).
* Send `Authorization: Bearer <access_token>` and optionally `X-Org-Id: <organization id>` to choose the tenant.
* Integrations can use `X-API-Key: mga_…` (created in Settings → API keys; the key carries its own role).
* Roles: owner > admin > analyst > viewer (see [SECURITY.md](SECURITY.md)).

## Conventions

* Errors: `{"detail": "human readable message", "request_id": "…"}` with 400 (invalid input/data), 401, 402 (plan limit), 403 (role), 404 (not found *or other tenant*), 413, 422 (validation), 429 (rate limit), 500.
* Long work (upload processing, cleaning, connector import, refresh) returns a `job`; poll `GET /jobs/{id}` until `status` is `done` or `failed`.
* Filters use one structure everywhere:

```json
{"column": "Region", "op": "in", "values": ["North", "West"]}
{"column": "Order Date", "op": "date_range", "values": ["2026-01-01", "2026-03-31"]}
{"column": "Sales Amount", "op": "between", "values": [1000, null]}
{"column": "*", "op": "contains", "value": "pune"}   // free-text search across columns
```

Operators: `eq neq in not_in gt gte lt lte between contains not_contains starts_with is_null not_null date_range relative`.

* Measures: `{"column": "Sales", "agg": "sum"}`, `{"agg": "count_rows"}`, `{"formula": "(SUM([Sales]) - SUM([Cost])) / SUM([Sales]) * 100", "alias": "Margin %"}`, conditional `{"agg": "count_rows", "filters": [...]}`. Aggregations: `count count_rows sum avg min max median count_distinct stddev variance`.
* Dimensions: `{"column": "Order Date", "granularity": "month"}` — granularities `day week month quarter year fy day_of_week month_of_year hour`.

## Example: upload a file and read its dashboard

```bash
TOKEN=$(curl -s -X POST localhost:8765/api/v1/auth/login -H 'content-type: application/json' \
  -d '{"email":"me@example.com","password":"…"}' | jq -r .access_token)
curl -s -X POST localhost:8765/api/v1/uploads -H "Authorization: Bearer $TOKEN" -F file=@sales.xlsx
curl -s localhost:8765/api/v1/jobs/<job id> -H "Authorization: Bearer $TOKEN"          # → result.created[0].dashboard_id
curl -s -X POST localhost:8765/api/v1/dashboards/<id>/data -H "Authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d '{"filters":[{"column":"Region","op":"in","values":["North"]}]}'
curl -s -X POST localhost:8765/api/v1/datasets/<id>/ask -H "Authorization: Bearer $TOKEN" \
  -H 'content-type: application/json' -d '{"question":"इस महीने सबसे ज्यादा बिक्री किस क्षेत्र में हुई?"}'
```

## Endpoints

### Auth

| Method | Path |
|---|---|
| POST | `/auth/change-password` |
| POST | `/auth/login` |
| POST | `/auth/logout` |
| GET | `/auth/me` |
| PATCH | `/auth/me` |
| POST | `/auth/refresh` |
| POST | `/auth/register` |
| GET | `/auth/setup-status` |

### Organizations

| Method | Path |
|---|---|
| GET | `/api-keys` |
| POST | `/api-keys` |
| DELETE | `/api-keys/{kid}` |
| GET | `/audit` |
| GET | `/orgs` |
| POST | `/orgs` |
| GET | `/orgs/current` |
| PATCH | `/orgs/current` |
| GET | `/orgs/current/members` |
| POST | `/orgs/current/members` |
| DELETE | `/orgs/current/members/{membership_id}` |
| PATCH | `/orgs/current/members/{membership_id}` |
| GET | `/workspaces` |
| POST | `/workspaces` |
| DELETE | `/workspaces/{wid}` |
| PATCH | `/workspaces/{wid}` |

### Datasets

| Method | Path |
|---|---|
| GET | `/connectors` |
| POST | `/connectors/test` |
| GET | `/datasets` |
| POST | `/datasets/demo` |
| POST | `/datasets/from-connector` |
| POST | `/datasets/from-sheets` |
| POST | `/datasets/join` |
| DELETE | `/datasets/{dataset_id}` |
| GET | `/datasets/{dataset_id}` |
| PATCH | `/datasets/{dataset_id}` |
| POST | `/datasets/{dataset_id}/clean` |
| POST | `/datasets/{dataset_id}/clean/preview` |
| PATCH | `/datasets/{dataset_id}/columns/{column}` |
| POST | `/datasets/{dataset_id}/describe-schema` |
| POST | `/datasets/{dataset_id}/distinct` |
| POST | `/datasets/{dataset_id}/export` |
| GET | `/datasets/{dataset_id}/quality` |
| POST | `/datasets/{dataset_id}/refresh` |
| POST | `/datasets/{dataset_id}/restore` |
| POST | `/datasets/{dataset_id}/rows` |
| GET | `/datasets/{dataset_id}/schema` |
| GET | `/datasets/{dataset_id}/versions` |
| GET | `/datasets/{dataset_id}/versions/compare` |
| POST | `/datasets/{dataset_id}/versions/upload` |
| POST | `/datasets/{dataset_id}/versions/{version_id}/activate` |
| GET | `/files` |
| GET | `/files/{file_id}` |
| GET | `/files/{file_id}/download` |
| GET | `/jobs/{job_id}` |
| POST | `/sheets/compare` |
| GET | `/sheets/{sheet_id}/preview` |
| POST | `/uploads` |

### Analytics

| Method | Path |
|---|---|
| POST | `/datasets/{dataset_id}/analytics/chart` |
| POST | `/datasets/{dataset_id}/analytics/kpi` |
| POST | `/datasets/{dataset_id}/analytics/pivot` |
| POST | `/datasets/{dataset_id}/analytics/query` |
| POST | `/datasets/{dataset_id}/analytics/recommend` |

### Dashboards

| Method | Path |
|---|---|
| GET | `/dashboards` |
| POST | `/dashboards` |
| DELETE | `/dashboards/{dashboard_id}` |
| GET | `/dashboards/{dashboard_id}` |
| PATCH | `/dashboards/{dashboard_id}` |
| POST | `/dashboards/{dashboard_id}/data` |
| POST | `/dashboards/{dashboard_id}/duplicate` |
| POST | `/dashboards/{dashboard_id}/export` |
| PUT | `/dashboards/{dashboard_id}/layout` |
| POST | `/dashboards/{dashboard_id}/preview-widget` |
| POST | `/dashboards/{dashboard_id}/reset` |
| POST | `/dashboards/{dashboard_id}/saved-filters` |
| DELETE | `/dashboards/{dashboard_id}/saved-filters/{filter_id}` |
| POST | `/dashboards/{dashboard_id}/widgets` |
| DELETE | `/dashboards/{dashboard_id}/widgets/{widget_id}` |
| PATCH | `/dashboards/{dashboard_id}/widgets/{widget_id}` |
| POST | `/dashboards/{dashboard_id}/widgets/{widget_id}/data` |
| POST | `/dashboards/{dashboard_id}/widgets/{widget_id}/duplicate` |
| GET | `/templates` |
| POST | `/templates/from-dashboard` |
| POST | `/templates/import` |
| DELETE | `/templates/{template_id}` |
| GET | `/templates/{template_id}` |
| POST | `/templates/{template_id}/apply` |
| GET | `/templates/{template_id}/export` |
| POST | `/templates/{template_id}/preview-binding` |

### Ai

| Method | Path |
|---|---|
| GET | `/ai/status` |
| POST | `/datasets/{dataset_id}/ask` |
| POST | `/datasets/{dataset_id}/insights` |
| GET | `/datasets/{dataset_id}/questions` |
| GET | `/datasets/{dataset_id}/suggestions` |
| GET | `/settings/ai` |
| PUT | `/settings/ai` |
| POST | `/settings/ai/test` |

### Reports

| Method | Path |
|---|---|
| GET | `/alerts` |
| POST | `/alerts` |
| POST | `/alerts/evaluate/{dataset_id}` |
| DELETE | `/alerts/{alert_id}` |
| GET | `/notifications` |
| POST | `/notifications/read-all` |
| POST | `/notifications/{nid}/read` |
| GET | `/reports` |
| POST | `/reports` |
| DELETE | `/reports/{report_id}` |
| GET | `/reports/{report_id}` |
| GET | `/reports/{report_id}/download` |

### System

| Method | Path |
|---|---|
| POST | `/backup/export` |
| POST | `/backup/import` |
| POST | `/billing/checkout` |
| PUT | `/billing/plan` |
| GET | `/billing/plans` |
| GET | `/billing/usage` |
| POST | `/billing/webhook` |
| GET | `/health` |
| GET | `/search` |
