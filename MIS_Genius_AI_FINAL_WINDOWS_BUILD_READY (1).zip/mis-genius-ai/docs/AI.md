# AI layer

MIS Genius AI is fully usable without any AI provider. With a provider configured, the AI **phrases, prioritises
and plans**; it never produces the numbers.

## Components (`services/api/misgenius/ai/`)

| Module | Role |
|---|---|
| `providers.py` | `AIProvider` interface; `AnthropicProvider`, `OpenAIProvider`, `GeminiProvider`, `OpenAICompatibleProvider` (Ollama, LM Studio, vLLM, gateways), `NoAIProvider`. Plain HTTPS via httpx, retries on 429/5xx, friendly errors, tolerant JSON extraction. |
| `service.py` | `AIService`: resolves the provider (org setting → environment), exposes insights / NLQ / schema interpreter. |
| `prompts.py` | `PromptManager`: versioned prompts (`insights-v1`, `nlq-v1`, `answer-v1`, `schema-v1`), English/Hindi output. |
| `facts.py` | Deterministic **fact sheet**: overview, totals, period-over-period changes, trend (least squares), period anomalies (median/MAD), top/bottom contributors, concentration (Pareto), biggest movers, extreme records, status shares, data-quality notes, relationships — each with numbers and evidence (calculation + SQL). |
| `insights.py` | `InsightEngine`: facts → optional LLM narrative → validation → fallback. |
| `validation.py` | Grounding checks: extracts numbers (understands ₹, lakh/crore, K/M, %), ignores years/periods/codes, requires each to match a cited fact (±1.5 %). |
| `nlq.py` | Natural-language questions → validated plan → query engine → answer. Rule-based planner (English, Hindi, Hinglish) plus optional LLM planner. |
| `reports.py` | Executive report content (summary, KPIs, trends, anomalies, contributors, explanations, actions, questions, quality notes). |
| `schema_interpreter.py` | `SchemaInterpreter`: labels/descriptions for columns; AI output accepted only for existing columns, never changes types. |

## Grounding pipeline

```
data ──► query engine ──► facts (id, text EN/HI, numbers, evidence)
                               │
               no provider ────┼──► deterministic insights (already final)
                               │
               provider ───────┴──► LLM (JSON: items with fact_ids)
                                        │
                              pydantic schema validation
                                        │
                  every number ∈ cited facts?  no ──► item rejected (reported in meta.grounding)
                                        │ yes
                    > 50 % rejected or empty summary? ──► whole answer replaced by deterministic insights
```

* The LLM only sees computed facts and schema summaries (column names, types, a few category values) —
  **not the raw rows**.
* NLQ: an LLM plan is accepted only if its intent is known and every column exists (fuzzy-matched, then
  validated); otherwise the rule-based plan is used. The answer text is computed; an optional LLM rewording
  is kept only if all its numbers appear in the result table.
* If a question asks for something the data does not contain (e.g. “total salary” in a sales file), the answer is
  “This cannot be determined from the available dataset” with the measures that do exist.

## Configuration

Environment (server default) — `AI_PROVIDER`, `AI_API_KEY`, `AI_MODEL`, `AI_BASE_URL`, `AI_TIMEOUT_SECONDS`.
Per organization — Settings → AI provider (admins). Keys are encrypted with a key derived from `SECRET_KEY`,
shown only as `••••last4`, and never returned to the browser. **Test connection** calls the provider once.

Default models (change them to whatever your account offers): Anthropic `claude-sonnet-5`, OpenAI `gpt-4.1-mini`,
Gemini `gemini-2.5-flash`, OpenAI-compatible `llama3.1`.

**Local LLM (offline AI)**: install Ollama, `ollama pull llama3.1`, then set provider *OpenAI-compatible* with base
URL `http://localhost:11434/v1`.

## Usage and limits

Each AI call is metered (`usage.metric = ai_requests`). When a plan's monthly AI quota is reached, the app keeps
working with deterministic analytics instead of failing.

## Supported question types

top/bottom N, “which X has the highest Y”, breakdown by a dimension, totals with value filters (“profit in North”),
counts and distinct counts (“how many customers”), trends (“monthly trend of sales”), period comparison
(“last month की तुलना में क्या बदला?”), time scopes (this/last month, this year, last N months, “March 2026”),
unusual records, KPI suggestions, “create a dashboard”, dataset description, data-quality questions.
