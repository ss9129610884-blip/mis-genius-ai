# Security

## Authentication and sessions
* Passwords: bcrypt (cost 12); minimum 8 characters with a letter and a number.
* Access tokens: HS256 JWT, 60 minutes, carry user, org and role. `SECRET_KEY` is mandatory in production; in
  local modes a random key is generated once and stored in the data folder with restricted permissions.
* Refresh tokens: random 48-byte values stored only as SHA-256 hashes; rotated on every use, revoked on logout and on
  password change. The web app keeps the access token in memory and the refresh token in localStorage (a strict
  CSP limits script injection; see below).
* API keys: `mga_…`, stored hashed, scoped to one organization and role, revocable, last use tracked.
* Rate limits: 20/min per IP on login/register/refresh, 600/min per IP or key elsewhere (in-process; use a
  shared limiter at the load balancer for multi-instance deployments).

## Authorization and tenant isolation
| Permission | Minimum role |
|---|---|
| read, export, ask AI | viewer |
| upload/clean data, dashboards, reports, alerts | analyst |
| delete data, connectors (SQL), members, settings, AI keys, audit log, API keys, backups | admin |
| billing, delete organization | owner |

Every query filters by the organization resolved from the membership; foreign IDs return 404. Only owners can
create owners; the last owner cannot be removed or demoted. Object storage keys are namespaced by org.

## Untrusted files
* Size limit (`MAX_UPLOAD_MB`) enforced while streaming; row/column limits.
* Type detection by magic bytes, not just extension; HTML disguised as `.xls` is rejected.
* XLSX: ZIP inspected before parsing — total uncompressed size cap, compression-ratio (zip bomb) check,
  encrypted packages rejected; XML parsed through defusedxml; formulas are never evaluated (cached values only).
* Files are parsed into values only; nothing from a file is executed. One failing sheet is isolated.

## Injection
* Analytics SQL is generated from validated specs: column names must exist in the schema and are quoted, all
  values are bound parameters. Users and the AI never supply SQL.
* Calculated metrics use a small recursive-descent parser (numbers, `[column]`, + − × ÷, SUM/AVG/…/ABS/ROUND);
  arbitrary code cannot be expressed.
* SQL connector: admin-only, single read-only `SELECT`/`WITH`, write keywords rejected, PostgreSQL sessions set to
  read-only; credentials encrypted at rest and never written to job rows in plain text.
* HTTP/Google Sheets connectors and webhooks: private, loopback and link-local addresses are blocked in cloud
  mode (SSRF protection, redirects re-checked), size-limited downloads, http only outside production.
* Storage keys validated against path traversal.

## Transport and browser
* Security headers on every response: CSP (`script-src 'self'`), `X-Frame-Options: DENY`, `nosniff`,
  `Referrer-Policy`, `Permissions-Policy`, COOP; HSTS in production; `Cache-Control: no-store` on API responses.
* CORS closed by default; enable only specific origins (e.g. the Capacitor app) via `CORS_ORIGINS`.
* `TRUSTED_HOSTS` restricts Host headers in production.
* The service worker caches only the static app shell, never API data.
* Terminate TLS at nginx (provided config) or your load balancer.

## Secrets and logs
* All secrets come from environment variables / `.env` (see `.env.example`) or the encrypted AI setting.
* Structured JSON logs are split into `app.log`, `error.log` and `audit.log`; tokens, API keys and passwords are
  redacted by pattern before writing. Audit details strip any key containing password/secret/token/api_key.
* Error responses never contain stack traces outside `APP_ENV=development`; each carries a `request_id`.

## Audit trail
Logged: login/logout/failed login, registration, password change, uploads/downloads, dataset create/update/
clean/refresh/delete/restore/purge, schema overrides, dashboards and widgets, templates, exports, AI insights and
questions, AI settings, members and roles, API keys, plan changes, backups.

## Privacy
Columns that look like emails, phone numbers, PAN, Aadhaar or GSTIN are flagged in the quality report so users
can take care when sharing exports. Uploaded data never leaves the server except to the configured AI provider,
which receives only computed facts and column metadata.
