"""Structured logging with separate application, error and audit streams.

Secrets are redacted before anything is written.
"""
from __future__ import annotations

import json
import logging
import logging.handlers
import re
from datetime import datetime, timezone
from pathlib import Path

# Patterns whose whole match is a secret.
_WHOLE = [
    re.compile(r"sk-ant-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"sk-[A-Za-z0-9_\-]{8,}"),
    re.compile(r"AIza[0-9A-Za-z_\-]{20,}"),
]
# Patterns where group(1) is a harmless prefix and the rest is secret.
_PREFIXED = [
    re.compile(r"(?i)(bearer\s+)[A-Za-z0-9\-_\.]+"),
    re.compile(r"(?i)((?:password|api_key|apikey|secret|token)\"?\s*[:=]\s*\"?)[^\s\",}]+"),
]


def redact(text: str) -> str:
    for pat in _WHOLE:
        text = pat.sub("***", text)
    for pat in _PREFIXED:
        text = pat.sub(lambda m: m.group(1) + "***", text)
    return text


class JsonFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        payload = {
            "ts": datetime.now(timezone.utc).isoformat(timespec="milliseconds"),
            "level": record.levelname,
            "logger": record.name,
            "msg": redact(record.getMessage()),
        }
        for key in ("request_id", "org_id", "user_id", "path", "status", "duration_ms", "action"):
            if hasattr(record, key):
                payload[key] = getattr(record, key)
        if record.exc_info:
            payload["exc"] = redact(self.formatException(record.exc_info))
        return json.dumps(payload, ensure_ascii=False, default=str)


class PlainFormatter(logging.Formatter):
    def format(self, record: logging.LogRecord) -> str:
        return redact(super().format(record))


_configured = False


def setup_logging(log_dir: Path, level: str = "INFO", json_logs: bool = True, to_files: bool = True) -> None:
    global _configured
    if _configured:
        return
    _configured = True
    fmt: logging.Formatter = JsonFormatter() if json_logs else PlainFormatter(
        "%(asctime)s %(levelname)s %(name)s: %(message)s"
    )
    root = logging.getLogger()
    root.setLevel(level.upper())
    console = logging.StreamHandler()
    console.setFormatter(fmt)
    root.handlers = [console]

    audit_logger = logging.getLogger("misgenius.audit")
    audit_logger.propagate = False
    audit_logger.setLevel(logging.INFO)

    if to_files:
        log_dir.mkdir(parents=True, exist_ok=True)
        app_h = logging.handlers.RotatingFileHandler(log_dir / "app.log", maxBytes=10_000_000, backupCount=5, encoding="utf-8")
        app_h.setFormatter(fmt)
        err_h = logging.handlers.RotatingFileHandler(log_dir / "error.log", maxBytes=10_000_000, backupCount=5, encoding="utf-8")
        err_h.setLevel(logging.ERROR)
        err_h.setFormatter(fmt)
        root.addHandler(app_h)
        root.addHandler(err_h)
        audit_h = logging.handlers.RotatingFileHandler(log_dir / "audit.log", maxBytes=10_000_000, backupCount=10, encoding="utf-8")
        audit_h.setFormatter(JsonFormatter())
        audit_logger.addHandler(audit_h)
    else:
        audit_logger.addHandler(console)

    for noisy in ("uvicorn.access", "httpx", "matplotlib", "PIL"):
        logging.getLogger(noisy).setLevel(logging.WARNING)
