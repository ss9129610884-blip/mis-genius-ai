"""Export engine: CSV, Excel, HTML report, PDF report and dashboard snapshots.

All exports are produced from the query layer, so they always respect the active
filters. Nothing here invents values.
"""
from __future__ import annotations

import html
import io
import math
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd

from misgenius.analytics.formatting import format_value

EXCEL_MAX_ROWS = 1_048_000


def _font_path() -> str | None:
    try:
        import matplotlib

        p = Path(matplotlib.get_data_path()) / "fonts" / "ttf" / "DejaVuSans.ttf"
        return str(p) if p.exists() else None
    except Exception:  # noqa: BLE001
        return None


# --------------------------------------------------------------------------- CSV / Excel
def csv_bytes(df: pd.DataFrame) -> bytes:
    buf = io.StringIO()
    df.to_csv(buf, index=False, date_format="%Y-%m-%d %H:%M:%S")
    return ("﻿" + buf.getvalue()).encode("utf-8")  # BOM so Excel shows ₹ / Hindi correctly


def _num_format(col: dict[str, Any] | None) -> str | None:
    if not col:
        return None
    dt = col.get("data_type")
    f = col.get("format") or {}
    if dt == "currency":
        cur = (f.get("currency") or "").upper()
        sym = {"INR": "₹", "USD": "$", "EUR": "€", "GBP": "£"}.get(cur, "")
        return f'"{sym}"#,##0.00' if sym else "#,##0.00"
    if dt == "percentage":
        return '0.0"%"'
    if dt == "decimal":
        return "#,##0.00"
    if dt == "integer":
        return "#,##0"
    if dt == "date":
        return "dd-mmm-yyyy"
    if dt == "datetime":
        return "dd-mmm-yyyy hh:mm"
    return None


def excel_bytes(df: pd.DataFrame, *, schema: dict[str, Any] | None = None, about: dict[str, Any] | None = None,
                extra_sheets: dict[str, pd.DataFrame] | None = None, sheet_name: str = "Data") -> bytes:
    cols = {c["name"]: c for c in (schema or {}).get("columns", [])}
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter", datetime_format="dd-mmm-yyyy hh:mm", date_format="dd-mmm-yyyy") as xw:
        wb = xw.book
        head = wb.add_format({"bold": True, "bg_color": "#1F3A5F", "font_color": "#FFFFFF", "border": 1, "text_wrap": True, "valign": "top"})
        if about:
            rows = [(k, str(v)) for k, v in about.items()]
            pd.DataFrame(rows, columns=["Item", "Value"]).to_excel(xw, sheet_name="About", index=False)
            ws = xw.sheets["About"]
            ws.set_column(0, 0, 28)
            ws.set_column(1, 1, 90)
            ws.write_row(0, 0, ["Item", "Value"], head)
        for name, extra in (extra_sheets or {}).items():
            safe = _sheet_name(name)
            extra.to_excel(xw, sheet_name=safe, index=False)
            ws = xw.sheets[safe]
            ws.write_row(0, 0, [str(c) for c in extra.columns], head)
            for i, c in enumerate(extra.columns):
                width = min(60, max(10, int(extra[c].astype(str).str.len().quantile(0.9) if len(extra) else 10) + 2, len(str(c)) + 2))
                ws.set_column(i, i, width)
        data = df.head(EXCEL_MAX_ROWS)
        data.to_excel(xw, sheet_name=_sheet_name(sheet_name), index=False)
        ws = xw.sheets[_sheet_name(sheet_name)]
        ws.write_row(0, 0, [str(c) for c in data.columns], head)
        ws.freeze_panes(1, 0)
        if len(data.columns):
            ws.autofilter(0, 0, max(1, len(data)), len(data.columns) - 1)
        for i, c in enumerate(data.columns):
            fmt = _num_format(cols.get(c))
            sample = data[c].head(500).astype(str)
            width = min(50, max(10, int(sample.str.len().quantile(0.9) if len(sample) else 10) + 2, len(str(c)) + 2))
            ws.set_column(i, i, width, wb.add_format({"num_format": fmt}) if fmt else None)
    return buf.getvalue()


def _sheet_name(name: str) -> str:
    bad = '[]:*?/\\'
    s = "".join("_" if ch in bad else ch for ch in name)[:31]
    return s or "Sheet"


# --------------------------------------------------------------------------- charts (server side)
def chart_png(chart: dict[str, Any], title: str, width: float = 7.0, height: float = 3.2) -> bytes | None:
    """Render simple chart data (bar/line/pie/etc.) with matplotlib for PDF snapshots."""
    import matplotlib

    matplotlib.use("Agg")
    import matplotlib.pyplot as plt

    t = chart.get("type")
    fig, ax = plt.subplots(figsize=(width, height), dpi=130)
    palette = ["#2563EB", "#F59E0B", "#10B981", "#EF4444", "#8B5CF6", "#06B6D4", "#EC4899", "#84CC16", "#F97316", "#64748B"]
    try:
        cats = [str(c)[:18] for c in chart.get("categories", [])]
        series = chart.get("series", [])
        if t in ("line", "area") and series:
            for i, s in enumerate(series[:6]):
                vals = [v if v is not None else math.nan for v in s["data"]]
                ax.plot(range(len(vals)), vals, marker="o" if len(vals) < 30 else None, color=palette[i % 10], label=str(s["name"])[:30], linewidth=1.8)
                if t == "area":
                    ax.fill_between(range(len(vals)), vals, alpha=0.15, color=palette[i % 10])
            _xt(ax, cats)
        elif t in ("bar", "combo", "histogram") and series:
            vals = [v or 0 for v in series[0]["data"]]
            ax.bar(range(len(vals)), vals, color=palette[0])
            if t == "combo" and len(series) > 1:
                ax2 = ax.twinx()
                ax2.plot(range(len(vals)), [v if v is not None else math.nan for v in series[1]["data"]], color=palette[1], marker="o")
            _xt(ax, cats)
        elif t == "hbar" and series:
            vals = [v or 0 for v in series[0]["data"]][::-1]
            ax.barh(range(len(vals)), vals, color=palette[0])
            ax.set_yticks(range(len(vals)))
            ax.set_yticklabels(cats[::-1], fontsize=7)
        elif t in ("stacked_bar", "stacked_bar_100") and series:
            bottom = [0.0] * len(cats)
            for i, s in enumerate(series[:10]):
                vals = [v or 0 for v in s["data"]]
                ax.bar(range(len(vals)), vals, bottom=bottom, color=palette[i % 10], label=str(s["name"])[:20])
                bottom = [a + b for a, b in zip(bottom, vals)]
            _xt(ax, cats)
            ax.legend(fontsize=6, ncol=4, loc="upper left")
        elif t in ("pie", "donut") and series:
            vals = [max(v or 0, 0) for v in series[0]["data"]]
            if sum(vals) <= 0:
                plt.close(fig)
                return None
            ax.pie(vals, labels=cats, autopct="%1.0f%%", textprops={"fontsize": 7}, colors=palette[: len(vals)],
                   wedgeprops={"width": 0.45} if t == "donut" else None)
            ax.axis("equal")
        elif t == "scatter":
            pts = chart.get("points", [])
            ax.scatter([p["x"] for p in pts], [p["y"] for p in pts], s=8, alpha=0.6, color=palette[0])
            ax.set_xlabel(str(chart.get("x_name", ""))[:40], fontsize=7)
            ax.set_ylabel(str(chart.get("y_name", ""))[:40], fontsize=7)
        elif t == "heatmap":
            xs, ys = chart.get("x", []), chart.get("y", [])
            import numpy as np

            grid = np.full((len(ys), len(xs)), np.nan)
            for xi, yi, v in chart.get("data", []):
                grid[yi][xi] = v if v is not None else np.nan
            im = ax.imshow(grid, aspect="auto", cmap="Blues")
            ax.set_xticks(range(len(xs)))
            ax.set_xticklabels([str(x)[:12] for x in xs], rotation=45, ha="right", fontsize=6)
            ax.set_yticks(range(len(ys)))
            ax.set_yticklabels([str(y)[:14] for y in ys], fontsize=6)
            fig.colorbar(im, ax=ax)
        else:
            plt.close(fig)
            return None
        ax.set_title(title[:80], fontsize=9)
        ax.tick_params(labelsize=7)
        if t not in ("pie", "donut", "heatmap"):
            from matplotlib.ticker import FuncFormatter

            from misgenius.analytics.formatting import compact

            fmt = FuncFormatter(lambda v, _pos: compact(v, True))
            (ax.xaxis if t == "hbar" else ax.yaxis).set_major_formatter(fmt)
        ax.spines[["top", "right"]].set_visible(False)
        fig.tight_layout()
        out = io.BytesIO()
        fig.savefig(out, format="png")
        return out.getvalue()
    finally:
        plt.close(fig)


def _xt(ax, cats: list[str]) -> None:
    n = len(cats)
    step = max(1, n // 12)
    ax.set_xticks(range(0, n, step))
    ax.set_xticklabels(cats[::step], rotation=35 if n > 6 else 0, ha="right" if n > 6 else "center", fontsize=7)


# --------------------------------------------------------------------------- HTML report
def report_html(report: dict[str, Any], charts: list[tuple[str, bytes]] | None = None) -> str:
    import base64

    lang = report.get("language", "en")
    esc = html.escape
    parts = [f"<!doctype html><html lang='{lang}'><head><meta charset='utf-8'><title>{esc(report['title'])}</title>",
             "<meta name='viewport' content='width=device-width,initial-scale=1'>",
             "<style>body{font-family:'Noto Sans','Noto Sans Devanagari','Segoe UI',Mangal,Arial,sans-serif;max-width:900px;margin:32px auto;padding:0 16px;color:#1f2937;line-height:1.55}"
             "h1{color:#1F3A5F;margin-bottom:4px}h2{color:#1F3A5F;border-bottom:2px solid #e5e7eb;padding-bottom:4px;margin-top:28px}"
             ".meta{color:#6b7280;font-size:13px}.demo{background:#fef3c7;border:1px solid #f59e0b;padding:8px 12px;border-radius:6px;margin:12px 0}"
             "table{border-collapse:collapse;width:100%;font-size:14px}td,th{border:1px solid #e5e7eb;padding:6px 8px;text-align:left}th{background:#f3f4f6}"
             ".up{color:#047857}.down{color:#b91c1c}.calc{color:#6b7280;font-size:12px}img{max-width:100%}li{margin:4px 0}"
             "@media print{body{margin:0}h2{page-break-after:avoid}}</style></head><body>"]
    parts.append(f"<h1>{esc(report['title'])}</h1>")
    sc = report.get("scope", {})
    rng = f" · {sc.get('date_from')} → {sc.get('date_to')}" if sc.get("date_from") else ""
    parts.append(f"<div class='meta'>{esc(str(sc.get('dataset', '')))} · {sc.get('rows', 0):,} records{rng} · "
                 f"generated {esc(report.get('generated_at', ''))} · {esc(report.get('generated_by', ''))}</div>")
    if sc.get("filters"):
        parts.append("<div class='meta'>Filters: " + esc("; ".join(_filter_text(f) for f in sc["filters"])) + "</div>")
    if sc.get("is_demo"):
        parts.append("<div class='demo'>DEMO DATA — synthetic records for demonstration, not real business data.</div>")
    for s in report.get("sections", []):
        parts.append(f"<h2>{esc(s['heading'])}</h2>")
        if s.get("kpis"):
            parts.append("<table><tr><th>KPI</th><th>Value</th><th>Change</th><th>Period</th></tr>")
            for k in s["kpis"]:
                ch = k.get("change_pct")
                cls = "up" if (ch or 0) > 0 else "down" if (ch or 0) < 0 else ""
                parts.append(f"<tr><td>{esc(k['title'])}<div class='calc'>{esc(k.get('calculation') or '')}</div></td><td><b>{esc(k['display'])}</b></td>"
                             f"<td class='{cls}'>{'' if ch is None else f'{ch:+.1f}%'}</td><td>{esc(k.get('period') or '')}</td></tr>")
            parts.append("</table>")
        if s.get("items"):
            parts.append("<ul>" + "".join(f"<li>{esc(i['text'])}</li>" for i in s["items"]) + "</ul>")
        if s["key"] == "kpis" and charts:
            for title, png in charts:
                parts.append(f"<figure><img alt='{esc(title)}' src='data:image/png;base64,{base64.b64encode(png).decode()}'></figure>")
    parts.append(f"<p class='meta'>{esc(report.get('disclaimer', ''))}</p></body></html>")
    return "".join(parts)


def _filter_text(f: dict[str, Any]) -> str:
    vals = f.get("values") if f.get("values") is not None else f.get("value")
    return f"{f.get('column')} {f.get('op')} {vals}"


# --------------------------------------------------------------------------- PDF
def _pdf_styles():
    from reportlab.lib.styles import ParagraphStyle, getSampleStyleSheet
    from reportlab.pdfbase import pdfmetrics
    from reportlab.pdfbase.ttfonts import TTFont

    font = "Helvetica"
    fp = _font_path()
    if fp:
        try:
            pdfmetrics.registerFont(TTFont("DejaVu", fp))
            font = "DejaVu"
        except Exception:  # noqa: BLE001
            pass
    ss = getSampleStyleSheet()
    return {
        "font": font,
        "title": ParagraphStyle("t", parent=ss["Title"], fontName=font, fontSize=18, textColor="#1F3A5F"),
        "h2": ParagraphStyle("h2", parent=ss["Heading2"], fontName=font, fontSize=12.5, textColor="#1F3A5F", spaceBefore=10),
        "body": ParagraphStyle("b", parent=ss["BodyText"], fontName=font, fontSize=9.5, leading=13),
        "meta": ParagraphStyle("m", parent=ss["BodyText"], fontName=font, fontSize=8, textColor="#6B7280"),
    }


def has_devanagari(obj: Any) -> bool:
    import re

    return bool(re.search(r"[ऀ-ॿ]", str(obj)))


def report_pdf(report: dict[str, Any], charts: list[tuple[str, bytes]] | None = None) -> bytes:
    """English PDF. Hindi (Devanagari) needs complex text shaping, so Hindi reports are
    exported as print-ready HTML instead (see API)."""
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4
    from reportlab.lib.units import mm
    from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    st = _pdf_styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=A4, leftMargin=16 * mm, rightMargin=16 * mm, topMargin=14 * mm, bottomMargin=14 * mm,
                            title=report["title"], author="MIS Genius AI")
    esc = html.escape
    flow: list[Any] = [Paragraph(esc(report["title"]), st["title"])]
    sc = report.get("scope", {})
    rng = f" · {sc.get('date_from')} to {sc.get('date_to')}" if sc.get("date_from") else ""
    flow.append(Paragraph(esc(f"{sc.get('dataset', '')} · {sc.get('rows', 0):,} records{rng} · generated {report.get('generated_at', '')} "
                              f"· {report.get('generated_by', '')}"), st["meta"]))
    if sc.get("filters"):
        flow.append(Paragraph(esc("Filters: " + "; ".join(_filter_text(f) for f in sc["filters"])), st["meta"]))
    if sc.get("is_demo"):
        flow.append(Paragraph("<b>DEMO DATA</b> — synthetic records for demonstration, not real business data.", st["body"]))
    flow.append(Spacer(1, 6))
    for s in report.get("sections", []):
        flow.append(Paragraph(esc(s["heading"]), st["h2"]))
        if s.get("kpis"):
            rows = [["KPI", "Value", "Change", "Period"]]
            for k in s["kpis"]:
                ch = k.get("change_pct")
                rows.append([Paragraph(esc(k["title"]), st["body"]), Paragraph(f"<b>{esc(k['display'])}</b>", st["body"]),
                             "" if ch is None else f"{ch:+.1f}%", Paragraph(esc(k.get("period") or ""), st["meta"])])
            t = Table(rows, colWidths=[62 * mm, 38 * mm, 22 * mm, 52 * mm])
            t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), st["font"]), ("FONTSIZE", (0, 0), (-1, -1), 8.5),
                                   ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3A5F")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                                   ("GRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#E5E7EB")), ("VALIGN", (0, 0), (-1, -1), "MIDDLE")]))
            flow.append(t)
            for title, png in (charts or []):
                flow.append(Spacer(1, 6))
                flow.append(Image(io.BytesIO(png), width=175 * mm, height=80 * mm))
        for it in s.get("items", []):
            flow.append(Paragraph("• " + esc(it["text"]), st["body"]))
    flow.append(Spacer(1, 10))
    flow.append(Paragraph(esc(report.get("disclaimer", "")), st["meta"]))
    doc.build(flow)
    return buf.getvalue()


def dashboard_pdf(title: str, subtitle: str, kpis: list[dict[str, Any]], charts: list[tuple[str, dict[str, Any]]],
                  tables: list[tuple[str, dict[str, Any]]], filters_text: str, is_demo: bool) -> bytes:
    from reportlab.lib import colors
    from reportlab.lib.pagesizes import A4, landscape
    from reportlab.lib.units import mm
    from reportlab.platypus import Image, Paragraph, SimpleDocTemplate, Spacer, Table, TableStyle

    st = _pdf_styles()
    buf = io.BytesIO()
    doc = SimpleDocTemplate(buf, pagesize=landscape(A4), leftMargin=12 * mm, rightMargin=12 * mm, topMargin=10 * mm, bottomMargin=10 * mm,
                            title=title, author="MIS Genius AI")
    esc = html.escape
    flow: list[Any] = [Paragraph(esc(title), st["title"]), Paragraph(esc(subtitle), st["meta"])]
    if filters_text:
        flow.append(Paragraph(esc("Filters: " + filters_text), st["meta"]))
    if is_demo:
        flow.append(Paragraph("<b>DEMO DATA</b> — not real business data.", st["body"]))
    flow.append(Spacer(1, 6))
    if kpis:
        cells = []
        for k in kpis:
            ch = k.get("change_pct")
            cells.append(Paragraph(f"<font size=8 color='#6B7280'>{esc(k['title'])}</font><br/><font size=14><b>{esc(k['display'])}</b></font>"
                                   + (f"<br/><font size=7>{ch:+.1f}% {esc(k.get('period') or '')}</font>" if ch is not None else ""), st["body"]))
        per = 4
        rows = [cells[i: i + per] + [""] * (per - len(cells[i: i + per])) for i in range(0, len(cells), per)]
        t = Table(rows, colWidths=[66 * mm] * per)
        t.setStyle(TableStyle([("BOX", (0, 0), (-1, -1), 0.4, colors.HexColor("#E5E7EB")), ("INNERGRID", (0, 0), (-1, -1), 0.4, colors.HexColor("#E5E7EB")),
                               ("VALIGN", (0, 0), (-1, -1), "TOP"), ("TOPPADDING", (0, 0), (-1, -1), 6), ("BOTTOMPADDING", (0, 0), (-1, -1), 6)]))
        flow.append(t)
    imgs = []
    for title_c, ch in charts:
        png = chart_png(ch, title_c, width=6.2, height=3.0)
        if png:
            imgs.append(Image(io.BytesIO(png), width=128 * mm, height=62 * mm))
    for i in range(0, len(imgs), 2):
        row = imgs[i: i + 2] + ([""] if len(imgs[i: i + 2]) == 1 else [])
        flow.append(Table([row], colWidths=[134 * mm, 134 * mm]))
    for title_t, tb in tables:
        flow.append(Paragraph(esc(title_t), st["h2"]))
        data = [[str(c) for c in tb.get("columns", [])]] + [[_cell(v) for v in r] for r in tb.get("rows", [])[:40]]
        if len(data) > 1:
            t = Table(data, repeatRows=1)
            t.setStyle(TableStyle([("FONTNAME", (0, 0), (-1, -1), st["font"]), ("FONTSIZE", (0, 0), (-1, -1), 7.5),
                                   ("BACKGROUND", (0, 0), (-1, 0), colors.HexColor("#1F3A5F")), ("TEXTCOLOR", (0, 0), (-1, 0), colors.white),
                                   ("GRID", (0, 0), (-1, -1), 0.3, colors.HexColor("#E5E7EB"))]))
            flow.append(t)
    flow.append(Spacer(1, 6))
    flow.append(Paragraph(esc(f"Generated {datetime.now(timezone.utc).isoformat(timespec='seconds')} by MIS Genius AI from the uploaded data."), st["meta"]))
    doc.build(flow)
    return buf.getvalue()


def _cell(v: Any) -> str:
    if isinstance(v, float):
        return format_value(v, "number", None, 2, compact_mode=False)
    return "" if v is None else str(v)[:60]
