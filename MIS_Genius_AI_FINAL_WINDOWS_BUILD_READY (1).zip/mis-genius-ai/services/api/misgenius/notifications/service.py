"""Notification channels and KPI alert evaluation.

In-app notifications always work. Email (SMTP) and webhook channels activate only
when configured, so the core app never needs notification credentials.
"""
from __future__ import annotations

import json
import logging
import smtplib
from email.message import EmailMessage
from typing import Any

import httpx
from sqlalchemy import select
from sqlalchemy.orm import Session

from misgenius.config import get_settings
from misgenius.db.models import AlertRule, Membership, Notification, User, utcnow

log = logging.getLogger("misgenius.notifications")
OPS = {">": lambda a, b: a > b, ">=": lambda a, b: a >= b, "<": lambda a, b: a < b, "<=": lambda a, b: a <= b,
       "==": lambda a, b: a == b, "!=": lambda a, b: a != b}


def notify(db: Session, org_id: str, *, kind: str, title: str, body: str = "", link: str | None = None,
           user_id: str | None = None, channels: list[str] | None = None, extra: dict[str, Any] | None = None) -> None:
    """Create in-app notifications (for one user or all org members) and fan out to optional channels."""
    targets = [user_id] if user_id else [m.user_id for m in db.scalars(select(Membership).where(Membership.org_id == org_id))]
    for uid in targets:
        db.add(Notification(org_id=org_id, user_id=uid, kind=kind, title=title[:255], body=body, link=link))
    for ch in channels or []:
        try:
            if ch == "email":
                emails = [u.email for u in db.scalars(select(User).where(User.id.in_(targets)))]
                send_email(emails, title, body)
            elif ch.startswith("webhook:"):
                send_webhook(ch.split(":", 1)[1], {"kind": kind, "title": title, "body": body, "link": link, **(extra or {})})
        except Exception as e:  # noqa: BLE001 - channels must never break the main flow
            log.warning("notification channel %s failed: %s", ch, e)


def send_email(to: list[str], subject: str, body: str) -> bool:
    s = get_settings()
    if not s.SMTP_HOST or not to:
        return False
    msg = EmailMessage()
    msg["Subject"] = subject
    msg["From"] = s.SMTP_FROM or s.SMTP_USER or "mis-genius@localhost"
    msg["To"] = ", ".join(to)
    msg.set_content(body)
    with smtplib.SMTP(s.SMTP_HOST, s.SMTP_PORT, timeout=20) as smtp:
        smtp.starttls()
        if s.SMTP_USER:
            smtp.login(s.SMTP_USER, s.SMTP_PASSWORD or "")
        smtp.send_message(msg)
    return True


def send_webhook(url: str, payload: dict[str, Any]) -> bool:
    from misgenius.connectors.base import _guard_url

    _guard_url(url)
    with httpx.Client(timeout=10) as c:
        c.post(url, content=json.dumps(payload, default=str), headers={"content-type": "application/json"})
    return True


def evaluate_alerts(db: Session, dataset_id: str, ds) -> list[dict[str, Any]]:
    """Evaluate every enabled KPI alert of a dataset against its current version."""
    from misgenius.analytics.formatting import format_value
    from misgenius.analytics.kpi import KPISpec, compute_kpi

    fired = []
    for rule in db.scalars(select(AlertRule).where(AlertRule.dataset_id == dataset_id, AlertRule.enabled.is_(True))):
        try:
            k = compute_kpi(ds, KPISpec(**{**rule.kpi, "sparkline": False}))
        except Exception as e:  # noqa: BLE001
            log.warning("alert %s failed: %s", rule.id, e)
            continue
        v = k.get("value")
        if not isinstance(v, (int, float)) or rule.operator not in OPS:
            continue
        if OPS[rule.operator](v, rule.threshold):
            f = k.get("format") or {}
            body = f"{rule.kpi.get('title', rule.name)} is {format_value(v, f.get('kind', 'number'), f.get('currency'))} ({rule.operator} {rule.threshold:,})."
            notify(db, rule.org_id, kind="kpi_alert", title=f"Alert: {rule.name}", body=body, link=f"/datasets/{dataset_id}",
                   channels=[c for c in (rule.channels or []) if c != "in_app"], extra={"value": v, "threshold": rule.threshold})
            rule.last_triggered_at = utcnow()
            fired.append({"rule": rule.id, "value": v})
    return fired
