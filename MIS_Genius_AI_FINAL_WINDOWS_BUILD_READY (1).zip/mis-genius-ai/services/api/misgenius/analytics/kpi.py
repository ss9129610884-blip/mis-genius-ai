"""Dynamic KPI engine.

A KPI is a specification (measure or ratio + filters + formatting + optional period
comparison). Nothing here assumes sales data: the auto-dashboard picks KPIs from
whatever measures/dimensions the uploaded dataset actually has.
"""
from __future__ import annotations

import calendar
from datetime import date, datetime, timedelta
from typing import Any, Literal

from pydantic import BaseModel, Field

from misgenius.analytics.query import (
    DataSource,
    Dimension,
    Filter,
    Measure,
    QueryError,
    QuerySpec,
    best_granularity,
    measure_alias,
)
from misgenius.analytics.stats import pct_change

PERIOD_NAMES = {"day": "day", "week": "week", "month": "month", "quarter": "quarter", "year": "year"}


class KPIFormat(BaseModel):
    kind: Literal["number", "currency", "percent"] = "number"
    currency: str | None = None
    decimals: int | None = None
    compact: bool = True
    prefix: str | None = None
    suffix: str | None = None


class KPIRatio(BaseModel):
    numerator: Measure
    denominator: Measure
    as_percent: bool = True


class KPIComparison(BaseModel):
    enabled: bool = True
    date_column: str | None = None
    granularity: Literal["day", "week", "month", "quarter", "year"] | None = None
    mode: Literal["latest_complete", "latest"] = "latest_complete"


class KPISpec(BaseModel):
    id: str | None = None
    title: str
    measure: Measure | None = None
    ratio: KPIRatio | None = None
    filters: list[Filter] = Field(default_factory=list)
    format: KPIFormat = Field(default_factory=KPIFormat)
    comparison: KPIComparison | None = None
    sparkline: bool = True
    target: float | None = None
    description: str | None = None
    higher_is_better: bool = True


def _period_end(start: date, g: str) -> date:
    if g == "day":
        return start
    if g == "week":
        return start + timedelta(days=6)
    if g == "month":
        return date(start.year, start.month, calendar.monthrange(start.year, start.month)[1])
    if g == "quarter":
        m = start.month + 2
        return date(start.year, m, calendar.monthrange(start.year, m)[1])
    return date(start.year, 12, 31)


def period_label(d: Any, g: str) -> str:
    if isinstance(d, str):
        try:
            d = datetime.fromisoformat(d)
        except ValueError:
            return d
    if isinstance(d, datetime):
        d = d.date()
    if not isinstance(d, date):
        return str(d)
    if g == "day":
        return d.strftime("%d %b %Y")
    if g == "week":
        return "Week of " + d.strftime("%d %b %Y")
    if g == "month":
        return d.strftime("%b %Y")
    if g == "quarter":
        return f"Q{(d.month - 1) // 3 + 1} {d.year}"
    return str(d.year)


def _as_date(v: Any) -> date | None:
    if v is None:
        return None
    if isinstance(v, datetime):
        return v.date()
    if isinstance(v, date):
        return v
    try:
        return datetime.fromisoformat(str(v)[:19]).date()
    except ValueError:
        return None


def describe_measure(m: Measure) -> str:
    if m.formula:
        base = f"formula {m.formula}"
    elif m.agg == "count_rows" or not m.column:
        base = "number of records"
    else:
        base = {"sum": "sum", "avg": "average", "min": "minimum", "max": "maximum", "median": "median",
                "count": "count of non-blank", "count_distinct": "count of distinct", "stddev": "standard deviation",
                "variance": "variance"}[m.agg] + f" of '{m.column}'"
    if m.filters:
        conds = []
        for f in m.filters:
            val = f.values if f.values is not None else f.value
            conds.append(f"{f.column} {f.op} {val}")
        base += " where " + " and ".join(conds)
    return base


def _ratio_measures(spec: KPISpec) -> list[Measure]:
    assert spec.ratio
    num = spec.ratio.numerator.model_copy(update={"alias": "__num"})
    den = spec.ratio.denominator.model_copy(update={"alias": "__den"})
    return [num, den]


def _value_from_row(spec: KPISpec, row: list[Any]) -> float | None:
    if spec.ratio:
        num, den = row[0], row[1]
        if num is None or den in (None, 0):
            return None
        v = float(num) / float(den)
        return v * 100 if spec.ratio.as_percent else v
    v = row[0]
    return float(v) if isinstance(v, (int, float)) else v


def compute_kpi(ds: DataSource, spec: KPISpec, filters: list[Filter] | None = None) -> dict[str, Any]:
    filters = list(filters or []) + list(spec.filters)
    out: dict[str, Any] = {"id": spec.id, "title": spec.title, "format": spec.format.model_dump(), "available": True,
                           "target": spec.target, "higher_is_better": spec.higher_is_better, "description": spec.description}
    try:
        if spec.ratio:
            measures = _ratio_measures(spec)
            explanation = f"({describe_measure(spec.ratio.numerator)}) ÷ ({describe_measure(spec.ratio.denominator)})" + (" × 100" if spec.ratio.as_percent else "")
        elif spec.measure:
            measures = [spec.measure]
            explanation = describe_measure(spec.measure)
        else:
            raise QueryError("KPI has no measure")
        res = ds.aggregate(QuerySpec(measures=measures, filters=filters))
        value = _value_from_row(spec, res["rows"][0]) if res["rows"] else None
        out["value"] = value
        out["evidence"] = {"calculation": explanation, "sql": res["sql"], "filters": [f.model_dump() for f in filters],
                           "rows_considered": ds.count(filters)}
        if spec.ratio:
            out["evidence"]["numerator"] = res["rows"][0][0]
            out["evidence"]["denominator"] = res["rows"][0][1]
        if spec.target is not None and isinstance(value, (int, float)) and spec.target:
            out["target_pct"] = value / spec.target * 100
    except QueryError as e:
        out.update({"available": False, "value": None, "reason": str(e)})
        return out

    cmp = spec.comparison
    date_col = (cmp.date_column if cmp else None) or ds.schema.get("primary_date_column")
    if date_col and date_col in ds.columns and ((cmp is None) or cmp.enabled):
        try:
            out.update(_compare_periods(ds, spec, measures, filters, date_col, cmp))
        except QueryError as e:
            out["comparison"] = {"available": False, "reason": str(e)}
    return out


def _compare_periods(ds: DataSource, spec: KPISpec, measures: list[Measure], filters: list[Filter], date_col: str,
                     cmp: KPIComparison | None) -> dict[str, Any]:
    lo, hi = ds.date_bounds(date_col, filters)
    if lo is None or hi is None:
        return {"comparison": {"available": False, "reason": "No dates in the selected data"}}
    g = cmp.granularity if (cmp and cmp.granularity) else best_granularity(lo, hi)
    series = ds.aggregate(QuerySpec(dimensions=[Dimension(column=date_col, granularity=g, alias="period")],
                                    measures=measures, filters=filters, limit=5000))
    points = []
    for row in series["rows"]:
        if row[0] is None:
            continue
        points.append((row[0], _value_from_row(spec, row[1:])))
    result: dict[str, Any] = {}
    if spec.sparkline:
        result["sparkline"] = [{"period": p, "label": period_label(p, g), "value": v} for p, v in points[-24:]]
    if len(points) < 2:
        result["comparison"] = {"available": False, "reason": "Only one period of data — nothing to compare with"}
        return result
    mode = cmp.mode if cmp else "latest_complete"
    cur_idx = len(points) - 1
    partial = False
    last_start = _as_date(points[-1][0])
    hi_d = _as_date(hi)
    if last_start and hi_d and g != "day":
        partial = hi_d < _period_end(last_start, g)
    if partial and mode == "latest_complete" and len(points) >= 3:
        cur_idx -= 1
    cur_p, cur_v = points[cur_idx]
    prev_p, prev_v = points[cur_idx - 1]
    change = (cur_v - prev_v) if (isinstance(cur_v, (int, float)) and isinstance(prev_v, (int, float))) else None
    result["comparison"] = {
        "available": True,
        "granularity": g,
        "current_period": period_label(cur_p, g),
        "previous_period": period_label(prev_p, g),
        "current_value": cur_v,
        "previous_value": prev_v,
        "change": change,
        "change_pct": pct_change(cur_v, prev_v) if isinstance(cur_v, (int, float)) and isinstance(prev_v, (int, float)) else None,
        "latest_period_partial": partial,
        "note": (f"{period_label(points[-1][0], g)} is incomplete (data ends {hi_d}), so the last complete {PERIOD_NAMES.get(g, g)} is compared."
                 if partial and cur_idx != len(points) - 1 else None),
        "calculation": f"({period_label(cur_p, g)} − {period_label(prev_p, g)}) ÷ |{period_label(prev_p, g)}| × 100",
    }
    return result


def kpi_measure_name(spec: KPISpec) -> str:
    return measure_alias(spec.measure) if spec.measure else spec.title
