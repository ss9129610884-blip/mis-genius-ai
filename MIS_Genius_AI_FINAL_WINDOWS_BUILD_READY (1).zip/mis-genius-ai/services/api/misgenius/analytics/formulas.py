"""Safe calculated-metric formulas.

Grammar (no arbitrary code is ever executed):

    expr    := term (('+' | '-') term)*
    term    := factor (('*' | '/') factor)*
    factor  := NUMBER | '(' expr ')' | '-' factor | FUNC '(' args ')' | '[' column ']'
    FUNC    := SUM AVG MIN MAX MEDIAN COUNT COUNT_DISTINCT COUNT_ROWS ABS ROUND

Examples:
    SUM([Sales Amount]) - SUM([Cost])                 (aggregate formula)
    (SUM([Sales Amount]) - SUM([Cost])) / SUM([Sales Amount]) * 100
    [Quantity] * [Unit Price]                          (row formula, aggregated by the measure's agg)

Formulas compile to DuckDB SQL with quoted identifiers; division is NULL-safe.
"""
from __future__ import annotations

import re
from dataclasses import dataclass

AGG_FUNCS = {"SUM": "SUM", "AVG": "AVG", "AVERAGE": "AVG", "MIN": "MIN", "MAX": "MAX", "MEDIAN": "MEDIAN",
             "COUNT": "COUNT", "COUNT_DISTINCT": "COUNT_DISTINCT", "DISTINCTCOUNT": "COUNT_DISTINCT", "COUNT_ROWS": "COUNT_ROWS"}
SCALAR_FUNCS = {"ABS", "ROUND"}
MAX_LEN = 500

_TOKEN = re.compile(r"\s*(?:(\d+(?:\.\d+)?)|(\[[^\]]{1,200}\])|([A-Za-z_]+)|(.))")


class FormulaError(ValueError):
    pass


def quote_ident(name: str) -> str:
    return '"' + name.replace('"', '""') + '"'


@dataclass
class Compiled:
    sql: str
    is_aggregate: bool
    columns: list[str]


class _Parser:
    def __init__(self, text: str, columns: set[str], numeric_columns: set[str]):
        if len(text) > MAX_LEN:
            raise FormulaError("Formula is too long")
        self.tokens: list[tuple[str, str]] = []
        for m in _TOKEN.finditer(text):
            num, col, word, other = m.groups()
            if num:
                self.tokens.append(("num", num))
            elif col:
                self.tokens.append(("col", col[1:-1].strip()))
            elif word:
                self.tokens.append(("word", word.upper()))
            elif other and other.strip():
                if other not in "+-*/(),":
                    raise FormulaError(f"Unexpected character '{other}'")
                self.tokens.append(("op", other))
        self.i = 0
        self.columns = columns
        self.numeric = numeric_columns
        self.used: list[str] = []
        self.has_agg = False
        self.bare_outside_agg = False
        self.depth_agg = 0

    def peek(self) -> tuple[str, str] | None:
        return self.tokens[self.i] if self.i < len(self.tokens) else None

    def take(self, kind: str | None = None, val: str | None = None) -> tuple[str, str]:
        t = self.peek()
        if t is None or (kind and t[0] != kind) or (val and t[1] != val):
            raise FormulaError(f"Expected {val or kind} in formula")
        self.i += 1
        return t

    def parse(self) -> str:
        if not self.tokens:
            raise FormulaError("Formula is empty")
        sql = self.expr()
        if self.peek() is not None:
            raise FormulaError(f"Unexpected '{self.peek()[1]}' in formula")
        return sql

    def expr(self) -> str:
        left = self.term()
        while (t := self.peek()) and t[0] == "op" and t[1] in "+-":
            self.i += 1
            right = self.term()
            left = f"({left} {t[1]} {right})"
        return left

    def term(self) -> str:
        left = self.factor()
        while (t := self.peek()) and t[0] == "op" and t[1] in "*/":
            self.i += 1
            right = self.factor()
            left = f"({left} * {right})" if t[1] == "*" else f"({left} / NULLIF({right}, 0))"
        return left

    def _column(self, name: str) -> str:
        if name not in self.columns:
            raise FormulaError(f"Unknown column [{name}]")
        self.used.append(name)
        return quote_ident(name)

    def factor(self) -> str:
        t = self.peek()
        if t is None:
            raise FormulaError("Formula ended unexpectedly")
        if t[0] == "num":
            self.i += 1
            return t[1]
        if t[0] == "op" and t[1] == "-":
            self.i += 1
            return f"(-{self.factor()})"
        if t[0] == "op" and t[1] == "(":
            self.i += 1
            inner = self.expr()
            self.take("op", ")")
            return f"({inner})"
        if t[0] == "col":
            self.i += 1
            if self.depth_agg == 0:
                self.bare_outside_agg = True
            if t[1] not in self.numeric and self.depth_agg == 0:
                raise FormulaError(f"Column [{t[1]}] is not numeric")
            return f"TRY_CAST({self._column(t[1])} AS DOUBLE)" if t[1] in self.numeric else self._column(t[1])
        if t[0] == "word":
            fn = t[1]
            self.i += 1
            self.take("op", "(")
            if fn in AGG_FUNCS:
                if self.depth_agg:
                    raise FormulaError("Aggregations cannot be nested")
                self.has_agg = True
                kind = AGG_FUNCS[fn]
                if kind == "COUNT_ROWS":
                    self.take("op", ")")
                    return "COUNT(*)"
                self.depth_agg += 1
                arg = self.expr()
                self.depth_agg -= 1
                self.take("op", ")")
                if kind == "COUNT_DISTINCT":
                    return f"COUNT(DISTINCT {arg})"
                return f"{kind}({arg})"
            if fn in SCALAR_FUNCS:
                arg = self.expr()
                if fn == "ROUND":
                    digits = "0"
                    if (p := self.peek()) and p == ("op", ","):
                        self.i += 1
                        digits = self.take("num")[1]
                    self.take("op", ")")
                    return f"ROUND({arg}, {int(float(digits))})"
                self.take("op", ")")
                return f"ABS({arg})"
            raise FormulaError(f"Unknown function {fn}")
        raise FormulaError(f"Unexpected '{t[1]}'")


def compile_formula(text: str, columns: set[str], numeric_columns: set[str]) -> Compiled:
    p = _Parser(text, columns, numeric_columns)
    sql = p.parse()
    if p.has_agg and p.bare_outside_agg:
        raise FormulaError("Mixes aggregated and row-level columns. Wrap every column in SUM/AVG/... or none of them.")
    return Compiled(sql=sql, is_aggregate=p.has_agg, columns=list(dict.fromkeys(p.used)))
