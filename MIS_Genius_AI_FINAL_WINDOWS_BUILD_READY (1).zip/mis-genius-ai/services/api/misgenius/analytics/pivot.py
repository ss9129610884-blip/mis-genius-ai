"""Pivot analytics: rows × column × values with correct (non-additive-safe) totals."""
from __future__ import annotations

from typing import Any

from misgenius.analytics.query import (
    DataSource,
    Dimension,
    Filter,
    Measure,
    QueryError,
    QuerySpec,
    Sort,
    dimension_alias,
)

MAX_COLS = 60
MAX_ROWS = 2000


def pivot(ds: DataSource, *, rows: list[Dimension], column: Dimension | None, values: list[Measure],
          filters: list[Filter] | None = None) -> dict[str, Any]:
    if not values:
        values = [Measure(agg="count_rows")]
    if len(rows) > 3:
        raise QueryError("Use at most 3 row fields")
    flt = list(filters or [])
    from misgenius.analytics.charts import _resolve_time

    rows = [_resolve_time(ds, r, flt) for r in rows]
    column = _resolve_time(ds, column, flt) if column else None
    col_keys: list[Any] = []
    truncated_cols = False
    if column:
        ck = ds.aggregate(QuerySpec(dimensions=[column], measures=[values[0]], filters=flt, limit=MAX_COLS,
                                    sort=[] if column.granularity else [Sort(by=dimension_alias(column), desc=False)]))
        col_keys = [r[0] for r in ck["rows"]]
        truncated_cols = ck["truncated"]
    dims = rows + ([column] if column else [])
    body = ds.aggregate(QuerySpec(dimensions=dims, measures=values, filters=flt, limit=MAX_ROWS * max(1, len(col_keys)),
                                  sort=[Sort(by=dimension_alias(d), desc=False) for d in dims]))
    nr = len(rows)
    row_map: dict[tuple, dict[str, Any]] = {}
    order: list[tuple] = []
    for r in body["rows"]:
        key = tuple(r[:nr])
        if key not in row_map:
            if len(order) >= MAX_ROWS:
                continue
            row_map[key] = {}
            order.append(key)
        ckey = r[nr] if column else "__all__"
        row_map[key][str(ckey)] = r[nr + (1 if column else 0):]
    # totals computed with their own queries so AVG / MEDIAN / DISTINCT totals are exact
    row_totals: dict[tuple, list[Any]] = {}
    if rows:
        rt = ds.aggregate(QuerySpec(dimensions=rows, measures=values, filters=flt, limit=MAX_ROWS * 5))
        row_totals = {tuple(r[:nr]): r[nr:] for r in rt["rows"]}
    col_totals: dict[str, list[Any]] = {}
    if column:
        ct = ds.aggregate(QuerySpec(dimensions=[column], measures=values, filters=flt, limit=MAX_COLS * 5))
        col_totals = {str(r[0]): r[1:] for r in ct["rows"]}
    grand = ds.aggregate(QuerySpec(measures=values, filters=flt))["rows"][0]
    value_names = body["measures"]
    return {
        "row_fields": [dimension_alias(r) for r in rows],
        "column_field": dimension_alias(column) if column else None,
        "column_keys": [c if c is not None else "(Blank)" for c in col_keys] if column else ["__all__"],
        "values": value_names,
        "rows": [
            {
                "keys": [k if k is not None else "(Blank)" for k in key],
                "cells": {("(Blank)" if c == "None" else c): v for c, v in row_map[key].items()},
                "total": row_totals.get(key),
            }
            for key in order
        ],
        "column_totals": {("(Blank)" if k == "None" else k): v for k, v in col_totals.items()},
        "grand_total": grand,
        "truncated_columns": truncated_cols,
        "truncated_rows": len(row_totals) > len(order),
    }
