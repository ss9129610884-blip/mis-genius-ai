"""Query layer: a validated, structured QuerySpec compiled to parameterised DuckDB SQL
over the dataset's typed Parquet file.

* All filtering / aggregation happens in the query engine (never by hiding UI).
* Column names are validated against the schema and quoted; values are bound
  parameters. Neither users nor the AI can inject SQL.
* The engine reads Parquet directly, so datasets do not need to fit in RAM.
"""
from __future__ import annotations

import math
import threading
from datetime import date, datetime, timedelta
from pathlib import Path
from typing import Any, Literal

import duckdb
from pydantic import BaseModel, Field, field_validator

from misgenius.analytics.formulas import FormulaError, compile_formula, quote_ident

NUMERIC_TYPES = {"integer", "decimal", "currency", "percentage"}
DATE_TYPES = {"date", "datetime"}
TEXT_TYPES = {"categorical", "text", "identifier"}
MAX_LIMIT = 50_000

FilterOp = Literal[
    "eq", "neq", "in", "not_in", "gt", "gte", "lt", "lte", "between", "contains", "not_contains",
    "starts_with", "is_null", "not_null", "date_range", "relative",
]
Agg = Literal["count", "count_rows", "sum", "avg", "min", "max", "median", "count_distinct", "stddev", "variance"]
Granularity = Literal["day", "week", "month", "quarter", "year", "fy", "day_of_week", "month_of_year", "hour"]


class QueryError(ValueError):
    """Invalid query (safe to show to the user)."""


class Filter(BaseModel):
    column: str
    op: FilterOp = "in"
    value: Any = None
    values: list[Any] | None = None

    @field_validator("values")
    @classmethod
    def _cap(cls, v):  # noqa: N805
        if v is not None and len(v) > 5000:
            raise ValueError("too many filter values")
        return v


class Measure(BaseModel):
    column: str | None = None
    agg: Agg = "sum"
    formula: str | None = None
    alias: str | None = None
    filters: list[Filter] = Field(default_factory=list)  # conditional aggregate (e.g. count where Status = Present)


class Dimension(BaseModel):
    column: str
    granularity: Granularity | None = None
    alias: str | None = None


class Sort(BaseModel):
    by: str
    desc: bool = True


class QuerySpec(BaseModel):
    dimensions: list[Dimension] = Field(default_factory=list)
    measures: list[Measure] = Field(default_factory=list)
    filters: list[Filter] = Field(default_factory=list)
    search: str | None = None
    sort: list[Sort] = Field(default_factory=list)
    limit: int | None = 1000
    offset: int = 0


AGG_LABEL = {
    "count": "Count", "count_rows": "Count", "sum": "Total", "avg": "Average", "min": "Minimum", "max": "Maximum",
    "median": "Median", "count_distinct": "Distinct", "stddev": "Std Dev", "variance": "Variance",
}


def measure_alias(m: Measure) -> str:
    if m.alias:
        return m.alias
    if m.formula:
        return m.formula[:60]
    if m.agg == "count_rows" or not m.column:
        return "Records"
    return f"{AGG_LABEL[m.agg]} {m.column}"


def dimension_alias(d: Dimension) -> str:
    if d.alias:
        return d.alias
    return f"{d.column} ({d.granularity})" if d.granularity else d.column


def _json(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, float):
        return None if (math.isnan(v) or math.isinf(v)) else round(v, 6)
    if isinstance(v, datetime):
        return v.isoformat(sep=" ") if (v.hour or v.minute or v.second) else v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, (int, str, bool)):
        return v
    if hasattr(v, "item"):
        return _json(v.item())
    try:
        from decimal import Decimal

        if isinstance(v, Decimal):
            return float(v)
    except Exception:  # noqa: BLE001
        pass
    return str(v)


class DataSource:
    """A queryable dataset version: Parquet path + its semantic schema."""

    _lock = threading.Lock()

    def __init__(self, path: Path | str, schema: dict[str, Any]):
        self.path = str(path)
        self.schema = schema
        self.columns: dict[str, dict[str, Any]] = {c["name"]: c for c in schema.get("columns", [])}

    # ------------------------------------------------------------------ helpers
    def col(self, name: str) -> dict[str, Any]:
        c = self.columns.get(name)
        if c is None:
            raise QueryError(f"Column '{name}' does not exist in this dataset")
        return c

    def dtype(self, name: str) -> str:
        return self.col(name)["data_type"]

    @property
    def numeric_columns(self) -> set[str]:
        return {n for n, c in self.columns.items() if c["data_type"] in NUMERIC_TYPES}

    def connect(self) -> duckdb.DuckDBPyConnection:
        con = duckdb.connect(database=":memory:", config={"threads": 2})
        path = self.path.replace("'", "''")
        con.execute(f"CREATE VIEW data AS SELECT * FROM read_parquet('{path}')")
        return con

    def run(self, sql: str, params: list[Any] | None = None) -> tuple[list[str], list[tuple]]:
        con = self.connect()
        try:
            cur = con.execute(sql, params or [])
            cols = [d[0] for d in cur.description]
            return cols, cur.fetchall()
        except duckdb.Error as e:
            raise QueryError(f"Query failed: {str(e).splitlines()[0][:200]}") from e
        finally:
            con.close()

    # ------------------------------------------------------------------ SQL pieces
    def dim_sql(self, d: Dimension) -> tuple[str, str | None]:
        """Returns (select expression, order expression or None)."""
        c = self.col(d.column)
        q = quote_ident(d.column)
        if d.granularity:
            if c["data_type"] not in DATE_TYPES:
                raise QueryError(f"'{d.column}' is not a date column, so it cannot be grouped by {d.granularity}")
            g = d.granularity
            if g in ("day", "week", "month", "quarter", "year", "hour"):
                expr = f"CAST(date_trunc('{g}', {q}) AS {'TIMESTAMP' if g == 'hour' else 'DATE'})"
                return expr, expr
            if g == "fy":
                y = f"(year({q}) - CASE WHEN month({q}) < 4 THEN 1 ELSE 0 END)"
                expr = f"('FY' || CAST({y} AS VARCHAR) || '-' || lpad(CAST(({y} + 1) % 100 AS VARCHAR), 2, '0'))"
                return expr, y
            if g == "day_of_week":
                return f"dayname({q})", f"isodow({q})"
            if g == "month_of_year":
                return f"monthname({q})", f"month({q})"
        return q, None

    def filter_sql(self, f: Filter, params: list[Any]) -> str:
        c = self.col(f.column)
        q = quote_ident(f.column)
        dt = c["data_type"]
        op = f.op

        def conv(v: Any) -> Any:
            if v is None:
                return None
            if dt in NUMERIC_TYPES:
                try:
                    return float(v)
                except (TypeError, ValueError) as e:
                    raise QueryError(f"'{v}' is not a number for filter on '{f.column}'") from e
            if dt in DATE_TYPES:
                if isinstance(v, (datetime, date)):
                    return v
                s = str(v)[:19]
                try:
                    return datetime.fromisoformat(s)
                except ValueError as e:
                    raise QueryError(f"'{v}' is not a date (use YYYY-MM-DD) for filter on '{f.column}'") from e
            if dt == "boolean":
                return str(v).lower() in ("true", "1", "yes")
            return str(v)

        if op in ("is_null", "not_null"):
            return f"{q} IS {'NOT ' if op == 'not_null' else ''}NULL"
        if op in ("in", "not_in"):
            vals = f.values if f.values is not None else ([f.value] if f.value is not None else [])
            if not vals:
                return "TRUE" if op == "not_in" else "FALSE"
            has_null = any(v is None or v == "(Blank)" for v in vals)
            real = [conv(v) for v in vals if v is not None and v != "(Blank)"]
            parts = []
            if real:
                params.extend(real)
                parts.append(f"{q} IN ({', '.join('?' for _ in real)})")
            if has_null:
                parts.append(f"{q} IS NULL")
            cond = "(" + " OR ".join(parts) + ")"
            return cond if op == "in" else f"NOT {cond}"
        if op in ("eq", "neq"):
            if f.value is None:
                return f"{q} IS {'NOT ' if op == 'neq' else ''}NULL"
            params.append(conv(f.value))
            return f"{q} {'=' if op == 'eq' else '<>'} ?"
        if op in ("gt", "gte", "lt", "lte"):
            params.append(conv(f.value))
            return f"{q} {dict(gt='>', gte='>=', lt='<', lte='<=')[op]} ?"
        if op in ("between", "date_range"):
            vals = f.values or (f.value if isinstance(f.value, list) else None)
            if not vals or len(vals) != 2:
                raise QueryError(f"'{op}' filter on '{f.column}' needs two values")
            lo, hi = vals
            parts = []
            if lo not in (None, ""):
                params.append(conv(lo))
                parts.append(f"{q} >= ?")
            if hi not in (None, ""):
                hv = conv(hi)
                if dt in DATE_TYPES and isinstance(hv, datetime) and len(str(hi)) <= 10:
                    params.append(hv + timedelta(days=1))
                    parts.append(f"{q} < ?")
                else:
                    params.append(hv)
                    parts.append(f"{q} <= ?")
            return "(" + " AND ".join(parts) + ")" if parts else "TRUE"
        if op in ("contains", "not_contains", "starts_with"):
            s = str(f.value or "").replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            params.append((s + "%") if op == "starts_with" else f"%{s}%")
            like = f"CAST({q} AS VARCHAR) ILIKE ? ESCAPE '\\'"
            return f"NOT ({like})" if op == "not_contains" else like
        if op == "relative":
            # value like {"unit": "month", "n": 3, "anchor": "data"|"today"}
            if dt not in DATE_TYPES:
                raise QueryError("Relative date filters need a date column")
            spec = f.value or {}
            unit = spec.get("unit", "month")
            n = int(spec.get("n", 1))
            if unit not in ("day", "week", "month", "quarter", "year"):
                raise QueryError("Invalid relative unit")
            anchor = "(SELECT max(" + q + ") FROM data)" if spec.get("anchor", "data") == "data" else "current_date"
            return f"{q} > {anchor} - INTERVAL ({n}) {unit.upper()}"
        raise QueryError(f"Unsupported filter operator {op}")

    def where_sql(self, filters: list[Filter], search: str | None, params: list[Any]) -> str:
        # a filter on column "*" is a free-text search across all columns (dashboard search box)
        stars = [str(f.value or "") for f in filters if f.column == "*" and f.value]
        filters = [f for f in filters if f.column != "*"]
        if stars:
            search = " ".join([search or ""] + stars).strip()
        parts = [self.filter_sql(f, params) for f in filters]
        if search:
            s = search.strip()[:200].replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_")
            text_cols = [n for n, c in self.columns.items() if c["data_type"] in TEXT_TYPES | {"boolean"} or c["data_type"] in NUMERIC_TYPES | DATE_TYPES]
            if text_cols:
                ors = []
                for n in text_cols:
                    params.append(f"%{s}%")
                    ors.append(f"CAST({quote_ident(n)} AS VARCHAR) ILIKE ? ESCAPE '\\'")
                parts.append("(" + " OR ".join(ors) + ")")
        return ("WHERE " + " AND ".join(parts)) if parts else ""

    def measure_sql(self, m: Measure, params: list[Any]) -> str:
        cond = ""
        if m.filters:
            sub: list[Any] = []
            cond = " FILTER (WHERE " + " AND ".join(self.filter_sql(f, sub) for f in m.filters) + ")"
            params.extend(sub)
        if m.formula:
            try:
                comp = compile_formula(m.formula, set(self.columns), self.numeric_columns)
            except FormulaError as e:
                raise QueryError(f"Formula error: {e}") from e
            if comp.is_aggregate:
                if cond:
                    raise QueryError("Measure filters cannot be combined with aggregate formulas")
                return comp.sql
            agg = m.agg if m.agg not in ("count_rows", "count_distinct") else "sum"
            return f"{self._agg_fn(agg, comp.sql)}{cond}"
        if m.agg == "count_rows" or not m.column:
            return f"COUNT(*){cond}"
        c = self.col(m.column)
        q = quote_ident(m.column)
        if m.agg in ("count", "count_distinct"):
            return (f"COUNT(DISTINCT {q})" if m.agg == "count_distinct" else f"COUNT({q})") + cond
        if c["data_type"] not in NUMERIC_TYPES:
            if m.agg in ("min", "max") and c["data_type"] in DATE_TYPES:
                return f"{m.agg.upper()}({q}){cond}"
            raise QueryError(f"Cannot compute {m.agg} of '{m.column}' because it is not numeric")
        return f"{self._agg_fn(m.agg, q)}{cond}"

    @staticmethod
    def _agg_fn(agg: str, expr: str) -> str:
        return {
            "sum": f"SUM({expr})", "avg": f"AVG({expr})", "min": f"MIN({expr})", "max": f"MAX({expr})",
            "median": f"MEDIAN({expr})", "stddev": f"STDDEV_SAMP({expr})", "variance": f"VAR_SAMP({expr})",
            "count": f"COUNT({expr})",
        }[agg]

    # ------------------------------------------------------------------ public API
    def aggregate(self, spec: QuerySpec) -> dict[str, Any]:
        params: list[Any] = []
        select: list[str] = []
        group: list[str] = []
        order_map: dict[str, str] = {}
        dim_aliases = []
        for d in spec.dimensions[:3]:
            expr, order_expr = self.dim_sql(d)
            alias = dimension_alias(d)
            dim_aliases.append(alias)
            select.append(f"{expr} AS {quote_ident(alias)}")
            group.append(expr)
            order_map[alias] = order_expr or expr
            if order_expr and order_expr != expr:
                group.append(order_expr)
        measures = spec.measures or [Measure(agg="count_rows")]
        m_aliases = []
        for m in measures[:12]:
            alias = measure_alias(m)
            base = alias
            k = 2
            while alias in m_aliases or alias in dim_aliases:
                alias = f"{base} ({k})"
                k += 1
            m_aliases.append(alias)
            select.append(f"{self.measure_sql(m, params)} AS {quote_ident(alias)}")
        where = self.where_sql(spec.filters, spec.search, params)
        sql = f"SELECT {', '.join(select)} FROM data {where}"
        if group:
            sql += " GROUP BY " + ", ".join(dict.fromkeys(group))
        order: list[str] = []
        for s in spec.sort:
            if s.by in order_map:
                order.append(f"{order_map[s.by]} {'DESC' if s.desc else 'ASC'} NULLS LAST")
            elif s.by in m_aliases:
                order.append(f"{quote_ident(s.by)} {'DESC' if s.desc else 'ASC'} NULLS LAST")
            else:
                raise QueryError(f"Cannot sort by '{s.by}'")
        if not order and group:
            first_dim = spec.dimensions[0]
            if first_dim.granularity:
                order.append(f"{order_map[dim_aliases[0]]} ASC")
            else:
                order.append(f"{quote_ident(m_aliases[0])} DESC NULLS LAST")
        if order:
            sql += " ORDER BY " + ", ".join(order)
        count_sql = None
        if group:
            count_sql = f"SELECT COUNT(*) FROM ({sql}) g"
        limit = min(spec.limit or MAX_LIMIT, MAX_LIMIT)
        if group:
            sql += f" LIMIT {int(limit)} OFFSET {int(max(0, spec.offset))}"
        cols, rows = self.run(sql, params)
        total_groups = self.run(count_sql, params)[1][0][0] if count_sql else 1
        return {
            "columns": cols,
            "dimensions": dim_aliases,
            "measures": m_aliases,
            "rows": [[_json(v) for v in r] for r in rows],
            "total_groups": int(total_groups),
            "truncated": bool(group) and int(total_groups) > len(rows) + max(0, spec.offset),
            "sql": _pretty_sql(sql),
        }

    def scalar(self, measure: Measure, filters: list[Filter] | None = None) -> Any:
        res = self.aggregate(QuerySpec(measures=[measure], filters=filters or []))
        return res["rows"][0][0] if res["rows"] else None

    def count(self, filters: list[Filter] | None = None, search: str | None = None) -> int:
        params: list[Any] = []
        where = self.where_sql(filters or [], search, params)
        return int(self.run(f"SELECT COUNT(*) FROM data {where}", params)[1][0][0])

    def distinct_values(self, column: str, filters: list[Filter] | None = None, search: str | None = None,
                        limit: int = 200) -> dict[str, Any]:
        self.col(column)
        q = quote_ident(column)
        params: list[Any] = []
        other = [f for f in (filters or []) if f.column != column]
        where_other = self.where_sql(other, None, params)
        conds = [where_other[len("WHERE "):]] if where_other else []
        if search:
            params.append(f"%{search.strip()[:100]}%")
            conds.append(f"CAST({q} AS VARCHAR) ILIKE ?")
        where = ("WHERE " + " AND ".join(conds)) if conds else ""
        sql = f"SELECT {q} AS v, COUNT(*) AS n FROM data {where} GROUP BY 1 ORDER BY n DESC, v LIMIT {int(min(limit, 5000))}"
        _, rows = self.run(sql, params)
        total = self.run(f"SELECT COUNT(DISTINCT {q}) FROM data {where}", params)[1][0][0]
        return {"column": column, "values": [{"value": _json(v), "count": int(n)} for v, n in rows], "total_distinct": int(total)}

    def rows(self, *, columns: list[str] | None = None, filters: list[Filter] | None = None, search: str | None = None,
             sort: list[Sort] | None = None, limit: int = 100, offset: int = 0, duplicates_only: bool = False,
             nulls_in: str | None = None) -> dict[str, Any]:
        cols = columns or list(self.columns)
        for c in cols:
            self.col(c)
        params: list[Any] = []
        where = self.where_sql(filters or [], search, params)
        base = "data"
        if duplicates_only:
            all_cols = ", ".join(quote_ident(c) for c in self.columns)
            base = f"(SELECT *, COUNT(*) OVER (PARTITION BY {all_cols}) AS __dup FROM data) d"
            where = (where + " AND __dup > 1") if where else "WHERE __dup > 1"
        if nulls_in:
            self.col(nulls_in)
            cond = f"{quote_ident(nulls_in)} IS NULL"
            where = (where + f" AND {cond}") if where else f"WHERE {cond}"
        order = ""
        if sort:
            order = " ORDER BY " + ", ".join(f"{quote_ident(self.col(s.by)['name'])} {'DESC' if s.desc else 'ASC'} NULLS LAST" for s in sort)
        sel = ", ".join(quote_ident(c) for c in cols)
        limit = max(1, min(int(limit), 5000))
        sql = f"SELECT {sel} FROM {base} {where}{order} LIMIT {limit} OFFSET {max(0, int(offset))}"
        _, data = self.run(sql, params)
        total = int(self.run(f"SELECT COUNT(*) FROM {base} {where}", params)[1][0][0])
        return {"columns": cols, "rows": [[_json(v) for v in r] for r in data], "total": total, "offset": offset, "limit": limit}

    def export_frame(self, *, columns: list[str] | None = None, filters: list[Filter] | None = None, search: str | None = None,
                     sort: list[Sort] | None = None, max_rows: int = 1_048_000):
        cols = columns or list(self.columns)
        for c in cols:
            self.col(c)
        params: list[Any] = []
        where = self.where_sql(filters or [], search, params)
        order = ""
        if sort:
            order = " ORDER BY " + ", ".join(f"{quote_ident(self.col(s.by)['name'])} {'DESC' if s.desc else 'ASC'}" for s in sort)
        sel = ", ".join(quote_ident(c) for c in cols)
        con = self.connect()
        try:
            return con.execute(f"SELECT {sel} FROM data {where}{order} LIMIT {int(max_rows)}", params).fetchdf()
        except duckdb.Error as e:
            raise QueryError(str(e).splitlines()[0]) from e
        finally:
            con.close()

    def date_bounds(self, column: str, filters: list[Filter] | None = None) -> tuple[datetime | None, datetime | None]:
        params: list[Any] = []
        where = self.where_sql(filters or [], None, params)
        q = quote_ident(column)
        _, rows = self.run(f"SELECT MIN({q}), MAX({q}) FROM data {where}", params)
        return rows[0][0], rows[0][1]


def _pretty_sql(sql: str) -> str:
    return sql.replace("read_parquet", "dataset")


def best_granularity(start: datetime | date | None, end: datetime | date | None) -> str:
    if not start or not end:
        return "month"
    days = (end - start).days if not isinstance(end - start, int) else end - start
    if days <= 45:
        return "day"
    if days <= 200:
        return "week"
    if days <= 365 * 4:
        return "month"
    if days <= 365 * 12:
        return "quarter"
    return "year"
