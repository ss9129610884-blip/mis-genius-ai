"""Number formatting shared by insights, reports and exports (Indian and international styles)."""
from __future__ import annotations

import math
from typing import Any

CURRENCY_SYMBOLS = {"INR": "₹", "USD": "$", "EUR": "€", "GBP": "£", "JPY": "¥", "AED": "AED ", "SAR": "SAR "}


def indian_group(n: int) -> str:
    s = str(abs(n))
    if len(s) <= 3:
        out = s
    else:
        head, tail = s[:-3], s[-3:]
        parts = []
        while len(head) > 2:
            parts.insert(0, head[-2:])
            head = head[:-2]
        if head:
            parts.insert(0, head)
        out = ",".join(parts) + "," + tail
    return ("-" if n < 0 else "") + out


def compact(v: float, indian: bool) -> str:
    a = abs(v)
    sign = "-" if v < 0 else ""
    if indian:
        for div, suf in ((1e7, " Cr"), (1e5, " L"), (1e3, "K")):
            if a >= div:
                return f"{sign}{a / div:,.2f}".rstrip("0").rstrip(".") + suf
    else:
        for div, suf in ((1e12, "T"), (1e9, "B"), (1e6, "M"), (1e3, "K")):
            if a >= div:
                return f"{sign}{a / div:,.2f}".rstrip("0").rstrip(".") + suf
    return f"{sign}{a:,.2f}".rstrip("0").rstrip(".") if not float(a).is_integer() else f"{sign}{int(a):,}"


def format_value(v: Any, kind: str = "number", currency: str | None = None, decimals: int | None = None,
                 compact_mode: bool = True, indian: bool = True) -> str:
    if v is None:
        return "—"
    if isinstance(v, str):
        return v
    if isinstance(v, bool):
        return "Yes" if v else "No"
    try:
        f = float(v)
    except (TypeError, ValueError):
        return str(v)
    if math.isnan(f) or math.isinf(f):
        return "—"
    if kind == "percent":
        d = 1 if decimals is None else decimals
        return f"{f:,.{d}f}%"
    sym = CURRENCY_SYMBOLS.get((currency or "").upper(), (currency + " ") if currency else "") if kind == "currency" else ""
    if compact_mode and abs(f) >= 100000:
        return sym + compact(f, indian)
    d = decimals if decimals is not None else (0 if f.is_integer() else 2)
    if indian and abs(f) >= 1000 and d == 0:
        return sym + indian_group(int(round(f)))
    if indian and abs(f) >= 1000:
        whole = int(abs(f))
        frac = f"{abs(f) - whole:.{d}f}"[1:]
        return sym + ("-" if f < 0 else "") + indian_group(whole) + frac
    return sym + f"{f:,.{d}f}"


def format_pct(v: float | None, decimals: int = 1, signed: bool = True) -> str:
    if v is None:
        return "—"
    s = f"{v:+.{decimals}f}%" if signed else f"{v:.{decimals}f}%"
    return s
