"""Statistical helpers used by KPIs, charts and the insight engine.

All functions work on already-aggregated, small series (periods, groups), so they
are cheap and deterministic.
"""
from __future__ import annotations

import math
from typing import Any

import numpy as np


def pct_change(current: float | None, previous: float | None) -> float | None:
    if current is None or previous is None:
        return None
    if previous == 0:
        return None
    return (current - previous) / abs(previous) * 100.0


def linear_trend(values: list[float]) -> dict[str, Any] | None:
    """Least-squares slope over equally spaced periods. Returns slope, % per period, r²."""
    y = np.array([v for v in values if v is not None and not (isinstance(v, float) and math.isnan(v))], dtype=float)
    if len(y) < 3:
        return None
    x = np.arange(len(y), dtype=float)
    slope, intercept = np.polyfit(x, y, 1)
    pred = slope * x + intercept
    ss_res = float(np.sum((y - pred) ** 2))
    ss_tot = float(np.sum((y - y.mean()) ** 2))
    r2 = 1 - ss_res / ss_tot if ss_tot > 0 else 0.0
    mean = float(y.mean())
    return {
        "slope": float(slope),
        "slope_pct_of_mean": float(slope / abs(mean) * 100) if mean else None,
        "r2": round(r2, 3),
        "direction": "up" if slope > 0 else "down" if slope < 0 else "flat",
        "strength": "strong" if r2 >= 0.6 else "moderate" if r2 >= 0.3 else "weak",
    }


def robust_anomalies(labels: list[Any], values: list[float | None], threshold: float = 3.5) -> list[dict[str, Any]]:
    """Modified z-score (median / MAD). Robust to the anomalies themselves."""
    pts = [(l, v) for l, v in zip(labels, values) if v is not None]
    if len(pts) < 6:
        return []
    arr = np.array([v for _, v in pts], dtype=float)
    med = float(np.median(arr))
    mad = float(np.median(np.abs(arr - med)))
    if mad == 0:
        std = float(arr.std())
        if std == 0:
            return []
        scores = (arr - arr.mean()) / std
        thr = 3.0
    else:
        scores = 0.6745 * (arr - med) / mad
        thr = threshold
    out = []
    for (label, v), z in zip(pts, scores):
        if abs(z) >= thr:
            out.append({"label": label, "value": v, "score": round(float(z), 2), "median": med,
                        "direction": "high" if z > 0 else "low"})
    return out


def concentration(values: list[float]) -> dict[str, Any] | None:
    """Share of the total held by the top 20% of groups (Pareto)."""
    vals = sorted([v for v in values if v is not None and v > 0], reverse=True)
    if len(vals) < 5:
        return None
    total = sum(vals)
    if total <= 0:
        return None
    k = max(1, math.ceil(len(vals) * 0.2))
    share = sum(vals[:k]) / total * 100
    return {"top_n": k, "groups": len(vals), "top_share_pct": share}


def moving_average(values: list[float | None], window: int) -> list[float | None]:
    out: list[float | None] = []
    for i in range(len(values)):
        win = [v for v in values[max(0, i - window + 1): i + 1] if v is not None]
        out.append(sum(win) / len(win) if len(win) == min(window, i + 1) and win else None)
    return out


def running_total(values: list[float | None]) -> list[float | None]:
    total = 0.0
    out: list[float | None] = []
    for v in values:
        total += v or 0.0
        out.append(total)
    return out


def contribution(values: list[float | None]) -> list[float | None]:
    total = sum(v for v in values if v is not None)
    return [(v / total * 100 if (v is not None and total) else None) for v in values]
