"""Chart engine: chart specs → chart-ready data, plus chart-type recommendation."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field

from misgenius.analytics.formulas import quote_ident
from misgenius.analytics.query import (
    DATE_TYPES,
    NUMERIC_TYPES,
    DataSource,
    Dimension,
    Filter,
    Measure,
    QueryError,
    QuerySpec,
    Sort,
    best_granularity,
    dimension_alias,
    measure_alias,
)
from misgenius.analytics.stats import contribution, moving_average, running_total

ChartType = Literal[
    "bar", "hbar", "line", "area", "pie", "donut", "scatter", "histogram", "stacked_bar", "stacked_bar_100",
    "combo", "kpi", "table", "pivot", "heatmap",
]
ADDITIVE = {"sum", "count", "count_rows"}


class ChartSpec(BaseModel):
    type: ChartType = "bar"
    dimension: Dimension | None = None
    series_dimension: Dimension | None = None
    measures: list[Measure] = Field(default_factory=list)
    x_measure: Measure | None = None
    y_measure: Measure | None = None
    histogram_column: str | None = None
    bins: int = 20
    top_n: int = 12
    other: bool = True
    sort: Literal["value_desc", "value_asc", "label", "natural"] = "natural"
    transform: Literal["none", "running_total", "moving_average", "contribution"] = "none"
    window: int = 3
    filters: list[Filter] = Field(default_factory=list)
    columns: list[str] | None = None  # for table widgets
    limit: int = 100


def _is_additive(m: Measure) -> bool:
    return not m.formula and m.agg in ADDITIVE


def _resolve_time(ds: DataSource, d: Dimension | None, filters: list[Filter]) -> Dimension | None:
    if d is None:
        return None
    if d.column in ds.columns and ds.dtype(d.column) in DATE_TYPES and d.granularity is None:
        lo, hi = ds.date_bounds(d.column, filters)
        return d.model_copy(update={"granularity": best_granularity(lo, hi)})
    return d


def build_chart(ds: DataSource, spec: ChartSpec, filters: list[Filter] | None = None) -> dict[str, Any]:
    flt = list(filters or []) + list(spec.filters)
    t = spec.type
    if t == "scatter":
        return _scatter(ds, spec, flt)
    if t == "histogram":
        return _histogram(ds, spec, flt)
    if t == "table":
        return _table(ds, spec, flt)
    if t == "heatmap":
        return _heatmap(ds, spec, flt)
    if t == "pivot":
        from misgenius.analytics.pivot import pivot

        rows = [spec.dimension] if spec.dimension else []
        return {"type": "pivot", **pivot(ds, rows=rows, column=spec.series_dimension, values=spec.measures or [Measure(agg="count_rows")], filters=flt)}
    measures = spec.measures or [Measure(agg="count_rows")]
    if t == "kpi" or spec.dimension is None:
        res = ds.aggregate(QuerySpec(measures=measures, filters=flt))
        return {"type": "kpi", "series": [{"name": n, "data": [v]} for n, v in zip(res["measures"], res["rows"][0])],
                "categories": [], "evidence": {"sql": res["sql"]}}
    dim = _resolve_time(ds, spec.dimension, flt)
    assert dim is not None
    sdim = spec.series_dimension
    is_time = bool(dim.granularity)
    if sdim and t in ("stacked_bar", "stacked_bar_100", "bar", "hbar", "line", "area"):
        return _two_dim(ds, spec, dim, sdim, measures[0], flt, is_time)

    sort: list[Sort] = []
    if not is_time:
        if spec.sort in ("value_desc", "natural"):
            sort = [Sort(by=measure_alias(measures[0]), desc=True)]
        elif spec.sort == "value_asc":
            sort = [Sort(by=measure_alias(measures[0]), desc=False)]
        elif spec.sort == "label":
            sort = [Sort(by=dim.alias or dim.column, desc=False)]
    limit = 5000 if is_time else max(1, min(spec.top_n, 200))
    res = ds.aggregate(QuerySpec(dimensions=[dim], measures=measures[:4], filters=flt, sort=sort, limit=limit))
    cats = [r[0] if r[0] is not None else "(Blank)" for r in res["rows"]]
    series = []
    for i, name in enumerate(res["measures"]):
        data = [r[1 + i] for r in res["rows"]]
        series.append({"name": name, "data": data, "kind": ("line" if (t == "combo" and i > 0) else None)})
    other_value = None
    if not is_time and spec.other and res["truncated"] and t not in ("line", "area") and all(_is_additive(m) for m in measures[:1]):
        total = ds.aggregate(QuerySpec(measures=measures[:1], filters=flt))["rows"][0][0] or 0
        shown = sum(v or 0 for v in series[0]["data"])
        other_value = total - shown
        if other_value and abs(other_value) > 1e-9:
            cats.append("Other")
            series[0]["data"].append(other_value)
            for s in series[1:]:
                s["data"].append(None)
    if spec.transform != "none":
        for s in series:
            if spec.transform == "running_total":
                s["data"] = running_total(s["data"])
            elif spec.transform == "moving_average":
                s["data"] = moving_average(s["data"], max(2, spec.window))
            elif spec.transform == "contribution":
                s["data"] = contribution(s["data"])
            s["transform"] = spec.transform
    return {
        "type": t,
        "categories": cats,
        "series": series,
        "dimension": dim.model_dump(),
        "is_time": is_time,
        "granularity": dim.granularity,
        "meta": {"total_groups": res["total_groups"], "truncated": res["truncated"], "other_included": other_value is not None},
        "evidence": {"sql": res["sql"]},
    }


def _two_dim(ds: DataSource, spec: ChartSpec, dim: Dimension, sdim: Dimension, m: Measure, flt: list[Filter], is_time: bool) -> dict[str, Any]:
    sdim = _resolve_time(ds, sdim, flt) or sdim
    top_series = ds.aggregate(QuerySpec(dimensions=[sdim], measures=[m], filters=flt, limit=10))
    keep = [r[0] for r in top_series["rows"]]
    res = ds.aggregate(QuerySpec(dimensions=[dim, sdim], measures=[m], filters=flt, limit=20000,
                                 sort=[Sort(by=dimension_alias(dim), desc=False)] if is_time else []))
    cat_totals: dict[Any, float] = {}
    for r in res["rows"]:
        cat_totals[r[0]] = cat_totals.get(r[0], 0) + (r[2] or 0)
    if is_time:
        cats = sorted(cat_totals, key=lambda x: (x is None, str(x)))
    else:
        cats = sorted(cat_totals, key=lambda k: -cat_totals[k])[: max(1, min(spec.top_n, 50))]
    idx = {c: i for i, c in enumerate(cats)}
    series_map: dict[Any, list[Any]] = {k: [None] * len(cats) for k in keep}
    has_other = False
    other = [0.0] * len(cats)
    for c, s, v in res["rows"]:
        if c not in idx:
            continue
        if s in series_map:
            series_map[s][idx[c]] = v
        elif _is_additive(m):
            has_other = True
            other[idx[c]] += v or 0
    series = [{"name": str(k) if k is not None else "(Blank)", "data": v} for k, v in series_map.items()]
    if has_other:
        series.append({"name": "Other", "data": other})
    if spec.type == "stacked_bar_100":
        for i in range(len(cats)):
            tot = sum((s["data"][i] or 0) for s in series)
            for s in series:
                s["data"][i] = (s["data"][i] or 0) / tot * 100 if tot else None
    return {
        "type": spec.type if spec.type != "bar" else "stacked_bar",
        "categories": [c if c is not None else "(Blank)" for c in cats],
        "series": series,
        "dimension": dim.model_dump(), "series_dimension": sdim.model_dump(), "is_time": is_time,
        "granularity": dim.granularity, "measure": measure_alias(m),
        "meta": {"total_groups": len(cat_totals), "truncated": len(cat_totals) > len(cats), "series_truncated": has_other},
        "evidence": {"sql": res["sql"]},
    }


def _scatter(ds: DataSource, spec: ChartSpec, flt: list[Filter]) -> dict[str, Any]:
    if not spec.x_measure or not spec.y_measure:
        raise QueryError("Scatter charts need an X and a Y measure")
    if spec.dimension:
        dim = _resolve_time(ds, spec.dimension, flt)
        res = ds.aggregate(QuerySpec(dimensions=[dim], measures=[spec.x_measure, spec.y_measure], filters=flt, limit=2000))
        pts = [{"label": r[0], "x": r[1], "y": r[2]} for r in res["rows"] if r[1] is not None and r[2] is not None]
        names = res["measures"]
        sql = res["sql"]
    else:
        xc, yc = spec.x_measure.column, spec.y_measure.column
        if not xc or not yc:
            raise QueryError("Row-level scatter needs two numeric columns")
        for c in (xc, yc):
            if ds.dtype(c) not in NUMERIC_TYPES:
                raise QueryError(f"'{c}' is not numeric")
        params: list[Any] = []
        where = ds.where_sql(flt, None, params)
        cond = f"{quote_ident(xc)} IS NOT NULL AND {quote_ident(yc)} IS NOT NULL"
        where = (where + " AND " + cond) if where else "WHERE " + cond
        sql = f"SELECT {quote_ident(xc)}, {quote_ident(yc)} FROM data {where} USING SAMPLE 2000 ROWS"
        _, rows = ds.run(sql, params)
        pts = [{"x": float(a), "y": float(b)} for a, b in rows]
        names = [xc, yc]
    corr = None
    if len(pts) >= 5:
        import numpy as np

        xs = np.array([p["x"] for p in pts], dtype=float)
        ys = np.array([p["y"] for p in pts], dtype=float)
        if xs.std() > 0 and ys.std() > 0:
            corr = float(np.corrcoef(xs, ys)[0, 1])
    return {"type": "scatter", "points": pts, "x_name": names[0], "y_name": names[1], "correlation": corr,
            "evidence": {"sql": sql}}


def _histogram(ds: DataSource, spec: ChartSpec, flt: list[Filter]) -> dict[str, Any]:
    col = spec.histogram_column or (spec.measures[0].column if spec.measures else None)
    if not col or ds.dtype(col) not in NUMERIC_TYPES:
        raise QueryError("Histogram needs a numeric column")
    params: list[Any] = []
    where = ds.where_sql(flt, None, params)
    q = quote_ident(col)
    cond = f"{q} IS NOT NULL"
    where2 = (where + " AND " + cond) if where else "WHERE " + cond
    _, b = ds.run(f"SELECT MIN({q}), MAX({q}), quantile_cont({q}, 0.01), quantile_cont({q}, 0.99), COUNT(*) FROM data {where2}", params)
    mn, mx, p1, p99, n = b[0]
    if n == 0 or mn is None:
        return {"type": "histogram", "categories": [], "series": [{"name": "Count", "data": []}], "column": col}
    lo, hi = float(p1), float(p99)
    if hi <= lo:
        lo, hi = float(mn), float(mx)
    bins = max(5, min(int(spec.bins), 60))
    width = (hi - lo) / bins if hi > lo else 1.0
    sql = (f"SELECT LEAST(GREATEST(FLOOR(({q} - ?) / ?), -1), ?) AS b, COUNT(*) FROM data {where2} GROUP BY 1 ORDER BY 1")
    _, rows = ds.run(sql, [lo, width, bins] + params)
    counts = {int(r[0]): int(r[1]) for r in rows}
    cats, data = [], []
    if counts.get(-1):
        cats.append(f"< {lo:,.2f}")
        data.append(counts[-1])
    for i in range(bins):
        a = lo + i * width
        cats.append(f"{a:,.2f} – {a + width:,.2f}")
        data.append(counts.get(i, 0))
    if counts.get(bins):
        cats[-1] = f"{lo + (bins - 1) * width:,.2f} – {hi:,.2f}"
        data[-1] += counts[bins]
    return {"type": "histogram", "categories": cats, "series": [{"name": "Count", "data": data}], "column": col,
            "meta": {"min": mn, "max": mx, "n": n, "clipped_to_percentiles": [1, 99]}, "evidence": {"sql": sql}}


def _heatmap(ds: DataSource, spec: ChartSpec, flt: list[Filter]) -> dict[str, Any]:
    if not spec.dimension or not spec.series_dimension:
        raise QueryError("Heatmap needs two dimensions")
    m = (spec.measures or [Measure(agg="count_rows")])[0]
    dx = _resolve_time(ds, spec.dimension, flt)
    dy = _resolve_time(ds, spec.series_dimension, flt)
    tx = ds.aggregate(QuerySpec(dimensions=[dx], measures=[m], filters=flt, limit=30))
    ty = ds.aggregate(QuerySpec(dimensions=[dy], measures=[m], filters=flt, limit=20))
    xs = [r[0] for r in tx["rows"]]
    ys = [r[0] for r in ty["rows"]]
    res = ds.aggregate(QuerySpec(dimensions=[dx, dy], measures=[m], filters=flt, limit=20000))
    xi = {v: i for i, v in enumerate(xs)}
    yi = {v: i for i, v in enumerate(ys)}
    data = [[xi[a], yi[b], v] for a, b, v in res["rows"] if a in xi and b in yi]
    return {"type": "heatmap", "x": [x if x is not None else "(Blank)" for x in xs], "y": [y if y is not None else "(Blank)" for y in ys],
            "data": data, "measure": measure_alias(m), "evidence": {"sql": res["sql"]}}


def _table(ds: DataSource, spec: ChartSpec, flt: list[Filter]) -> dict[str, Any]:
    if spec.dimension:
        dim = _resolve_time(ds, spec.dimension, flt)
        measures = spec.measures or [Measure(agg="count_rows")]
        sort = [] if dim.granularity else [Sort(by=measure_alias(measures[0]), desc=spec.sort != "value_asc")]
        res = ds.aggregate(QuerySpec(dimensions=[dim], measures=measures, filters=flt, limit=max(1, min(spec.limit, 1000)), sort=sort))
        total = ds.aggregate(QuerySpec(measures=measures, filters=flt))["rows"][0]
        return {"type": "table", "columns": res["columns"], "rows": res["rows"], "totals": ["Total", *total] if all(_is_additive(m) for m in measures) else None,
                "meta": {"total_groups": res["total_groups"], "truncated": res["truncated"]}, "evidence": {"sql": res["sql"]}}
    data = ds.rows(columns=spec.columns, filters=flt, limit=max(1, min(spec.limit, 500)))
    return {"type": "table", "columns": data["columns"], "rows": data["rows"], "meta": {"total_groups": data["total"], "truncated": data["total"] > len(data["rows"])}}


# --------------------------------------------------------------------------- recommendation
def recommend_charts(ds: DataSource, dimensions: list[str], measures: list[str]) -> list[dict[str, Any]]:
    cols = ds.columns
    dims = [cols[d] for d in dimensions if d in cols]
    meas = [cols[m] for m in measures if m in cols]
    recs: list[dict[str, Any]] = []

    def add(t: str, score: float, reason: str) -> None:
        recs.append({"type": t, "score": round(score, 2), "reason": reason})

    time_dims = [d for d in dims if d["data_type"] in DATE_TYPES or d["role"] == "time"]
    cat_dims = [d for d in dims if d not in time_dims]
    if not dims and len(meas) == 1:
        add("kpi", 0.95, "A single number is best shown as a KPI card.")
        add("histogram", 0.7, "A histogram shows how the values are distributed.")
    if not dims and len(meas) >= 2:
        add("scatter", 0.9, "Two measures without a category: a scatter plot shows their relationship.")
    if time_dims and not cat_dims:
        add("line", 0.95, "Values over time read best as a line.")
        add("area", 0.75, "An area chart emphasises volume over time.")
        if len(meas) >= 2:
            add("combo", 0.85, "Two measures over time: bars for one, a line for the other.")
        add("bar", 0.6, "Bars work for a small number of periods.")
    if time_dims and cat_dims:
        add("stacked_bar", 0.85, "Shows how each category contributes in every period.")
        add("line", 0.75, "One line per category (top 10) over time.")
        add("heatmap", 0.6, "Period × category intensity.")
    if cat_dims and not time_dims:
        d = cat_dims[0]
        card = d.get("stats", {}).get("distinct", 0)
        if len(cat_dims) >= 2:
            add("stacked_bar", 0.85, "Two categories: stacked bars compare the mix.")
            add("heatmap", 0.8 if card <= 30 else 0.5, "Two categories: a heatmap shows every combination.")
            add("stacked_bar_100", 0.7, "Compares proportions within each category.")
        if card <= 6 and len(meas) <= 1:
            add("donut", 0.85, f"Only {card} categories: a donut shows the share of each.")
            add("bar", 0.8, "Bars compare categories precisely.")
        elif card <= 15:
            add("bar", 0.9, f"{card} categories compare well as bars.")
            add("hbar", 0.75, "Horizontal bars suit long labels.")
        else:
            add("hbar", 0.9, f"{card} categories: show the top {12} as horizontal bars, the rest as Other.")
            add("table", 0.75, "A ranked table lists every category.")
        if len(meas) >= 2:
            add("combo", 0.7, "Compare two measures per category.")
        add("pie", 0.4 if card > 6 else 0.7, "Pie charts only work for a few categories.")
    if not recs:
        add("table", 0.6, "A table fits any combination of columns.")
    recs.sort(key=lambda r: -r["score"])
    return recs
