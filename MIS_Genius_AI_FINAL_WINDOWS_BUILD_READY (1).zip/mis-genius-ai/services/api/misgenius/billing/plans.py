"""Subscription plans and entitlement checks.

Limits are enforced in production (SaaS). Local, LAN and development installs are
single-organisation deployments owned by the customer and run without limits
unless ENFORCE_LIMITS=true.
"""
from __future__ import annotations

from dataclasses import asdict, dataclass
from datetime import datetime, timedelta, timezone
from typing import Any

from sqlalchemy import func, select
from sqlalchemy.orm import Session

from misgenius.config import get_settings
from misgenius.db.models import Dashboard, Dataset, Membership, Organization, UsageRecord


@dataclass(frozen=True)
class Plan:
    key: str
    name: str
    price_inr_month: int | None
    datasets: int | None
    max_file_mb: int | None
    ai_requests_month: int | None
    users: int | None
    dashboards: int | None
    storage_mb: int | None
    api_calls_day: int | None


PLANS: dict[str, Plan] = {
    "free": Plan("free", "Free", 0, 5, 10, 50, 2, 10, 250, 1_000),
    "starter": Plan("starter", "Starter", 999, 25, 50, 500, 5, 50, 2_048, 10_000),
    "professional": Plan("professional", "Professional", 2_999, 100, 100, 3_000, 15, 250, 10_240, 50_000),
    "business": Plan("business", "Business", 9_999, 500, 200, 15_000, 50, 1_000, 51_200, 200_000),
    "enterprise": Plan("enterprise", "Enterprise", None, None, None, None, None, None, None, None),
}


class LimitExceeded(Exception):
    def __init__(self, metric: str, limit: int, plan: str):
        super().__init__(f"Your {PLANS[plan].name} plan allows {limit:,} {metric.replace('_', ' ')}. Upgrade the plan to continue.")
        self.metric, self.limit, self.plan = metric, limit, plan


def enforce_limits() -> bool:
    import os

    v = os.environ.get("ENFORCE_LIMITS")
    if v is not None:
        return v.lower() in ("1", "true", "yes")
    return get_settings().is_production


def plan_for(org: Organization) -> Plan:
    return PLANS.get(org.plan or "free", PLANS["free"])


def _month_start() -> datetime:
    now = datetime.now(timezone.utc)
    return now.replace(day=1, hour=0, minute=0, second=0, microsecond=0)


def usage_summary(db: Session, org: Organization) -> dict[str, Any]:
    from misgenius.storage.base import get_storage

    plan = plan_for(org)
    ds_count = db.scalar(select(func.count()).select_from(Dataset).where(Dataset.org_id == org.id, Dataset.deleted_at.is_(None))) or 0
    dash_count = db.scalar(select(func.count()).select_from(Dashboard).where(Dashboard.org_id == org.id)) or 0
    users = db.scalar(select(func.count()).select_from(Membership).where(Membership.org_id == org.id)) or 0
    ai = db.scalar(select(func.coalesce(func.sum(UsageRecord.quantity), 0)).where(
        UsageRecord.org_id == org.id, UsageRecord.metric == "ai_requests", UsageRecord.created_at >= _month_start())) or 0
    api = db.scalar(select(func.coalesce(func.sum(UsageRecord.quantity), 0)).where(
        UsageRecord.org_id == org.id, UsageRecord.metric == "api_calls", UsageRecord.created_at >= datetime.now(timezone.utc) - timedelta(days=1))) or 0
    try:
        storage_mb = round(get_storage().size_of_prefix(f"orgs/{org.id}") / 1024 / 1024, 2)
    except Exception:  # noqa: BLE001
        storage_mb = None
    used = {"datasets": ds_count, "dashboards": dash_count, "users": users, "ai_requests_month": int(ai),
            "api_calls_day": int(api), "storage_mb": storage_mb}
    return {"plan": asdict(plan), "used": used, "enforced": enforce_limits()}


def check_limit(db: Session, org: Organization, metric: str, adding: float = 1) -> None:
    if not enforce_limits():
        return
    plan = plan_for(org)
    limit = getattr(plan, metric, None)
    if limit is None:
        return
    used = usage_summary(db, org)["used"].get(metric) or 0
    if used + adding > limit:
        raise LimitExceeded(metric, limit, plan.key)


def check_file_size(org: Organization, size_bytes: int) -> None:
    s = get_settings()
    if size_bytes > s.MAX_UPLOAD_MB * 1024 * 1024:
        raise LimitExceeded("max_file_mb", s.MAX_UPLOAD_MB, org.plan if org.plan in PLANS else "free")
    if enforce_limits():
        plan = plan_for(org)
        if plan.max_file_mb is not None and size_bytes > plan.max_file_mb * 1024 * 1024:
            raise LimitExceeded("max_file_mb", plan.max_file_mb, plan.key)
