"""Payment provider abstraction.

`ManualPaymentProvider` (default) lets an owner/admin set the plan directly — used
for local/LAN installs and invoiced enterprise customers.
`StripePaymentProvider` creates Checkout sessions and verifies webhooks using the
Stripe REST API (no SDK needed); it activates only when STRIPE_SECRET_KEY is set.
"""
from __future__ import annotations

import hashlib
import hmac
import json
import time
from abc import ABC, abstractmethod
from typing import Any

import httpx

from misgenius.config import get_settings


class PaymentError(Exception):
    pass


class PaymentProvider(ABC):
    name = "base"

    @abstractmethod
    def create_checkout(self, *, org_id: str, plan: str, success_url: str, cancel_url: str, customer_email: str) -> dict[str, Any]: ...

    @abstractmethod
    def parse_webhook(self, payload: bytes, signature: str | None) -> dict[str, Any] | None: ...


class ManualPaymentProvider(PaymentProvider):
    name = "manual"

    def create_checkout(self, **kw: Any) -> dict[str, Any]:
        raise PaymentError("Online payment is not configured. Ask your administrator to change the plan, or set STRIPE_SECRET_KEY.")

    def parse_webhook(self, payload: bytes, signature: str | None) -> dict[str, Any] | None:
        return None


class StripePaymentProvider(PaymentProvider):  # pragma: no cover - needs Stripe credentials
    name = "stripe"
    API = "https://api.stripe.com/v1"

    def __init__(self, secret_key: str, webhook_secret: str | None, price_ids: dict[str, str]):
        self.secret_key = secret_key
        self.webhook_secret = webhook_secret
        self.price_ids = price_ids

    def create_checkout(self, *, org_id: str, plan: str, success_url: str, cancel_url: str, customer_email: str) -> dict[str, Any]:
        price = self.price_ids.get(plan)
        if not price:
            raise PaymentError(f"No Stripe price configured for plan '{plan}' (set STRIPE_PRICE_{plan.upper()}).")
        data = {
            "mode": "subscription", "success_url": success_url, "cancel_url": cancel_url, "customer_email": customer_email,
            "line_items[0][price]": price, "line_items[0][quantity]": "1", "client_reference_id": org_id,
            "metadata[org_id]": org_id, "metadata[plan]": plan, "subscription_data[metadata][org_id]": org_id,
            "subscription_data[metadata][plan]": plan,
        }
        with httpx.Client(timeout=30) as c:
            r = c.post(f"{self.API}/checkout/sessions", data=data, auth=(self.secret_key, ""))
        if r.status_code >= 400:
            raise PaymentError(f"Stripe error: {r.json().get('error', {}).get('message', r.status_code)}")
        body = r.json()
        return {"url": body["url"], "id": body["id"]}

    def parse_webhook(self, payload: bytes, signature: str | None) -> dict[str, Any] | None:
        if not self.webhook_secret:
            raise PaymentError("STRIPE_WEBHOOK_SECRET is not configured")
        verify_stripe_signature(payload, signature or "", self.webhook_secret)
        event = json.loads(payload)
        obj = event.get("data", {}).get("object", {})
        meta = obj.get("metadata") or {}
        et = event.get("type")
        if et == "checkout.session.completed":
            return {"org_id": meta.get("org_id") or obj.get("client_reference_id"), "plan": meta.get("plan"), "status": "active",
                    "customer": obj.get("customer"), "subscription": obj.get("subscription")}
        if et in ("customer.subscription.updated", "customer.subscription.deleted"):
            status = obj.get("status", "canceled") if et.endswith("updated") else "canceled"
            return {"org_id": meta.get("org_id"), "plan": meta.get("plan") if status == "active" else "free", "status": status,
                    "customer": obj.get("customer"), "subscription": obj.get("id"), "current_period_end": obj.get("current_period_end")}
        return None


def verify_stripe_signature(payload: bytes, header: str, secret: str, tolerance: int = 300) -> None:
    parts = dict(p.split("=", 1) for p in header.split(",") if "=" in p)
    ts = parts.get("t")
    sig = parts.get("v1")
    if not ts or not sig:
        raise PaymentError("Missing Stripe signature")
    expected = hmac.new(secret.encode(), f"{ts}.".encode() + payload, hashlib.sha256).hexdigest()
    if not hmac.compare_digest(expected, sig):
        raise PaymentError("Invalid Stripe signature")
    if abs(time.time() - int(ts)) > tolerance:
        raise PaymentError("Stripe signature is too old")


def get_payment_provider() -> PaymentProvider:
    import os

    s = get_settings()
    if s.STRIPE_SECRET_KEY:
        prices = {p: os.environ.get(f"STRIPE_PRICE_{p.upper()}", "") for p in ("starter", "professional", "business")}
        return StripePaymentProvider(s.STRIPE_SECRET_KEY, s.STRIPE_WEBHOOK_SECRET, {k: v for k, v in prices.items() if v})
    return ManualPaymentProvider()
