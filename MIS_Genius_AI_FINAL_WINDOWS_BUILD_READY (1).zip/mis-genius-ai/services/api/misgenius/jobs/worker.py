"""Background worker entry point: `python -m misgenius.jobs.worker`.

Runs queued jobs and scheduled dataset refreshes. Start several workers to scale
horizontally (cloud mode, JOB_MODE=external).
"""
from __future__ import annotations

import logging
import threading
import time
from datetime import timedelta

from sqlalchemy import select

from misgenius.config import get_settings
from misgenius.db.models import Dataset, Job, utcnow
from misgenius.db.session import SessionLocal, run_migrations
from misgenius.jobs.runner import enqueue, recover_stale, worker_loop
from misgenius.logging_setup import setup_logging

log = logging.getLogger("misgenius.worker")


def schedule_refreshes() -> int:
    """Queue refresh jobs for connector datasets whose refresh interval has elapsed."""
    db = SessionLocal()
    n = 0
    try:
        now = utcnow()
        rows = db.scalars(select(Dataset).where(Dataset.refresh_minutes.is_not(None), Dataset.deleted_at.is_(None))).all()
        for ds in rows:
            last = ds.last_refreshed_at
            if last is not None and last.tzinfo is None:
                last = last.replace(tzinfo=now.tzinfo)
            if last and now - last < timedelta(minutes=max(15, ds.refresh_minutes or 0)):
                continue
            pending = db.scalars(select(Job).where(Job.kind == "refresh_dataset", Job.status.in_(["queued", "running"]))).all()
            if any(j.payload.get("dataset_id") == ds.id for j in pending):
                continue
            ds.last_refreshed_at = now  # prevents duplicate scheduling if the refresh fails
            db.commit()
            enqueue(db, "refresh_dataset", {"dataset_id": ds.id}, org_id=ds.org_id, user_id=None)
            n += 1
    finally:
        db.close()
    return n


def scheduler_loop(stop: threading.Event, interval: float = 60.0) -> None:
    while not stop.is_set():
        try:
            schedule_refreshes()
        except Exception as e:  # noqa: BLE001
            log.warning("refresh scheduler error: %s", e)
        stop.wait(interval)


def main() -> None:
    s = get_settings()
    setup_logging(s.DATA_DIR / "logs", s.LOG_LEVEL, s.LOG_JSON, to_files=True)
    run_migrations()
    db = SessionLocal()
    try:
        recover_stale(db)
    finally:
        db.close()
    stop = threading.Event()
    threading.Thread(target=scheduler_loop, args=(stop,), daemon=True).start()
    try:
        worker_loop(stop=stop)
    except KeyboardInterrupt:
        stop.set()
        time.sleep(0.2)


if __name__ == "__main__":
    main()
