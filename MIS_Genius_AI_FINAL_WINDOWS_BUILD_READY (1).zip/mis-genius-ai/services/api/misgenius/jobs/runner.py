"""Background job runner.

JOB_MODE=thread   → jobs run in a small in-process thread pool (desktop / LAN / single server)
JOB_MODE=inline   → jobs run synchronously inside the request (tests)
JOB_MODE=external → jobs stay queued for `python -m misgenius.jobs.worker` processes (cloud, scalable)

Job state lives in the database, so any API instance can report progress.
"""
from __future__ import annotations

import logging
import threading
import time
import traceback
from concurrent.futures import ThreadPoolExecutor
from datetime import timedelta
from typing import Any, Callable

from sqlalchemy import select, update
from sqlalchemy.orm import Session

from misgenius.config import get_settings
from misgenius.db.models import Job, utcnow
from misgenius.db.session import SessionLocal

log = logging.getLogger("misgenius.jobs")
HANDLERS: dict[str, Callable[[Session, Job], dict[str, Any]]] = {}
_pool: ThreadPoolExecutor | None = None
_pool_lock = threading.Lock()


class JobError(Exception):
    """Expected failure with a user-facing message."""


def handler(kind: str):
    def deco(fn: Callable[[Session, Job], dict[str, Any]]):
        HANDLERS[kind] = fn
        return fn

    return deco


def _get_pool() -> ThreadPoolExecutor:
    global _pool
    with _pool_lock:
        if _pool is None:
            _pool = ThreadPoolExecutor(max_workers=2, thread_name_prefix="mis-job")
        return _pool


def enqueue(db: Session, kind: str, payload: dict[str, Any], *, org_id: str | None, user_id: str | None) -> Job:
    job = Job(kind=kind, payload=payload, org_id=org_id, created_by=user_id, status="queued")
    db.add(job)
    db.commit()
    mode = get_settings().JOB_MODE
    if mode == "inline":
        run_job(job.id)
        db.refresh(job)
    elif mode == "thread":
        _get_pool().submit(run_job, job.id)
    return job


def run_job(job_id: str) -> None:
    db = SessionLocal()
    try:
        claimed = db.execute(update(Job).where(Job.id == job_id, Job.status == "queued")
                             .values(status="running", started_at=utcnow())).rowcount
        db.commit()
        if not claimed:
            return
        job = db.get(Job, job_id)
        fn = HANDLERS.get(job.kind)
        if fn is None:
            raise JobError(f"No handler for job type {job.kind}")
        result = fn(db, job)
        job = db.get(Job, job_id)
        job.status, job.result, job.progress, job.finished_at = "done", result or {}, 1.0, utcnow()
        db.commit()
    except Exception as e:  # noqa: BLE001
        db.rollback()
        user_msg = str(e) if isinstance(e, JobError) or e.__class__.__name__ in (
            "IngestionError", "QueryError", "TransformError", "ConnectorError", "StorageError", "LimitExceeded", "DatasetError", "FormulaError") else \
            "Processing failed unexpectedly. The error was logged; please try again or contact support."
        log.error("job %s failed: %s\n%s", job_id, e, traceback.format_exc())
        job = db.get(Job, job_id)
        if job:
            job.status, job.error, job.finished_at = "failed", user_msg, utcnow()
            db.commit()
    finally:
        db.close()


def set_progress(db: Session, job: Job, progress: float) -> None:
    job.progress = max(0.0, min(1.0, progress))
    db.commit()


def recover_stale(db: Session, older_than_minutes: int = 30) -> int:
    """Re-queue jobs left 'running' by a crashed process."""
    cutoff = utcnow() - timedelta(minutes=older_than_minutes)
    n = db.execute(update(Job).where(Job.status == "running", Job.started_at < cutoff).values(status="queued")).rowcount
    db.commit()
    return n


def claim_next(db: Session) -> str | None:
    job = db.scalars(select(Job).where(Job.status == "queued").order_by(Job.created_at).limit(1)).first()
    return job.id if job else None


def worker_loop(poll_seconds: float = 2.0, stop: threading.Event | None = None) -> None:
    import misgenius.services.job_handlers  # noqa: F401 - registers handlers

    log.info("worker started")
    while not (stop and stop.is_set()):
        db = SessionLocal()
        try:
            job_id = claim_next(db)
        finally:
            db.close()
        if job_id:
            run_job(job_id)
        else:
            time.sleep(poll_seconds)
