"""Dashboard templates built on semantic slots instead of fixed column names.

`to_template` replaces every column reference in a dashboard with a slot that
describes *what kind* of column is needed (type group, role, semantic tags, name
hint). `apply_template` binds slots to the best-matching columns of another
dataset, so a template made from one file works on a different file with
different column names. Widgets whose slots cannot be bound are skipped and
reported — never filled with invented columns.
"""
from __future__ import annotations

import copy
import difflib
import re
from typing import Any

from misgenius.schema.semantics import name_tokens

COLUMN_KEYS = {"column", "histogram_column", "date_column"}
TYPE_GROUPS = {
    "integer": "numeric", "decimal": "numeric", "currency": "numeric", "percentage": "numeric",
    "date": "date", "datetime": "date", "categorical": "category", "boolean": "category",
    "text": "text", "identifier": "identifier", "empty": "empty",
}
_BRACKET = re.compile(r"\[([^\]]+)\]")


def _walk_columns(obj: Any, fn) -> Any:
    """Return a copy of obj with every column reference transformed by fn(name) -> name."""
    if isinstance(obj, dict):
        out = {}
        for k, v in obj.items():
            if k in COLUMN_KEYS and isinstance(v, str):
                out[k] = fn(v)
            elif k == "columns" and isinstance(v, list) and all(isinstance(x, str) for x in v):
                out[k] = [fn(x) for x in v]
            elif k == "formula" and isinstance(v, str):
                out[k] = _BRACKET.sub(lambda m: "[" + fn(m.group(1).strip()) + "]", v)
            else:
                out[k] = _walk_columns(v, fn)
        return out
    if isinstance(obj, list):
        return [_walk_columns(x, fn) for x in obj]
    return obj


def collect_columns(obj: Any) -> set[str]:
    found: set[str] = set()

    def grab(name: str) -> str:
        found.add(name)
        return name

    _walk_columns(obj, grab)
    return found


def to_template(dashboard: dict[str, Any], schema: dict[str, Any], name: str | None = None, description: str = "") -> dict[str, Any]:
    cols = {c["name"]: c for c in schema.get("columns", [])}
    used = sorted(collect_columns({"config": dashboard.get("config", {}), "widgets": dashboard.get("widgets", [])}))
    slots: dict[str, dict[str, Any]] = {}
    mapping: dict[str, str] = {}
    for i, cname in enumerate(used):
        c = cols.get(cname)
        if c is None:
            continue
        sid = f"slot{i + 1}"
        mapping[cname] = sid
        slots[sid] = {
            "id": sid,
            "label": c.get("label") or cname,
            "name_hint": cname,
            "type_group": TYPE_GROUPS.get(c["data_type"], "text"),
            "role": c["role"],
            "tags": [t for t in c.get("semantic_tags", []) if not t.startswith("time_part") and t not in ("pii", "high_cardinality")],
            "required": True,
        }
    ref = lambda n: "{{" + mapping[n] + "}}" if n in mapping else n  # noqa: E731
    widgets = []
    for w in dashboard.get("widgets", []):
        widgets.append({
            "widget_type": w["widget_type"], "title": _templ_title(w.get("title", ""), mapping),
            "config": _walk_columns(w.get("config", {}), ref), "layout": w.get("layout", {}), "hidden": w.get("hidden", False),
        })
    return {
        "format": "mis-genius-template/v1",
        "name": name or dashboard.get("name", "Template"),
        "description": description or dashboard.get("description", ""),
        "slots": list(slots.values()),
        "config": _walk_columns(dashboard.get("config", {}), ref),
        "widgets": widgets,
    }


def _templ_title(title: str, mapping: dict[str, str]) -> str:
    for cname in sorted(mapping, key=len, reverse=True):
        title = title.replace(cname, "{{" + mapping[cname] + "}}")
    return title


def _score(slot: dict[str, Any], col: dict[str, Any]) -> float:
    group = TYPE_GROUPS.get(col["data_type"], "text")
    if group != slot["type_group"]:
        # categorical text and high-cardinality text are interchangeable for grouping
        if not ({group, slot["type_group"]} <= {"category", "text", "identifier"}):
            return -1.0
        base = 0.3
    else:
        base = 1.0
    score = base
    if col["role"] == slot["role"]:
        score += 0.5
    tags = set(col.get("semantic_tags", []))
    st = set(slot.get("tags", []))
    if st:
        overlap = tags & st
        score += 1.5 * len(overlap) / len(st)
        if not overlap:
            score -= 1.2  # e.g. never bind a "profit" slot to a quantity column just because both are numbers
    a = " ".join(name_tokens(slot.get("name_hint", "")))
    b = " ".join(name_tokens(col["name"]))
    score += 1.2 * difflib.SequenceMatcher(None, a, b).ratio()
    return score


def bind_slots(template: dict[str, Any], schema: dict[str, Any], manual: dict[str, str] | None = None) -> dict[str, Any]:
    cols = [c for c in schema.get("columns", []) if c["data_type"] != "empty"]
    manual = manual or {}
    binding: dict[str, str] = {}
    taken: set[str] = set()
    for sid, cname in manual.items():
        if any(c["name"] == cname for c in cols):
            binding[sid] = cname
            taken.add(cname)
    cands = []
    for slot in template.get("slots", []):
        if slot["id"] in binding:
            continue
        for c in cols:
            s = _score(slot, c)
            if s > 0.9:
                cands.append((s, slot["id"], c["name"]))
    cands.sort(reverse=True)
    for s, sid, cname in cands:
        if sid in binding or cname in taken:
            continue
        binding[sid] = cname
        taken.add(cname)
    unbound = [s["id"] for s in template.get("slots", []) if s["id"] not in binding]
    return {"binding": binding, "unbound": unbound,
            "details": [{"slot": s["id"], "label": s["label"], "column": binding.get(s["id"])} for s in template.get("slots", [])]}


def apply_template(template: dict[str, Any], schema: dict[str, Any], manual: dict[str, str] | None = None) -> dict[str, Any]:
    b = bind_slots(template, schema, manual)
    binding = b["binding"]

    def resolve(text: str) -> str:
        return re.sub(r"\{\{(slot\d+)\}\}", lambda m: binding.get(m.group(1), m.group(0)), text)

    unresolved = re.compile(r"\{\{slot\d+\}\}")
    widgets = []
    skipped = []
    for w in template.get("widgets", []):
        cfg = _walk_columns(copy.deepcopy(w.get("config", {})), resolve)
        if unresolved.search(str(cfg)):
            skipped.append(w.get("title"))
            continue
        widgets.append({**w, "title": resolve(w.get("title", "")), "config": cfg})
    config = _walk_columns(copy.deepcopy(template.get("config", {})), resolve)
    if "filters" in config:
        config["filters"] = [f for f in config["filters"] if not (isinstance(f.get("column"), str) and unresolved.search(f["column"]))]
    for i, w in enumerate(widgets):
        w["position"] = i
    return {"name": template.get("name", "Dashboard"), "description": template.get("description", ""), "config": config,
            "widgets": widgets, "binding": b, "skipped_widgets": skipped}
