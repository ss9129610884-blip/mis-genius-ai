"""Automatic dashboard generation from a semantic schema.

UPLOAD → PROFILE → SCHEMA → pick measures / dimensions / time → KPIs → charts →
filters → layout. Works for any tabular dataset: sales, expenses, attendance,
inventory, certificates, medical, … If there are no numeric measures at all the
dashboard is built from counts and distinct counts instead.
"""
from __future__ import annotations

import re
import uuid
from typing import Any

from misgenius.analytics.charts import ChartSpec
from misgenius.analytics.kpi import KPIComparison, KPIFormat, KPIRatio, KPISpec
from misgenius.analytics.query import Dimension, Filter, Measure

GRID_COLS = 12
POSITIVE_STATUS = ["present", "completed", "complete", "approved", "paid", "delivered", "closed", "active", "pass",
                   "passed", "yes", "success", "done", "issued", "resolved", "p", "उपस्थित"]


def _wid() -> str:
    return uuid.uuid4().hex[:12]


def _cols(schema: dict[str, Any]) -> dict[str, dict[str, Any]]:
    return {c["name"]: c for c in schema.get("columns", [])}


def rank_measures(schema: dict[str, Any]) -> list[dict[str, Any]]:
    derived_targets = {r["to"] for r in schema.get("relationships", []) if r.get("type") == "derived"}
    out = []
    for c in schema.get("columns", []):
        if c["role"] != "measure":
            continue
        tags = set(c.get("semantic_tags", []))
        st = c.get("stats", {})
        score = 1.0
        score += 2.0 if c["data_type"] == "currency" else 0
        score += 1.5 if "revenue_like" in tags else 0
        score += 1.0 if "money" in tags else 0
        score += 0.8 if ("quantity" in tags or "stock" in tags) else 0
        score += 0.6 if "profit_like" in tags else 0
        score += 0.4 if "cost_like" in tags else 0
        score += 0.5 if c["name"] in derived_targets else 0
        score -= 0.6 if c["data_type"] == "percentage" else 0
        score -= 0.8 if ("money" in tags and any(k in c["name"].lower() for k in ("price", "rate", "mrp"))) else 0
        score -= 1.5 * (st.get("null_pct", 0) / 100)
        if st.get("distinct", 0) <= 1:
            score -= 3
        out.append({**c, "_score": score})
    out.sort(key=lambda c: -c["_score"])
    return out


def rank_dimensions(schema: dict[str, Any]) -> list[dict[str, Any]]:
    hier_children = {r["from"] for r in schema.get("relationships", []) if r.get("type") == "hierarchy"}
    out = []
    for c in schema.get("columns", []):
        if c["role"] != "dimension":
            continue
        tags = set(c.get("semantic_tags", []))
        d = c.get("stats", {}).get("distinct", 0)
        if d < 2:
            continue
        score = 1.0
        if 2 <= d <= 12:
            score += 1.5
        elif d <= 50:
            score += 1.0
        elif d <= 500:
            score += 0.3
        else:
            score -= 0.5
        score += 0.9 if "location" in tags else 0
        score += 0.8 if "product" in tags else 0
        score += 0.7 if "org_unit" in tags else 0
        score += 0.6 if "status" in tags else 0
        score += 0.4 if "person" in tags else 0
        score -= 0.4 if c["name"] in hier_children else 0  # prefer the parent level (State over City)
        score -= 1.0 * (c.get("stats", {}).get("null_pct", 0) / 100)
        out.append({**c, "_score": score, "_distinct": d})
    out.sort(key=lambda c: -c["_score"])
    return out


def _entity_from_id(name: str) -> str:
    base = re.sub(r"(?i)[\s_\-]*(id|code|no\.?|number|num|#)$", "", name).strip()
    if not base:
        return "Records"
    if base.lower() in ("emp", "employee", "staff"):
        return "Employees"
    return base + ("s" if not base.endswith("s") else "")


def _fmt_for(col: dict[str, Any], agg: str, default_currency: str = "INR") -> KPIFormat:
    f = col.get("format", {})
    if col["data_type"] == "percentage" or f.get("percent"):
        return KPIFormat(kind="percent", decimals=1)
    if col["data_type"] == "currency" and agg not in ("count", "count_distinct", "count_rows"):
        return KPIFormat(kind="currency", currency=f.get("currency") or default_currency, decimals=f.get("decimals"))
    return KPIFormat(kind="number", decimals=0 if col["data_type"] == "integer" and agg in ("sum", "count") else None)


def default_agg(col: dict[str, Any]) -> str:
    tags = set(col.get("semantic_tags", []))
    if col["data_type"] == "percentage" or "score" in tags or "percentage" in tags:
        return "avg"
    if any(k in col["name"].lower() for k in ("price", "rate", "mrp", "age", "rating")):
        return "avg"
    if "balance" in tags:
        return "sum"
    return "sum"


def _agg_title(agg: str, name: str) -> str:
    return {"sum": f"Total {name}", "avg": f"Average {name}", "median": f"Median {name}", "min": f"Minimum {name}",
            "max": f"Maximum {name}", "count_distinct": f"Distinct {name}", "count": f"{name} (count)"}.get(agg, name)


def build_kpis(schema: dict[str, Any], measures: list[dict[str, Any]], dims: list[dict[str, Any]]) -> list[KPISpec]:
    cols = _cols(schema)
    cur = _default_currency(schema)
    date_col = schema.get("primary_date_column")
    cmp = KPIComparison(date_column=date_col) if date_col else KPIComparison(enabled=False)
    kpis: list[KPISpec] = []

    # 1) entity / record count
    pk = next((r["column"] for r in schema.get("relationships", []) if r.get("type") == "primary_key"), None)
    id_cols = schema.get("identifier_columns", [])
    if pk:
        kpis.append(KPISpec(id=_wid(), title=f"Total {_entity_from_id(pk)}", measure=Measure(column=pk, agg="count_distinct"),
                            format=KPIFormat(kind="number", decimals=0), comparison=cmp,
                            description=f"Distinct values of '{pk}'."))
    elif id_cols:
        c = id_cols[0]
        kpis.append(KPISpec(id=_wid(), title=f"Distinct {_entity_from_id(c)}", measure=Measure(column=c, agg="count_distinct"),
                            format=KPIFormat(kind="number", decimals=0), comparison=cmp))
    else:
        kpis.append(KPISpec(id=_wid(), title="Total Records", measure=Measure(agg="count_rows"),
                            format=KPIFormat(kind="number", decimals=0), comparison=cmp, description="Number of rows in the data."))

    # 2) top measures
    for m in measures[:3]:
        agg = default_agg(m)
        kpis.append(KPISpec(id=_wid(), title=_agg_title(agg, m["name"]), measure=Measure(column=m["name"], agg=agg),
                            format=_fmt_for(m, agg, cur), comparison=cmp,
                            higher_is_better=not ("cost_like" in m.get("semantic_tags", []))))

    # 3) derived net / margin from revenue-like and cost/profit-like columns (only when both exist)
    rev = next((m for m in measures if "revenue_like" in m.get("semantic_tags", [])), None)
    profit = next((m for m in measures if "profit_like" in m.get("semantic_tags", [])), None)
    cost = next((m for m in measures if "cost_like" in m.get("semantic_tags", []) and m is not rev), None)
    if rev and profit:
        kpis.append(KPISpec(id=_wid(), title=f"Margin % ({profit['name']} ÷ {rev['name']})",
                            ratio=KPIRatio(numerator=Measure(column=profit["name"]), denominator=Measure(column=rev["name"])),
                            format=KPIFormat(kind="percent", decimals=1), comparison=cmp,
                            description=f"SUM({profit['name']}) ÷ SUM({rev['name']}) × 100"))
    elif rev and cost:
        kpis.append(KPISpec(id=_wid(), title=f"Net ({rev['name']} − {cost['name']})",
                            measure=Measure(formula=f"SUM([{rev['name']}]) - SUM([{cost['name']}])", alias="Net"),
                            format=_fmt_for(rev, "sum", cur), comparison=cmp,
                            description=f"SUM({rev['name']}) − SUM({cost['name']})"))
        kpis.append(KPISpec(id=_wid(), title="Net Margin %",
                            measure=Measure(formula=f"(SUM([{rev['name']}]) - SUM([{cost['name']}])) / SUM([{rev['name']}]) * 100", alias="Net Margin %"),
                            format=KPIFormat(kind="percent", decimals=1), comparison=cmp))

    # 4) status share (attendance %, completion %, approval %)
    status = next((d for d in dims if "status" in d.get("semantic_tags", []) and 2 <= d["_distinct"] <= 8), None)
    if status:
        tops = [t["value"] for t in status.get("stats", {}).get("top_values", [])]
        pos = next((v for v in tops if v.strip().lower() in POSITIVE_STATUS), tops[0] if tops else None)
        if pos is not None:
            kpis.append(KPISpec(id=_wid(), title=f"{pos} %", ratio=KPIRatio(
                numerator=Measure(agg="count_rows", filters=[Filter(column=status["name"], op="eq", value=pos)]),
                denominator=Measure(agg="count_rows")), format=KPIFormat(kind="percent", decimals=1), comparison=cmp,
                description=f"Share of rows where {status['name']} = {pos}"))

    # 5) distinct entities (customers, employees, products …)
    for d in dims:
        if len(kpis) >= 6:
            break
        tags = d.get("semantic_tags", [])
        if ("person" in tags or "identifier" in tags or "product" in tags) and d["_distinct"] >= 5:
            if any(k.measure and k.measure.column == d["name"] for k in kpis):
                continue
            title = _entity_from_id(d["name"]) if "identifier" in tags else f"Distinct {d['name']}"
            kpis.append(KPISpec(id=_wid(), title=title, measure=Measure(column=d["name"], agg="count_distinct"),
                                format=KPIFormat(kind="number", decimals=0), comparison=KPIComparison(enabled=False),
                                description=f"Number of different values in '{d['name']}'."))
            break

    # 6) datasets with no measures: add distinct counts of the main dimensions
    if not measures:
        for d in dims[:3]:
            if len(kpis) >= 5:
                break
            kpis.append(KPISpec(id=_wid(), title=f"Distinct {d['name']}", measure=Measure(column=d["name"], agg="count_distinct"),
                                format=KPIFormat(kind="number", decimals=0), comparison=KPIComparison(enabled=False)))
    for k in kpis:
        if k.comparison and k.comparison.enabled and not date_col:
            k.comparison.enabled = False
        _ = cols
    return kpis[:6]


def build_charts(schema: dict[str, Any], measures: list[dict[str, Any]], dims: list[dict[str, Any]]) -> list[dict[str, Any]]:
    date_col = schema.get("primary_date_column")
    charts: list[dict[str, Any]] = []
    m0 = measures[0] if measures else None
    pm = Measure(column=m0["name"], agg=default_agg(m0)) if m0 else Measure(agg="count_rows", alias="Records")
    pm_name = (_agg_title(pm.agg, m0["name"]) if m0 else "Records")

    def add(title: str, spec: ChartSpec, w: int = 6, h: int = 5, recommended: list[str] | None = None, wtype: str = "chart") -> None:
        charts.append({"widget_type": wtype, "title": title, "config": {"chart": spec.model_dump(exclude_none=True)}, "w": w, "h": h})

    if date_col:
        rev = next((m for m in measures if "revenue_like" in m.get("semantic_tags", [])), None)
        cost = next((m for m in measures if "cost_like" in m.get("semantic_tags", [])), None)
        if rev and cost and rev is not cost:
            add(f"{rev['name']} vs {cost['name']} over time",
                ChartSpec(type="combo", dimension=Dimension(column=date_col), measures=[Measure(column=rev["name"]), Measure(column=cost["name"])]), w=12)
        else:
            add(f"{pm_name} over time", ChartSpec(type="line", dimension=Dimension(column=date_col), measures=[pm]), w=12)
    small_dims = [d for d in dims if d["_distinct"] <= 12]
    big_dims = [d for d in dims if d["_distinct"] > 12]
    used: set[str] = set()
    if dims:
        d0 = dims[0]
        used.add(d0["name"])
        t = "bar" if d0["_distinct"] <= 15 else "hbar"
        add(f"{pm_name} by {d0['name']}", ChartSpec(type=t, dimension=Dimension(column=d0["name"]), measures=[pm], top_n=12), w=6)
    donut = next((d for d in small_dims if d["name"] not in used and d["_distinct"] <= 6), None)
    if donut:
        used.add(donut["name"])
        if "status" in donut.get("semantic_tags", []) or not m0:
            add(f"Records by {donut['name']}", ChartSpec(type="donut", dimension=Dimension(column=donut["name"]), measures=[Measure(agg="count_rows", alias="Records")]), w=6)
        else:
            add(f"Share of {pm_name} by {donut['name']}", ChartSpec(type="donut", dimension=Dimension(column=donut["name"]), measures=[pm]), w=6)
    ranked = next((d for d in big_dims if d["name"] not in used), None)
    if ranked:
        used.add(ranked["name"])
        add(f"Top 10 {ranked['name']} by {pm_name}", ChartSpec(type="hbar", dimension=Dimension(column=ranked["name"]), measures=[pm], top_n=10, other=False), w=6)
    if date_col:
        stack = next((d for d in small_dims if d["name"] not in used or d is dims[0]), None)
        if stack:
            add(f"{pm_name} by {stack['name']} over time",
                ChartSpec(type="stacked_bar", dimension=Dimension(column=date_col), series_dimension=Dimension(column=stack["name"]), measures=[pm]), w=6)
    two = [d for d in small_dims][:2]
    if len(two) == 2:
        add(f"{pm_name}: {two[0]['name']} × {two[1]['name']}",
            ChartSpec(type="heatmap", dimension=Dimension(column=two[0]["name"]), series_dimension=Dimension(column=two[1]["name"]), measures=[pm]), w=6)
    if m0:
        add(f"Distribution of {m0['name']}", ChartSpec(type="histogram", histogram_column=m0["name"], bins=20), w=6)
    corr = next((r for r in schema.get("relationships", []) if r.get("type") == "correlation"), None)
    if corr and not any(r.get("type") == "derived" and corr["from"] in r.get("from", []) + [r.get("to")] for r in schema.get("relationships", [])):
        add(f"{corr['from']} vs {corr['to']}", ChartSpec(type="scatter", x_measure=Measure(column=corr["from"]), y_measure=Measure(column=corr["to"])), w=6)
    if dims:
        tm = [Measure(column=m["name"], agg=default_agg(m)) for m in measures[:3]] or [Measure(agg="count_rows", alias="Records")]
        if m0 and not any(m.agg == "count_rows" for m in tm):
            tm.append(Measure(agg="count_rows", alias="Records"))
        add(f"{dims[0]['name']} summary", ChartSpec(type="table", dimension=Dimension(column=dims[0]["name"]), measures=tm, limit=50), w=6, h=6, wtype="table")
    if len(dims) >= 2:
        charts.append({"widget_type": "pivot", "title": f"{pm_name}: {dims[0]['name']} by {dims[1]['name']}",
                       "config": {"chart": ChartSpec(type="pivot", dimension=Dimension(column=dims[0]["name"]),
                                                     series_dimension=Dimension(column=dims[1]["name"]), measures=[pm]).model_dump(exclude_none=True)},
                       "w": 12, "h": 6})
    return charts


def build_filters(schema: dict[str, Any], measures: list[dict[str, Any]], dims: list[dict[str, Any]]) -> list[dict[str, Any]]:
    filters: list[dict[str, Any]] = []
    if schema.get("primary_date_column"):
        filters.append({"id": _wid(), "column": schema["primary_date_column"], "type": "date_range", "label": schema["primary_date_column"]})
    for d in dims[:4]:
        if d["_distinct"] <= 5000:
            filters.append({"id": _wid(), "column": d["name"], "type": "multi_select", "label": d["name"]})
    if measures:
        filters.append({"id": _wid(), "column": measures[0]["name"], "type": "numeric_range", "label": measures[0]["name"]})
    filters.append({"id": _wid(), "column": None, "type": "search", "label": "Search all columns"})
    return filters


def layout_widgets(widgets: list[dict[str, Any]]) -> list[dict[str, Any]]:
    x = y = 0
    row_h = 0
    out = []
    for i, w in enumerate(widgets):
        ww, hh = w.pop("w", 6), w.pop("h", 5)
        if x + ww > GRID_COLS:
            x, y, row_h = 0, y + row_h, 0
        w["layout"] = {"x": x, "y": y, "w": ww, "h": hh}
        w["position"] = i
        x += ww
        row_h = max(row_h, hh)
        out.append(w)
    return out


def generate_dashboard(schema: dict[str, Any], dataset_name: str) -> dict[str, Any]:
    measures = rank_measures(schema)
    dims = rank_dimensions(schema)
    kpis = build_kpis(schema, measures, dims)
    kpi_w = max(2, GRID_COLS // max(1, min(len(kpis), 6)))
    widgets: list[dict[str, Any]] = []
    for k in kpis:
        widgets.append({"widget_type": "kpi", "title": k.title, "config": {"kpi": k.model_dump(exclude_none=True)}, "w": kpi_w, "h": 4})
    widgets.append({"widget_type": "insights", "title": "AI Insights", "config": {"max_items": 6}, "w": 6, "h": 6})
    widgets.append({"widget_type": "quality", "title": "Data Quality", "config": {}, "w": 6, "h": 6})
    charts = build_charts(schema, measures, dims)
    first = charts[:1] if charts and charts[0]["w"] == 12 else []
    widgets = widgets[: len(kpis)] + first + widgets[len(kpis):] + charts[len(first):]
    domain = schema.get("domain", {}).get("guess", "general")
    return {
        "name": f"{dataset_name} — Overview",
        "description": f"Automatically generated from {schema.get('row_count', 0):,} rows and {schema.get('column_count', 0)} columns"
                       + (f" (looks like {domain.replace('_', ' ')} data)." if domain != "general" else "."),
        "config": {
            "filters": build_filters(schema, measures, dims),
            "metrics": [],
            "theme": {"palette": "default", "density": "comfortable"},
            "number_format": {"locale": "en-IN", "currency": _default_currency(schema), "compact": True},
            "date_format": "DD MMM YYYY",
            "refresh": {"auto": False, "minutes": None},
            "generator": {"version": 1, "domain": domain, "measures": [m["name"] for m in measures[:5]], "dimensions": [d["name"] for d in dims[:5]]},
        },
        "widgets": layout_widgets(widgets),
    }


def _default_currency(schema: dict[str, Any]) -> str:
    for c in schema.get("columns", []):
        cur = (c.get("format") or {}).get("currency")
        if cur:
            return cur
    return "INR"
