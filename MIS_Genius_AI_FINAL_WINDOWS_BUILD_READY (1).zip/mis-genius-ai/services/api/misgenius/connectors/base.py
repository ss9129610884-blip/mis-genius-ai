"""Data connectors.

Every connector returns a RawWorkbook (the same structure the file ingestion uses),
so dashboards, analytics and AI work identically for every source. Implemented:
file upload (xlsx/xls/csv/json), HTTP JSON/CSV URL, Google Sheets (link-shared
sheets through the official CSV export URL) and SQL databases via SQLAlchemy
(PostgreSQL, MySQL*, SQL Server*, SQLite — *driver package required).
Interfaces for ERP/CRM connectors can be added by registering a new Connector.
"""
from __future__ import annotations

import ipaddress
import re
import socket
from abc import ABC, abstractmethod
from typing import Any
from urllib.parse import urlparse

import httpx

from misgenius.config import get_settings
from misgenius.ingestion.readers import IngestionError, RawSheet, RawWorkbook, read_file

MAX_DOWNLOAD_MB = 100


class ConnectorError(Exception):
    pass


class Connector(ABC):
    type: str = "base"
    label: str = "Base"
    description: str = ""
    config_fields: list[dict[str, Any]] = []
    admin_only = False

    @abstractmethod
    def fetch(self, config: dict[str, Any]) -> tuple[str, RawWorkbook]:
        """Return (source_name, workbook)."""

    def test(self, config: dict[str, Any]) -> dict[str, Any]:
        name, wb = self.fetch(config)
        return {"ok": True, "source": name, "sheets": [{"name": s.name, "rows": len(s.grid)} for s in wb.sheets]}

    def describe(self) -> dict[str, Any]:
        return {"type": self.type, "label": self.label, "description": self.description, "fields": self.config_fields,
                "admin_only": self.admin_only}


def _guard_url(url: str) -> str:
    s = get_settings()
    p = urlparse(url)
    if p.scheme not in ("https", "http"):
        raise ConnectorError("Only http(s) URLs are allowed")
    if p.scheme == "http" and s.is_production:
        raise ConnectorError("Use an https URL")
    if not p.hostname:
        raise ConnectorError("Invalid URL")
    if not s.allow_private_network:
        try:
            infos = socket.getaddrinfo(p.hostname, p.port or (443 if p.scheme == "https" else 80))
        except socket.gaierror as e:
            raise ConnectorError(f"Cannot resolve host {p.hostname}") from e
        for info in infos:
            ip = ipaddress.ip_address(info[4][0])
            if ip.is_private or ip.is_loopback or ip.is_link_local or ip.is_reserved or ip.is_multicast:
                raise ConnectorError("URLs pointing to private or internal network addresses are not allowed")
    return url


def _download(url: str, headers: dict[str, str] | None = None) -> tuple[bytes, str]:
    _guard_url(url)
    limit = MAX_DOWNLOAD_MB * 1024 * 1024
    with httpx.Client(timeout=60, follow_redirects=False) as c:
        for _ in range(5):
            with c.stream("GET", url, headers=headers or {}) as r:
                if r.status_code in (301, 302, 303, 307, 308):
                    url = _guard_url(str(httpx.URL(url).join(r.headers.get("location", ""))))
                    continue
                if r.status_code >= 400:
                    raise ConnectorError(f"The server returned HTTP {r.status_code}")
                buf = bytearray()
                for chunk in r.iter_bytes():
                    buf.extend(chunk)
                    if len(buf) > limit:
                        raise ConnectorError(f"Download is larger than {MAX_DOWNLOAD_MB} MB")
                return bytes(buf), r.headers.get("content-type", "")
    raise ConnectorError("Too many redirects")


class HttpConnector(Connector):
    type = "http"
    label = "Web URL (JSON / CSV / Excel)"
    description = "Fetch a JSON API, CSV or Excel file from a URL. JSON must contain a list of records."
    config_fields = [{"name": "url", "label": "URL", "type": "url", "required": True},
                     {"name": "headers", "label": "Headers (JSON, optional)", "type": "json", "required": False}]

    def fetch(self, config: dict[str, Any]) -> tuple[str, RawWorkbook]:
        url = str(config.get("url") or "").strip()
        headers = config.get("headers") or {}
        if not isinstance(headers, dict):
            raise ConnectorError("headers must be an object")
        data, ctype = _download(url, {str(k): str(v) for k, v in headers.items()})
        name = urlparse(url).path.rsplit("/", 1)[-1] or "data"
        if "json" in ctype or name.lower().endswith(".json") or data[:1] in (b"{", b"["):
            name = name if name.lower().endswith(".json") else name + ".json"
        elif "csv" in ctype and not name.lower().endswith(".csv"):
            name += ".csv"
        elif not re.search(r"\.(xlsx|xls|csv|json|tsv|txt)$", name.lower()):
            name += ".csv"
        s = get_settings()
        try:
            return name, read_file(name, data, max_rows=s.MAX_ROWS, max_cols=s.MAX_COLUMNS, max_uncompressed_mb=s.MAX_XLSX_UNCOMPRESSED_MB)
        except IngestionError as e:
            raise ConnectorError(str(e)) from e


class GoogleSheetsConnector(Connector):
    type = "google_sheets"
    label = "Google Sheets (shared link)"
    description = "Paste the link of a Google Sheet shared as 'Anyone with the link can view'. Uses Google's CSV export."
    config_fields = [{"name": "url", "label": "Sheet link", "type": "url", "required": True}]

    def fetch(self, config: dict[str, Any]) -> tuple[str, RawWorkbook]:
        url = str(config.get("url") or "")
        m = re.search(r"docs\.google\.com/spreadsheets/d/([A-Za-z0-9_\-]+)", url)
        if not m:
            raise ConnectorError("This is not a Google Sheets link")
        gid = re.search(r"[#&?]gid=(\d+)", url)
        export = f"https://docs.google.com/spreadsheets/d/{m.group(1)}/export?format=csv" + (f"&gid={gid.group(1)}" if gid else "")
        data, ctype = _download(export)
        if b"<html" in data[:500].lower():
            raise ConnectorError("Google returned a sign-in page. Share the sheet as 'Anyone with the link can view'.")
        s = get_settings()
        return "Google Sheet.csv", read_file("sheet.csv", data, max_rows=s.MAX_ROWS, max_cols=s.MAX_COLUMNS, max_uncompressed_mb=s.MAX_XLSX_UNCOMPRESSED_MB)


_SELECT_ONLY = re.compile(r"^\s*(select|with)\b", re.I)
_FORBIDDEN = re.compile(r"\b(insert|update|delete|drop|alter|create|truncate|grant|revoke|merge|exec|execute|call|copy|attach|pragma)\b", re.I)


class SQLConnector(Connector):
    type = "sql"
    label = "SQL database"
    description = "Run a read-only SELECT on PostgreSQL, MySQL, SQL Server or SQLite (SQLAlchemy URL)."
    admin_only = True
    config_fields = [
        {"name": "url", "label": "Connection URL", "type": "secret", "required": True,
         "placeholder": "postgresql+psycopg://user:pass@host:5432/db"},
        {"name": "query", "label": "SELECT query", "type": "textarea", "required": True},
    ]

    def fetch(self, config: dict[str, Any]) -> tuple[str, RawWorkbook]:
        from sqlalchemy import create_engine, text

        url = str(config.get("url") or "")
        query = str(config.get("query") or "").strip().rstrip(";")
        if not _SELECT_ONLY.match(query) or ";" in query or _FORBIDDEN.search(re.sub(r"'[^']*'", "''", query)):
            raise ConnectorError("Only a single read-only SELECT query is allowed")
        s = get_settings()
        if s.is_production and not s.allow_private_network and url.startswith("sqlite"):
            raise ConnectorError("SQLite files are not allowed in production")
        try:
            eng = create_engine(url, pool_pre_ping=True)
        except Exception as e:  # noqa: BLE001
            raise ConnectorError(f"Invalid connection URL or missing driver: {type(e).__name__}") from e
        try:
            with eng.connect() as conn:
                try:
                    if eng.dialect.name == "postgresql":
                        conn.execute(text("SET TRANSACTION READ ONLY"))
                except Exception:  # noqa: BLE001
                    pass
                res = conn.execution_options(stream_results=True).execute(text(query))
                cols = list(res.keys())
                grid: list[list[Any]] = [cols]
                for i, row in enumerate(res):
                    if i >= s.MAX_ROWS:
                        break
                    grid.append(list(row))
        except ConnectorError:
            raise
        except Exception as e:  # noqa: BLE001
            raise ConnectorError(f"Query failed: {str(e).splitlines()[0][:200]}") from e
        finally:
            eng.dispose()
        return "SQL query", RawWorkbook("sql", [RawSheet(name="Query", grid=grid)])


REGISTRY: dict[str, Connector] = {c.type: c for c in (HttpConnector(), GoogleSheetsConnector(), SQLConnector())}


def get_connector(kind: str) -> Connector:
    c = REGISTRY.get(kind)
    if c is None:
        raise ConnectorError(f"Unknown connector: {kind}")
    return c


PLANNED_CONNECTORS = [
    {"type": "erp", "label": "ERP systems (Tally, SAP, Oracle)", "status": "planned"},
    {"type": "crm", "label": "CRM systems (Salesforce, Zoho, HubSpot)", "status": "planned"},
    {"type": "google_sheets_oauth", "label": "Private Google Sheets (OAuth)", "status": "planned"},
]
