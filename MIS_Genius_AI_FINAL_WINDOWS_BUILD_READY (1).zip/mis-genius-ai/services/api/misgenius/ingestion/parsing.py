"""Robust value parsers for messy real-world spreadsheets.

Handles Indian number formats (1,00,000), currency symbols (₹, Rs., INR, $, €, £),
accounting negatives "(500)", trailing minus "500-", percentages, text-formatted
numbers, lakh/crore/K/M/B suffixes, and many date formats including Excel serials.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass
from datetime import date, datetime, time, timedelta
from typing import Any

NULL_TOKENS = {
    "", "-", "--", "—", "–", "na", "n/a", "n.a.", "nan", "null", "none", "nil", "#n/a", "#na",
    "#value!", "#ref!", "#div/0!", "#name?", "#null!", "#num!", "?", "not available", "missing",
}

CURRENCY_TOKENS = [
    ("₹", "INR"), ("rs.", "INR"), ("rs", "INR"), ("inr", "INR"), ("us$", "USD"), ("usd", "USD"), ("$", "USD"),
    ("€", "EUR"), ("eur", "EUR"), ("£", "GBP"), ("gbp", "GBP"), ("¥", "JPY"), ("aed", "AED"), ("sar", "SAR"),
]

_SCALE_WORDS = {
    "k": 1e3, "thousand": 1e3, "m": 1e6, "mn": 1e6, "million": 1e6, "b": 1e9, "bn": 1e9, "billion": 1e9,
    "lakh": 1e5, "lakhs": 1e5, "lac": 1e5, "lacs": 1e5, "crore": 1e7, "crores": 1e7, "cr": 1e7,
}

_NUM_CORE = re.compile(r"^[+-]?(\d+(\.\d*)?|\.\d+)([eE][+-]?\d+)?$")
_EURO = re.compile(r"^[+-]?\d{1,3}(\.\d{3})+(,\d+)?$")
_SCALE_RE = re.compile(r"^(.*?\d)\s*(k|thousand|mn|m|million|bn|b|billion|lakhs?|lacs?|crores?|cr)$", re.I)


def is_null_like(v: Any) -> bool:
    if v is None:
        return True
    if isinstance(v, float) and math.isnan(v):
        return True
    if isinstance(v, str):
        return v.strip().lower() in NULL_TOKENS
    return False


@dataclass(slots=True)
class ParsedNumber:
    value: float
    currency: str | None = None
    percent: bool = False
    was_text: bool = False


def parse_number(v: Any, drcr: bool = False) -> ParsedNumber | None:
    """Parse a single cell into a number, or None if it is not numeric.

    drcr=True means the column uses Tally-style "Dr"/"Cr" suffixes, so "Cr" is a
    credit marker instead of the "crore" multiplier.
    """
    if v is None or isinstance(v, bool):
        return None
    if isinstance(v, (int, float)):
        if isinstance(v, float) and (math.isnan(v) or math.isinf(v)):
            return None
        return ParsedNumber(float(v))
    if isinstance(v, (datetime, date, time, timedelta)):
        return None
    s = str(v).strip()
    if not s:
        return None
    s = s.replace(" ", " ").replace(" ", " ").replace(" ", " ")
    low = s.lower()
    currency = None
    for tok, code in CURRENCY_TOKENS:
        if low.startswith(tok) or low.endswith(tok) or low.startswith("-" + tok) or low.startswith("(" + tok):
            if tok.isalpha():
                # word tokens must be separated from digits sensibly (avoid "rsvp")
                if not re.search(rf"(^|[\s(\-]){re.escape(tok)}\.?\s*[\d(\-+.]|\d\s*{re.escape(tok)}$", low):
                    continue
            currency = code
            low = low.replace(tok, " ")
            break
    negative = False
    t = low.strip()
    if t.startswith("(") and t.endswith(")"):
        negative, t = True, t[1:-1].strip()
    if t.endswith("-") and len(t) > 1 and t[:-1].strip().replace(",", "").replace(".", "").isdigit():
        negative, t = True, t[:-1].strip()
    if re.search(r"\s?dr\.?$", t) and re.search(r"\d\s?dr\.?$", t):
        negative, t = True, re.sub(r"\s?dr\.?$", "", t).strip()  # accounting debit notation
    elif drcr and re.search(r"\d\s?cr\.?$", t):
        t = re.sub(r"\s?cr\.?$", "", t).strip()
    percent = False
    if t.endswith("%"):
        percent, t = True, t[:-1].strip()
    t = t.strip().lstrip("=").strip()
    if t.startswith(("-", "−")):
        negative = not negative
        t = t[1:].strip()
    elif t.startswith("+"):
        t = t[1:].strip()
    # currency symbol may sit after the sign: "-₹500" handled above; "₹ -500"
    if t.startswith(("-", "−")):
        negative = not negative
        t = t[1:].strip()
    scale = 1.0
    m = _SCALE_RE.match(t)
    if m:
        scale = _SCALE_WORDS[m.group(2).lower()]
        t = m.group(1).strip()
    t = t.replace(" ", "")
    if _EURO.match(t) and "," in t:
        t = t.replace(".", "").replace(",", ".")
    elif "," in t:
        # Indian/Western thousands separators: 1,00,000.50  or 1,000,000.50
        if re.match(r"^\d{1,2}(,\d{2})*,\d{3}(\.\d+)?$", t) or re.match(r"^\d{1,3}(,\d{3})+(\.\d+)?$", t):
            t = t.replace(",", "")
        elif re.match(r"^\d+,\d{1,2}$", t):  # European decimal comma: 12,34
            t = t.replace(",", ".")
        else:
            return None
    if not _NUM_CORE.match(t):
        return None
    try:
        val = float(t) * scale
    except ValueError:
        return None
    if math.isinf(val) or math.isnan(val):
        return None
    return ParsedNumber(-val if negative else val, currency=currency, percent=percent, was_text=True)


# --------------------------------------------------------------------------- dates
_MONTHS = {
    "jan": 1, "january": 1, "feb": 2, "february": 2, "mar": 3, "march": 3, "apr": 4, "april": 4,
    "may": 5, "jun": 6, "june": 6, "jul": 7, "july": 7, "aug": 8, "august": 8, "sep": 9, "sept": 9,
    "september": 9, "oct": 10, "october": 10, "nov": 11, "november": 11, "dec": 12, "december": 12,
}
_MON = r"(jan(?:uary)?|feb(?:ruary)?|mar(?:ch)?|apr(?:il)?|may|june?|july?|aug(?:ust)?|sep(?:t(?:ember)?)?|oct(?:ober)?|nov(?:ember)?|dec(?:ember)?)"
_TIME = r"(?:[ T](\d{1,2}):(\d{2})(?::(\d{2})(?:\.\d+)?)?\s*(am|pm)?(?:Z|[+-]\d{2}:?\d{2})?)?"

DATE_PATTERNS: list[tuple[str, re.Pattern[str]]] = [
    ("ymd", re.compile(r"^(\d{4})[-/.](\d{1,2})[-/.](\d{1,2})" + _TIME + r"$", re.I)),
    ("dmy_or_mdy", re.compile(r"^(\d{1,2})[-/.](\d{1,2})[-/.](\d{2}|\d{4})" + _TIME + r"$", re.I)),
    ("d_mon_y", re.compile(r"^(\d{1,2})(?:st|nd|rd|th)?[\s\-/.,]*" + _MON + r"[\s\-/.,]*(\d{2}|\d{4})" + _TIME + r"$", re.I)),
    ("mon_d_y", re.compile(r"^" + _MON + r"[\s\-/.]*(\d{1,2})(?:st|nd|rd|th)?,?[\s\-/.]*(\d{4})" + _TIME + r"$", re.I)),
    ("mon_y", re.compile(r"^" + _MON + r"[\s\-/.',]*(\d{2}|\d{4})$", re.I)),
    ("y_mon", re.compile(r"^(\d{4})[\s\-/.]*" + _MON + r"$", re.I)),
    ("ym", re.compile(r"^(\d{4})[-/](\d{1,2})$")),
    ("compact", re.compile(r"^(\d{4})(\d{2})(\d{2})$")),
]


def _year(y: str) -> int:
    yi = int(y)
    if len(y) == 2:
        yi += 2000 if yi < 70 else 1900
    return yi


def _apply_time(d: datetime, groups: tuple[str | None, ...]) -> datetime:
    hh, mm, ss, ampm = groups
    if hh is None:
        return d
    h = int(hh)
    if ampm:
        if ampm.lower() == "pm" and h < 12:
            h += 12
        if ampm.lower() == "am" and h == 12:
            h = 0
    return d.replace(hour=h, minute=int(mm or 0), second=int(ss or 0))


def excel_serial_to_datetime(v: float) -> datetime | None:
    if not (1 <= v < 2958466):
        return None
    base = datetime(1899, 12, 30)
    try:
        return base + timedelta(days=float(v))
    except OverflowError:
        return None


def parse_date(v: Any, dayfirst: bool | None = True) -> tuple[datetime | None, str | None]:
    """Return (datetime, format_key). `dayfirst=None` means 'unknown' → prefer day-first."""
    if v is None:
        return None, None
    if isinstance(v, datetime):
        return v.replace(tzinfo=None), "native"
    if isinstance(v, date):
        return datetime(v.year, v.month, v.day), "native"
    if isinstance(v, (int, float)) or isinstance(v, bool):
        return None, None
    s = str(v).strip()
    if not s or len(s) > 40:
        return None, None
    for key, pat in DATE_PATTERNS:
        m = pat.match(s)
        if not m:
            continue
        g = m.groups()
        try:
            if key == "ymd":
                d = datetime(int(g[0]), int(g[1]), int(g[2]))
                return _apply_time(d, g[3:7]), "ymd"
            if key == "dmy_or_mdy":
                a, b, y = int(g[0]), int(g[1]), _year(g[2])
                if a > 12 and b <= 12:
                    d = datetime(y, b, a)
                elif b > 12 and a <= 12:
                    d = datetime(y, a, b)
                elif dayfirst is False:
                    d = datetime(y, a, b)
                else:
                    d = datetime(y, b, a)
                return _apply_time(d, g[3:7]), "dmy_or_mdy"
            if key == "d_mon_y":
                d = datetime(_year(g[2]), _MONTHS[g[1].lower()[:3] if g[1].lower()[:4] != "sept" else "sep"], int(g[0]))
                return _apply_time(d, g[3:7]), "d_mon_y"
            if key == "mon_d_y":
                d = datetime(int(g[2]), _MONTHS[g[0].lower()[:3]], int(g[1]))
                return _apply_time(d, g[3:7]), "mon_d_y"
            if key == "mon_y":
                return datetime(_year(g[1]), _MONTHS[g[0].lower()[:3]], 1), "mon_y"
            if key == "y_mon":
                return datetime(int(g[0]), _MONTHS[g[1].lower()[:3]], 1), "y_mon"
            if key == "ym":
                return datetime(int(g[0]), int(g[1]), 1), "ym"
            if key == "compact":
                y = int(g[0])
                if 1900 <= y <= 2200:
                    return datetime(y, int(g[1]), int(g[2])), "compact"
        except (ValueError, KeyError):
            return None, None
    return None, None


def detect_dayfirst(values: list[Any]) -> tuple[bool | None, bool]:
    """Scan ambiguous numeric dates (a/b/y). Returns (dayfirst, ambiguous).

    dayfirst is True/False when evidence exists, None when every value is ambiguous.
    """
    pat = DATE_PATTERNS[1][1]
    day_first_evidence = month_first_evidence = 0
    for v in values:
        if not isinstance(v, str):
            continue
        m = pat.match(v.strip())
        if not m:
            continue
        a, b = int(m.group(1)), int(m.group(2))
        if a > 12 >= b:
            day_first_evidence += 1
        elif b > 12 >= a:
            month_first_evidence += 1
    if day_first_evidence and not month_first_evidence:
        return True, False
    if month_first_evidence and not day_first_evidence:
        return False, False
    if day_first_evidence and month_first_evidence:
        return (day_first_evidence >= month_first_evidence), True  # inconsistent file
    return None, True


_BOOL_TRUE = {"true", "yes", "y", "t", "1"}
_BOOL_FALSE = {"false", "no", "n", "f", "0"}


def parse_bool(v: Any) -> bool | None:
    if isinstance(v, bool):
        return v
    if isinstance(v, str):
        s = v.strip().lower()
        if s in _BOOL_TRUE:
            return True
        if s in _BOOL_FALSE:
            return False
    return None


def to_text(v: Any) -> str | None:
    """Canonical string representation used for raw storage."""
    if is_null_like(v):
        return None
    if isinstance(v, datetime):
        return v.isoformat(sep=" ") if (v.hour or v.minute or v.second) else v.date().isoformat()
    if isinstance(v, date):
        return v.isoformat()
    if isinstance(v, time):
        return v.isoformat()
    if isinstance(v, bool):
        return "TRUE" if v else "FALSE"
    if isinstance(v, float):
        if v.is_integer() and abs(v) < 1e15:
            return str(int(v))
        return repr(v)
    return str(v).strip()
