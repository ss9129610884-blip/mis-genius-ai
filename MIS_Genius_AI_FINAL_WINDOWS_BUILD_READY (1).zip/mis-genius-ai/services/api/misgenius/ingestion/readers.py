"""Safe readers that turn untrusted XLSX / XLS / CSV / JSON bytes into raw grids.

A grid is a list of rows; each row is a list of Python values (str, float, int,
datetime, bool, None). Number-format hints from Excel (percent / currency) are
captured for the first rows so the profiler can use them.
"""
from __future__ import annotations

import csv
import io
import json
import zipfile
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any


class IngestionError(Exception):
    """User-facing ingestion failure (message is safe to show)."""


@dataclass
class RawSheet:
    name: str
    grid: list[list[Any]]
    format_hints: dict[tuple[int, int], str] = field(default_factory=dict)  # (row, col) -> number_format
    truncated: bool = False
    hidden: bool = False


@dataclass
class RawWorkbook:
    file_format: str
    sheets: list[RawSheet]
    warnings: list[str] = field(default_factory=list)


XLSX_MAGIC = b"PK\x03\x04"
XLS_MAGIC = b"\xd0\xcf\x11\xe0\xa1\xb1\x1a\xe1"
FORMAT_HINT_ROWS = 300


def detect_format(filename: str, data: bytes) -> str:
    name = filename.lower()
    head = data[:8]
    if head.startswith(XLSX_MAGIC):
        if name.endswith((".xlsx", ".xlsm")) or not name.endswith((".csv", ".txt", ".tsv")):
            return "xlsx"
    if head.startswith(XLS_MAGIC):
        return "xls"
    if name.endswith((".csv", ".txt", ".tsv")):
        if b"\x00" in data[:4096] and not data[:2] in (b"\xff\xfe", b"\xfe\xff"):
            raise IngestionError("This file looks binary, not a text CSV.")
        return "csv"
    if name.endswith(".json"):
        return "json"
    if name.endswith((".xlsx", ".xlsm")):
        raise IngestionError("The file has an .xlsx extension but is not a valid Excel workbook (it may be corrupted).")
    if name.endswith(".xls"):
        # Some systems export HTML or CSV with an .xls extension
        sniff = data[:2048].lower()
        if b"<html" in sniff or b"<table" in sniff:
            raise IngestionError("This .xls file is actually an HTML page. Open it in Excel and 'Save As' .xlsx or .csv.")
        return "csv"
    raise IngestionError("Unsupported file type. Please upload .xlsx, .xls or .csv.")


def read_file(filename: str, data: bytes, *, max_rows: int, max_cols: int, max_uncompressed_mb: int) -> RawWorkbook:
    if not data:
        raise IngestionError("The uploaded file is empty.")
    fmt = detect_format(filename, data)
    if fmt == "xlsx":
        return _read_xlsx(data, max_rows, max_cols, max_uncompressed_mb)
    if fmt == "xls":
        return _read_xls(data, max_rows, max_cols)
    if fmt == "json":
        return _read_json(data, max_rows, max_cols)
    return _read_csv(filename, data, max_rows, max_cols)


# --------------------------------------------------------------------------- XLSX
def _check_zip(data: bytes, max_uncompressed_mb: int) -> None:
    try:
        zf = zipfile.ZipFile(io.BytesIO(data))
    except zipfile.BadZipFile as e:
        raise IngestionError("The Excel file is corrupted or not a real .xlsx file.") from e
    total = 0
    for info in zf.infolist():
        if info.flag_bits & 0x1:
            raise IngestionError("Password-protected Excel files are not supported. Remove the password and re-upload.")
        total += info.file_size
        if info.compress_size and info.file_size / max(info.compress_size, 1) > 1000 and info.file_size > 50_000_000:
            raise IngestionError("The Excel file has a suspicious compression ratio and was rejected for safety.")
    if total > max_uncompressed_mb * 1024 * 1024:
        raise IngestionError(f"The Excel file is too large when uncompressed (limit {max_uncompressed_mb} MB).")
    names = set(zf.namelist())
    if "xl/workbook.xml" not in names:
        if "EncryptedPackage" in names:
            raise IngestionError("Password-protected Excel files are not supported.")
        raise IngestionError("The file is a ZIP archive but not an Excel workbook.")


def _read_xlsx(data: bytes, max_rows: int, max_cols: int, max_uncompressed_mb: int) -> RawWorkbook:
    _check_zip(data, max_uncompressed_mb)
    import openpyxl  # defusedxml is installed, which openpyxl uses automatically

    try:
        wb = openpyxl.load_workbook(io.BytesIO(data), read_only=True, data_only=True)
    except Exception as e:  # noqa: BLE001 - openpyxl raises many types
        raise IngestionError(f"Could not open the Excel workbook: {type(e).__name__}. The file may be corrupted.") from e
    sheets: list[RawSheet] = []
    warnings: list[str] = []
    formula_without_cache = False
    try:
        for ws in wb.worksheets:
            hints: dict[tuple[int, int], str] = {}
            grid: list[list[Any]] = []
            truncated = False
            if hasattr(ws, "reset_dimensions"):
                ws.reset_dimensions()  # some exporters write a wrong <dimension>; read everything
            for r_idx, row in enumerate(ws.iter_rows()):
                if r_idx >= max_rows + 50:
                    truncated = True
                    break
                vals: list[Any] = []
                for c_idx, cell in enumerate(row):
                    if c_idx >= max_cols:
                        break
                    v = getattr(cell, "value", None)
                    if r_idx < FORMAT_HINT_ROWS and v is not None:
                        nf = getattr(cell, "number_format", None)
                        if nf and nf != "General":
                            hints[(r_idx, c_idx)] = nf
                    if isinstance(v, str) and v.startswith("="):
                        formula_without_cache = True
                    vals.append(v)
                grid.append(vals)
            state = getattr(ws, "sheet_state", "visible")
            sheets.append(RawSheet(name=ws.title, grid=grid, format_hints=hints, truncated=truncated, hidden=state != "visible"))
            if truncated:
                warnings.append(f"Sheet '{ws.title}' has more than {max_rows:,} rows; only the first {max_rows:,} were read.")
    finally:
        wb.close()
    if formula_without_cache:
        warnings.append("Some cells contain formulas without saved results. Open the file in Excel, save it, and re-upload for exact values.")
    if not sheets:
        raise IngestionError("The workbook does not contain any worksheets.")
    return RawWorkbook("xlsx", sheets, warnings)


# --------------------------------------------------------------------------- XLS
def _read_xls(data: bytes, max_rows: int, max_cols: int) -> RawWorkbook:
    import xlrd

    try:
        book = xlrd.open_workbook(file_contents=data, on_demand=True)
    except Exception as e:  # noqa: BLE001
        raise IngestionError(f"Could not open the .xls workbook ({type(e).__name__}). It may be corrupted or encrypted.") from e
    sheets: list[RawSheet] = []
    warnings: list[str] = []
    try:
        for idx in range(book.nsheets):
            sh = book.sheet_by_index(idx)
            grid: list[list[Any]] = []
            nrows = min(sh.nrows, max_rows + 50)
            ncols = min(sh.ncols, max_cols)
            for r in range(nrows):
                row: list[Any] = []
                for c in range(ncols):
                    cell = sh.cell(r, c)
                    if cell.ctype == xlrd.XL_CELL_DATE:
                        try:
                            row.append(xlrd.xldate.xldate_as_datetime(cell.value, book.datemode))
                        except Exception:  # noqa: BLE001
                            row.append(cell.value)
                    elif cell.ctype in (xlrd.XL_CELL_EMPTY, xlrd.XL_CELL_BLANK):
                        row.append(None)
                    elif cell.ctype == xlrd.XL_CELL_BOOLEAN:
                        row.append(bool(cell.value))
                    elif cell.ctype == xlrd.XL_CELL_ERROR:
                        row.append(None)
                    else:
                        row.append(cell.value)
                grid.append(row)
            truncated = sh.nrows > nrows
            if truncated:
                warnings.append(f"Sheet '{sh.name}' has more than {max_rows:,} rows; only the first {max_rows:,} were read.")
            sheets.append(RawSheet(name=sh.name, grid=grid, truncated=truncated, hidden=bool(getattr(sh, "visibility", 0))))
            book.unload_sheet(idx)
    finally:
        book.release_resources()
    if not sheets:
        raise IngestionError("The workbook does not contain any worksheets.")
    return RawWorkbook("xls", sheets, warnings)


# --------------------------------------------------------------------------- CSV
def decode_text(data: bytes) -> str:
    if data[:2] in (b"\xff\xfe", b"\xfe\xff"):
        return data.decode("utf-16")
    for enc in ("utf-8-sig", "cp1252", "latin-1"):
        try:
            return data.decode(enc)
        except UnicodeDecodeError:
            continue
    return data.decode("utf-8", errors="replace")


def _read_csv(filename: str, data: bytes, max_rows: int, max_cols: int) -> RawWorkbook:
    text = decode_text(data)
    if not text.strip():
        raise IngestionError("The CSV file is empty.")
    sample = text[:65536]
    delimiter = "\t" if filename.lower().endswith(".tsv") else None
    if delimiter is None:
        try:
            delimiter = csv.Sniffer().sniff(sample, delimiters=",;\t|").delimiter
        except csv.Error:
            counts = {d: sample.count(d) for d in (",", ";", "\t", "|")}
            delimiter = max(counts, key=counts.get) if max(counts.values()) else ","
    csv.field_size_limit(10_000_000)
    reader = csv.reader(io.StringIO(text, newline=""), delimiter=delimiter)
    grid: list[list[Any]] = []
    truncated = False
    try:
        for i, row in enumerate(reader):
            if i >= max_rows + 50:
                truncated = True
                break
            grid.append([c if c.strip() != "" else None for c in row[:max_cols]])
    except csv.Error as e:
        raise IngestionError(f"The CSV file could not be parsed: {e}") from e
    warnings = [f"Only the first {max_rows:,} rows were read."] if truncated else []
    name = filename.rsplit("/", 1)[-1].rsplit(".", 1)[0] or "CSV"
    return RawWorkbook("csv", [RawSheet(name=name[:100], grid=grid, truncated=truncated)], warnings)


# --------------------------------------------------------------------------- JSON
def records_to_grid(records: list[dict[str, Any]], max_cols: int) -> list[list[Any]]:
    import pandas as pd

    df = pd.json_normalize(records, max_level=2)
    cols = list(df.columns)[:max_cols]
    grid: list[list[Any]] = [cols]
    for row in df[cols].itertuples(index=False):
        out = []
        for v in row:
            if isinstance(v, (list, dict)):
                v = json.dumps(v, ensure_ascii=False)
            elif v is not None and not isinstance(v, (str, int, float, bool, datetime)):
                v = str(v)
            try:
                if v is not None and not isinstance(v, str) and pd.isna(v):
                    v = None
            except (TypeError, ValueError):
                pass
            out.append(v)
        grid.append(out)
    return grid


def _read_json(data: bytes, max_rows: int, max_cols: int) -> RawWorkbook:
    try:
        obj = json.loads(decode_text(data))
    except json.JSONDecodeError as e:
        raise IngestionError(f"Invalid JSON: {e.msg}") from e
    records = extract_records(obj)
    if not records:
        raise IngestionError("The JSON does not contain a list of records.")
    return RawWorkbook("json", [RawSheet(name="JSON", grid=records_to_grid(records[:max_rows], max_cols))])


def extract_records(obj: Any) -> list[dict[str, Any]]:
    """Find the first list of objects in a JSON document (common API shapes)."""
    if isinstance(obj, list):
        if obj and all(isinstance(x, dict) for x in obj[:50]):
            return obj
        return []
    if isinstance(obj, dict):
        for key in ("data", "results", "items", "records", "rows", "value", "values"):
            if key in obj:
                r = extract_records(obj[key])
                if r:
                    return r
        for v in obj.values():
            r = extract_records(v)
            if r:
                return r
    return []
