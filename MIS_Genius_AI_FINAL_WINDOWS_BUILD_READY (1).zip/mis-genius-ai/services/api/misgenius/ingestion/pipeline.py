"""Ingestion pipeline: UPLOAD → INSPECT → DETECT TABLES → RAW FRAME → PROFILE."""
from __future__ import annotations

from dataclasses import dataclass, field
from typing import Any

import pandas as pd

from misgenius.ingestion.readers import IngestionError, RawWorkbook, read_file
from misgenius.ingestion.tables import DetectedTable, detect_tables, table_preview
from misgenius.schema.profiler import ProfileResult, profile_dataframe, raw_frame


@dataclass
class InspectResult:
    file_format: str
    tables: list[DetectedTable]
    sheet_summaries: list[dict[str, Any]]
    warnings: list[str] = field(default_factory=list)


def inspect_bytes(filename: str, data: bytes, *, max_rows: int, max_cols: int, max_uncompressed_mb: int) -> InspectResult:
    wb: RawWorkbook = read_file(filename, data, max_rows=max_rows, max_cols=max_cols, max_uncompressed_mb=max_uncompressed_mb)
    return inspect_workbook(wb)


def inspect_workbook(wb: RawWorkbook) -> InspectResult:
    tables: list[DetectedTable] = []
    summaries: list[dict[str, Any]] = []
    for sheet in wb.sheets:
        try:
            found = detect_tables(sheet)
        except Exception as e:  # noqa: BLE001 - one bad sheet must not break the upload
            summaries.append({"sheet": sheet.name, "status": "error", "tables": 0,
                              "message": f"Unable to read a data table in sheet '{sheet.name}' ({type(e).__name__})."})
            continue
        usable = [t for t in found if t.rows]
        if not usable:
            summaries.append({"sheet": sheet.name, "status": "empty", "tables": 0, "hidden": sheet.hidden,
                              "message": f"Unable to detect a valid data table in sheet '{sheet.name}'."})
            continue
        summaries.append({"sheet": sheet.name, "status": "ok", "tables": len(usable), "hidden": sheet.hidden})
        tables.extend(usable)
    if not tables:
        raise IngestionError("No data table could be detected in this file. Make sure it has a header row and at least one data row.")
    return InspectResult(wb.file_format, tables, summaries, wb.warnings)


def table_to_raw(t: DetectedTable) -> tuple[pd.DataFrame, dict[str, str | None], dict[str, str]]:
    raw = raw_frame(t.columns, t.rows)
    hints = {c: h for c, h in zip(t.columns, t.format_hints)}
    originals = {c: o for c, o in zip(t.columns, t.original_columns)}
    return raw, hints, originals


def profile_raw(raw: pd.DataFrame, *, hints: dict[str, str | None] | None = None, originals: dict[str, str] | None = None,
                overrides: dict[str, dict[str, Any]] | None = None, dayfirst: bool = True) -> ProfileResult:
    return profile_dataframe(raw, format_hints=hints, overrides=overrides, original_names=originals, dayfirst_default=dayfirst)


def table_summary(t: DetectedTable) -> dict[str, Any]:
    return {
        "sheet_name": t.sheet_name, "table_index": t.table_index, "label": t.label, "header_row": t.header_row,
        "first_row": t.first_row, "last_row": t.last_row, "row_count": len(t.rows), "col_count": len(t.columns),
        "columns": t.columns, "preview": table_preview(t), "header_confidence": t.header_confidence,
        "notes": t.notes, "excluded_rows": t.excluded_rows[:50], "title": t.title,
    }
