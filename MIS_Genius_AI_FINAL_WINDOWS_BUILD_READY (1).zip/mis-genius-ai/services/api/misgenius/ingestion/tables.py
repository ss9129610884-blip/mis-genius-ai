"""Table-region and header detection for poorly formatted spreadsheets.

Real MIS workbooks contain title rows, notes, blank spacer rows/columns, merged
two-row headers, repeated header rows (page breaks), "Grand Total" rows and even
several tables on one sheet. This module finds the actual data tables.
"""
from __future__ import annotations

import re
from collections import Counter
from dataclasses import dataclass, field
from datetime import date, datetime
from typing import Any

from misgenius.ingestion.parsing import is_null_like, parse_date, parse_number, to_text
from misgenius.ingestion.readers import RawSheet

TOTAL_RE = re.compile(r"^\s*(grand\s*total|sub\s*-?\s*total|total|totals|कुल|कुल योग|सकल योग)\s*[:\-]?\s*$", re.I)
MAX_HEADER_SCAN = 15


@dataclass
class DetectedTable:
    sheet_name: str
    table_index: int
    label: str
    header_row: int | None  # 1-based sheet row, None if no header
    first_row: int
    last_row: int
    first_col: int
    columns: list[str]
    original_columns: list[str]
    rows: list[list[Any]]
    format_hints: list[str | None]
    header_confidence: float
    excluded_rows: list[dict[str, Any]] = field(default_factory=list)
    notes: list[str] = field(default_factory=list)
    title: str | None = None


def col_letter(idx: int) -> str:
    s = ""
    idx += 1
    while idx:
        idx, rem = divmod(idx - 1, 26)
        s = chr(65 + rem) + s
    return s


def _clean(v: Any) -> Any:
    """Blank strings become None; other values are kept exactly (whitespace is
    preserved so the data-quality engine can report it)."""
    if isinstance(v, str):
        return v if v.strip() else None
    if v is None:
        return None
    if isinstance(v, float) and v != v:  # NaN
        return None
    return v


def _is_texty(v: Any) -> bool:
    if not isinstance(v, str):
        return False
    if parse_number(v) is not None:
        return False
    if parse_date(v)[0] is not None:
        return False
    return True


def _row_profile(row: list[Any], c0: int, c1: int) -> tuple[float, float, float, int]:
    cells = row[c0:c1]
    width = max(c1 - c0, 1)
    vals = [v for v in cells if v is not None]
    if not vals:
        return 0.0, 0.0, 0.0, 0
    filled = len(vals) / width
    text_ratio = sum(1 for v in vals if _is_texty(v)) / len(vals)
    uniq = len({str(v).lower() for v in vals}) / len(vals)
    return filled, text_ratio, uniq, len(vals)


def normalize_names(raw_names: list[Any], first_col: int) -> tuple[list[str], list[str]]:
    names: list[str] = []
    originals: list[str] = []
    seen: Counter[str] = Counter()
    for i, raw in enumerate(raw_names):
        orig = to_text(raw) if raw is not None else ""
        orig = orig or ""
        name = re.sub(r"\s+", " ", orig.replace("\n", " ").replace("\r", " ")).strip()
        if not name:
            name = f"Column {col_letter(first_col + i)}"
        base = name[:120]
        key = base.lower()
        seen[key] += 1
        if seen[key] > 1:
            candidate = f"{base} ({seen[key]})"
            while candidate.lower() in seen:
                seen[key] += 1
                candidate = f"{base} ({seen[key]})"
            seen[candidate.lower()] += 1
            name = candidate
        else:
            name = base
        names.append(name)
        originals.append(orig)
    return names, originals


def _split_blocks(grid: list[list[Any]]) -> list[tuple[int, int]]:
    """Return (start, end_exclusive) row ranges of non-empty rows separated by blank rows."""
    blocks: list[tuple[int, int]] = []
    start = None
    for i, row in enumerate(grid):
        empty = all(v is None for v in row)
        if not empty and start is None:
            start = i
        elif empty and start is not None:
            blocks.append((start, i))
            start = None
    if start is not None:
        blocks.append((start, len(grid)))
    return blocks


def _col_span(grid: list[list[Any]], r0: int, r1: int) -> tuple[int, int]:
    lo, hi = None, -1
    for r in range(r0, r1):
        row = grid[r]
        for c, v in enumerate(row):
            if v is not None:
                lo = c if lo is None else min(lo, c)
                hi = max(hi, c)
    return (lo or 0, hi + 1)


def _looks_like_header(row: list[Any], c0: int, c1: int) -> bool:
    filled, text_ratio, uniq, n = _row_profile(row, c0, c1)
    return n >= 2 and text_ratio >= 0.7 and uniq >= 0.9 and filled >= 0.5


def _merge_blocks(grid: list[list[Any]], blocks: list[tuple[int, int]]) -> list[tuple[int, int, str | None]]:
    """Merge blocks split by stray blank rows; attach tiny title blocks to the next block."""
    merged: list[tuple[int, int, str | None]] = []
    pending_title: str | None = None
    i = 0
    while i < len(blocks):
        s, e = blocks[i]
        c0, c1 = _col_span(grid, s, e)
        n_cells = sum(1 for r in range(s, e) for v in grid[r] if v is not None)
        if (e - s) <= 3 and n_cells <= (e - s) * 2 and (c1 - c0) <= 3 and i + 1 < len(blocks):
            texts = [to_text(v) for r in range(s, e) for v in grid[r] if v is not None]
            pending_title = " · ".join(t for t in texts if t)[:200] or pending_title
            i += 1
            continue
        # absorb following blocks that continue the same table (no new header, same span)
        while i + 1 < len(blocks):
            ns, ne = blocks[i + 1]
            gap = ns - e
            nc0, nc1 = _col_span(grid, ns, ne)
            overlap = max(0, min(c1, nc1) - max(c0, nc0)) / max(c1 - c0, nc1 - nc0, 1)
            if gap <= 2 and overlap >= 0.8 and not _looks_like_header(grid[ns], nc0, nc1) and not _is_total_row(grid[ns]):
                e = ne
                c0, c1 = min(c0, nc0), max(c1, nc1)
                i += 1
            else:
                break
        merged.append((s, e, pending_title))
        pending_title = None
        i += 1
    return merged


def _is_total_row(row: list[Any]) -> bool:
    firsts = [v for v in row if v is not None][:2]
    return any(isinstance(v, str) and TOTAL_RE.match(v) for v in firsts)


def _split_columns(grid: list[list[Any]], s: int, e: int, c0: int, c1: int) -> list[tuple[int, int]]:
    empty_cols = [c for c in range(c0, c1) if all(grid[r][c] is None for r in range(s, e))]
    if not empty_cols:
        return [(c0, c1)]
    segments: list[tuple[int, int]] = []
    cur = c0
    for c in empty_cols + [c1]:
        if c > cur:
            segments.append((cur, c))
        cur = c + 1
    if len(segments) <= 1:
        return segments or [(c0, c1)]
    # only treat as separate tables if each segment is table-like (>=2 cols, own header)
    if all((b - a) >= 2 and _looks_like_header(grid[s], a, b) for a, b in segments):
        return segments
    return [(c0, c1)]


def _pick_header(grid: list[list[Any]], s: int, e: int, c0: int, c1: int) -> tuple[int | None, float, bool]:
    """Return (header_row_index or None, confidence, two_row_header)."""
    best_row, best_score = None, -1.0
    limit = min(e, s + MAX_HEADER_SCAN)
    scores: dict[int, tuple[float, float, float]] = {}
    for r in range(s, limit):
        filled, text_ratio, uniq, n = _row_profile(grid[r], c0, c1)
        if n == 0:
            continue
        # data should follow the header
        below = [
            _row_profile(grid[rr], c0, c1)[0] for rr in range(r + 1, min(e, r + 11)) if any(v is not None for v in grid[rr][c0:c1])
        ]
        below_filled = sum(below) / len(below) if below else 0.0
        score = 0.35 * filled + 0.4 * text_ratio + 0.15 * uniq + 0.1 * below_filled
        if n < 2 and (c1 - c0) > 1:
            score *= 0.4
        scores[r] = (score, text_ratio, filled)
        if score > best_score + 0.05:
            best_row, best_score = r, score
    if best_row is None:
        return None, 0.0, False
    _, text_ratio, filled = scores[best_row]
    # compare with the first data row: if the "header" looks just like data, there is no header
    nxt = next((rr for rr in range(best_row + 1, e) if any(v is not None for v in grid[rr][c0:c1])), None)
    if text_ratio < 0.5:
        return None, round(1 - text_ratio, 2), False
    if nxt is not None:
        _, nxt_text, _, _ = _row_profile(grid[nxt], c0, c1)
        if nxt_text >= 0.99 and text_ratio >= 0.99:
            # all-text table: header is still the first row; confidence lower
            conf = 0.7
        else:
            conf = min(1.0, 0.6 + (text_ratio - nxt_text) * 0.5 + 0.2 * filled)
    else:
        conf = 0.5
    two_row = False
    if nxt is not None and nxt == best_row + 1 and filled < 0.95:
        f2, t2, _, _ = _row_profile(grid[nxt], c0, c1)
        after = next((rr for rr in range(nxt + 1, e) if any(v is not None for v in grid[rr][c0:c1])), None)
        if after is not None and t2 >= 0.8 and f2 >= 0.6:
            _, t3, _, _ = _row_profile(grid[after], c0, c1)
            if t2 - t3 >= 0.3:
                two_row = True
    return best_row, round(max(0.3, min(conf, 1.0)), 2), two_row


def _format_hint_for_col(sheet: RawSheet, rows: list[int], col: int) -> str | None:
    hints = Counter()
    for r in rows[:200]:
        h = sheet.format_hints.get((r, col))
        if h:
            hints[h] += 1
    if not hints:
        return None
    return hints.most_common(1)[0][0]


def detect_tables(sheet: RawSheet) -> list[DetectedTable]:
    width = max((len(r) for r in sheet.grid), default=0)
    grid = [[_clean(v) for v in row] + [None] * (width - len(row)) for row in sheet.grid]
    if width == 0 or not grid:
        return []
    tables: list[DetectedTable] = []
    for s, e, title in _merge_blocks(grid, _split_blocks(grid)):
        c0, c1 = _col_span(grid, s, e)
        for a, b in _split_columns(grid, s, e, c0, c1):
            t = _build_table(sheet, grid, s, e, a, b, len(tables), title)
            if t is not None:
                tables.append(t)
    many = len(tables) > 1
    for t in tables:
        rng = f"{col_letter(t.first_col)}{t.header_row or t.first_row}:{col_letter(t.first_col + len(t.columns) - 1)}{t.last_row}"
        t.label = f"{sheet.name} · Table {t.table_index + 1} ({rng})" if many else sheet.name
    return tables


def _build_table(
    sheet: RawSheet, grid: list[list[Any]], s: int, e: int, c0: int, c1: int, index: int, title: str | None
) -> DetectedTable | None:
    header_idx, conf, two_row = _pick_header(grid, s, e, c0, c1)
    notes: list[str] = []
    if header_idx is None:
        raw_names: list[Any] = [None] * (c1 - c0)
        data_start = s
        notes.append("No header row was detected; columns were named by their Excel letters.")
    else:
        raw_names = list(grid[header_idx][c0:c1])
        data_start = header_idx + 1
        if two_row:
            top = list(grid[header_idx][c0:c1])
            # forward-fill merged top header cells
            last = None
            for i, v in enumerate(top):
                if v is None:
                    top[i] = last
                else:
                    last = v
            sub = grid[header_idx + 1][c0:c1]
            raw_names = [
                " ".join(str(x) for x in (t, b) if x is not None and str(x).strip()) or None
                for t, b in zip(top, sub)
            ]
            data_start = header_idx + 2
            notes.append("A two-row (merged) header was detected and combined.")
        if header_idx > s:
            texts = [to_text(v) for r in range(s, header_idx) for v in grid[r] if v is not None]
            title = " · ".join(t for t in texts if t)[:200] or title
    header_key = [str(v).strip().lower() if v is not None else "" for v in grid[header_idx][c0:c1]] if header_idx is not None else None

    rows: list[list[Any]] = []
    row_idx: list[int] = []
    excluded: list[dict[str, Any]] = []
    for r in range(data_start, e):
        vals = grid[r][c0:c1]
        if all(v is None for v in vals):
            continue
        if _is_total_row(vals):
            excluded.append({"row": r + 1, "reason": "total_row", "label": to_text(next(v for v in vals if v is not None))})
            continue
        if header_key is not None and [str(v).strip().lower() if v is not None else "" for v in vals] == header_key:
            excluded.append({"row": r + 1, "reason": "repeated_header"})
            continue
        rows.append(list(vals))
        row_idx.append(r)

    # drop columns that have neither a header nor any data
    keep = [
        i for i in range(c1 - c0)
        if raw_names[i] is not None or any(row[i] is not None for row in rows)
    ]
    if not keep:
        return None
    raw_names = [raw_names[i] for i in keep]
    rows = [[row[i] for i in keep] for row in rows]
    first_col = c0 + keep[0]
    names, originals = normalize_names(raw_names, first_col)
    if any(n != (o or "").strip() and o for n, o in zip(names, originals)):
        dupes = [o for o, n in zip(originals, names) if o and n != re.sub(r"\s+", " ", o).strip()]
        if dupes:
            notes.append(f"Duplicate column names were made unique: {', '.join(sorted(set(dupes))[:5])}.")
    hints = [_format_hint_for_col(sheet, row_idx, c0 + i) for i in keep]
    if excluded:
        n_tot = sum(1 for x in excluded if x["reason"] == "total_row")
        if n_tot:
            notes.append(f"{n_tot} total/subtotal row(s) were excluded so totals are not double counted.")
    if not rows and header_idx is None:
        return None
    return DetectedTable(
        sheet_name=sheet.name,
        table_index=index,
        label=sheet.name,
        header_row=(header_idx + 1) if header_idx is not None else None,
        first_row=(row_idx[0] + 1) if row_idx else data_start + 1,
        last_row=(row_idx[-1] + 1) if row_idx else data_start + 1,
        first_col=first_col,
        columns=names,
        original_columns=originals,
        rows=rows,
        format_hints=hints,
        header_confidence=conf if header_idx is not None else 0.0,
        excluded_rows=excluded,
        notes=notes,
        title=title,
    )


def table_preview(t: DetectedTable, n: int = 8) -> list[list[str | None]]:
    out = []
    for row in t.rows[:n]:
        out.append([(to_text(v)[:80] if to_text(v) is not None else None) for v in row])
    return out


__all__ = ["DetectedTable", "detect_tables", "table_preview", "col_letter", "normalize_names", "datetime", "date"]
