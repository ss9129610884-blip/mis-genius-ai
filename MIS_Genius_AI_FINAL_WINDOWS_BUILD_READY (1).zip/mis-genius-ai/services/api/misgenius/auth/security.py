"""Password hashing, tokens and at-rest encryption helpers."""
from __future__ import annotations

import base64
import hashlib
import hmac
import secrets
from datetime import datetime, timedelta, timezone
from typing import Any

import bcrypt
import jwt
from cryptography.fernet import Fernet, InvalidToken

from misgenius.config import get_settings

ALGO = "HS256"


def hash_password(password: str) -> str:
    return bcrypt.hashpw(password.encode("utf-8")[:72], bcrypt.gensalt(rounds=12)).decode()


def verify_password(password: str, hashed: str) -> bool:
    try:
        return bcrypt.checkpw(password.encode("utf-8")[:72], hashed.encode())
    except ValueError:
        return False


def password_problems(password: str) -> list[str]:
    probs = []
    if len(password) < 8:
        probs.append("at least 8 characters")
    if not any(c.isalpha() for c in password):
        probs.append("a letter")
    if not any(c.isdigit() for c in password):
        probs.append("a number")
    if len(password) > 200:
        probs.append("at most 200 characters")
    return probs


def create_access_token(user_id: str, org_id: str | None, role: str | None, extra: dict[str, Any] | None = None) -> str:
    s = get_settings()
    now = datetime.now(timezone.utc)
    payload = {"sub": user_id, "org": org_id, "role": role, "type": "access", "iat": now,
               "exp": now + timedelta(minutes=s.ACCESS_TOKEN_MINUTES), "jti": secrets.token_hex(8)}
    if extra:
        payload.update(extra)
    return jwt.encode(payload, s.secret_key, algorithm=ALGO)


def decode_access_token(token: str) -> dict[str, Any]:
    payload = jwt.decode(token, get_settings().secret_key, algorithms=[ALGO], options={"require": ["exp", "sub"]})
    if payload.get("type") != "access":
        raise jwt.InvalidTokenError("wrong token type")
    return payload


def new_refresh_token() -> tuple[str, str]:
    raw = secrets.token_urlsafe(48)
    return raw, sha256(raw)


def new_api_key() -> tuple[str, str, str]:
    raw = "mga_" + secrets.token_urlsafe(32)
    return raw, raw[:10], sha256(raw)


def sha256(value: str) -> str:
    return hashlib.sha256(value.encode()).hexdigest()


def _fernet() -> Fernet:
    key = hashlib.sha256(("mis-genius-enc:" + get_settings().secret_key).encode()).digest()
    return Fernet(base64.urlsafe_b64encode(key))


def encrypt_secret(value: str) -> str:
    return _fernet().encrypt(value.encode()).decode()


def decrypt_secret(token: str) -> str | None:
    try:
        return _fernet().decrypt(token.encode()).decode()
    except (InvalidToken, ValueError):
        return None


def constant_time_equals(a: str, b: str) -> bool:
    return hmac.compare_digest(a.encode(), b.encode())
