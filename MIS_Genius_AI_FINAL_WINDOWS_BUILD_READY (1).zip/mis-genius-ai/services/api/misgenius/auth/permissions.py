"""Role-based permissions (Owner > Admin > Analyst > Viewer)."""
from __future__ import annotations

ROLES = ["viewer", "analyst", "admin", "owner"]
ROLE_RANK = {r: i for i, r in enumerate(ROLES)}

PERMISSIONS: dict[str, str] = {
    "read": "viewer",
    "export": "viewer",
    "ai.use": "viewer",
    "data.write": "analyst",
    "dashboard.write": "analyst",
    "report.write": "analyst",
    "alert.write": "analyst",
    "data.delete": "admin",
    "connector.manage": "admin",
    "members.manage": "admin",
    "settings.manage": "admin",
    "audit.read": "admin",
    "apikeys.manage": "admin",
    "backup.manage": "admin",
    "billing.manage": "owner",
    "org.delete": "owner",
}


def has_permission(role: str | None, perm: str) -> bool:
    if role not in ROLE_RANK:
        return False
    need = PERMISSIONS.get(perm)
    if need is None:
        return False
    return ROLE_RANK[role] >= ROLE_RANK[need]


def can_assign(actor_role: str, target_role: str) -> bool:
    """Admins manage analysts/viewers/admins; only owners create owners."""
    if target_role not in ROLE_RANK or actor_role not in ROLE_RANK:
        return False
    if target_role == "owner":
        return actor_role == "owner"
    return ROLE_RANK[actor_role] >= ROLE_RANK["admin"]


def permissions_for(role: str) -> list[str]:
    return [p for p in PERMISSIONS if has_permission(role, p)]
