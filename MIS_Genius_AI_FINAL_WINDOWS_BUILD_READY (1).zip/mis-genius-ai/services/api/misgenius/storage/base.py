"""Object storage abstraction.

`LocalStorage` keeps files under DATA_DIR/storage (desktop, LAN, single server).
`S3Storage` works with AWS S3, MinIO, Cloudflare R2, DigitalOcean Spaces, etc.
Analytics reads parquet through `local_path()`, which for S3 downloads into a
local cache, so the query engine never depends on the storage backend.
"""
from __future__ import annotations

import hashlib
import os
import re
import shutil
from abc import ABC, abstractmethod
from pathlib import Path

from misgenius.config import Settings, get_settings

_SAFE_KEY = re.compile(r"^[A-Za-z0-9][A-Za-z0-9._\-/]{0,480}$")


class StorageError(Exception):
    pass


def validate_key(key: str) -> str:
    """Reject anything that could escape the storage root (path traversal)."""
    if not key or not _SAFE_KEY.match(key) or ".." in key.split("/") or key.startswith("/") or "\\" in key:
        raise StorageError(f"Invalid storage key: {key!r}")
    return key


class Storage(ABC):
    @abstractmethod
    def put_bytes(self, key: str, data: bytes) -> None: ...

    @abstractmethod
    def put_file(self, key: str, path: Path) -> None: ...

    @abstractmethod
    def get_bytes(self, key: str) -> bytes: ...

    @abstractmethod
    def local_path(self, key: str) -> Path:
        """Return a local filesystem path for reading (downloading if needed)."""

    @abstractmethod
    def exists(self, key: str) -> bool: ...

    @abstractmethod
    def delete(self, key: str) -> None: ...

    @abstractmethod
    def delete_prefix(self, prefix: str) -> None: ...

    @abstractmethod
    def size_of_prefix(self, prefix: str) -> int: ...


class LocalStorage(Storage):
    def __init__(self, root: Path):
        self.root = root.resolve()
        self.root.mkdir(parents=True, exist_ok=True)

    def _path(self, key: str) -> Path:
        validate_key(key)
        p = (self.root / key).resolve()
        if self.root not in p.parents and p != self.root:
            raise StorageError("Path escapes storage root")
        return p

    def put_bytes(self, key: str, data: bytes) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        tmp = p.with_suffix(p.suffix + ".tmp")
        tmp.write_bytes(data)
        os.replace(tmp, p)

    def put_file(self, key: str, path: Path) -> None:
        p = self._path(key)
        p.parent.mkdir(parents=True, exist_ok=True)
        shutil.copyfile(path, p)

    def get_bytes(self, key: str) -> bytes:
        p = self._path(key)
        if not p.exists():
            raise StorageError(f"Object not found: {key}")
        return p.read_bytes()

    def local_path(self, key: str) -> Path:
        p = self._path(key)
        if not p.exists():
            raise StorageError(f"Object not found: {key}")
        return p

    def exists(self, key: str) -> bool:
        return self._path(key).exists()

    def delete(self, key: str) -> None:
        p = self._path(key)
        if p.exists():
            p.unlink()

    def delete_prefix(self, prefix: str) -> None:
        p = self._path(prefix.rstrip("/"))
        if p.is_dir():
            shutil.rmtree(p)
        elif p.exists():
            p.unlink()

    def size_of_prefix(self, prefix: str) -> int:
        p = self._path(prefix.rstrip("/"))
        if not p.exists():
            return 0
        if p.is_file():
            return p.stat().st_size
        return sum(f.stat().st_size for f in p.rglob("*") if f.is_file())


class S3Storage(Storage):  # pragma: no cover - requires external service
    def __init__(self, settings: Settings):
        try:
            import boto3  # type: ignore
        except ImportError as e:
            raise StorageError("STORAGE_PROVIDER=s3 requires the 'boto3' package (pip install boto3)") from e
        if not settings.S3_BUCKET:
            raise StorageError("S3_BUCKET must be configured")
        self.bucket = settings.S3_BUCKET
        self.client = boto3.client(
            "s3",
            endpoint_url=settings.S3_ENDPOINT_URL,
            region_name=settings.S3_REGION,
            aws_access_key_id=settings.S3_ACCESS_KEY,
            aws_secret_access_key=settings.S3_SECRET_KEY,
        )
        self.cache = settings.DATA_DIR / "cache" / "s3"
        self.cache.mkdir(parents=True, exist_ok=True)

    def put_bytes(self, key: str, data: bytes) -> None:
        self.client.put_object(Bucket=self.bucket, Key=validate_key(key), Body=data)

    def put_file(self, key: str, path: Path) -> None:
        self.client.upload_file(str(path), self.bucket, validate_key(key))

    def get_bytes(self, key: str) -> bytes:
        obj = self.client.get_object(Bucket=self.bucket, Key=validate_key(key))
        return obj["Body"].read()

    def local_path(self, key: str) -> Path:
        validate_key(key)
        name = hashlib.sha256(key.encode()).hexdigest() + Path(key).suffix
        p = self.cache / name
        if not p.exists():
            tmp = p.with_suffix(".part")
            self.client.download_file(self.bucket, key, str(tmp))
            os.replace(tmp, p)
        return p

    def exists(self, key: str) -> bool:
        try:
            self.client.head_object(Bucket=self.bucket, Key=validate_key(key))
            return True
        except Exception:
            return False

    def delete(self, key: str) -> None:
        self.client.delete_object(Bucket=self.bucket, Key=validate_key(key))

    def delete_prefix(self, prefix: str) -> None:
        paginator = self.client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.bucket, Prefix=validate_key(prefix)):
            keys = [{"Key": o["Key"]} for o in page.get("Contents", [])]
            if keys:
                self.client.delete_objects(Bucket=self.bucket, Delete={"Objects": keys})

    def size_of_prefix(self, prefix: str) -> int:
        total = 0
        paginator = self.client.get_paginator("list_objects_v2")
        for page in paginator.paginate(Bucket=self.bucket, Prefix=validate_key(prefix)):
            total += sum(o["Size"] for o in page.get("Contents", []))
        return total


_storage: Storage | None = None


def get_storage() -> Storage:
    global _storage
    if _storage is None:
        s = get_settings()
        _storage = S3Storage(s) if s.STORAGE_PROVIDER == "s3" else LocalStorage(s.DATA_DIR / "storage")
    return _storage


def reset_storage() -> None:
    global _storage
    _storage = None
