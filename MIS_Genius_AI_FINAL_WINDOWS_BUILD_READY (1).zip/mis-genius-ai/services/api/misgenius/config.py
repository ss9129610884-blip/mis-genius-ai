"""Centralised configuration.

Every setting comes from environment variables (or a `.env` file). Nothing secret
is hard-coded. The same code runs in development, testing, local (desktop),
LAN and production modes; only the configuration differs.
"""
from __future__ import annotations

import os
import secrets
from functools import lru_cache
from pathlib import Path
from typing import Literal

from pydantic import Field, field_validator
from pydantic_settings import BaseSettings, SettingsConfigDict

AppEnv = Literal["development", "testing", "local", "lan", "production"]


def _default_data_dir() -> Path:
    env = os.environ.get("MIS_DATA_DIR")
    if env:
        return Path(env)
    if os.name == "nt" and os.environ.get("LOCALAPPDATA"):
        return Path(os.environ["LOCALAPPDATA"]) / "MISGeniusAI"
    return Path.cwd() / "data"


class Settings(BaseSettings):
    model_config = SettingsConfigDict(env_file=".env", env_file_encoding="utf-8", extra="ignore")

    APP_NAME: str = "MIS Genius AI"
    APP_VERSION: str = "1.0.0"
    APP_ENV: AppEnv = "development"

    HOST: str = "127.0.0.1"
    PORT: int = 8765

    DATA_DIR: Path = Field(default_factory=_default_data_dir)
    DATABASE_URL: str | None = None  # default: sqlite file inside DATA_DIR
    SECRET_KEY: str | None = None

    ACCESS_TOKEN_MINUTES: int = 60
    REFRESH_TOKEN_DAYS: int = 30
    ALLOW_REGISTRATION: bool = True

    CORS_ORIGINS: str = ""  # comma separated
    TRUSTED_HOSTS: str = ""  # comma separated; empty = allow all

    STORAGE_PROVIDER: Literal["local", "s3"] = "local"
    S3_BUCKET: str | None = None
    S3_ENDPOINT_URL: str | None = None
    S3_REGION: str | None = None
    S3_ACCESS_KEY: str | None = None
    S3_SECRET_KEY: str | None = None

    AI_PROVIDER: Literal["none", "anthropic", "openai", "gemini", "openai_compatible"] = "none"
    AI_API_KEY: str | None = None
    AI_MODEL: str | None = None
    AI_BASE_URL: str | None = None  # for openai_compatible / local LLMs (Ollama, LM Studio)
    AI_TIMEOUT_SECONDS: float = 60.0

    MAX_UPLOAD_MB: int = 100
    MAX_ROWS: int = 2_000_000
    MAX_COLUMNS: int = 500
    MAX_XLSX_UNCOMPRESSED_MB: int = 1024
    DATE_DAYFIRST: bool = True  # Indian/UK default; ambiguous dates are reported

    JOB_MODE: Literal["thread", "inline", "external"] = "thread"
    RATE_LIMIT_PER_MINUTE: int = 600
    AUTH_RATE_LIMIT_PER_MINUTE: int = 20

    SMTP_HOST: str | None = None
    SMTP_PORT: int = 587
    SMTP_USER: str | None = None
    SMTP_PASSWORD: str | None = None
    SMTP_FROM: str | None = None

    STRIPE_SECRET_KEY: str | None = None
    STRIPE_WEBHOOK_SECRET: str | None = None

    ALLOW_PRIVATE_NETWORK_CONNECTORS: bool | None = None  # default depends on env
    SERVE_WEB: bool = True
    WEB_DIST_DIR: Path | None = None
    LOG_LEVEL: str = "INFO"
    LOG_JSON: bool = True

    @field_validator("DATA_DIR", mode="before")
    @classmethod
    def _expand(cls, v):  # noqa: N805
        return Path(v).expanduser() if v else _default_data_dir()

    # ---- derived helpers -------------------------------------------------
    @property
    def is_production(self) -> bool:
        return self.APP_ENV == "production"

    @property
    def is_local_like(self) -> bool:
        return self.APP_ENV in ("local", "development", "testing")

    @property
    def database_url(self) -> str:
        if self.DATABASE_URL:
            url = self.DATABASE_URL
            if url.startswith("postgres://"):
                url = "postgresql+psycopg://" + url[len("postgres://"):]
            elif url.startswith("postgresql://"):
                url = "postgresql+psycopg://" + url[len("postgresql://"):]
            return url
        return f"sqlite:///{(self.DATA_DIR / 'misgenius.db').as_posix()}"

    @property
    def cors_origins(self) -> list[str]:
        return [o.strip() for o in self.CORS_ORIGINS.split(",") if o.strip()]

    @property
    def trusted_hosts(self) -> list[str]:
        return [h.strip() for h in self.TRUSTED_HOSTS.split(",") if h.strip()]

    @property
    def allow_private_network(self) -> bool:
        if self.ALLOW_PRIVATE_NETWORK_CONNECTORS is not None:
            return self.ALLOW_PRIVATE_NETWORK_CONNECTORS
        return self.APP_ENV in ("local", "lan", "development", "testing")

    @property
    def secret_key(self) -> str:
        """Return SECRET_KEY. Production requires it explicitly; local modes
        generate one once and persist it inside DATA_DIR so tokens survive restarts."""
        if self.SECRET_KEY:
            return self.SECRET_KEY
        if self.is_production:
            raise RuntimeError("SECRET_KEY must be set in production mode")
        key_file = self.DATA_DIR / ".secret_key"
        self.DATA_DIR.mkdir(parents=True, exist_ok=True)
        if key_file.exists():
            return key_file.read_text().strip()
        key = secrets.token_urlsafe(48)
        key_file.write_text(key)
        try:
            os.chmod(key_file, 0o600)
        except OSError:
            pass
        return key

    @property
    def web_dist_dir(self) -> Path | None:
        if self.WEB_DIST_DIR:
            return self.WEB_DIST_DIR
        here = Path(__file__).resolve()
        candidates = [
            here.parent / "web_dist",  # packaged (PyInstaller / Docker)
            here.parents[3] / "apps" / "web" / "dist",  # monorepo checkout
        ]
        for c in candidates:
            if (c / "index.html").exists():
                return c
        return None


@lru_cache
def get_settings() -> Settings:
    s = Settings()
    s.DATA_DIR.mkdir(parents=True, exist_ok=True)
    return s


def reset_settings_cache() -> None:
    get_settings.cache_clear()
