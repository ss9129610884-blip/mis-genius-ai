"""Non-destructive data-cleaning transforms.

Transforms operate on a *copy* of the raw (text) DataFrame and are recorded as a
list of steps on the new dataset version. The original upload and every earlier
version stay untouched, so any cleaning can be undone by switching versions.
Type-level fixes (convert type, date order) are stored as schema overrides.
"""
from __future__ import annotations

from typing import Any, Callable

import pandas as pd

from misgenius.ingestion.parsing import is_null_like, parse_number, to_text


class TransformError(ValueError):
    pass


OVERRIDE_OPS = {"convert_type", "standardize_dates", "set_role", "set_label"}


def _cols(df: pd.DataFrame, params: dict[str, Any], key: str = "columns", required: bool = False) -> list[str]:
    cols = params.get(key)
    if cols is None and "column" in params:
        cols = [params["column"]]
    if not cols:
        if required:
            raise TransformError(f"'{key}' is required")
        return list(df.columns)
    missing = [c for c in cols if c not in df.columns]
    if missing:
        raise TransformError(f"Unknown column(s): {', '.join(missing)}")
    return list(cols)


def _map_nonnull(s: pd.Series, fn: Callable[[str], Any]) -> pd.Series:
    return s.map(lambda v: v if v is None or (isinstance(v, float) and v != v) else fn(v))


def trim_whitespace(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p)
    for c in cols:
        df[c] = _map_nonnull(df[c], lambda v: " ".join(str(v).split()) or None)
    return df, f"Trimmed extra spaces in {len(cols)} column(s)"


def standardize_case(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p, required=True)
    case = p.get("case", "title")
    fn = {"upper": str.upper, "lower": str.lower, "title": lambda x: " ".join(w[:1].upper() + w[1:].lower() for w in x.split())}.get(case)
    if fn is None:
        raise TransformError("case must be upper, lower or title")
    for c in cols:
        df[c] = _map_nonnull(df[c], lambda v: fn(str(v).strip()))
    return df, f"Converted {', '.join(cols)} to {case} case"


def remove_duplicates(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    subset = p.get("columns") or None
    if subset:
        _cols(df, p)
    before = len(df)
    df = df.loc[~df.astype(str).duplicated(subset=subset, keep="first")].reset_index(drop=True)
    return df, f"Removed {before - len(df):,} duplicate row(s)"


def remove_empty_rows(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    before = len(df)
    mask = df.apply(lambda col: col.map(is_null_like)).all(axis=1)
    df = df.loc[~mask].reset_index(drop=True)
    return df, f"Removed {before - len(df):,} empty row(s)"


def remove_empty_columns(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    empty = [c for c in df.columns if df[c].map(is_null_like).all()]
    df = df.drop(columns=empty)
    return df, f"Removed {len(empty)} empty column(s)" + (f": {', '.join(empty)}" if empty else "")


def drop_columns(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p, required=True)
    if len(cols) >= len(df.columns):
        raise TransformError("Cannot remove every column")
    return df.drop(columns=cols), f"Removed column(s): {', '.join(cols)}"


def fill_missing(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p, required=True)
    strategy = p.get("strategy", "value")
    total = 0
    for c in cols:
        mask = df[c].map(is_null_like)
        n = int(mask.sum())
        if not n:
            continue
        if strategy == "value":
            if p.get("value") in (None, ""):
                raise TransformError("A fill value is required")
            df.loc[mask, c] = str(p["value"])
        elif strategy == "zero":
            df.loc[mask, c] = "0"
        elif strategy in ("mean", "median"):
            nums = df[c].map(lambda v: (parse_number(v).value if parse_number(v) else None) if not is_null_like(v) else None).dropna()
            if nums.empty:
                raise TransformError(f"Column '{c}' has no numbers to compute a {strategy}")
            val = nums.astype(float).mean() if strategy == "mean" else nums.astype(float).median()
            df.loc[mask, c] = to_text(round(float(val), 6))
        elif strategy == "mode":
            vc = df.loc[~mask, c].value_counts()
            if vc.empty:
                raise TransformError(f"Column '{c}' has no values")
            df.loc[mask, c] = vc.index[0]
        elif strategy in ("ffill", "bfill"):
            tmp = df[c].where(~mask, None)
            df[c] = tmp.ffill() if strategy == "ffill" else tmp.bfill()
        else:
            raise TransformError("strategy must be value, zero, mean, median, mode, ffill or bfill")
        total += n
    return df, f"Filled {total:,} missing value(s) in {', '.join(cols)} using {strategy}"


def replace_values(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p, required=True)
    find = p.get("find")
    if find is None or find == "":
        raise TransformError("'find' is required")
    repl = p.get("replace")
    match = p.get("match", "exact")
    case_sensitive = bool(p.get("case_sensitive", False))
    count = 0
    for c in cols:
        s = df[c]
        sv = s.map(lambda v: None if v is None else str(v))
        if match == "exact":
            mask = sv.map(lambda v: v is not None and (v.strip() == find if case_sensitive else v.strip().lower() == str(find).lower()))
            df.loc[mask, c] = repl if repl not in ("",) else None
            count += int(mask.sum())
        elif match == "contains":
            mask = sv.map(lambda v: v is not None and ((find in v) if case_sensitive else (str(find).lower() in v.lower())))
            if case_sensitive:
                df.loc[mask, c] = sv[mask].map(lambda v: v.replace(find, repl or ""))
            else:
                import re

                pat = re.compile(re.escape(str(find)), re.I)
                df.loc[mask, c] = sv[mask].map(lambda v: pat.sub(repl or "", v))
            count += int(mask.sum())
        else:
            raise TransformError("match must be exact or contains")
    return df, f"Replaced {count:,} value(s) matching '{find}'"


def rename_column(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    old, new = p.get("column"), (p.get("new_name") or "").strip()
    if old not in df.columns:
        raise TransformError(f"Unknown column: {old}")
    if not new or len(new) > 120:
        raise TransformError("new_name must be 1-120 characters")
    if new in df.columns and new != old:
        raise TransformError(f"A column named '{new}' already exists")
    return df.rename(columns={old: new}), f"Renamed '{old}' to '{new}'"


def split_column(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    col = p.get("column")
    if col not in df.columns:
        raise TransformError(f"Unknown column: {col}")
    delim = p.get("delimiter")
    if not delim:
        raise TransformError("delimiter is required")
    names = p.get("into") or []
    parts = df[col].map(lambda v: None if is_null_like(v) else [x.strip() for x in str(v).split(delim)])
    n = max((len(x) for x in parts if x), default=0)
    if n < 2:
        raise TransformError(f"No value in '{col}' contains '{delim}'")
    n = min(n, 10)
    names = (list(names) + [f"{col} {i + 1}" for i in range(len(names), n)])[:n]
    for nm in names:
        if nm in df.columns:
            raise TransformError(f"A column named '{nm}' already exists")
    pos = list(df.columns).index(col) + 1
    for i, nm in enumerate(names):
        df.insert(pos + i, nm, parts.map(lambda x, i=i: (x[i] if x and len(x) > i and x[i] != "" else None)).astype(object))
    if not p.get("keep_original", True):
        df = df.drop(columns=[col])
    return df, f"Split '{col}' by '{delim}' into {', '.join(names)}"


def merge_columns(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p, required=True)
    if len(cols) < 2:
        raise TransformError("Select at least two columns to merge")
    new = (p.get("new_name") or " ".join(cols))[:120]
    if new in df.columns:
        raise TransformError(f"A column named '{new}' already exists")
    sep = p.get("separator", " ")
    df[new] = df[cols].apply(lambda r: sep.join(str(v).strip() for v in r if not is_null_like(v)) or None, axis=1).astype(object)
    return df, f"Merged {', '.join(cols)} into '{new}'"


def standardize_numbers(df: pd.DataFrame, p: dict[str, Any]) -> tuple[pd.DataFrame, str]:
    cols = _cols(df, p, required=True)
    changed = 0
    for c in cols:
        def conv(v: Any) -> Any:
            pn = parse_number(v)
            return to_text(pn.value) if pn else v

        new = _map_nonnull(df[c], conv)
        changed += int((new.astype(str) != df[c].astype(str)).sum())
        df[c] = new
    return df, f"Standardised {changed:,} number(s) (currency symbols, commas, brackets removed) in {', '.join(cols)}"


TRANSFORMS: dict[str, Callable[[pd.DataFrame, dict[str, Any]], tuple[pd.DataFrame, str]]] = {
    "trim_whitespace": trim_whitespace,
    "standardize_case": standardize_case,
    "remove_duplicates": remove_duplicates,
    "remove_empty_rows": remove_empty_rows,
    "remove_empty_columns": remove_empty_columns,
    "drop_columns": drop_columns,
    "fill_missing": fill_missing,
    "replace_values": replace_values,
    "rename_column": rename_column,
    "split_column": split_column,
    "merge_columns": merge_columns,
    "standardize_numbers": standardize_numbers,
    "normalize_currency": standardize_numbers,
}


def apply_transforms(raw: pd.DataFrame, steps: list[dict[str, Any]], overrides: dict[str, dict[str, Any]] | None = None
                     ) -> tuple[pd.DataFrame, dict[str, dict[str, Any]], list[dict[str, Any]]]:
    """Apply steps to a copy. Returns (new_raw, overrides, applied_steps_with_descriptions)."""
    df = raw.copy(deep=True)
    ov = {k: dict(v) for k, v in (overrides or {}).items()}
    applied: list[dict[str, Any]] = []
    for step in steps:
        op = step.get("op")
        params = dict(step.get("params") or {})
        if op in OVERRIDE_OPS:
            col = params.get("column")
            if col not in df.columns:
                raise TransformError(f"Unknown column: {col}")
            entry = ov.setdefault(col, {})
            if op == "convert_type":
                dt = params.get("data_type")
                from misgenius.schema.profiler import DATA_TYPES

                if dt not in DATA_TYPES:
                    raise TransformError(f"data_type must be one of {', '.join(DATA_TYPES)}")
                entry["data_type"] = dt
                desc = f"Treat '{col}' as {dt}"
            elif op == "standardize_dates":
                entry["data_type"] = entry.get("data_type") or "date"
                entry["dayfirst"] = bool(params.get("dayfirst", True))
                desc = f"Read dates in '{col}' as {'DD/MM' if entry['dayfirst'] else 'MM/DD'}"
            elif op == "set_role":
                entry["role"] = params.get("role")
                desc = f"Use '{col}' as {params.get('role')}"
            else:
                entry["label"] = params.get("label")
                desc = f"Label '{col}' as '{params.get('label')}'"
            applied.append({"op": op, "params": params, "description": desc})
            continue
        fn = TRANSFORMS.get(op or "")
        if fn is None:
            raise TransformError(f"Unknown cleaning operation: {op}")
        before_cols = list(df.columns)
        df, desc = fn(df, params)
        if op == "rename_column" and params.get("column") in ov:
            ov[params["new_name"].strip()] = ov.pop(params["column"])
        for gone in set(before_cols) - set(df.columns):
            ov.pop(gone, None)
        applied.append({"op": op, "params": params, "description": desc, "rows_after": len(df), "columns_after": len(df.columns)})
    return df, ov, applied
