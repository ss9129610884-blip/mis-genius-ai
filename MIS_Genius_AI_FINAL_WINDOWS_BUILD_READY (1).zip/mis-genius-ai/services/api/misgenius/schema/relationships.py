"""Relationship detection between columns (sample-based, bounded cost)."""
from __future__ import annotations

from itertools import combinations, permutations
from typing import TYPE_CHECKING, Any

import numpy as np
import pandas as pd

if TYPE_CHECKING:  # pragma: no cover
    from misgenius.schema.profiler import ColumnProfile

SAMPLE = 20000


def detect_relationships(df: pd.DataFrame, profiles: list[ColumnProfile]) -> list[dict[str, Any]]:
    rels: list[dict[str, Any]] = []
    if df.empty:
        return rels
    sample = df.sample(n=SAMPLE, random_state=7) if len(df) > SAMPLE else df
    dims = [p for p in profiles if p.role == "dimension" and 2 <= p.stats.get("distinct", 0) <= 5000][:15]
    measures = [p for p in profiles if p.role == "measure"][:12]
    ids = [p for p in profiles if p.role == "identifier"]

    # hierarchies: A -> B (every A value maps to exactly one B value), e.g. City -> State
    for a, b in permutations(dims, 2):
        da, db = a.stats.get("distinct", 0), b.stats.get("distinct", 0)
        if da <= db:
            continue
        sub = sample[[a.name, b.name]].dropna()
        if len(sub) < 10:
            continue
        per = sub.groupby(a.name, observed=True)[b.name].nunique()
        purity = float((per == 1).mean())
        if purity >= 0.98:
            rels.append({
                "type": "hierarchy", "from": a.name, "to": b.name, "confidence": round(purity, 3),
                "description": f"Each '{a.name}' belongs to one '{b.name}' ({b.name} → {a.name} drill-down).",
            })

    # correlations between measures
    if len(measures) >= 2:
        m = sample[[p.name for p in measures]].astype("float64")
        corr = m.corr(min_periods=10)
        for x, y in combinations(corr.columns, 2):
            c = corr.loc[x, y]
            if pd.notna(c) and abs(c) >= 0.8:
                rels.append({
                    "type": "correlation", "from": x, "to": y, "confidence": round(float(abs(c)), 3), "value": round(float(c), 3),
                    "description": f"'{x}' and '{y}' move {'together' if c > 0 else 'in opposite directions'} (r = {c:.2f}).",
                })

        # derived columns: A = B - C, A = B + C, A = B * C
        arr = {p.name: sample[p.name].to_numpy(dtype="float64") for p in measures}
        names = list(arr)
        for a in names:
            for b, c in combinations([n for n in names if n != a], 2):
                A, B, C = arr[a], arr[b], arr[c]
                mask = ~(np.isnan(A) | np.isnan(B) | np.isnan(C))
                if mask.sum() < 10:
                    continue
                A, B, C = A[mask], B[mask], C[mask]
                tol = np.maximum(1e-6, np.abs(A) * 1e-3) + 0.011
                for op, val, expr in (("minus", B - C, f"{b} − {c}"), ("minus", C - B, f"{c} − {b}"),
                                      ("plus", B + C, f"{b} + {c}"), ("times", B * C, f"{b} × {c}")):
                    if float(np.mean(np.abs(A - val) <= tol)) >= 0.98:
                        rels.append({"type": "derived", "from": [b, c], "to": a, "formula": expr, "confidence": 0.98,
                                     "description": f"'{a}' equals {expr} in the data."})
                        break

    # primary-key candidates
    for p in ids:
        if p.stats.get("nulls", 0) == 0 and p.stats.get("duplicates", 1) == 0:
            rels.append({"type": "primary_key", "column": p.name, "confidence": 1.0,
                         "description": f"'{p.name}' uniquely identifies each row."})
    return rels
