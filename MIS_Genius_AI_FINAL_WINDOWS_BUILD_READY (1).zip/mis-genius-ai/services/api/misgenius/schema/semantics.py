"""Lightweight semantic hints from column names and values.

These hints only *help* naming and default-dashboard choices. Nothing in the
engine requires any of them: a dataset with none of these words still gets a
full profile, KPIs, charts and insights based on types and statistics.
English, Hinglish and Hindi (Devanagari) keywords are recognised.
"""
from __future__ import annotations

import re

TAG_KEYWORDS: dict[str, list[str]] = {
    "money": [
        "amount", "amt", "value", "price", "cost", "revenue", "sales", "turnover", "income", "expense", "expenditure",
        "spend", "salary", "wage", "wages", "pay", "payment", "paid", "ctc", "fee", "fees", "charge", "charges", "tax",
        "gst", "tds", "balance", "debit", "credit", "profit", "loss", "budget", "mrp", "bill", "invoice value",
        "outstanding", "due", "receivable", "payable", "rs", "inr", "rupees", "₹", "net", "gross", "cogs", "discount amount",
        "premium", "claim", "loan", "emi", "interest", "fund", "grant", "allocation", "sanction", "disbursed",
        "राशि", "रकम", "खर्च", "व्यय", "बिक्री", "आय", "वेतन", "मूल्य", "कीमत", "शुल्क", "बजट", "भुगतान",
    ],
    "revenue_like": ["sales", "revenue", "turnover", "income", "receipt", "receipts", "billing", "gmv", "बिक्री", "आय", "राजस्व"],
    "cost_like": ["expense", "expenses", "cost", "expenditure", "spend", "cogs", "purchase", "outflow", "खर्च", "व्यय", "लागत"],
    "profit_like": ["profit", "earnings", "ebitda", "net income", "surplus", "मुनाफा", "लाभ"],
    "debit": ["debit", "dr", "withdrawal", "withdrawals"],
    "credit": ["credit", "cr", "deposit", "deposits"],
    "balance": ["balance", "closing balance", "opening balance", "शेष"],
    "quantity": ["qty", "quantity", "units", "pcs", "pieces", "volume", "nos", "count", "items", "stock", "inventory",
                 "मात्रा", "संख्या"],
    "stock": ["stock", "inventory", "on hand", "in stock", "closing stock", "opening stock", "reorder"],
    "percentage": ["%", "percent", "percentage", "pct", "ratio", "share", "margin", "प्रतिशत"],
    "status": ["status", "result", "attendance", "outcome", "stage", "state of", "approval", "पद", "स्थिति", "उपस्थिति"],
    "location": ["region", "zone", "area", "territory", "city", "state", "country", "district", "branch", "location",
                 "circle", "division", "taluka", "tehsil", "block", "village", "pincode", "pin code", "zip", "क्षेत्र",
                 "शहर", "राज्य", "जिला", "गांव"],
    "product": ["product", "item", "sku", "material", "category", "sub category", "subcategory", "brand", "model",
                "service", "उत्पाद", "वस्तु", "श्रेणी"],
    "person": ["customer", "client", "employee", "emp", "staff", "patient", "student", "vendor", "supplier", "party",
               "member", "beneficiary", "agent", "salesperson", "sales rep", "doctor", "teacher", "applicant",
               "ग्राहक", "कर्मचारी", "मरीज", "छात्र", "विक्रेता", "लाभार्थी"],
    "org_unit": ["department", "dept", "team", "business unit", "cost center", "cost centre", "function", "section", "office",
                 "project", "scheme", "विभाग", "योजना", "परियोजना"],
    "time_part": ["year", "month", "quarter", "week", "day", "fy", "financial year", "period", "वर्ष", "महीना", "माह"],
    "date": ["date", "dt", "time", "timestamp", "created", "updated", "dob", "joining", "doj", "posted", "period",
             "दिनांक", "तारीख"],
    "contact": ["email", "e-mail", "mail", "phone", "mobile", "contact", "whatsapp"],
    "score": ["score", "marks", "grade", "rating", "points", "अंक"],
    "duration": ["hours", "hrs", "days", "minutes", "mins", "duration", "tenure", "age", "आयु"],
    "identifier": ["id", "code", "no", "no.", "number", "num", "#", "sku", "ref", "reference", "voucher", "invoice",
                   "bill no", "txn", "transaction id", "order id", "uid", "uuid", "roll", "registration", "reg",
                   "account no", "a/c", "pan", "gstin", "aadhaar", "aadhar", "folio", "serial", "sr", "s.no", "sl",
                   "क्रमांक", "संख्या क्र"],
}

_TOKEN_RE = re.compile(r"[a-z0-9%₹#/]+|[ऀ-ॿ]+")


def name_tokens(name: str) -> list[str]:
    s = re.sub(r"(?<=[a-z])(?=[A-Z])", " ", name)
    s = s.lower().replace("_", " ").replace("-", " ").replace(".", " ")
    return _TOKEN_RE.findall(s)


def has_keyword(name: str, keywords: list[str]) -> bool:
    low = " " + " ".join(name_tokens(name)) + " "
    raw = name.lower()
    for kw in keywords:
        if kw in ("%", "₹", "#"):
            if kw in raw:
                return True
            continue
        if re.search(r"[ऀ-ॿ]", kw):
            if kw in raw:
                return True
            continue
        if f" {kw} " in low:
            return True
    return False


def tags_for_name(name: str) -> list[str]:
    return [tag for tag, kws in TAG_KEYWORDS.items() if has_keyword(name, kws)]


DOMAIN_RULES: dict[str, dict[str, list[str]]] = {
    "sales": {"any": ["sales", "revenue", "order", "invoice", "customer", "product", "sku", "discount", "units sold", "बिक्री"]},
    "expenses": {"any": ["expense", "expenditure", "spend", "cost center", "reimbursement", "vendor", "खर्च", "व्यय"]},
    "finance_accounting": {"any": ["debit", "credit", "balance", "ledger", "voucher", "journal", "account", "narration", "gst", "tds"]},
    "banking": {"any": ["transaction", "withdrawal", "deposit", "cheque", "ifsc", "account no", "balance", "utr"]},
    "hr_payroll": {"any": ["employee", "emp", "salary", "ctc", "basic", "hra", "pf", "esi", "designation", "department", "doj", "वेतन"]},
    "attendance": {"any": ["attendance", "present", "absent", "leave", "in time", "out time", "check in", "check out", "shift", "उपस्थिति"]},
    "inventory": {"any": ["stock", "inventory", "warehouse", "reorder", "on hand", "sku", "opening stock", "closing stock", "bin"]},
    "procurement": {"any": ["purchase order", "po", "vendor", "supplier", "grn", "requisition", "tender", "procurement"]},
    "logistics": {"any": ["shipment", "delivery", "dispatch", "awb", "tracking", "transporter", "vehicle", "freight", "route"]},
    "medical": {"any": ["patient", "diagnosis", "doctor", "ward", "admission", "discharge", "icd", "hospital", "treatment", "मरीज"]},
    "education": {"any": ["student", "marks", "grade", "class", "subject", "roll", "exam", "school", "semester", "छात्र"]},
    "projects": {"any": ["project", "task", "milestone", "progress", "completion", "physical progress", "scheme", "work order", "योजना"]},
    "production": {"any": ["production", "output", "machine", "batch", "downtime", "yield", "rejection", "shift"]},
    "customers_crm": {"any": ["lead", "customer", "contact", "email", "phone", "segment", "churn", "opportunity"]},
    "certificates_allotments": {"any": ["certificate", "allotment", "allottee", "license", "licence", "issued", "validity", "application no"]},
}


def guess_domains(column_names: list[str], sample_values: dict[str, list[str]] | None = None) -> list[dict[str, float | str]]:
    scores: dict[str, float] = {}
    joined = [" ".join(name_tokens(c)) for c in column_names]
    for domain, rule in DOMAIN_RULES.items():
        hits = 0
        for kw in rule["any"]:
            for n in joined:
                if f" {kw} " in f" {n} " or (re.search(r"[ऀ-ॿ]", kw) and kw in n):
                    hits += 1
                    break
        if hits:
            scores[domain] = hits
    if sample_values:
        vals = " ".join(" ".join(v[:50]) for v in sample_values.values()).lower()
        if re.search(r"\b(present|absent|p|a|leave)\b", vals) and any("attend" in n or "status" in n for n in joined):
            scores["attendance"] = scores.get("attendance", 0) + 3
    if not scores:
        return [{"domain": "general", "confidence": 0.5}]
    total = sum(scores.values())
    ranked = sorted(scores.items(), key=lambda kv: -kv[1])[:3]
    return [{"domain": d, "confidence": round(min(0.95, 0.35 + 0.65 * s / max(total, 1) * min(1, s / 3)), 2)} for d, s in ranked]


PII_PATTERNS = {
    "email": re.compile(r"^[^@\s]+@[^@\s]+\.[a-z]{2,}$", re.I),
    "phone": re.compile(r"^(\+?\d{1,3}[\s-]?)?[6-9]\d{9}$|^\+?\d[\d\s-]{9,14}$"),
    "pan": re.compile(r"^[A-Z]{5}\d{4}[A-Z]$"),
    "aadhaar": re.compile(r"^\d{4}\s?\d{4}\s?\d{4}$"),
    "gstin": re.compile(r"^\d{2}[A-Z]{5}\d{4}[A-Z]\d[Z][A-Z\d]$"),
}
