"""Data-quality engine: counts, percentages and actionable, bilingual explanations."""
from __future__ import annotations

from datetime import datetime
from typing import TYPE_CHECKING, Any

import pandas as pd

if TYPE_CHECKING:  # pragma: no cover
    from misgenius.schema.profiler import ColumnProfile

NUMERIC = {"integer", "decimal", "currency", "percentage"}


def _issue(kind: str, severity: str, column: str | None, en: str, hi: str, *, count: int | None = None,
           pct: float | None = None, examples: list[Any] | None = None, action: dict[str, Any] | None = None) -> dict[str, Any]:
    return {
        "type": kind, "severity": severity, "column": column, "message": en, "message_hi": hi,
        "count": count, "percent": pct, "examples": examples or [], "suggested_action": action,
    }


def _fmt(v: Any) -> str:
    if v is None:
        return "?"
    v = float(v)
    return f"{v:,.0f}" if abs(v) >= 100 else f"{v:,.2f}"


def build_quality_report(raw: pd.DataFrame, typed: pd.DataFrame, profiles: list[ColumnProfile]) -> dict[str, Any]:
    n_rows, n_cols = raw.shape
    cells = max(n_rows * n_cols, 1)
    null_counts = {p.name: p.stats.get("nulls", 0) for p in profiles}
    missing_cells = int(sum(null_counts.values()))
    # exact duplicate rows on the raw text (what the user sees in Excel)
    if n_rows:
        dup_mask = raw.astype(str).duplicated(keep="first")
        dup_rows = int(dup_mask.sum())
        dup_examples = [int(i) + 1 for i in raw.index[dup_mask][:5]]
    else:
        dup_rows, dup_examples = 0, []
    empty_cols = [p.name for p in profiles if p.data_type == "empty"]
    issues: list[dict[str, Any]] = []

    if dup_rows:
        pct = round(dup_rows / n_rows * 100, 2)
        issues.append(_issue(
            "duplicate_rows", "warning" if pct < 5 else "critical", None,
            f"{dup_rows:,} rows ({pct}%) are exact duplicates of another row. They are counted in totals unless removed.",
            f"{dup_rows:,} पंक्तियाँ ({pct}%) किसी दूसरी पंक्ति की हूबहू कॉपी हैं। हटाए बिना ये टोटल में गिनी जाती हैं।",
            count=dup_rows, pct=pct, examples=dup_examples, action={"op": "remove_duplicates"},
        ))
    for c in empty_cols:
        issues.append(_issue("empty_column", "info", c, f"Column '{c}' is completely empty.", f"कॉलम '{c}' पूरी तरह खाली है।",
                             action={"op": "remove_empty_columns"}))

    today = datetime.now()
    for p in profiles:
        if p.data_type == "empty":
            continue
        s = p.stats
        name = p.name
        null_pct = s.get("null_pct", 0.0)
        if null_pct > 0:
            sev = "info" if null_pct < 5 else ("warning" if null_pct < 30 else "critical")
            issues.append(_issue(
                "missing_values", sev, name,
                f"Column '{name}' has {s['nulls']:,} missing values ({null_pct}%).",
                f"कॉलम '{name}' में {s['nulls']:,} मान खाली हैं ({null_pct}%)।",
                count=s["nulls"], pct=null_pct,
                action={"op": "fill_missing", "params": {"column": name, "strategy": "zero" if p.data_type in NUMERIC else "value", "value": "Unknown"}},
            ))
        inv = p.issues.get("invalid")
        if inv:
            label = "numbers" if p.data_type in NUMERIC else ("dates" if p.data_type in ("date", "datetime") else "values")
            pct = round(inv["count"] / max(n_rows, 1) * 100, 2)
            issues.append(_issue(
                "invalid_" + ("numbers" if label == "numbers" else "dates" if label == "dates" else "values"), "warning", name,
                f"Column '{name}' has {inv['count']:,} values that are not valid {label} (e.g. {', '.join(map(str, inv['examples'][:3]))}). They are treated as blank in calculations.",
                f"कॉलम '{name}' में {inv['count']:,} मान सही {'संख्या' if label == 'numbers' else 'तारीख' if label == 'dates' else 'मान'} नहीं हैं (जैसे {', '.join(map(str, inv['examples'][:3]))})। गणना में इन्हें खाली माना गया है।",
                count=inv["count"], pct=pct, examples=inv["examples"],
                action={"op": "replace_values", "params": {"column": name}},
            ))
        if p.issues.get("date_formats"):
            fm = p.issues["date_formats"]
            issues.append(_issue(
                "inconsistent_date_formats", "warning", name,
                f"Column '{name}' mixes {len(fm)} date formats ({', '.join(sorted(fm))}). All were converted, but check the source system.",
                f"कॉलम '{name}' में {len(fm)} अलग-अलग तारीख फॉर्मेट हैं। सभी को बदल दिया गया है, फिर भी स्रोत जांचें।",
                count=sum(fm.values()), examples=sorted(fm), action={"op": "standardize_dates", "params": {"column": name}},
            ))
        if p.issues.get("date_ambiguous"):
            assumed = p.issues["date_ambiguous"]["assumed"]
            issues.append(_issue(
                "ambiguous_dates", "info", name,
                f"Dates in '{name}' like 05/06/2026 are ambiguous; they were read as {assumed}. Change it in column settings if wrong.",
                f"'{name}' की तारीखें (जैसे 05/06/2026) अस्पष्ट हैं; इन्हें {assumed} माना गया है। गलत हो तो कॉलम सेटिंग में बदलें।",
            ))
        if p.data_type in ("date", "datetime") and s.get("max"):
            try:
                mx = datetime.fromisoformat(s["max"])
                mn = datetime.fromisoformat(s["min"])
                if mx.year > today.year + 1:
                    issues.append(_issue("future_dates", "warning", name, f"Column '{name}' contains dates far in the future (up to {mx.date()}).",
                                         f"कॉलम '{name}' में भविष्य की तारीखें हैं ({mx.date()} तक)।"))
                if mn.year < 1950:
                    issues.append(_issue("old_dates", "info", name, f"Column '{name}' contains very old dates (from {mn.date()}). Check for data-entry errors.",
                                         f"कॉलम '{name}' में बहुत पुरानी तारीखें हैं ({mn.date()} से)।"))
            except ValueError:
                pass
        if p.data_type in NUMERIC:
            out = s.get("outliers_extreme", 0)
            if out and s.get("count"):
                pct = round(out / s["count"] * 100, 2)
                issues.append(_issue(
                    "outliers", "info" if pct < 1 else "warning", name,
                    f"Column '{name}' has {out:,} extreme value(s) ({pct}%) outside the expected range {_fmt(s.get('lower_fence'))} to {_fmt(s.get('upper_fence'))}. Check whether they are genuine.",
                    f"कॉलम '{name}' में {out:,} बहुत असामान्य मान ({pct}%) हैं जो अपेक्षित दायरे {_fmt(s.get('lower_fence'))} से {_fmt(s.get('upper_fence'))} के बाहर हैं। जाँचें कि ये सही हैं या नहीं।",
                    count=out, pct=pct, action={"op": "view_outliers", "params": {"column": name}},
                ))
            neg = s.get("negatives", 0)
            if neg and ("quantity" in p.semantic_tags or "stock" in p.semantic_tags):
                issues.append(_issue(
                    "suspicious_negatives", "warning", name,
                    f"Column '{name}' looks like a quantity but has {neg:,} negative values (returns or data-entry errors?).",
                    f"कॉलम '{name}' मात्रा जैसा है पर इसमें {neg:,} ऋणात्मक मान हैं।", count=neg,
                ))
            if p.issues.get("converted_fraction_to_percent"):
                issues.append(_issue("percent_scaled", "info", name,
                                     f"Values in '{name}' were stored as fractions (0.25) and are shown as percentages (25%).",
                                     f"'{name}' के मान भिन्न (0.25) में थे; इन्हें प्रतिशत (25%) में दिखाया गया है।"))
            if p.issues.get("drcr_notation"):
                issues.append(_issue("drcr", "info", name, f"'{name}' uses Dr/Cr notation; Dr values are treated as negative.",
                                     f"'{name}' में Dr/Cr लिखा है; Dr को ऋणात्मक माना गया है।"))
        if p.issues.get("mixed_types"):
            ratio = p.issues["mixed_types"]
            issues.append(_issue(
                "mixed_types", "warning", name,
                f"Column '{name}' mixes numbers ({round(ratio * 100)}%) and text, so it was treated as text. Convert it if it should be numeric.",
                f"कॉलम '{name}' में संख्याएँ ({round(ratio * 100)}%) और टेक्स्ट दोनों हैं, इसलिए इसे टेक्स्ट माना गया।",
                action={"op": "convert_type", "params": {"column": name, "data_type": "decimal"}},
            ))
        if p.issues.get("whitespace"):
            n = p.issues["whitespace"]
            issues.append(_issue("whitespace", "info", name, f"{n:,} values in '{name}' have leading/trailing spaces (they were trimmed for analysis).",
                                 f"'{name}' के {n:,} मानों में आगे/पीछे खाली जगह है।", count=n, action={"op": "trim_whitespace", "params": {"columns": [name]}}))
        if p.issues.get("case_variants"):
            cv = p.issues["case_variants"]
            ex = ["/".join(g) for g in cv["examples"]]
            issues.append(_issue(
                "case_variants", "warning", name,
                f"'{name}' has {cv['groups']} value(s) written in different ways ({'; '.join(ex)}). They are counted as separate categories until standardised.",
                f"'{name}' में {cv['groups']} मान अलग-अलग तरह से लिखे हैं ({'; '.join(ex)})।",
                count=cv["groups"], examples=ex, action={"op": "standardize_case", "params": {"columns": [name], "case": "title"}},
            ))
        if p.data_type == "identifier" and s.get("duplicates"):
            d = s["duplicates"]
            issues.append(_issue(
                "duplicate_ids", "warning", name, f"Column '{name}' looks like an ID but {d:,} values are repeated.",
                f"कॉलम '{name}' ID जैसा है पर {d:,} मान दोहराए गए हैं।", count=d,
            ))
        if p.issues.get("constant"):
            issues.append(_issue("constant_column", "info", name, f"Column '{name}' has the same value in every row.",
                                 f"कॉलम '{name}' की हर पंक्ति में एक ही मान है।"))
        if "pii" in p.semantic_tags:
            issues.append(_issue("personal_data", "info", name,
                                 f"Column '{name}' appears to contain personal identifiers ({p.semantic_tags[-1]}). Share exports carefully.",
                                 f"कॉलम '{name}' में व्यक्तिगत जानकारी लगती है। एक्सपोर्ट सावधानी से साझा करें।"))

    sev_weight = {"critical": 12, "warning": 4, "info": 0.5}
    score = 100.0 - sum(sev_weight[i["severity"]] for i in issues)
    score -= min(20.0, missing_cells / cells * 100)
    score = max(0.0, min(100.0, round(score, 1)))
    summary = {
        "rows": int(n_rows),
        "columns": int(n_cols),
        "missing_cells": missing_cells,
        "missing_pct": round(missing_cells / cells * 100, 2),
        "duplicate_rows": dup_rows,
        "duplicate_pct": round(dup_rows / max(n_rows, 1) * 100, 2),
        "empty_columns": len(empty_cols),
        "invalid_values": int(sum(p.stats.get("invalid", 0) for p in profiles)),
        "issues": len(issues),
        "score": score,
        "grade": "A" if score >= 90 else "B" if score >= 75 else "C" if score >= 60 else "D",
    }
    order = {"critical": 0, "warning": 1, "info": 2}
    issues.sort(key=lambda i: (order[i["severity"]], -(i.get("count") or 0)))
    per_column = {
        p.name: {
            "missing": p.stats.get("nulls", 0), "missing_pct": p.stats.get("null_pct", 0), "distinct": p.stats.get("distinct", 0),
            "invalid": p.stats.get("invalid", 0), "type_consistency": round(
                100 - (p.stats.get("invalid", 0) / max(p.stats.get("count", 0) or 1, 1) * 100), 2),
        }
        for p in profiles
    }
    return {"summary": summary, "issues": issues, "per_column": per_column, "duplicate_row_examples": dup_examples}
