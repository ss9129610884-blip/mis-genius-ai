"""Column type inference and semantic schema generation.

Input: a *raw* DataFrame (every cell is text or None — exactly what was in the
file) plus optional Excel number-format hints and user overrides.
Output: a typed DataFrame (numbers, dates, booleans, strings), the semantic
schema (types, roles, tags, confidence, stats, relationships, domain guess)
and a data-quality report. The raw DataFrame is never modified.
"""
from __future__ import annotations

import math
import re
from dataclasses import dataclass, field
from datetime import datetime
from typing import Any

import numpy as np
import pandas as pd

from misgenius.ingestion.parsing import (
    detect_dayfirst,
    excel_serial_to_datetime,
    is_null_like,
    parse_bool,
    parse_date,
    parse_number,
)
from misgenius.schema import semantics
from misgenius.schema.quality import build_quality_report
from misgenius.schema.relationships import detect_relationships

DATA_TYPES = [
    "integer", "decimal", "currency", "percentage", "date", "datetime", "boolean",
    "categorical", "text", "identifier", "empty",
]
ROLES = ["measure", "dimension", "time", "identifier", "attribute", "ignore"]
NUMERIC_TYPES = {"integer", "decimal", "currency", "percentage"}
SAMPLE_SIZE = 5000
TYPE_THRESHOLD = 0.8
CURRENCY_FORMAT_RE = re.compile(r"[₹$€£¥]|\[\$|Rs|INR", re.I)
DATE_FORMAT_RE = re.compile(r"(^|[^A-Za-z])(d{1,4}|m{1,4}|y{2,4})([^A-Za-z]|$)", re.I)


@dataclass
class ColumnProfile:
    name: str
    original_name: str
    position: int
    data_type: str
    role: str
    confidence: float
    semantic_tags: list[str] = field(default_factory=list)
    stats: dict[str, Any] = field(default_factory=dict)
    fmt: dict[str, Any] = field(default_factory=dict)
    label: str | None = None
    description: str | None = None
    user_override: bool = False
    issues: dict[str, Any] = field(default_factory=dict)  # internal: invalid values etc.

    def to_dict(self) -> dict[str, Any]:
        return {
            "name": self.name,
            "original_name": self.original_name,
            "position": self.position,
            "data_type": self.data_type,
            "role": self.role,
            "confidence": round(self.confidence, 3),
            "semantic_tags": self.semantic_tags,
            "stats": self.stats,
            "format": self.fmt,
            "label": self.label or self.name,
            "description": self.description,
            "user_override": self.user_override,
        }


@dataclass
class ProfileResult:
    typed: pd.DataFrame
    columns: list[ColumnProfile]
    schema: dict[str, Any]
    quality: dict[str, Any]


def _sample(values: list[Any], n: int = SAMPLE_SIZE) -> list[Any]:
    if len(values) <= n:
        return values
    half = n // 2
    step = max(1, (len(values) - half) // half)
    return values[:half] + values[half::step][:half]


def _json_num(v: Any) -> Any:
    if v is None:
        return None
    if isinstance(v, (np.integer,)):
        return int(v)
    if isinstance(v, (float, np.floating)):
        f = float(v)
        if math.isnan(f) or math.isinf(f):
            return None
        return round(f, 6)
    return v


# --------------------------------------------------------------------------- conversions
def convert_numeric(raw: pd.Series, drcr: bool = False, pct_fraction_to_percent: bool = False) -> tuple[pd.Series, pd.Series]:
    """Return (float series, invalid mask). Invalid = non-null text that is not a number."""
    s = raw.astype(object)
    null_mask = s.map(is_null_like)
    stripped = s.where(~null_mask, None)
    fast = pd.to_numeric(stripped, errors="coerce")
    need = fast.isna() & ~null_mask
    if need.any():
        memo: dict[Any, float | None] = {}

        def _p(v: Any) -> float:
            if v in memo:
                r = memo[v]
            else:
                pn = parse_number(v, drcr=drcr)
                r = memo[v] = (pn.value if pn else None)
            return np.nan if r is None else r

        fast = fast.astype("float64")
        fast.loc[need] = stripped[need].map(_p).astype("float64")
    out = fast.astype("float64")
    invalid = out.isna() & ~null_mask
    if pct_fraction_to_percent:
        out = out * 100.0
    return out, invalid


def convert_dates(raw: pd.Series, dayfirst: bool | None, serial: bool = False) -> tuple[pd.Series, pd.Series, dict[str, int]]:
    s = raw.astype(object)
    null_mask = s.map(is_null_like)
    formats: dict[str, int] = {}
    memo: dict[Any, Any] = {}

    def _p(v: Any) -> Any:
        if v in memo:
            return memo[v]
        d, fmt = parse_date(v, dayfirst)
        if d is None and serial:
            pn = parse_number(v)
            if pn is not None:
                d, fmt = excel_serial_to_datetime(pn.value), "excel_serial"
        if d is not None and not (1800 <= d.year <= 2300):
            d = None
        memo[v] = (d, fmt)
        return memo[v]

    parsed = s.where(~null_mask, None).map(lambda v: None if v is None else _p(v))
    vals = parsed.map(lambda t: t[0] if t else None)
    for t in parsed:
        if t and t[1]:
            formats[t[1]] = formats.get(t[1], 0) + 1
    out = pd.to_datetime(vals, errors="coerce")
    invalid = out.isna() & ~null_mask
    return out, invalid, formats


def convert_bool(raw: pd.Series) -> tuple[pd.Series, pd.Series]:
    s = raw.astype(object)
    null_mask = s.map(is_null_like)
    parsed = s.map(lambda v: None if is_null_like(v) else parse_bool(v))
    invalid = parsed.isna() & ~null_mask
    return parsed.astype("boolean"), invalid


def convert_text(raw: pd.Series) -> pd.Series:
    return raw.astype(object).map(lambda v: None if is_null_like(v) else str(v).strip()).astype("string")


# --------------------------------------------------------------------------- inference
_ID_STRONG = ["id", "code", "sku", "uuid", "uid", "txn", "voucher", "ref", "reference", "gstin", "pan", "aadhaar", "aadhar",
              "folio", "roll", "registration", "reg", "serial", "sr", "sl", "account", "invoice", "bill", "order", "#",
              "no", "number", "num", "pincode", "pin", "zip", "mobile", "phone", "email", "क्रमांक"]


def _id_name(name: str) -> bool:
    toks = semantics.name_tokens(name)
    if not toks:
        return False
    last = toks[-1]
    if last in ("id", "code", "no", "number", "num", "#", "uuid", "uid", "sku", "ref", "gstin", "pan", "aadhaar", "aadhar",
                "pincode", "zip", "mobile", "phone", "email", "folio", "क्रमांक"):
        return True
    if "number" in toks and ("count" in toks or "of" in toks):
        return False  # "Number of units"
    return any(t in ("id", "sku", "uuid", "gstin", "email", "phone", "mobile") for t in toks)


def infer_column(name: str, raw: pd.Series, hint: str | None, dayfirst_default: bool) -> dict[str, Any]:
    """Infer type for one raw column. Returns a dict of decisions + evidence."""
    values = [v for v in raw.tolist() if not is_null_like(v)]
    n_total = len(raw)
    n = len(values)
    tags = semantics.tags_for_name(name)
    if n == 0:
        return {"data_type": "empty", "role": "ignore", "confidence": 1.0, "tags": tags}
    sample = _sample(values)
    ns = len(sample)
    str_sample = [str(v).strip() for v in sample]

    # --- booleans (words only; 0/1 stays numeric) ---
    bools = [parse_bool(v) for v in str_sample]
    word_bools = [v for v in str_sample if v.lower() not in ("0", "1")]
    bool_ratio = sum(b is not None for b in bools) / ns
    distinct_lower = {v.lower() for v in str_sample}
    if bool_ratio >= 0.95 and word_bools and len(distinct_lower) <= 4:
        return {"data_type": "boolean", "role": "dimension", "confidence": bool_ratio, "tags": tags}

    # --- dates ---
    dayfirst, ambiguous = detect_dayfirst(str_sample)
    use_dayfirst = dayfirst if dayfirst is not None else dayfirst_default
    date_hits, fmts, with_time = 0, set(), 0
    for v in str_sample:
        d, f = parse_date(v, use_dayfirst)
        if d is not None and 1800 <= d.year <= 2300:
            date_hits += 1
            fmts.add(f)
            if d.hour or d.minute or d.second:
                with_time += 1
    date_ratio = date_hits / ns

    # --- numbers ---
    drcr = any(re.search(r"\d\s?cr\.?$", v.lower()) for v in str_sample) and any(
        re.search(r"\d\s?dr\.?$", v.lower()) for v in str_sample
    )
    parsed = [parse_number(v, drcr=drcr) for v in str_sample]
    nums = [p for p in parsed if p is not None]
    num_ratio = len(nums) / ns

    date_name = "date" in tags or bool(re.search(r"(date|dt|dob|doj|timestamp|दिनांक|तारीख)", name.lower()))
    hint_is_date = bool(hint and DATE_FORMAT_RE.search(hint) and not CURRENCY_FORMAT_RE.search(hint) and "0" not in hint)
    serial = False
    if num_ratio >= TYPE_THRESHOLD and (date_name or hint_is_date) and date_ratio < 0.5:
        vals = [p.value for p in nums]
        if vals and all(20000 <= x <= 80000 for x in vals):  # Excel serials (1954–2119)
            serial, date_ratio, num_ratio = True, num_ratio, 0.0

    if date_ratio >= TYPE_THRESHOLD and date_ratio >= num_ratio:
        # A column of plain years (2019, 2020) parses as numbers, not dates, so it is handled below.
        dtype = "datetime" if with_time / max(date_hits, 1) > 0.3 else "date"
        conf = date_ratio * (0.85 if ambiguous and "dmy_or_mdy" in fmts else 1.0)
        return {
            "data_type": dtype, "role": "time", "confidence": conf, "tags": tags,
            "dayfirst": use_dayfirst, "date_ambiguous": bool(ambiguous and "dmy_or_mdy" in fmts),
            "date_formats": sorted(f for f in fmts if f), "excel_serial": serial,
        }

    if num_ratio >= TYPE_THRESHOLD:
        vals = [p.value for p in nums]
        pct_text = sum(p.percent for p in nums) / len(nums)
        cur_text = [p.currency for p in nums if p.currency]
        hint_pct = bool(hint and "%" in hint)
        hint_cur = bool(hint and CURRENCY_FORMAT_RE.search(hint))
        is_int = all(float(x).is_integer() for x in vals)
        distinct = len(set(vals))
        uniq_ratio = distinct / len(vals)
        res: dict[str, Any] = {"confidence": num_ratio, "tags": tags, "drcr": drcr}
        fmt: dict[str, Any] = {}
        # identifiers stored as numbers (Emp ID 1001, Pincode 411001)
        if _id_name(name) and is_int and (uniq_ratio > 0.3 or "pincode" in name.lower() or "zip" in name.lower()):
            return {**res, "data_type": "identifier", "role": "identifier", "confidence": 0.9, "numeric_identifier": True}
        tlow = name.lower()
        if is_int and vals and all(1900 <= x <= 2100 for x in vals) and ("year" in tlow or "fy" in semantics.name_tokens(name) or "वर्ष" in tlow):
            return {**res, "data_type": "integer", "role": "time", "time_part": "year"}
        if is_int and vals and all(1 <= x <= 12 for x in vals) and ("month" in tlow or "माह" in tlow or "महीना" in tlow):
            return {**res, "data_type": "integer", "role": "time", "time_part": "month"}
        if is_int and vals and all(1 <= x <= 4 for x in vals) and ("quarter" in tlow or re.search(r"\bqtr\b", tlow)):
            return {**res, "data_type": "integer", "role": "time", "time_part": "quarter"}
        if pct_text >= 0.5 or hint_pct or ("percentage" in tags and vals and min(vals) >= -100 and max(vals) <= 100):
            scale_fraction = (hint_pct and pct_text < 0.5) or ("percentage" in tags and pct_text < 0.5 and max(abs(x) for x in vals) <= 1.0 and not is_int)
            fmt = {"percent": True, "decimals": 1}
            return {**res, "data_type": "percentage", "role": "measure", "format": fmt, "pct_fraction": bool(scale_fraction)}
        if cur_text or hint_cur or "money" in tags:
            code = max(set(cur_text), key=cur_text.count) if cur_text else ("INR" if hint and re.search(r"₹|INR|Rs", hint) else None)
            fmt = {"currency": code or "", "decimals": 0 if is_int else 2}
            conf = num_ratio if (cur_text or hint_cur) else num_ratio * 0.85
            return {**res, "data_type": "currency", "role": "measure", "format": fmt, "confidence": conf}
        # low-cardinality integer codes (e.g. "Grade 1..5", "Zone 1..4") remain measures but are flagged
        dtype = "integer" if is_int else "decimal"
        res.update({"data_type": dtype, "role": "measure", "format": {"decimals": 0 if is_int else 2}})
        if is_int and distinct <= 12 and len(vals) >= 50 and ("status" in tags or "location" in tags or "org_unit" in tags):
            res.update({"role": "dimension", "confidence": 0.7})
        return res

    # --- strings: identifier / categorical / text ---
    col_vals = [str(v).strip() for v in values]
    distinct = len(set(col_vals))
    uniq_ratio = distinct / n
    avg_len = sum(len(v) for v in str_sample) / ns
    pii = None
    for kind, pat in semantics.PII_PATTERNS.items():
        hits = sum(1 for v in str_sample[:500] if pat.match(v))
        if hits / min(ns, 500) >= 0.8:
            pii = kind
            break
    mixed_numeric = 0.3 <= num_ratio < TYPE_THRESHOLD
    base = {"tags": tags + (["pii", pii] if pii else []), "mixed_numeric_ratio": round(num_ratio, 3) if mixed_numeric else None}
    if pii in ("email", "phone", "pan", "aadhaar", "gstin"):
        return {**base, "data_type": "identifier", "role": "identifier", "confidence": 0.9}
    has_digits = sum(1 for v in str_sample if re.search(r"\d", v)) / ns
    if _id_name(name) and uniq_ratio >= 0.5:
        return {**base, "data_type": "identifier", "role": "identifier", "confidence": 0.95}
    if uniq_ratio >= 0.95 and n >= 20 and avg_len <= 40 and has_digits >= 0.8:
        return {**base, "data_type": "identifier", "role": "identifier", "confidence": 0.75}
    if avg_len > 60:
        return {**base, "data_type": "text", "role": "attribute", "confidence": 0.85}
    if distinct <= 50 or (uniq_ratio <= 0.5 and distinct <= 5000):
        conf = 0.95 if distinct <= 50 else 0.8
        return {**base, "data_type": "categorical", "role": "dimension", "confidence": conf}
    if uniq_ratio < 0.9 and avg_len <= 40:
        return {**base, "data_type": "categorical", "role": "dimension", "confidence": 0.65, "high_cardinality": True}
    return {**base, "data_type": "text", "role": "attribute", "confidence": 0.7}


def robust_fences(x: pd.Series) -> tuple[float | None, float | None, str]:
    """Extreme-value fences that respect skewed and zero-inflated business data.

    Money columns are usually right-skewed (a laptop order vs a keyboard order),
    so fences are computed on log scale when the data is positive and skewed.
    Zero-inflated columns (e.g. hours = 0 on leave days) ignore the zeros.
    """
    base = x.dropna()
    method = "iqr"
    if len(base) and (base == 0).mean() > 0.05:
        base = base[base != 0]
        method = "iqr_nonzero"
    if len(base) < 8:
        return None, None, method
    if base.min() > 0 and base.skew() > 1:
        lb = np.log(base)
        q1, q3 = lb.quantile(0.25), lb.quantile(0.75)
        iqr = q3 - q1
        if iqr <= 0:
            return None, None, method
        return float(np.exp(q1 - 3 * iqr)), float(np.exp(q3 + 3 * iqr)), method + "_log"
    q1, q3 = base.quantile(0.25), base.quantile(0.75)
    iqr = q3 - q1
    if iqr <= 0:
        return None, None, method
    return float(q1 - 3 * iqr), float(q3 + 3 * iqr), method


def _numeric_stats(s: pd.Series) -> dict[str, Any]:
    x = s.dropna()
    if x.empty:
        return {}
    q1, q3 = x.quantile(0.25), x.quantile(0.75)
    lo, hi, method = robust_fences(x)
    nz = x if method.startswith("iqr_nonzero") is False else x[x != 0]
    extreme = int(((nz < lo) | (nz > hi)).sum()) if lo is not None else 0
    return {
        "min": _json_num(x.min()), "max": _json_num(x.max()), "mean": _json_num(x.mean()), "median": _json_num(x.median()),
        "std": _json_num(x.std()) if len(x) > 1 else 0.0, "sum": _json_num(x.sum()), "q1": _json_num(q1), "q3": _json_num(q3),
        "negatives": int((x < 0).sum()), "zeros": int((x == 0).sum()),
        "outliers_extreme": extreme, "lower_fence": _json_num(lo), "upper_fence": _json_num(hi), "outlier_method": method,
        "skew": _json_num(x.skew()) if len(x) > 2 else None,
    }


def _top_values(s: pd.Series, k: int = 10) -> list[dict[str, Any]]:
    vc = s.dropna().astype(str).value_counts().head(k)
    total = int(s.notna().sum()) or 1
    return [{"value": str(v), "count": int(c), "share": round(int(c) / total, 4)} for v, c in vc.items()]


def profile_dataframe(
    raw: pd.DataFrame,
    *,
    format_hints: dict[str, str | None] | None = None,
    overrides: dict[str, dict[str, Any]] | None = None,
    original_names: dict[str, str] | None = None,
    dayfirst_default: bool = True,
) -> ProfileResult:
    format_hints = format_hints or {}
    overrides = overrides or {}
    original_names = original_names or {}
    typed_cols: dict[str, pd.Series] = {}
    profiles: list[ColumnProfile] = []
    n_rows = len(raw)

    for pos, col in enumerate(raw.columns):
        series = raw[col]
        inf = infer_column(col, series, format_hints.get(col), dayfirst_default)
        ov = overrides.get(col, {})
        dtype = ov.get("data_type") or inf["data_type"]
        role = ov.get("role") or inf["role"]
        if ov.get("data_type") and not ov.get("role"):
            role = {
                "date": "time", "datetime": "time", "identifier": "identifier", "text": "attribute", "empty": "ignore",
                "categorical": "dimension", "boolean": "dimension",
            }.get(dtype, "measure")
        conf = 1.0 if ov else float(inf.get("confidence", 1.0))
        issues: dict[str, Any] = {}
        fmt = dict(inf.get("format") or {})
        if ov.get("format"):
            fmt.update(ov["format"])

        null_mask = series.map(is_null_like)
        if dtype in NUMERIC_TYPES:
            typed, invalid = convert_numeric(series, drcr=bool(inf.get("drcr")), pct_fraction_to_percent=bool(inf.get("pct_fraction")) and dtype == "percentage" and not ov.get("data_type"))
            if dtype == "percentage":
                fmt.setdefault("percent", True)
                if inf.get("pct_fraction") and not ov.get("data_type"):
                    issues["converted_fraction_to_percent"] = True
            if dtype == "currency":
                fmt.setdefault("currency", "")
            if inf.get("drcr"):
                issues["drcr_notation"] = True
        elif dtype in ("date", "datetime"):
            dfirst = ov["dayfirst"] if "dayfirst" in ov else inf.get("dayfirst", dayfirst_default)
            typed, invalid, fmts = convert_dates(series, dfirst, serial=bool(inf.get("excel_serial")))
            if len([f for f in fmts if f not in ("native",)]) > 1:
                issues["date_formats"] = fmts
            if inf.get("date_ambiguous") and "dayfirst" not in ov:
                issues["date_ambiguous"] = {"assumed": "day-first (DD/MM)" if inf.get("dayfirst", dayfirst_default) else "month-first (MM/DD)"}
            fmt.setdefault("date", "datetime" if dtype == "datetime" else "date")
        elif dtype == "boolean":
            typed, invalid = convert_bool(series)
        else:
            typed = convert_text(series)
            invalid = pd.Series(False, index=series.index)
        typed_cols[col] = typed

        n_null = int(null_mask.sum())
        n_invalid = int(invalid.sum())
        if n_invalid:
            examples = series[invalid].astype(str).drop_duplicates().head(5).tolist()
            issues["invalid"] = {"count": n_invalid, "examples": examples}
        non_null_typed = typed.dropna()
        distinct = int(non_null_typed.astype(str).nunique()) if len(non_null_typed) else 0
        stats: dict[str, Any] = {
            "count": int(n_rows - n_null),
            "nulls": n_null,
            "null_pct": round(n_null / n_rows * 100, 2) if n_rows else 0.0,
            "distinct": distinct,
            "distinct_pct": round(distinct / max(n_rows - n_null, 1) * 100, 2),
            "invalid": n_invalid,
        }
        if dtype in NUMERIC_TYPES:
            stats.update(_numeric_stats(typed))
        elif dtype in ("date", "datetime"):
            nn = typed.dropna()
            if not nn.empty:
                stats.update({"min": nn.min().isoformat(), "max": nn.max().isoformat(),
                              "span_days": int((nn.max() - nn.min()).days)})
        if dtype in ("categorical", "boolean", "text", "identifier") or role == "dimension":
            stats["top_values"] = _top_values(typed)
        if dtype in ("categorical", "text", "identifier"):
            s_str = series[~null_mask].astype(str)
            ws = int((s_str != s_str.str.strip()).sum())
            if ws:
                issues["whitespace"] = ws
            if dtype == "categorical":
                norm = s_str.str.strip().str.lower()
                groups = s_str.str.strip().groupby(norm).nunique()
                variants = groups[groups > 1]
                if len(variants):
                    issues["case_variants"] = {
                        "groups": int(len(variants)),
                        "examples": [sorted(s_str.str.strip()[norm == k].unique().tolist())[:4] for k in variants.index[:3]],
                    }
        if dtype == "identifier":
            dups = int(non_null_typed.astype(str).duplicated().sum())
            stats["duplicates"] = dups
        if inf.get("mixed_numeric_ratio"):
            issues["mixed_types"] = inf["mixed_numeric_ratio"]
        if distinct == 1 and n_rows > 1:
            issues["constant"] = True

        tags = list(dict.fromkeys(inf.get("tags", [])))
        if inf.get("time_part"):
            tags.append(f"time_part:{inf['time_part']}")
        if inf.get("high_cardinality"):
            tags.append("high_cardinality")
        profiles.append(
            ColumnProfile(
                name=col,
                original_name=original_names.get(col, col),
                position=pos,
                data_type=dtype,
                role=role,
                confidence=conf,
                semantic_tags=tags,
                stats=stats,
                fmt=fmt,
                label=ov.get("label"),
                description=ov.get("description"),
                user_override=bool(ov),
                issues=issues,
            )
        )

    typed_df = pd.DataFrame(typed_cols, index=raw.index)
    relationships = detect_relationships(typed_df, profiles)
    quality = build_quality_report(raw, typed_df, profiles)
    schema = build_schema(profiles, relationships, quality, n_rows)
    return ProfileResult(typed=typed_df, columns=profiles, schema=schema, quality=quality)


def build_schema(profiles: list[ColumnProfile], relationships: list[dict[str, Any]], quality: dict[str, Any], n_rows: int) -> dict[str, Any]:
    by = lambda pred: [p.name for p in profiles if pred(p)]  # noqa: E731
    date_cols = by(lambda p: p.data_type in ("date", "datetime"))
    primary_date = None
    if date_cols:
        cands = [p for p in profiles if p.name in date_cols]
        cands.sort(key=lambda p: (-(p.stats.get("count", 0)), -int("date" in p.semantic_tags), -(p.stats.get("distinct", 0))))
        primary_date = cands[0].name
    domains = semantics.guess_domains(
        [p.name for p in profiles],
        {p.name: [t["value"] for t in p.stats.get("top_values", [])] for p in profiles if p.stats.get("top_values")},
    )
    return {
        "row_count": n_rows,
        "column_count": len(profiles),
        "columns": [p.to_dict() for p in profiles],
        "dimensions": by(lambda p: p.role == "dimension"),
        "measures": by(lambda p: p.role == "measure"),
        "time_columns": by(lambda p: p.role == "time"),
        "date_columns": date_cols,
        "primary_date_column": primary_date,
        "categorical_columns": by(lambda p: p.data_type in ("categorical", "boolean")),
        "numeric_columns": by(lambda p: p.data_type in NUMERIC_TYPES),
        "text_columns": by(lambda p: p.data_type == "text"),
        "identifier_columns": by(lambda p: p.data_type == "identifier"),
        "possible_currency_columns": by(lambda p: p.data_type == "currency" or ("money" in p.semantic_tags and p.data_type in NUMERIC_TYPES)),
        "possible_percentage_columns": by(lambda p: p.data_type == "percentage"),
        "boolean_columns": by(lambda p: p.data_type == "boolean"),
        "empty_columns": by(lambda p: p.data_type == "empty"),
        "data_quality": quality.get("summary", {}),
        "relationships": relationships,
        "confidence": {p.name: round(p.confidence, 3) for p in profiles},
        "domain": {"guess": domains[0]["domain"], "candidates": domains},
        "profiled_at": datetime.utcnow().isoformat(timespec="seconds") + "Z",
    }


def raw_frame(columns: list[str], rows: list[list[Any]]) -> pd.DataFrame:
    """Build the immutable raw (all-text) DataFrame from detected table rows."""
    from misgenius.ingestion.parsing import to_text

    width = len(columns)
    data = {c: [] for c in columns}
    for row in rows:
        for i, c in enumerate(columns):
            v = row[i] if i < len(row) else None
            if isinstance(v, str):
                data[c].append(v if v.strip() else None)
            else:
                data[c].append(to_text(v))
    del width
    return pd.DataFrame({c: pd.Series(v, dtype=object) for c, v in data.items()})
