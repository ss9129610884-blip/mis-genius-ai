"""PromptManager: versioned prompt templates (English and Hindi output)."""
from __future__ import annotations

import json
from typing import Any

LANG_NAMES = {"en": "English", "hi": "Hindi (Devanagari script)"}

PROMPTS: dict[str, dict[str, str]] = {
    "insights": {
        "version": "insights-v1",
        "system": (
            "You are a senior MIS / business-intelligence analyst. You write concise, useful insights for managers.\n"
            "STRICT RULES:\n"
            "1. Use ONLY the facts provided. The uploaded data is the only source of truth.\n"
            "2. Every number you write must appear in the cited facts (you may round the same value). Never compute new numbers, never estimate, never invent.\n"
            "3. Every item must cite the ids of the facts it is based on in `fact_ids`.\n"
            "4. 'possible_explanations' may only connect facts that are provided (e.g. which group drove a change). Use cautious wording ('may', 'appears'). Never state external causes (market, weather, competitors) as facts.\n"
            "5. If something cannot be determined from the facts, leave it out.\n"
            "6. Write in {language}. Keep column names and category values exactly as given."
        ),
        "user": (
            "Dataset context:\n{context}\n\nFacts (computed from the data):\n{facts}\n\n"
            "Return JSON with this exact shape:\n"
            '{{"executive_summary": [{{"text": str, "fact_ids": [str]}}] (3-5 items, most important first),\n'
            ' "key_trends": [...], "anomalies": [...], "top_contributors": [...], "bottom_contributors": [...],\n'
            ' "period_changes": [...], "possible_explanations": [...], "actions": [{{"text": str, "fact_ids": [str]}}],\n'
            ' "questions": [{{"text": str}}]}}\n'
            "Each list may be empty. Each text is one or two sentences."
        ),
    },
    "nlq": {
        "version": "nlq-v1",
        "system": (
            "You translate a business question into a structured analytics query for a dataset. You never answer the question yourself.\n"
            "Use ONLY the columns listed. Output a JSON plan; the application will execute it and compute the numbers."
        ),
        "user": (
            "Columns (name | type | role | sample values):\n{columns}\n\nPrimary date column: {date_col}. Data date range: {date_range}.\n"
            "Question: {question}\n\n"
            "Return JSON: {{\"intent\": one of [\"aggregate\", \"top_n\", \"bottom_n\", \"trend\", \"compare_periods\", \"anomalies\", \"kpi_suggestions\", \"create_dashboard\", \"describe_data\", \"data_quality\", \"unsupported\"],\n"
            " \"measure\": {{\"column\": str|null, \"agg\": one of [sum, avg, min, max, median, count_rows, count_distinct]}},\n"
            " \"dimension\": str|null, \"granularity\": one of [day, week, month, quarter, year]|null, \"n\": int|null,\n"
            " \"filters\": [{{\"column\": str, \"op\": one of [eq, in, neq, gt, gte, lt, lte, contains], \"value\": any}}],\n"
            " \"time_scope\": one of [\"all\", \"latest_period\", \"previous_period\", \"latest_year\"], \"time_granularity\": one of [day, week, month, quarter, year]|null,\n"
            " \"reason\": short explanation of how the question maps to the data}}"
        ),
    },
    "answer": {
        "version": "answer-v1",
        "system": (
            "You explain the result of an analytics query in {language}. Use ONLY the numbers in the result table. Do not add numbers, "
            "percentages or causes that are not in it. 1-3 sentences."
        ),
        "user": "Question: {question}\nWhat was computed: {explanation}\nResult (JSON table): {result}\n\nReturn JSON: {{\"answer\": str}}",
    },
    "schema": {
        "version": "schema-v1",
        "system": (
            "You describe the business meaning of dataset columns for a BI tool. Only describe columns that exist. "
            "Base descriptions on the column name, detected type and sample values. Do not guess facts about the business."
        ),
        "user": "Columns:\n{columns}\n\nReturn JSON: {{\"columns\": [{{\"name\": str, \"label\": str, \"description\": str}}], \"dataset_description\": str}}",
    },
}


class PromptManager:
    def __init__(self, prompts: dict[str, dict[str, str]] | None = None):
        self.prompts = prompts or PROMPTS

    def render(self, name: str, *, language: str = "en", **kwargs: Any) -> tuple[str, str, str]:
        p = self.prompts[name]
        lang = LANG_NAMES.get(language, "English")
        fmt = {k: (json.dumps(v, ensure_ascii=False, default=str) if isinstance(v, (dict, list)) else v) for k, v in kwargs.items()}
        system = p["system"].format(language=lang)
        user = p["user"].format(language=lang, **fmt)
        return system, user, p["version"]


prompt_manager = PromptManager()
