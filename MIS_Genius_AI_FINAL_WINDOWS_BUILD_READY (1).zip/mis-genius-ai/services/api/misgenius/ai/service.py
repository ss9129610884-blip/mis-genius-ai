"""AIService: resolves the configured provider (org setting → environment) and exposes
the AI features. API keys are decrypted only here, server-side."""
from __future__ import annotations

from typing import Any

from misgenius.ai.insights import InsightEngine
from misgenius.ai.nlq import NLQEngine
from misgenius.ai.providers import AIConfig, AIProvider, make_provider
from misgenius.ai.schema_interpreter import SchemaInterpreter
from misgenius.config import Settings


def resolve_config(settings: Settings, org_setting: Any | None, decrypt) -> AIConfig:
    """Org-level settings override environment defaults when enabled."""
    if org_setting is not None and org_setting.enabled and org_setting.provider and org_setting.provider != "none":
        key = decrypt(org_setting.api_key_encrypted) if org_setting.api_key_encrypted else None
        return AIConfig(provider=org_setting.provider, api_key=key, model=org_setting.model or None,
                        base_url=org_setting.base_url or None, timeout=settings.AI_TIMEOUT_SECONDS)
    if org_setting is not None and not org_setting.enabled:
        return AIConfig(provider="none")
    return AIConfig(provider=settings.AI_PROVIDER, api_key=settings.AI_API_KEY, model=settings.AI_MODEL,
                    base_url=settings.AI_BASE_URL, timeout=settings.AI_TIMEOUT_SECONDS)


class AIService:
    def __init__(self, provider: AIProvider):
        self.provider = provider
        self.insights = InsightEngine(provider)
        self.nlq = NLQEngine(provider)
        self.schema = SchemaInterpreter(provider)

    @classmethod
    def from_config(cls, cfg: AIConfig) -> AIService:
        return cls(make_provider(cfg))

    @property
    def status(self) -> dict[str, Any]:
        return {"available": self.provider.available, "provider": self.provider.name, "model": self.provider.model if self.provider.available else None,
                "mode": "ai" if self.provider.available else "deterministic"}
