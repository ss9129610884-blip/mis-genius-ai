"""Grounding validation: every number an AI writes must exist in the computed facts."""
from __future__ import annotations

import re
from typing import Any

_UNITS = {
    "cr": 1e7, "crore": 1e7, "crores": 1e7, "करोड़": 1e7, "l": 1e5, "lakh": 1e5, "lakhs": 1e5, "lac": 1e5, "लाख": 1e5,
    "k": 1e3, "thousand": 1e3, "हज़ार": 1e3, "हजार": 1e3, "m": 1e6, "mn": 1e6, "million": 1e6, "b": 1e9, "bn": 1e9, "billion": 1e9,
}
_NUM = re.compile(
    r"(?<![\w.])(-|−)?\s?(?:₹|rs\.?\s?|inr\s?|\$|€|£)?\s?(\d{1,3}(?:,\d{2,3})+(?:\.\d+)?|\d+(?:\.\d+)?)\s?"
    r"(crores?|crore|cr|lakhs?|lac|l|k|thousand|mn|million|bn|billion|m|b|करोड़|लाख|हज़ार|हजार)?(?![\w])",
    re.I,
)
_MONTHS = r"(jan|feb|mar|apr|may|jun|jul|aug|sep|sept|oct|nov|dec)[a-z]*"


def extract_numbers(text: str) -> list[float]:
    t = re.sub(_MONTHS + r"\s+\d{4}", " ", text, flags=re.I)  # "Mar 2026" is a period, not a claim
    t = re.sub(r"\b(q[1-4]|fy)\s?-?\d{2,4}(-\d{2})?\b", " ", t, flags=re.I)
    t = re.sub(r"\b\d{4}-\d{2}-\d{2}\b", " ", t)
    t = re.sub(r"\bweek of \d{1,2}\b", " ", t, flags=re.I)
    t = re.sub(r"\b[A-Z]{2,}[-_]?\d+\b", " ", t)  # codes like SO-25668, EMP1014
    out: list[float] = []
    for m in _NUM.finditer(t):
        neg, num, unit = m.group(1), m.group(2), (m.group(3) or "").lower()
        try:
            v = float(num.replace(",", ""))
        except ValueError:
            continue
        if unit in ("l", "m", "b") and not re.search(r"\d\s?" + unit + r"\b", m.group(0), re.I):
            unit = ""
        v *= _UNITS.get(unit, 1.0)
        if neg:
            v = -v
        out.append(v)
    return out


def _close(a: float, b: float) -> bool:
    if a == b:
        return True
    if abs(a - b) <= 0.051 and max(abs(a), abs(b)) < 100:
        return True
    denom = max(abs(a), abs(b), 1e-12)
    return abs(a - b) / denom <= 0.015


def allowed_numbers(facts: list[dict[str, Any]]) -> list[float]:
    nums: list[float] = []
    for f in facts:
        for n in f.get("numbers", []):
            try:
                nums.append(float(n))
                nums.append(abs(float(n)))
            except (TypeError, ValueError):
                pass
        for lang_text in (f.get("text") or {}).values():
            nums.extend(extract_numbers(lang_text))
    return nums


def check_grounded(text: str, facts: list[dict[str, Any]], *, small_int_ok: int = 10) -> tuple[bool, list[float]]:
    """Return (ok, unsupported_numbers)."""
    allowed = allowed_numbers(facts)
    bad = []
    for v in extract_numbers(text):
        if float(v).is_integer() and 0 <= v <= small_int_ok:
            continue
        if 1900 <= v <= 2100 and float(v).is_integer():
            continue
        if not any(_close(v, a) or _close(abs(v), a) for a in allowed):
            bad.append(v)
    return (not bad), bad
