"""Executive report generator (content model). Renderers live in misgenius.export."""
from __future__ import annotations

from datetime import datetime, timezone
from typing import Any

from misgenius.ai.insights import InsightEngine
from misgenius.analytics.formatting import format_value
from misgenius.analytics.kpi import KPISpec, compute_kpi
from misgenius.analytics.query import DataSource, Filter
from misgenius.dashboard.generator import build_kpis, rank_dimensions, rank_measures

HEADINGS = {
    "en": {"summary": "Executive Summary", "kpis": "Key Performance Indicators", "trends": "Major Trends", "anomalies": "Anomalies",
           "top": "Top Contributors", "bottom": "Bottom Contributors", "changes": "Period-over-Period Changes",
           "observations": "Important Observations", "explanations": "Possible Explanations (based on the data only)",
           "actions": "Recommended Actions", "questions": "Recommended Questions", "quality": "Data Quality Notes",
           "scope": "Scope", "kpi": "KPI", "value": "Value", "change": "Change", "period": "Period"},
    "hi": {"summary": "कार्यकारी सारांश", "kpis": "मुख्य प्रदर्शन संकेतक (KPI)", "trends": "मुख्य रुझान", "anomalies": "असामान्यताएँ",
           "top": "शीर्ष योगदानकर्ता", "bottom": "सबसे कम योगदानकर्ता", "changes": "अवधि-दर-अवधि बदलाव",
           "observations": "महत्वपूर्ण अवलोकन", "explanations": "संभावित कारण (केवल डेटा के आधार पर)",
           "actions": "सुझाए गए कदम", "questions": "सुझाए गए प्रश्न", "quality": "डेटा गुणवत्ता टिप्पणियाँ",
           "scope": "दायरा", "kpi": "KPI", "value": "मान", "change": "बदलाव", "period": "अवधि"},
}


def kpi_display(k: dict[str, Any]) -> str:
    f = k.get("format") or {}
    return format_value(k.get("value"), f.get("kind", "number"), f.get("currency"), f.get("decimals"))


def generate_report(ds: DataSource, engine: InsightEngine, *, title: str, dataset_name: str, filters: list[Filter] | None = None,
                    quality: dict[str, Any] | None = None, language: str = "en", kpi_specs: list[dict[str, Any]] | None = None,
                    is_demo: bool = False) -> dict[str, Any]:
    lang = "hi" if language == "hi" else "en"
    h = HEADINGS[lang]
    ins = engine.generate(ds, filters=filters, quality=quality, language=lang)
    specs = [KPISpec(**s) for s in (kpi_specs or [])]
    if not specs:
        specs = build_kpis(ds.schema, rank_measures(ds.schema), rank_dimensions(ds.schema))
    kpis = []
    for s in specs[:8]:
        k = compute_kpi(ds, s, filters)
        if not k.get("available"):
            continue
        c = k.get("comparison") or {}
        kpis.append({
            "title": s.title, "value": k.get("value"), "display": kpi_display(k), "format": k.get("format"),
            "change_pct": c.get("change_pct") if c.get("available") else None,
            "period": f"{c.get('current_period')} vs {c.get('previous_period')}" if c.get("available") else None,
            "calculation": (k.get("evidence") or {}).get("calculation"),
        })

    def sec(key: str, items: list[dict[str, Any]], heading: str) -> dict[str, Any]:
        return {"key": key, "heading": heading, "items": [{"text": i["text"], "fact_ids": i.get("fact_ids", []),
                                                           "evidence": i.get("evidence")} for i in items]}

    sections = [
        sec("executive_summary", ins["executive_summary"], h["summary"]),
        {"key": "kpis", "heading": h["kpis"], "kpis": kpis},
        sec("key_trends", ins["key_trends"], h["trends"]),
        sec("period_changes", ins["period_changes"], h["changes"]),
        sec("anomalies", ins["anomalies"], h["anomalies"]),
        sec("top_contributors", ins["top_contributors"], h["top"]),
        sec("bottom_contributors", ins["bottom_contributors"], h["bottom"]),
        sec("possible_explanations", ins.get("possible_explanations", []), h["explanations"]),
        sec("observations", ins.get("observations", []), h["observations"]),
        sec("actions", ins.get("actions", []), h["actions"]),
        sec("questions", ins.get("questions", []), h["questions"]),
        sec("data_quality", ins.get("data_quality", []), h["quality"]),
    ]
    sections = [s for s in sections if s.get("items") or s.get("kpis")]
    ctx = ins["meta"]["context"]
    scope = {
        "dataset": dataset_name, "rows": ctx.get("rows"), "date_from": ctx.get("date_from"), "date_to": ctx.get("date_to"),
        "filters": [f.model_dump() for f in (filters or [])], "is_demo": is_demo,
    }
    return {
        "title": title,
        "language": lang,
        "generated_at": datetime.now(timezone.utc).isoformat(timespec="seconds"),
        "generated_by": ins["meta"]["generated_by"],
        "provider": ins["meta"].get("provider"),
        "grounding": ins["meta"].get("grounding"),
        "scope": scope,
        "sections": sections,
        "facts": ins["facts"],
        "disclaimer": ("Every number in this report was computed from the uploaded dataset. " + ("DEMO DATA — not real business data." if is_demo else ""))
        if lang == "en" else ("इस रिपोर्ट की हर संख्या अपलोड किए गए डेटा से गणना की गई है। " + ("डेमो डेटा — वास्तविक व्यावसायिक डेटा नहीं।" if is_demo else "")),
    }
