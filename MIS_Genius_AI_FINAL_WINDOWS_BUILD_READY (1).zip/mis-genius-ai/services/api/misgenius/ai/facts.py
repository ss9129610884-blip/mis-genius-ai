"""Deterministic fact extraction — the grounding layer for every AI feature.

Every statement shown as an "insight" comes from a Fact computed here with the
query engine. Each fact carries the numbers it states and the evidence (query,
SQL, calculation) so the UI can show how it was calculated. LLMs may only
rephrase / prioritise these facts; their output is validated against them.
"""
from __future__ import annotations

from typing import Any

from misgenius.analytics.charts import ChartSpec, recommend_charts
from misgenius.analytics.formatting import format_value
from misgenius.analytics.kpi import KPIComparison, KPISpec, compute_kpi, period_label
from misgenius.analytics.query import (
    DataSource,
    Dimension,
    Filter,
    Measure,
    QueryError,
    QuerySpec,
    Sort,
    best_granularity,
    quote_ident,
)
from misgenius.analytics.stats import concentration, linear_trend, pct_change, robust_anomalies
from misgenius.dashboard.generator import default_agg, rank_dimensions, rank_measures

GRAN_HI = {"day": "दिन", "week": "सप्ताह", "month": "महीने", "quarter": "तिमाही", "year": "वर्ष"}


class FactSheet:
    def __init__(self) -> None:
        self.facts: list[dict[str, Any]] = []
        self._n = 0

    def add(self, kind: str, en: str, hi: str, *, numbers: list[Any], evidence: dict[str, Any], importance: float,
            section: str, data: dict[str, Any] | None = None) -> dict[str, Any]:
        self._n += 1
        f = {"id": f"F{self._n}", "kind": kind, "section": section, "importance": round(importance, 3),
             "text": {"en": en, "hi": hi}, "numbers": [n for n in numbers if n is not None], "evidence": evidence, "data": data or {}}
        self.facts.append(f)
        return f


def _fmt_kind(col: dict[str, Any] | None, agg: str) -> tuple[str, str | None]:
    if not col or agg in ("count_rows", "count", "count_distinct"):
        return "number", None
    f = col.get("format", {})
    if col["data_type"] == "percentage":
        return "percent", None
    if col["data_type"] == "currency":
        return "currency", (f.get("currency") or "INR")
    return "number", None


class _Fmt:
    def __init__(self, ds: DataSource):
        self.ds = ds

    def val(self, v: Any, col: str | None, agg: str) -> str:
        kind, cur = _fmt_kind(self.ds.columns.get(col) if col else None, agg)
        return format_value(v, kind, cur)


def _cap(s: str) -> str:
    return s[:1].upper() + s[1:]


def _mname(m: Measure) -> str:
    if m.agg == "count_rows" or not m.column:
        return "number of records"
    return m.column if m.agg == "sum" else f"average {m.column}" if m.agg == "avg" else f"{m.agg} of {m.column}"


def _mname_hi(m: Measure) -> str:
    if m.agg == "count_rows" or not m.column:
        return "रिकॉर्ड"
    return m.column if m.agg == "sum" else f"औसत {m.column}" if m.agg == "avg" else m.column


def build_fact_sheet(ds: DataSource, *, filters: list[Filter] | None = None, quality: dict[str, Any] | None = None,
                     max_dims: int = 3) -> dict[str, Any]:
    filters = list(filters or [])
    schema = ds.schema
    fs = FactSheet()
    fmt = _Fmt(ds)
    measures = rank_measures(schema)
    dims = rank_dimensions(schema)
    date_col = schema.get("primary_date_column")
    n_rows = ds.count(filters)
    ctx: dict[str, Any] = {"rows": n_rows, "filters": [f.model_dump() for f in filters], "date_column": date_col,
                           "measures": [m["name"] for m in measures[:5]], "dimensions": [d["name"] for d in dims[:5]],
                           "domain": schema.get("domain", {}).get("guess")}
    if n_rows == 0:
        fs.add("overview", "No records match the current filters.", "मौजूदा फ़िल्टर से कोई रिकॉर्ड मेल नहीं खाता।",
               numbers=[0], evidence={"calculation": "COUNT(*) with filters"}, importance=1.0, section="executive_summary")
        return {"facts": fs.facts, "context": ctx}

    # ---- overview -----------------------------------------------------------
    lo = hi = None
    g = "month"
    if date_col:
        lo, hi = ds.date_bounds(date_col, filters)
        g = best_granularity(lo, hi)
        ctx.update({"date_from": str(lo)[:10] if lo else None, "date_to": str(hi)[:10] if hi else None, "granularity": g})
    rng_en = f" from {str(lo)[:10]} to {str(hi)[:10]}" if lo and hi else ""
    rng_hi = f" ({str(lo)[:10]} से {str(hi)[:10]} तक)" if lo and hi else ""
    fs.add("overview", f"The analysis covers {n_rows:,} records{rng_en}.", f"विश्लेषण में {n_rows:,} रिकॉर्ड शामिल हैं{rng_hi}।",
           numbers=[n_rows], evidence={"calculation": "COUNT(*) of rows matching the filters" + (f"; MIN/MAX of {date_col}" if date_col else "")},
           importance=0.3, section="executive_summary")

    pmeasures = [Measure(column=m["name"], agg=default_agg(m)) for m in measures[:3]] or [Measure(agg="count_rows")]
    pm = pmeasures[0]

    # ---- totals -------------------------------------------------------------
    for i, m in enumerate(pmeasures[:2]):
        if m.agg == "count_rows":
            continue
        res = ds.aggregate(QuerySpec(measures=[m], filters=filters))
        v = res["rows"][0][0]
        if v is None:
            continue
        word = "Total" if m.agg == "sum" else "Average"
        word_hi = "कुल" if m.agg == "sum" else "औसत"
        fs.add("total", f"{word} {m.column} is {fmt.val(v, m.column, m.agg)}.", f"{word_hi} {m.column} {fmt.val(v, m.column, m.agg)} है।",
               numbers=[v], evidence={"calculation": f"{m.agg.upper()}({m.column})", "sql": res["sql"], "query": QuerySpec(measures=[m], filters=filters).model_dump()},
               importance=0.7 - i * 0.1, section="executive_summary", data={"measure": m.column, "value": v})

    # ---- period-over-period -------------------------------------------------
    if date_col:
        for i, m in enumerate(pmeasures[:2] + ([Measure(agg="count_rows")] if pm.agg != "count_rows" else [])):
            k = compute_kpi(ds, KPISpec(title=_mname(m), measure=m, comparison=KPIComparison(date_column=date_col), sparkline=False), filters)
            c = k.get("comparison") or {}
            if not c.get("available") or c.get("change_pct") is None or abs(c["change_pct"]) < 0.5:
                continue
            ch = c["change_pct"]
            direction = "up" if ch > 0 else "down" if ch < 0 else "unchanged"
            dir_hi = "बढ़कर" if ch > 0 else "घटकर" if ch < 0 else "बिना बदलाव के"
            cur, prev = c["current_value"], c["previous_value"]
            en = (f"{_cap(_mname(m))} in {c['current_period']} was {fmt.val(cur, m.column, m.agg)}, "
                  f"{direction} {abs(ch):.1f}% from {c['previous_period']} ({fmt.val(prev, m.column, m.agg)}).")
            hi_t = (f"{c['current_period']} में {_mname_hi(m)} {fmt.val(cur, m.column, m.agg)} रहा, जो {c['previous_period']} "
                    f"({fmt.val(prev, m.column, m.agg)}) की तुलना में {abs(ch):.1f}% {dir_hi} है।")
            if c.get("note"):
                en += " " + c["note"]
                hi_t += f" (अंतिम अवधि अधूरी है, इसलिए पिछली पूरी अवधि की तुलना की गई।)"
            fs.add("period_change", en, hi_t, numbers=[cur, prev, ch, abs(ch)],
                   evidence={"calculation": c["calculation"], "current": cur, "previous": prev, "sql": k.get("evidence", {}).get("sql")},
                   importance=min(1.0, 0.55 + abs(ch) / 200) - i * 0.05, section="period_changes",
                   data={"measure": _mname(m), "change_pct": ch, "current_period": c["current_period"], "previous_period": c["previous_period"]})

        # ---- trend + period anomalies --------------------------------------
        series = ds.aggregate(QuerySpec(dimensions=[Dimension(column=date_col, granularity=g, alias="p")], measures=[pm], filters=filters, limit=5000))
        pts = [(r[0], r[1]) for r in series["rows"] if r[0] is not None]
        if len(pts) >= 4:
            vals = [p[1] for p in pts]
            tr = linear_trend(vals[:-1] if _last_partial(pts, hi, g) else vals)
            if tr and tr["strength"] != "weak" and tr["direction"] != "flat":
                first, last = pts[0], pts[-1]
                en = (f"{_cap(_mname(pm))} shows a {tr['strength']} {'upward' if tr['direction'] == 'up' else 'downward'} trend across "
                      f"{len(pts)} {g}s ({period_label(first[0], g)}: {fmt.val(first[1], pm.column, pm.agg)} → {period_label(last[0], g)}: {fmt.val(last[1], pm.column, pm.agg)}).")
                hi_t = (f"{len(pts)} {GRAN_HI.get(g, g)} में {_mname_hi(pm)} का रुझान {'बढ़ता' if tr['direction'] == 'up' else 'घटता'} है "
                        f"({period_label(first[0], g)}: {fmt.val(first[1], pm.column, pm.agg)} → {period_label(last[0], g)}: {fmt.val(last[1], pm.column, pm.agg)})।")
                fs.add("trend", en, hi_t, numbers=[first[1], last[1], len(pts)],
                       evidence={"calculation": f"Least-squares slope of {_mname(pm)} per {g} (R² = {tr['r2']})", "sql": series["sql"], "r2": tr["r2"]},
                       importance=0.6 + 0.2 * tr["r2"], section="key_trends", data=tr)
            apts = list(pts)
            if _last_partial(apts, hi, g):
                apts = apts[:-1]
            if apts and _first_partial(apts, lo, g):
                apts = apts[1:]
            if len(apts) >= 6:
                found = [a for a in robust_anomalies([p[0] for p in apts], [p[1] for p in apts])
                         if a["median"] and abs(a["value"] / a["median"] - 1) >= 0.25]
                for a in found[:3]:
                    a["period"] = period_label(a["label"], g)
                    ratio = a["value"] / a["median"] if a["median"] else None
                    en = (f"{period_label(a['label'], g)} was unusually {'high' if a['direction'] == 'high' else 'low'} for {_mname(pm)}: "
                          f"{fmt.val(a['value'], pm.column, pm.agg)} vs a typical {g} of {fmt.val(a['median'], pm.column, pm.agg)}"
                          + (f" ({ratio:.1f}×)." if ratio else "."))
                    hi_t = (f"{period_label(a['label'], g)} में {_mname_hi(pm)} असामान्य रूप से {'अधिक' if a['direction'] == 'high' else 'कम'} रहा: "
                            f"{fmt.val(a['value'], pm.column, pm.agg)}, जबकि सामान्य {GRAN_HI.get(g, g)} {fmt.val(a['median'], pm.column, pm.agg)} है।")
                    fs.add("anomaly_period", en, hi_t, numbers=[a["value"], a["median"]] + ([round(ratio, 1)] if ratio else []),
                           evidence={"calculation": f"Modified z-score {a['score']} (median/MAD across {len(apts)} complete {g}s; threshold 3.5)", "sql": series["sql"]},
                           importance=0.75, section="anomalies", data=a)

    # ---- contributors -------------------------------------------------------
    additive = pm.agg in ("sum", "count_rows")
    total_v = ds.aggregate(QuerySpec(measures=[pm], filters=filters))["rows"][0][0] if additive else None
    contrib_dims = [d for d in dims if "status" not in d.get("semantic_tags", [])][:max_dims]
    for di, d in enumerate(contrib_dims):
        if d["_distinct"] > 5000:
            continue
        spec = QuerySpec(dimensions=[Dimension(column=d["name"])], measures=[pm], filters=filters, limit=500,
                         sort=[Sort(by=_alias(pm), desc=True)])
        try:
            res = ds.aggregate(spec)
        except QueryError:
            continue
        rows = [r for r in res["rows"] if r[1] is not None]
        if len(rows) < 2:
            continue
        top = rows[0]
        if additive and total_v and top[1] / total_v >= 0.99:
            continue
        if additive and total_v:
            share = top[1] / total_v * 100
            en = f"{top[0]} is the top {d['name']} with {fmt.val(top[1], pm.column, pm.agg)} ({share:.1f}% of total {_mname(pm)})."
            hi_t = f"{d['name']} में {top[0]} सबसे आगे है: {fmt.val(top[1], pm.column, pm.agg)} (कुल {_mname_hi(pm)} का {share:.1f}%)।"
            nums = [top[1], share]
        else:
            share = None
            en = f"{top[0]} has the highest {_mname(pm)} among {d['name']} values ({fmt.val(top[1], pm.column, pm.agg)})."
            hi_t = f"{d['name']} में {top[0]} का {_mname_hi(pm)} सबसे अधिक है ({fmt.val(top[1], pm.column, pm.agg)})।"
            nums = [top[1]]
        fs.add("top_contributor", en, hi_t, numbers=nums,
               evidence={"calculation": f"{pm.agg.upper()} of {pm.column or 'rows'} grouped by {d['name']}, sorted descending", "sql": res["sql"],
                         "query": spec.model_dump(), "result": rows[:5]},
               importance=0.65 - di * 0.08, section="top_contributors", data={"dimension": d["name"], "value": top[0], "share_pct": share})
        if len(rows) >= 3 and not res["truncated"]:
            bot = rows[-1]
            if additive and total_v:
                bshare = bot[1] / total_v * 100
                en = f"{bot[0]} is the smallest {d['name']} at {fmt.val(bot[1], pm.column, pm.agg)} ({bshare:.1f}% of total)."
                hi_t = f"{d['name']} में {bot[0]} सबसे पीछे है: {fmt.val(bot[1], pm.column, pm.agg)} (कुल का {bshare:.1f}%)।"
                nums = [bot[1], bshare]
            else:
                en = f"{bot[0]} has the lowest {_mname(pm)} among {d['name']} values ({fmt.val(bot[1], pm.column, pm.agg)})."
                hi_t = f"{d['name']} में {bot[0]} का {_mname_hi(pm)} सबसे कम है ({fmt.val(bot[1], pm.column, pm.agg)})।"
                nums = [bot[1]]
            fs.add("bottom_contributor", en, hi_t, numbers=nums,
                   evidence={"calculation": f"Same grouping as above, lowest value", "sql": res["sql"]},
                   importance=0.45 - di * 0.08, section="bottom_contributors", data={"dimension": d["name"], "value": bot[0]})
        if additive and len(rows) >= 10 and not res["truncated"]:
            con = concentration([r[1] for r in rows])
            if con and con["top_share_pct"] >= 50:
                en = (f"The top {con['top_n']} of {con['groups']} {d['name']} values (20%) account for {con['top_share_pct']:.1f}% of total {_mname(pm)} — results are concentrated.")
                hi_t = (f"{con['groups']} में से शीर्ष {con['top_n']} {d['name']} (20%) कुल {_mname_hi(pm)} का {con['top_share_pct']:.1f}% हिस्सा रखते हैं।")
                fs.add("concentration", en, hi_t, numbers=[con["top_n"], con["groups"], con["top_share_pct"], 20],
                       evidence={"calculation": "Share of the top 20% of groups (Pareto analysis)", "sql": res["sql"]},
                       importance=0.55, section="key_trends", data=con)

    # ---- movers between the last two complete periods -----------------------
    if date_col and dims and additive:
        _movers(ds, fs, fmt, pm, dims[0], date_col, filters, g, hi)

    # ---- row-level extreme values -------------------------------------------
    if measures:
        _outlier_rows(ds, fs, fmt, measures[0], filters, schema)

    # ---- status share -------------------------------------------------------
    status = next((d for d in dims if "status" in d.get("semantic_tags", []) and 2 <= d["_distinct"] <= 8), None)
    if status:
        res = ds.aggregate(QuerySpec(dimensions=[Dimension(column=status["name"])], measures=[Measure(agg="count_rows", alias="n")], filters=filters))
        tot = sum(r[1] for r in res["rows"]) or 1
        parts = [f"{r[0]}: {r[1] / tot * 100:.1f}%" for r in res["rows"][:4]]
        fs.add("status_share", f"{status['name']} breakdown — " + ", ".join(parts) + ".", f"{status['name']} का विवरण — " + ", ".join(parts) + "।",
               numbers=[round(r[1] / tot * 100, 1) for r in res["rows"][:4]] + [r[1] for r in res["rows"][:4]],
               evidence={"calculation": f"COUNT(*) grouped by {status['name']} ÷ total rows", "sql": res["sql"]},
               importance=0.6, section="executive_summary")

    # ---- data quality -------------------------------------------------------
    seen_types: set[str] = set()
    for issue in (quality or {}).get("issues", [])[:10]:
        if issue["severity"] == "info" and issue["type"] not in ("outliers",):
            continue
        if issue["type"] in seen_types or (issue["type"] == "outliers" and any(f["kind"] == "outlier_rows" for f in fs.facts)):
            continue
        seen_types.add(issue["type"])
        nums = [x for x in (issue.get("count"), issue.get("percent")) if x is not None]
        fs.add("quality", issue["message"], issue.get("message_hi") or issue["message"], numbers=nums,
               evidence={"calculation": f"Data-quality check '{issue['type']}'", "column": issue.get("column")},
               importance=0.4 if issue["severity"] == "warning" else 0.6, section="data_quality", data={"issue": issue["type"]})

    # ---- relationships -------------------------------------------------------
    for rel in schema.get("relationships", [])[:6]:
        if rel["type"] in ("derived", "hierarchy"):
            fs.add("relationship", rel["description"], rel["description"], numbers=[],
                   evidence={"calculation": f"Checked on the data ({rel['type']}, confidence {rel.get('confidence')})"},
                   importance=0.2, section="observations")

    ctx["primary_measure"] = _mname(pm)
    return {"facts": fs.facts, "context": ctx}


def _alias(m: Measure) -> str:
    from misgenius.analytics.query import measure_alias

    return measure_alias(m)


def _last_partial(pts: list[tuple[Any, Any]], hi: Any, g: str) -> bool:
    from misgenius.analytics.kpi import _as_date, _period_end

    last = _as_date(pts[-1][0])
    h = _as_date(hi)
    return bool(last and h and g != "day" and h < _period_end(last, g))


def _first_partial(pts: list[tuple[Any, Any]], lo: Any, g: str) -> bool:
    from misgenius.analytics.kpi import _as_date

    first = _as_date(pts[0][0])
    low = _as_date(lo)
    return bool(first and low and g != "day" and low > first)


def _movers(ds: DataSource, fs: FactSheet, fmt: _Fmt, pm: Measure, dim: dict[str, Any], date_col: str,
            filters: list[Filter], g: str, hi: Any) -> None:
    if dim["_distinct"] > 500:
        return
    try:
        series = ds.aggregate(QuerySpec(dimensions=[Dimension(column=date_col, granularity=g, alias="p")], measures=[Measure(agg="count_rows")],
                                        filters=filters, limit=5000))
    except QueryError:
        return
    periods = [r[0] for r in series["rows"] if r[0] is not None]
    if len(periods) < 2:
        return
    pts = [(p, None) for p in periods]
    idx = len(periods) - 1
    if _last_partial(pts, hi, g) and len(periods) >= 3:
        idx -= 1
    cur_p, prev_p = periods[idx], periods[idx - 1]
    res = ds.aggregate(QuerySpec(dimensions=[Dimension(column=date_col, granularity=g, alias="p"), Dimension(column=dim["name"])],
                                 measures=[pm], filters=filters, limit=20000))
    cur: dict[Any, float] = {}
    prev: dict[Any, float] = {}
    for p, k, v in res["rows"]:
        if p == cur_p:
            cur[k] = v or 0
        elif p == prev_p:
            prev[k] = v or 0
    deltas = [(k, cur.get(k, 0) - prev.get(k, 0), pct_change(cur.get(k, 0), prev.get(k, 0))) for k in set(cur) | set(prev)]
    if len(deltas) < 2:
        return
    deltas.sort(key=lambda x: x[1])
    up, down = deltas[-1], deltas[0]
    lbl_c, lbl_p = period_label(cur_p, g), period_label(prev_p, g)
    for kind, (k, d, pc) in (("gainer", up), ("decliner", down)):
        if (kind == "gainer" and d <= 0) or (kind == "decliner" and d >= 0):
            continue
        pc_txt = f", {pc:+.1f}%" if pc is not None else ""
        en = (f"{k} had the biggest {'increase' if kind == 'gainer' else 'decrease'} in {_mname(pm)} among {dim['name']} values from {lbl_p} to {lbl_c} "
              f"({'+' if d > 0 else '−'}{fmt.val(abs(d), pm.column, pm.agg)}{pc_txt}).")
        hi_t = (f"{lbl_p} से {lbl_c} के बीच {dim['name']} में {k} के {_mname_hi(pm)} में सबसे {'ज़्यादा बढ़त' if kind == 'gainer' else 'ज़्यादा गिरावट'} रही "
                f"({'+' if d > 0 else '−'}{fmt.val(abs(d), pm.column, pm.agg)}{pc_txt})।")
        fs.add("mover", en, hi_t, numbers=[abs(d), d] + ([pc, abs(pc)] if pc is not None else []),
               evidence={"calculation": f"{_mname(pm)} per {dim['name']} in {lbl_c} minus {lbl_p}", "sql": res["sql"]},
               importance=0.6, section="period_changes", data={"dimension": dim["name"], "value": k, "delta": d, "pct": pc})


def _outlier_rows(ds: DataSource, fs: FactSheet, fmt: _Fmt, mcol: dict[str, Any], filters: list[Filter], schema: dict[str, Any]) -> None:
    st = mcol.get("stats", {})
    hi_f, lo_f = st.get("upper_fence"), st.get("lower_fence")
    if hi_f is None:
        return
    name = mcol["name"]
    q = quote_ident(name)
    params: list[Any] = []
    where = ds.where_sql(filters, None, params)
    cond = f"({q} > ? OR {q} < ?)" + (f" AND {q} <> 0" if str(st.get("outlier_method", "")).startswith("iqr_nonzero") else "")
    where = (where + " AND " + cond) if where else "WHERE " + cond
    params_o = params + [hi_f, lo_f if lo_f is not None else float("-inf")]
    _, rows = ds.run(f"SELECT COUNT(*) FROM data {where}", params_o)
    n = int(rows[0][0])
    if n == 0:
        return
    label_cols = (schema.get("identifier_columns") or [])[:1] + [d["name"] for d in rank_dimensions(schema)[:1]]
    sel = ", ".join([q] + [quote_ident(c) for c in label_cols])
    _, ex = ds.run(f"SELECT {sel} FROM data {where} ORDER BY ABS({q} - {float(st.get('median') or 0)}) DESC LIMIT 3", params_o)
    med = st.get("median") or 0
    top = ex[0]
    label = ", ".join(str(v) for v in top[1:] if v is not None)
    ratio = (top[0] / med) if med else None
    en = (f"{n:,} record(s) have extreme {name} values outside the expected range. The largest is {fmt.val(top[0], name, 'sum')}"
          + (f" ({label})" if label else "") + (f", about {ratio:,.0f}× the median of {fmt.val(med, name, 'sum')}." if ratio and ratio >= 2 else "."))
    hi_t = (f"{n:,} रिकॉर्ड में {name} के मान अपेक्षित दायरे से बहुत बाहर हैं। सबसे बड़ा मान {fmt.val(top[0], name, 'sum')}"
            + (f" ({label})" if label else "") + (f" है, जो माध्यिका {fmt.val(med, name, 'sum')} का लगभग {ratio:,.0f} गुना है।" if ratio and ratio >= 2 else " है।"))
    fs.add("outlier_rows", en, hi_t, numbers=[n, top[0], med] + ([round(ratio)] if ratio else []),
           evidence={"calculation": f"Rows where {name} is outside the robust fences {hi_f:,.2f} / {lo_f if lo_f is not None else '-∞'}",
                     "examples": [list(r) for r in ex]},
           importance=0.7, section="anomalies", data={"column": name, "count": n})


# --------------------------------------------------------------------------- suggestions
def suggestions(ds: DataSource, facts: list[dict[str, Any]], existing_kpis: list[str] | None = None) -> dict[str, list[dict[str, Any]]]:
    from misgenius.dashboard.generator import build_kpis

    schema = ds.schema
    measures = rank_measures(schema)
    dims = rank_dimensions(schema)
    pm = measures[0]["name"] if measures else None
    qs: list[dict[str, Any]] = []
    acts: list[dict[str, Any]] = []
    for f in facts:
        k = f["kind"]
        d = f.get("data", {})
        if k == "period_change" and abs(d.get("change_pct", 0)) >= 10 and dims and not any("drove the change" in q["en"] for q in qs):
            qs.append({"en": f"Which {dims[0]['name']} drove the change in {d['measure']} in {d['current_period']}?",
                       "hi": f"{d['current_period']} में {d['measure']} में बदलाव किस {dims[0]['name']} की वजह से हुआ?", "fact_ids": [f["id"]]})
        if k == "anomaly_period":
            acts.append({"en": f"Review the records behind the unusually {d.get('direction')} value in {d.get('period', d.get('label'))}.",
                         "hi": f"{d.get('period', d.get('label'))} के असामान्य मान के पीछे के रिकॉर्ड जाँचें।", "fact_ids": [f["id"]]})
        if k == "outlier_rows":
            acts.append({"en": f"Verify the {d['count']:,} extreme {d['column']} record(s) — confirm they are genuine and not data-entry errors.",
                         "hi": f"{d['column']} के {d['count']:,} असामान्य रिकॉर्ड जाँचें कि वे सही हैं या प्रविष्टि की गलती।", "fact_ids": [f["id"]]})
        if k == "bottom_contributor":
            acts.append({"en": f"Look into why {d['value']} is the lowest {d['dimension']}.",
                         "hi": f"जाँचें कि {d['dimension']} में {d['value']} सबसे पीछे क्यों है।", "fact_ids": [f["id"]]})
        if k == "concentration":
            acts.append({"en": "A few groups dominate the total — consider the dependency risk on the top contributors.",
                         "hi": "कुछ ही समूह कुल का बड़ा हिस्सा रखते हैं — शीर्ष योगदानकर्ताओं पर निर्भरता का जोखिम देखें।", "fact_ids": [f["id"]]})
        if k == "quality":
            acts.append({"en": "Fix the data-quality issue: " + f["text"]["en"], "hi": "डेटा गुणवत्ता सुधारें: " + f["text"]["hi"], "fact_ids": [f["id"]]})
    if pm and len(dims) >= 2:
        qs.append({"en": f"How does {pm} compare across {dims[0]['name']} and {dims[1]['name']}?",
                   "hi": f"{dims[0]['name']} और {dims[1]['name']} के अनुसार {pm} की तुलना कैसी है?", "fact_ids": []})
    if pm and schema.get("primary_date_column"):
        qs.append({"en": f"What is the monthly trend of {pm}?", "hi": f"{pm} का महीनेवार ट्रेंड क्या है?", "fact_ids": []})
    if dims:
        qs.append({"en": f"Show the top 10 {dims[0]['name']} by {pm or 'records'}.", "hi": f"{pm or 'रिकॉर्ड'} के अनुसार शीर्ष 10 {dims[0]['name']} दिखाओ।", "fact_ids": []})
    existing = set(existing_kpis or [])
    kpis = [{"title": k.title, "description": k.description or "", "spec": k.model_dump(exclude_none=True)}
            for k in build_kpis(schema, measures, dims) if k.title not in existing]
    charts = []
    if dims and measures:
        for r in recommend_charts(ds, [dims[0]["name"]], [measures[0]["name"]])[:2]:
            charts.append({"title": f"{measures[0]['name']} by {dims[0]['name']} ({r['type']})", "reason": r["reason"],
                           "spec": ChartSpec(type=r["type"], dimension=Dimension(column=dims[0]["name"]),
                                             measures=[Measure(column=measures[0]["name"], agg=default_agg(measures[0]))]).model_dump(exclude_none=True)})
    if schema.get("primary_date_column") and measures:
        charts.append({"title": f"{measures[0]['name']} trend", "reason": "Time series of the main measure",
                       "spec": ChartSpec(type="line", dimension=Dimension(column=schema["primary_date_column"]),
                                         measures=[Measure(column=measures[0]["name"], agg=default_agg(measures[0]))]).model_dump(exclude_none=True)})
    return {"questions": qs[:6], "actions": acts[:6], "suggested_kpis": kpis[:6], "suggested_charts": charts[:4]}
