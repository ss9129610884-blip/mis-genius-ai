"""Natural-language analytics.

A question (English, Hindi or Hinglish) is translated into a *plan* — a small,
validated structure (intent, measure, dimension, filters, time scope). The plan
is executed by the query engine; answers are written from the computed result.
An LLM, when configured, may propose the plan and phrase the answer, but its
plan is validated against the schema and its wording against the result.
Without an LLM a rule-based parser handles common questions.
"""
from __future__ import annotations

import calendar
import difflib
import logging
import re
from datetime import date, datetime, timedelta
from typing import Any

from misgenius.ai.facts import suggestions
from misgenius.ai.prompts import prompt_manager
from misgenius.ai.providers import AIProvider, AIProviderError
from misgenius.ai.validation import check_grounded
from misgenius.analytics.charts import ChartSpec, build_chart
from misgenius.analytics.formatting import format_value
from misgenius.analytics.kpi import _as_date, _period_end, period_label
from misgenius.analytics.query import (
    DATE_TYPES,
    NUMERIC_TYPES,
    DataSource,
    Dimension,
    Filter,
    Measure,
    QueryError,
    QuerySpec,
    Sort,
    best_granularity,
    measure_alias,
    quote_ident,
)
from misgenius.analytics.stats import linear_trend, pct_change
from misgenius.dashboard.generator import default_agg, rank_dimensions, rank_measures
from misgenius.schema.semantics import name_tokens

log = logging.getLogger("misgenius.ai.nlq")

MEASURE_SYNONYMS: dict[str, list[str]] = {
    "revenue_like": ["sales", "sale", "revenue", "turnover", "income", "बिक्री", "बिक्रि", "सेल्स", "सेल", "राजस्व", "आय", "kamai", "bikri"],
    "cost_like": ["expense", "expenses", "spend", "spending", "spent", "cost", "costs", "खर्च", "खर्चा", "ख़र्च", "व्यय", "लागत", "kharch", "kharcha"],
    "profit_like": ["profit", "profits", "margin", "मुनाफा", "मुनाफ़ा", "लाभ", "munafa", "fayda", "फायदा"],
    "quantity": ["quantity", "qty", "units", "pieces", "volume", "मात्रा", "नग"],
    "salary": ["salary", "salaries", "wage", "wages", "ctc", "payroll", "वेतन", "तनख्वाह", "तनख़्वाह", "tankhwah"],
    "money": ["amount", "value", "राशि", "रकम", "paisa", "पैसा", "payment", "भुगतान"],
    "duration": ["hours", "घंटे", "ghante", "duration"],
    "stock": ["stock", "inventory", "स्टॉक", "माल"],
    "score": ["marks", "score", "अंक", "rating"],
}
DIM_SYNONYMS: dict[str, list[str]] = {
    "location": ["region", "regions", "zone", "area", "city", "cities", "state", "states", "branch", "location", "district",
                 "क्षेत्र", "शहर", "राज्य", "जिला", "ज़िला", "इलाका", "ब्रांच"],
    "org_unit": ["department", "departments", "dept", "team", "division", "विभाग", "डिपार्टमेंट", "टीम", "vibhag"],
    "product": ["product", "products", "item", "items", "sku", "category", "categories", "उत्पाद", "प्रोडक्ट", "सामान", "वस्तु", "श्रेणी"],
    "person": ["customer", "customers", "client", "clients", "buyer", "employee", "employees", "staff", "vendor", "vendors",
               "supplier", "suppliers", "ग्राहक", "कस्टमर", "कर्मचारी", "विक्रेता", "सप्लायर", "grahak"],
    "status": ["status", "स्थिति", "स्टेटस"],
}
INTENT_WORDS: dict[str, list[str]] = {
    "create_dashboard": ["create dashboard", "create a dashboard", "build dashboard", "build a dashboard", "make a dashboard", "make dashboard",
                         "generate dashboard", "new dashboard", "डैशबोर्ड बनाओ", "डैशबोर्ड बनाएं", "dashboard banao"],
    "kpi_suggestions": ["which kpi", "what kpi", "kpis should", "kpi should", "which metrics", "what metrics should", "track", "कौन से kpi",
                        "कौन से केपीआई", "kaun se kpi", "kya track"],
    "anomalies": ["unusual", "anomal", "outlier", "strange", "suspicious", "odd ", "fraud", "abnormal", "असामान्य", "अजीब", "गड़बड़", "संदिग्ध", "ajeeb", "gadbad"],
    "data_quality": ["missing", "data quality", "duplicate", "blank", "empty values", "errors in data", "खाली", "डुप्लिकेट", "गुणवत्ता", "गलत डेटा"],
    "describe_data": ["describe", "what is in this data", "what does this data", "summary of the data", "summarize", "summarise", "overview",
                      "इस डेटा में क्या", "डेटा के बारे में", "सारांश", "is data me kya"],
    "compare_periods": ["compare", "compared", "comparison", " vs ", "versus", "change from", "what changed", "changed", "growth", "grew", "decline",
                        "तुलना", "बदला", "बदलाव", "बढ़ोतरी", "गिरावट", "tulna", "badla"],
    "trend": ["trend", "over time", "monthly", "per month", "by month", "month wise", "month-wise", "weekly", "daily", "yearly", "quarterly",
              "ट्रेंड", "हर महीने", "महीनेवार", "महीने के अनुसार", "रुझान", "mahine wise"],
    "bottom_n": ["lowest", "least", "minimum", "worst", "bottom", "smallest", "सबसे कम", "न्यूनतम", "sabse kam"],
    "top_n": ["top", "highest", "most", "maximum", "best", "largest", "biggest", "leading", "सबसे ज्यादा", "सबसे ज़्यादा", "सबसे अधिक",
              "सर्वाधिक", "टॉप", "शीर्ष", "sabse jyada", "sabse zyada", "sabse adhik"],
}
AGG_WORDS = {
    "avg": ["average", "avg", "mean", "औसत", "ausat"],
    "count": ["how many", "count", "number of", "no of", "no. of", "कितने", "कितनी", "संख्या", "kitne", "kitni"],
    "max": ["max value", "maximum value", "highest value", "largest value", "सबसे बड़ा मान"],
    "min": ["min value", "minimum value", "lowest value", "smallest value"],
}
TIME_WORDS = {
    "latest_period": ["this month", "current month", "latest month", "इस महीने", "इस माह", "is mahine", "this week", "इस सप्ताह", "this quarter", "इस तिमाही"],
    "previous_period": ["last month", "previous month", "पिछले महीने", "पिछला महीना", "pichle mahine", "last week", "पिछले सप्ताह", "last quarter", "पिछली तिमाही"],
    "latest_year": ["this year", "current year", "इस साल", "इस वर्ष", "is saal"],
    "previous_year": ["last year", "previous year", "पिछले साल", "पिछले वर्ष", "pichle saal"],
}
MONTH_WORDS = {m.lower(): i for i, m in enumerate(calendar.month_name) if m} | {m.lower(): i for i, m in enumerate(calendar.month_abbr) if m} | {
    "जनवरी": 1, "फरवरी": 2, "मार्च": 3, "अप्रैल": 4, "मई": 5, "जून": 6, "जुलाई": 7, "अगस्त": 8, "सितंबर": 9, "अक्टूबर": 10, "नवंबर": 11, "दिसंबर": 12}
GRAN_WORDS = {"day": ["daily", "per day", "day wise", "दैनिक", "रोज़"], "week": ["weekly", "per week", "week wise", "साप्ताहिक"],
              "month": ["monthly", "per month", "month wise", "महीनेवार", "मासिक", "mahine"], "quarter": ["quarterly", "per quarter", "तिमाही"],
              "year": ["yearly", "per year", "annual", "year wise", "वार्षिक", "सालाना"]}


def detect_language(q: str) -> str:
    return "hi" if re.search(r"[ऀ-ॿ]", q) else "en"


def _has(q: str, words: list[str]) -> bool:
    for w in words:
        if re.search(r"[ऀ-ॿ]", w):
            if w in q:
                return True
        elif re.search(r"(?<![a-z0-9])" + re.escape(w.strip()) + r"(?![a-z0-9])", q) or (w.startswith(" ") and w in q):
            return True
    return False


class Planner:
    def __init__(self, ds: DataSource):
        self.ds = ds
        self.schema = ds.schema
        self.cols = ds.columns
        self.measures = rank_measures(self.schema)
        self.dims = rank_dimensions(self.schema)

    # ------------------------------------------------------------ column mentions
    def _mentions(self, q: str) -> list[tuple[str, int, int]]:
        """Columns explicitly mentioned: (name, start_pos, length)."""
        found = []
        for name, c in self.cols.items():
            for cand in {name.lower(), (c.get("label") or name).lower()}:
                i = q.find(cand)
                if i >= 0 and len(cand) >= 2:
                    found.append((name, i, len(cand)))
                    break
            else:
                toks = [t for t in name_tokens(name) if len(t) >= 4 and t not in ("total", "amount", "value", "name", "date", "code")]
                for t in toks:
                    m = re.search(r"(?<![a-z])" + re.escape(t) + r"(es|s)?(?![a-z])", q)
                    if m:
                        found.append((name, m.start(), len(t) - 1))
                        break
        found.sort(key=lambda x: -x[2])
        return found

    def _by_tag(self, tag: str, pool: list[dict[str, Any]]) -> dict[str, Any] | None:
        return next((c for c in pool if tag in c.get("semantic_tags", [])), None)

    def _resolve_measure(self, q: str, mentioned: list[str]) -> tuple[dict[str, Any] | None, str | None]:
        """Returns (column, missing_concept)."""
        for name in mentioned:
            c = self.cols[name]
            if c["data_type"] in NUMERIC_TYPES and c["role"] == "measure":
                return c, None
        for tag, words in MEASURE_SYNONYMS.items():
            if _has(q, words):
                if tag == "salary":
                    c = next((m for m in self.measures if any(k in m["name"].lower() for k in ("salary", "wage", "ctc", "pay", "वेतन"))), None)
                    if c is not None:
                        return c, None
                    return None, next(w for w in words if _has(q, [w]))
                c = self._by_tag(tag, self.measures)
                if c is None and tag in ("revenue_like", "cost_like", "profit_like"):
                    c = next((m for m in self.measures if any(w in m["name"].lower() for w in words if w.isascii())), None)
                if c is None and tag in ("cost_like", "revenue_like") and not any(tag2 in ("revenue_like", "cost_like") for m in self.measures for tag2 in m.get("semantic_tags", [])):
                    c = self._by_tag("money", self.measures)
                if c is not None:
                    return c, None
                return None, next(w for w in words if _has(q, [w]))
        return None, None

    def _resolve_dimension(self, q: str, mentioned: list[str], measure: str | None) -> dict[str, Any] | None:
        for name in mentioned:
            c = self.cols[name]
            if name != measure and (c["role"] in ("dimension", "identifier") or c["data_type"] in ("categorical", "text", "boolean")):
                return c
        for tag, words in DIM_SYNONYMS.items():
            if _has(q, words):
                pool = [c for c in self.dims] + [c for c in self.cols.values() if c["role"] == "identifier"]
                hit = [c for c in pool if tag in c.get("semantic_tags", [])]
                # prefer the column whose own name contains the spoken word ("customer" → Customer, not Emp Code)
                for w in words:
                    for c in hit:
                        if w.isascii() and w.rstrip("s") in c["name"].lower():
                            return c
                if hit:
                    return hit[0]
        return None

    def _value_filters(self, q: str, skip: set[str], original: str = "") -> list[Filter]:
        out: list[Filter] = []
        used_spans: list[tuple[int, int]] = []
        cands = []
        for d in self.dims:
            if d["name"] in skip or d["_distinct"] > 300:
                continue
            try:
                vals = self.ds.distinct_values(d["name"], limit=300)["values"]
            except QueryError:
                continue
            for v in vals:
                sv = str(v["value"]) if v["value"] is not None else ""
                if len(sv) < 2 or sv.isdigit():
                    continue
                if len(sv) <= 3:  # short codes like "IT", "HR", "A" must match exactly as written
                    m = re.search(r"(?<![\w])" + re.escape(sv) + r"(?![\w])", original) if original else None
                    if m:
                        m = re.search(r"(?<![\w])" + re.escape(sv.lower()) + r"(?![\w])", q)
                else:
                    m = re.search(r"(?<![\w])" + re.escape(sv.lower()) + r"(?![\w])", q)
                if m:
                    cands.append((len(sv), d["name"], v["value"], m.span()))
        cands.sort(key=lambda x: -x[0])
        by_col: dict[str, list[Any]] = {}
        for _, col, val, span in cands:
            if any(not (span[1] <= a or span[0] >= b) for a, b in used_spans):
                continue
            used_spans.append(span)
            by_col.setdefault(col, []).append(val)
        for col, vals in by_col.items():
            out.append(Filter(column=col, op="in", values=vals))
        return out

    def _explicit_month(self, q: str) -> tuple[int, int | None] | None:
        for word, num in sorted(MONTH_WORDS.items(), key=lambda kv: -len(kv[0])):
            if len(word) < 3:
                continue
            m = re.search(r"(?<![a-z])" + re.escape(word) + r"(?![a-z])\s*,?\s*(\d{4})?", q)
            if m and not (word == "may" and not m.group(1) and re.search(r"\bmay (i|we|you)\b", q)):
                return num, (int(m.group(1)) if m.group(1) else None)
        return None

    # ------------------------------------------------------------ main
    def plan(self, question: str) -> dict[str, Any]:
        q = " " + re.sub(r"\s+", " ", question.strip().lower()) + " "
        intent = "aggregate"
        for name in ("create_dashboard", "kpi_suggestions", "anomalies", "data_quality", "describe_data", "compare_periods", "trend", "bottom_n", "top_n"):
            if _has(q, INTENT_WORDS[name]):
                intent = name
                break
        if intent == "top_n" and _has(q, AGG_WORDS["max"]):
            intent = "aggregate"
        mentions = [m[0] for m in self._mentions(q)]
        measure_col, missing = self._resolve_measure(q, mentions)
        agg = None
        for a, words in AGG_WORDS.items():
            if _has(q, words):
                agg = a
                break
        dim_col = self._resolve_dimension(q, [m for m in mentions if not measure_col or m != measure_col["name"]], measure_col["name"] if measure_col else None)
        plan: dict[str, Any] = {"intent": intent, "source": "rules", "filters": [], "time_scope": "all", "n": None,
                                "granularity": None, "dimension": None, "measure": None, "reason": ""}
        if missing and intent not in ("create_dashboard", "kpi_suggestions", "describe_data", "data_quality"):
            plan.update({"intent": "unsupported", "missing": missing,
                         "reason": f"No column in this dataset matches '{missing}'."})
            return plan
        if agg == "count":
            if dim_col and re.search(r"(how many|number of|कितने|कितनी|kitne)\s+\w*\s*" + re.escape(dim_col["name"].lower().split()[0][:5]), q):
                plan["measure"] = {"column": dim_col["name"], "agg": "count_distinct"}
                dim_col = None
            else:
                plan["measure"] = {"column": None, "agg": "count_rows"}
        elif measure_col:
            plan["measure"] = {"column": measure_col["name"], "agg": {"avg": "avg", "max": "max", "min": "min"}.get(agg or "", default_agg(measure_col))}
        elif self.measures:
            m0 = self.measures[0]
            plan["measure"] = {"column": m0["name"], "agg": {"avg": "avg", "max": "max", "min": "min"}.get(agg or "", default_agg(m0))}
            plan["measure_defaulted"] = True
        else:
            plan["measure"] = {"column": None, "agg": "count_rows"}
        if dim_col:
            plan["dimension"] = dim_col["name"]
        n = re.search(r"(?:top|bottom|best|worst|टॉप|शीर्ष|first)\s*(\d{1,3})|(\d{1,3})\s*(?:top|best|सबसे)", q)
        if n:
            plan["n"] = int(n.group(1) or n.group(2))
        for gname, words in GRAN_WORDS.items():
            if _has(q, words):
                plan["granularity"] = gname
                break
        for scope, words in TIME_WORDS.items():
            if _has(q, words):
                plan["time_scope"] = scope
                if "week" in " ".join(w for w in words if _has(q, [w])) or "सप्ताह" in q:
                    plan["time_granularity"] = "week"
                elif "quarter" in q or "तिमाही" in q:
                    plan["time_granularity"] = "quarter"
                break
        lastn = re.search(r"(?:last|past|previous|पिछले|pichle)\s+(\d{1,2})\s+(day|week|month|quarter|year|दिन|सप्ताह|महीने|महीनों|साल|वर्ष)", q)
        if lastn:
            unit = {"दिन": "day", "सप्ताह": "week", "महीने": "month", "महीनों": "month", "साल": "year", "वर्ष": "year"}.get(lastn.group(2), lastn.group(2))
            plan["time_scope"] = "last_n"
            plan["last_n"] = {"n": int(lastn.group(1)), "unit": unit}
        em = self._explicit_month(q)
        if em and plan["time_scope"] == "all":
            plan["time_scope"] = "month"
            plan["month"] = {"month": em[0], "year": em[1]}
        vfilters = self._value_filters(q, set(), question)
        grouping = bool(re.search(r"(\bby\b|\bper\b|\beach\b|wise|\bwhich\b|\btop\b|\bbottom\b|कौन|किस|अनुसार|वार|\bkis\b|\bkaun\b)", q))
        if plan["dimension"] and any(f.column == plan["dimension"] for f in vfilters):
            if grouping and plan["intent"] in ("top_n", "bottom_n", "aggregate", "breakdown"):
                vfilters = [f for f in vfilters if f.column != plan["dimension"]]
            else:
                plan["dimension"] = None
        plan["filters"] = [f.model_dump() for f in vfilters]
        if plan.get("measure_defaulted") and vfilters and agg is None:
            plan["measure"] = {"column": None, "agg": "count_rows"}
            plan.pop("measure_defaulted", None)
        which = bool(re.search(r"(\bwhich\b|कौन|किस|\bkis\b|\bkaun\b|\bwho\b)", q))
        if plan["intent"] == "aggregate" and plan["dimension"] and which:
            plan["intent"] = "top_n"
        if plan["intent"] in ("top_n", "bottom_n") and which and not plan.get("n"):
            plan["n"] = 5
            plan["single_answer"] = True
        if plan["intent"] in ("aggregate",) and plan["dimension"]:
            plan["intent"] = "breakdown"
        plan["reason"] = self._reason(plan)
        return plan

    def _reason(self, p: dict[str, Any]) -> str:
        m = p.get("measure") or {}
        parts = [f"{m.get('agg')} of {m.get('column') or 'rows'}"]
        if p.get("dimension"):
            parts.append(f"grouped by {p['dimension']}")
        if p.get("filters"):
            parts.append("filtered to " + "; ".join(f"{f['column']} = {', '.join(map(str, f.get('values') or [f.get('value')]))}" for f in p["filters"]))
        if p.get("time_scope") not in (None, "all"):
            parts.append(f"time: {p['time_scope']}")
        return ", ".join(parts)

    # ------------------------------------------------------------ AI plan validation
    def validate_ai_plan(self, raw: dict[str, Any]) -> dict[str, Any] | None:
        def fix(name: Any) -> str | None:
            if not name or not isinstance(name, str):
                return None
            if name in self.cols:
                return name
            low = {n.lower(): n for n in self.cols}
            if name.lower() in low:
                return low[name.lower()]
            m = difflib.get_close_matches(name.lower(), list(low), n=1, cutoff=0.85)
            return low[m[0]] if m else None

        intent = raw.get("intent")
        valid_intents = {"aggregate", "top_n", "bottom_n", "trend", "compare_periods", "anomalies", "kpi_suggestions", "create_dashboard",
                         "describe_data", "data_quality", "unsupported"}
        if intent not in valid_intents:
            return None
        m = raw.get("measure") or {}
        col = fix(m.get("column")) if m.get("column") else None
        if m.get("column") and not col:
            return None
        agg = m.get("agg") or "sum"
        if agg not in ("sum", "avg", "min", "max", "median", "count_rows", "count_distinct"):
            agg = "sum"
        if col and agg in ("sum", "avg", "min", "max", "median") and self.cols[col]["data_type"] not in NUMERIC_TYPES:
            agg = "count_distinct"
        dim = fix(raw.get("dimension")) if raw.get("dimension") else None
        if raw.get("dimension") and not dim:
            return None
        filters = []
        for f in raw.get("filters") or []:
            c = fix(f.get("column"))
            if not c or f.get("op") not in ("eq", "in", "neq", "gt", "gte", "lt", "lte", "contains"):
                return None
            val = f.get("value")
            filters.append({"column": c, "op": "in" if f["op"] in ("eq", "in") else f["op"],
                            "values": (val if isinstance(val, list) else [val]) if f["op"] in ("eq", "in") else None,
                            "value": None if f["op"] in ("eq", "in") else val})
        plan = {"intent": "breakdown" if intent == "aggregate" and dim else intent, "source": "ai", "measure": {"column": col, "agg": agg if col else "count_rows"},
                "dimension": dim, "granularity": raw.get("granularity"), "n": raw.get("n"), "filters": filters,
                "time_scope": raw.get("time_scope") or "all", "time_granularity": raw.get("time_granularity"), "reason": str(raw.get("reason", ""))[:300]}
        if plan["granularity"] not in (None, "day", "week", "month", "quarter", "year"):
            plan["granularity"] = None
        if plan["time_scope"] not in ("all", "latest_period", "previous_period", "latest_year"):
            plan["time_scope"] = "all"
        return plan


class NLQEngine:
    def __init__(self, provider: AIProvider):
        self.provider = provider

    def ask(self, ds: DataSource, question: str, *, filters: list[Filter] | None = None, quality: dict[str, Any] | None = None,
            language: str | None = None) -> dict[str, Any]:
        question = (question or "").strip()[:500]
        lang = language if language in ("en", "hi") else detect_language(question)
        planner = Planner(ds)
        plan = planner.plan(question)
        ai_error = None
        if self.provider.available:
            try:
                ai_plan = self._ai_plan(planner, question)
                if ai_plan:
                    # keep rule-detected value filters the AI may have missed
                    if not ai_plan["filters"] and plan["filters"]:
                        ai_plan["filters"] = plan["filters"]
                    plan = ai_plan
            except (AIProviderError, ValueError, KeyError, TypeError) as e:
                ai_error = str(e)[:200]
        base_filters = list(filters or [])
        try:
            res = self._execute(ds, planner, plan, base_filters, quality, lang, question)
        except QueryError as e:
            res = {"answer": _t(lang, f"I could not compute that: {e}", f"यह गणना नहीं हो सकी: {e}"), "table": None, "chart": None}
        res.update({"question": question, "language": lang, "plan": plan, "intent": plan["intent"], "answer_source": "computed"})
        if ai_error:
            res["ai_error"] = ai_error
        if self.provider.available and res.get("table") and plan["intent"] not in ("kpi_suggestions", "create_dashboard", "describe_data"):
            try:
                self._ai_answer(res, question, lang)
            except (AIProviderError, ValueError, KeyError, TypeError) as e:
                res["ai_error"] = str(e)[:200]
        return res

    # ------------------------------------------------------------ AI helpers
    def _ai_plan(self, planner: Planner, question: str) -> dict[str, Any] | None:
        lines = []
        for c in list(planner.cols.values())[:80]:
            tops = ", ".join(str(t["value"]) for t in c.get("stats", {}).get("top_values", [])[:5]) if c["data_type"] in ("categorical", "boolean") else ""
            lines.append(f"{c['name']} | {c['data_type']} | {c['role']} | {tops}")
        date_col = planner.schema.get("primary_date_column")
        rng = ""
        if date_col:
            lo, hi = planner.ds.date_bounds(date_col)
            rng = f"{str(lo)[:10]} to {str(hi)[:10]}"
        system, user, _ = prompt_manager.render("nlq", columns="\n".join(lines), date_col=date_col, date_range=rng, question=question)
        raw = self.provider.complete_json(system, user, max_tokens=600)
        if not isinstance(raw, dict):
            return None
        return planner.validate_ai_plan(raw)

    def _ai_answer(self, res: dict[str, Any], question: str, lang: str) -> None:
        table = res["table"]
        system, user, _ = prompt_manager.render("answer", language=lang, question=question, explanation=res.get("explanation", ""),
                                                result={"columns": table["columns"], "rows": table["rows"][:15]})
        raw = self.provider.complete_json(system, user, max_tokens=400)
        text = str(raw.get("answer", "")).strip() if isinstance(raw, dict) else ""
        if not text:
            return
        nums = [v for r in table["rows"][:15] for v in r if isinstance(v, (int, float))]
        pseudo = [{"numbers": nums + res.get("derived_numbers", []), "text": {"en": res["answer"]}}]
        ok, bad = check_grounded(text, pseudo)
        if ok:
            res["computed_answer"] = res["answer"]
            res["answer"] = text
            res["answer_source"] = "ai"
        else:
            res["ai_answer_rejected"] = {"text": text, "unsupported_numbers": bad}

    # ------------------------------------------------------------ execution
    def _time_filters(self, ds: DataSource, plan: dict[str, Any], base: list[Filter]) -> tuple[list[Filter], str | None]:
        date_col = ds.schema.get("primary_date_column")
        scope = plan.get("time_scope", "all")
        if scope == "all" or not date_col:
            return [], None
        lo, hi = ds.date_bounds(date_col, base)
        hi_d = _as_date(hi)
        if not hi_d:
            return [], None
        g = plan.get("time_granularity") or "month"

        def start_of(d: date, gg: str) -> date:
            if gg == "week":
                return d - timedelta(days=d.weekday())
            if gg == "quarter":
                return date(d.year, 3 * ((d.month - 1) // 3) + 1, 1)
            if gg == "year":
                return date(d.year, 1, 1)
            return date(d.year, d.month, 1)

        if scope in ("latest_period", "previous_period"):
            s = start_of(hi_d, g)
            if scope == "previous_period":
                s = start_of(s - timedelta(days=1), g)
            e = _period_end(s, g)
            label = period_label(s, g)
            return [Filter(column=date_col, op="date_range", values=[s.isoformat(), e.isoformat()])], label
        if scope in ("latest_year", "previous_year"):
            y = hi_d.year - (1 if scope == "previous_year" else 0)
            return [Filter(column=date_col, op="date_range", values=[f"{y}-01-01", f"{y}-12-31"])], str(y)
        if scope == "last_n":
            ln = plan.get("last_n") or {"n": 3, "unit": "month"}
            return [Filter(column=date_col, op="relative", value={"unit": ln["unit"], "n": ln["n"], "anchor": "data"})], f"last {ln['n']} {ln['unit']}(s) of data"
        if scope == "month":
            mm = plan["month"]
            y = mm.get("year") or hi_d.year
            if not mm.get("year") and date(y, mm["month"], 1) > hi_d:
                y -= 1
            s = date(y, mm["month"], 1)
            return [Filter(column=date_col, op="date_range", values=[s.isoformat(), _period_end(s, "month").isoformat()])], period_label(s, "month")
        return [], None

    def _execute(self, ds: DataSource, planner: Planner, plan: dict[str, Any], base: list[Filter], quality: dict[str, Any] | None,
                 lang: str, question: str) -> dict[str, Any]:
        intent = plan["intent"]
        fvals = [Filter(**f) for f in plan.get("filters", [])]
        tfs, tlabel = self._time_filters(ds, plan, base)
        flt = base + fvals + tfs
        scope_txt = f" in {tlabel}" if tlabel else ""
        scope_hi = f" ({tlabel})" if tlabel else ""
        mdef = plan.get("measure") or {"column": None, "agg": "count_rows"}
        m = Measure(column=mdef.get("column"), agg=mdef.get("agg") or "sum")
        mname = measure_alias(m) if m.agg != "count_rows" else "Records"
        kind, cur = self._fmt(ds, m)
        fv = lambda v: format_value(v, kind, cur)  # noqa: E731
        out: dict[str, Any] = {"table": None, "chart": None, "explanation": "", "sql": None, "suggestions": []}
        filt_txt = _pretty_filters(fvals + tfs)
        vals_txt = _pretty_filters(fvals)

        if intent == "unsupported":
            miss = plan.get("missing") or "that"
            out["answer"] = _t(lang, f"This cannot be determined from the available dataset: there is no column for '{miss}'. "
                                     f"Available measures: {', '.join(c['name'] for c in planner.measures[:6]) or 'none'}.",
                               f"यह उपलब्ध डेटा से तय नहीं किया जा सकता: '{miss}' के लिए कोई कॉलम नहीं है। उपलब्ध मापक: {', '.join(c['name'] for c in planner.measures[:6]) or 'कोई नहीं'}।")
            out["suggestions"] = [q.get(lang) or q["en"] for q in suggestions(ds, [])["questions"][:4]]
            return out
        if intent == "kpi_suggestions":
            s = suggestions(ds, [])
            items = s["suggested_kpis"]
            out["kpis"] = items
            out["answer"] = _t(lang, "Based on the columns in this dataset, these KPIs are worth tracking: " + "; ".join(k["title"] for k in items) + ".",
                               "इस डेटा के कॉलम के आधार पर ये KPI ट्रैक करने लायक हैं: " + "; ".join(k["title"] for k in items) + "।")
            out["explanation"] = "Suggested from detected measures, dimensions, status columns and identifiers (no numbers invented)."
            return out
        if intent == "create_dashboard":
            out["create_dashboard"] = True
            out["answer"] = _t(lang, "I created a new dashboard from this dataset's schema.", "मैंने इस डेटा के स्कीमा से एक नया डैशबोर्ड बनाया है।")
            return out
        if intent == "describe_data":
            sc = ds.schema
            n = ds.count(base)
            dcol = sc.get("primary_date_column")
            rng = ""
            if dcol:
                lo, hi = ds.date_bounds(dcol, base)
                rng = f" from {str(lo)[:10]} to {str(hi)[:10]}"
            dom = sc.get("domain", {}).get("guess", "general").replace("_", " ")
            out["answer"] = _t(lang,
                               f"The dataset has {n:,} records and {sc.get('column_count')} columns{rng}. It looks like {dom} data. "
                               f"Measures: {', '.join(sc.get('measures', [])[:8]) or 'none'}. Dimensions: {', '.join(sc.get('dimensions', [])[:8]) or 'none'}.",
                               f"इस डेटा में {n:,} रिकॉर्ड और {sc.get('column_count')} कॉलम हैं{(' (' + rng.strip() + ')') if rng else ''}। "
                               f"मापक: {', '.join(sc.get('measures', [])[:8]) or 'कोई नहीं'}। आयाम: {', '.join(sc.get('dimensions', [])[:8]) or 'कोई नहीं'}।")
            out["table"] = {"columns": ["Column", "Type", "Role", "Missing %"],
                            "rows": [[c["name"], c["data_type"], c["role"], c.get("stats", {}).get("null_pct")] for c in sc.get("columns", [])]}
            return out
        if intent == "data_quality":
            qs = (quality or {}).get("summary", {})
            issues = (quality or {}).get("issues", [])[:8]
            out["answer"] = _t(lang,
                               f"Data quality score {qs.get('score', '—')}/100: {qs.get('missing_cells', 0):,} missing cells ({qs.get('missing_pct', 0)}%), "
                               f"{qs.get('duplicate_rows', 0):,} duplicate rows, {qs.get('invalid_values', 0):,} invalid values.",
                               f"डेटा गुणवत्ता स्कोर {qs.get('score', '—')}/100: {qs.get('missing_cells', 0):,} खाली सेल ({qs.get('missing_pct', 0)}%), "
                               f"{qs.get('duplicate_rows', 0):,} डुप्लिकेट पंक्तियाँ, {qs.get('invalid_values', 0):,} गलत मान।")
            out["table"] = {"columns": ["Severity", "Column", "Issue"], "rows": [[i["severity"], i.get("column") or "—", i["message_hi"] if lang == "hi" else i["message"]] for i in issues]}
            out["derived_numbers"] = [qs.get("score"), qs.get("missing_cells"), qs.get("missing_pct"), qs.get("duplicate_rows"), qs.get("invalid_values")]
            return out
        if intent == "anomalies":
            return self._anomalies(ds, planner, m, flt, lang, out, fv)
        date_col = ds.schema.get("primary_date_column")
        if intent == "trend":
            if not date_col:
                out["answer"] = _t(lang, "This dataset has no date column, so a trend over time cannot be determined.",
                                   "इस डेटा में तारीख का कॉलम नहीं है, इसलिए समय के साथ ट्रेंड नहीं निकाला जा सकता।")
                return out
            lo, hi = ds.date_bounds(date_col, flt)
            g = plan.get("granularity") or best_granularity(lo, hi)
            dims = [Dimension(column=date_col, granularity=g, alias="Period")]
            res = ds.aggregate(QuerySpec(dimensions=dims, measures=[m], filters=flt, limit=500))
            rows = [r for r in res["rows"] if r[0] is not None]
            if not rows:
                out["answer"] = _t(lang, "No data for this selection.", "इस चयन के लिए कोई डेटा नहीं है।")
                return out
            vals = [r[1] for r in rows]
            peak = max(rows, key=lambda r: r[1] or float("-inf"))
            tr = linear_trend(vals)
            direction = {"up": "upward", "down": "downward", "flat": "flat"}.get(tr["direction"], "") if tr else "unclear"
            out["answer"] = _t(lang,
                               f"{mname}{scope_txt} by {g}: from {fv(rows[0][1])} ({period_label(rows[0][0], g)}) to {fv(rows[-1][1])} ({period_label(rows[-1][0], g)}). "
                               f"The highest {g} was {period_label(peak[0], g)} ({fv(peak[1])}). Overall trend: {direction}"
                               + (f" ({tr['strength']})." if tr else "."),
                               f"{mname}{scope_hi} ({g}): {period_label(rows[0][0], g)} में {fv(rows[0][1])} से {period_label(rows[-1][0], g)} में {fv(rows[-1][1])}। "
                               f"सबसे अधिक {period_label(peak[0], g)} में ({fv(peak[1])})। कुल रुझान: {'बढ़ता' if tr and tr['direction'] == 'up' else 'घटता' if tr and tr['direction'] == 'down' else 'स्थिर/अस्पष्ट'}।")
            out["table"] = {"columns": ["Period", mname], "rows": [[period_label(r[0], g), r[1]] for r in rows]}
            out["chart"] = build_chart(ds, ChartSpec(type="line", dimension=dims[0], measures=[m]), flt)
            out["sql"] = res["sql"]
            out["explanation"] = f"{mname} grouped by {g} of {date_col}" + (f"; filters: {filt_txt}" if filt_txt else "")
            return out
        if intent == "compare_periods":
            return self._compare(ds, plan, m, mname, base + fvals, lang, out, fv)
        if intent in ("top_n", "bottom_n", "breakdown"):
            dim_name = plan.get("dimension")
            if not dim_name:
                d0 = planner.dims[0] if planner.dims else None
                if not d0:
                    intent = "aggregate"
                else:
                    dim_name = d0["name"]
                    plan["dimension"] = dim_name
                    plan["dimension_defaulted"] = True
            if dim_name:
                n = int(plan.get("n") or (5 if plan.get("single_answer") else 10))
                n = max(1, min(n, 100))
                desc = intent != "bottom_n"
                dim = Dimension(column=dim_name)
                if ds.dtype(dim_name) in DATE_TYPES:
                    lo, hi = ds.date_bounds(dim_name, flt)
                    dim = Dimension(column=dim_name, granularity=plan.get("granularity") or best_granularity(lo, hi))
                spec = QuerySpec(dimensions=[dim], measures=[m], filters=flt, sort=[Sort(by=mname, desc=desc)], limit=n)
                res = ds.aggregate(spec)
                rows = [r for r in res["rows"] if r[1] is not None]
                if not rows:
                    out["answer"] = _t(lang, "No data matches this question.", "इस प्रश्न से मेल खाता कोई डेटा नहीं है।")
                    return out
                total = ds.aggregate(QuerySpec(measures=[m], filters=flt))["rows"][0][0] if m.agg in ("sum", "count_rows") else None
                first = rows[0]
                share = (first[1] / total * 100) if total else None
                word = "highest" if desc else "lowest"
                word_hi = "सबसे अधिक" if desc else "सबसे कम"
                if plan.get("single_answer") or intent in ("top_n", "bottom_n") and n == 1:
                    rest = ", ".join(f"{r[0]} ({fv(r[1])})" for r in rows[1:4])
                    en = f"{first[0]} has the {word} {mname}{scope_txt}: {fv(first[1])}" + (f" ({share:.1f}% of total)" if share is not None else "") + "." + (f" Next: {rest}." if rest else "")
                    hi_t = f"{scope_hi.strip() + ' ' if scope_hi else ''}{dim_name} में {first[0]} का {mname} {word_hi} है: {fv(first[1])}" + (f" (कुल का {share:.1f}%)" if share is not None else "") + "।" + (f" इसके बाद: {rest}।" if rest else "")
                elif intent == "breakdown":
                    listed = ", ".join(f"{r[0]}: {fv(r[1])}" for r in rows[:6])
                    en = f"{mname} by {dim_name}{scope_txt} — {listed}" + (" …" if len(rows) > 6 or res["truncated"] else "") + "."
                    hi_t = f"{dim_name} के अनुसार {mname}{scope_hi} — {listed}" + (" …" if len(rows) > 6 or res["truncated"] else "") + "।"
                else:
                    listed = ", ".join(f"{i + 1}. {r[0]} ({fv(r[1])})" for i, r in enumerate(rows[:10]))
                    en = f"{'Top' if desc else 'Bottom'} {len(rows)} {dim_name} by {mname}{scope_txt}: {listed}."
                    hi_t = f"{mname}{scope_hi} के अनुसार {word_hi} {len(rows)} {dim_name}: {listed}।"
                out["answer"] = _t(lang, en, hi_t)
                cols = [dim_name, mname] + (["Share %"] if total else [])
                out["table"] = {"columns": cols, "rows": [[r[0], r[1]] + ([round(r[1] / total * 100, 2)] if total else []) for r in rows]}
                if share is not None:
                    out["derived_numbers"] = [round(share, 2)] + [round(r[1] / total * 100, 2) for r in rows]
                out["chart"] = build_chart(ds, ChartSpec(type="hbar" if not dim.granularity else "line", dimension=dim, measures=[m], top_n=n, other=False,
                                                         sort="value_desc" if desc else "value_asc"), flt)
                out["sql"] = res["sql"]
                out["explanation"] = (f"{mname} grouped by {dim_name}, sorted {'descending' if desc else 'ascending'}, top {n}"
                                      + (f"; filters: {filt_txt}" if filt_txt else "") + (" (dimension chosen automatically)" if plan.get("dimension_defaulted") else ""))
                return out
        # plain aggregate
        res = ds.aggregate(QuerySpec(measures=[m], filters=flt))
        v = res["rows"][0][0]
        n_rows = ds.count(flt)
        label = "Number of records" if m.agg == "count_rows" else mname
        label_hi = "रिकॉर्ड की संख्या" if m.agg == "count_rows" else mname
        out["answer"] = _t(lang, f"{label}{scope_txt}" + (f" where {vals_txt}" if fvals else "") + f" is {fv(v)}" + (f", based on {n_rows:,} records." if m.agg != "count_rows" else "."),
                           f"{label_hi}{scope_hi}" + (f" ({vals_txt})" if fvals else "") + f": {fv(v)}" + (f" ({n_rows:,} रिकॉर्ड के आधार पर)।" if m.agg != "count_rows" else "।"))
        out["table"] = {"columns": [mname, "Records"], "rows": [[v, n_rows]]}
        out["sql"] = res["sql"]
        out["explanation"] = f"{mname}" + (f" with filters: {filt_txt}" if filt_txt else " over all rows") + (" (measure chosen automatically)" if plan.get("measure_defaulted") else "")
        return out

    def _fmt(self, ds: DataSource, m: Measure) -> tuple[str, str | None]:
        if m.agg in ("count_rows", "count", "count_distinct") or not m.column:
            return "number", None
        c = ds.columns.get(m.column, {})
        if c.get("data_type") == "percentage":
            return "percent", None
        if c.get("data_type") == "currency":
            return "currency", (c.get("format") or {}).get("currency") or "INR"
        return "number", None

    def _compare(self, ds: DataSource, plan: dict[str, Any], m: Measure, mname: str, flt: list[Filter], lang: str,
                 out: dict[str, Any], fv) -> dict[str, Any]:
        date_col = ds.schema.get("primary_date_column")
        if not date_col:
            out["answer"] = _t(lang, "This dataset has no date column, so periods cannot be compared.", "इस डेटा में तारीख का कॉलम नहीं है, इसलिए अवधियों की तुलना नहीं हो सकती।")
            return out
        g = plan.get("time_granularity") or plan.get("granularity") or "month"
        lo, hi = ds.date_bounds(date_col, flt)
        res = ds.aggregate(QuerySpec(dimensions=[Dimension(column=date_col, granularity=g, alias="p")], measures=[m], filters=flt, limit=5000))
        pts = [r for r in res["rows"] if r[0] is not None]
        if len(pts) < 2:
            out["answer"] = _t(lang, "There is only one period in the data, so nothing can be compared.", "डेटा में केवल एक अवधि है, इसलिए तुलना नहीं हो सकती।")
            return out
        cur_p, cur_v = pts[-1]
        prev_p, prev_v = pts[-2]
        ch = pct_change(cur_v, prev_v)
        diff = (cur_v or 0) - (prev_v or 0)
        lc, lp = period_label(cur_p, g), period_label(prev_p, g)
        partial = _as_date(hi) and _as_date(cur_p) and _as_date(hi) < _period_end(_as_date(cur_p), g)
        en = (f"{mname} in {lc} is {fv(cur_v)} vs {fv(prev_v)} in {lp} ({'+' if diff >= 0 else '−'}{fv(abs(diff))}"
              + (f", {ch:+.1f}%" if ch is not None else "") + ")." + (f" Note: {lc} is incomplete in the data." if partial else ""))
        hi_t = (f"{lc} में {mname} {fv(cur_v)} है, जबकि {lp} में {fv(prev_v)} था ({'+' if diff >= 0 else '−'}{fv(abs(diff))}"
                + (f", {ch:+.1f}%" if ch is not None else "") + ")।" + (f" ध्यान दें: {lc} का डेटा अधूरा है।" if partial else ""))
        rows = [["Previous", lp, prev_v], ["Current", lc, cur_v]]
        table = {"columns": ["", "Period", mname], "rows": rows}
        derived = [diff, abs(diff)] + ([ch, abs(ch)] if ch is not None else [])
        dim_name = plan.get("dimension") or (rank_dimensions(ds.schema)[0]["name"] if rank_dimensions(ds.schema) else None)
        if dim_name and ds.dtype(dim_name) not in DATE_TYPES:
            bd = ds.aggregate(QuerySpec(dimensions=[Dimension(column=date_col, granularity=g, alias="p"), Dimension(column=dim_name)],
                                        measures=[m], filters=flt, limit=20000))
            cur_map = {k: v for p, k, v in bd["rows"] if p == cur_p}
            prev_map = {k: v for p, k, v in bd["rows"] if p == prev_p}
            deltas = sorted(((k, (cur_map.get(k) or 0) - (prev_map.get(k) or 0), prev_map.get(k), cur_map.get(k)) for k in set(cur_map) | set(prev_map)),
                            key=lambda x: -abs(x[1]))
            if deltas:
                k, d, pv, cv = deltas[0]
                en += f" The biggest change was in {dim_name} '{k}' ({'+' if d >= 0 else '−'}{fv(abs(d))})."
                hi_t += f" सबसे बड़ा बदलाव {dim_name} '{k}' में रहा ({'+' if d >= 0 else '−'}{fv(abs(d))})।"
                table = {"columns": [dim_name, lp, lc, "Change", "Change %"],
                         "rows": [[k2, p2, c2, d2, (round(pct_change(c2, p2), 2) if (c2 is not None and p2) else None)] for k2, d2, p2, c2 in deltas[:20]]}
                derived += [x for k2, d2, p2, c2 in deltas[:20] for x in (d2, abs(d2), (pct_change(c2, p2) if (c2 is not None and p2) else 0))]
                table["summary"] = rows
        out.update({"answer": _t(lang, en, hi_t), "table": table, "derived_numbers": derived + [prev_v, cur_v],
                    "chart": build_chart(ds, ChartSpec(type="bar", dimension=Dimension(column=date_col, granularity=g), measures=[m]), flt),
                    "sql": res["sql"], "explanation": f"{mname} for the last two {g}s in the data ({lp} and {lc})" + (f", broken down by {dim_name}" if dim_name else "")})
        return out

    def _anomalies(self, ds: DataSource, planner: Planner, m: Measure, flt: list[Filter], lang: str, out: dict[str, Any], fv) -> dict[str, Any]:
        col = m.column if (m.column and ds.dtype(m.column) in NUMERIC_TYPES) else (planner.measures[0]["name"] if planner.measures else None)
        if not col:
            out["answer"] = _t(lang, "There are no numeric columns, so unusual values cannot be detected.", "कोई संख्यात्मक कॉलम नहीं है, इसलिए असामान्य मान नहीं खोजे जा सकते।")
            return out
        st = ds.columns[col].get("stats", {})
        hi_f, lo_f = st.get("upper_fence"), st.get("lower_fence")
        if hi_f is None:
            out["answer"] = _t(lang, f"'{col}' has too little variation to detect unusual values.", f"'{col}' में असामान्य मान पहचानने लायक विविधता नहीं है।")
            return out
        q = quote_ident(col)
        params: list[Any] = []
        where = ds.where_sql(flt, None, params)
        cond = f"({q} > ? OR {q} < ?)" + (f" AND {q} <> 0" if str(st.get("outlier_method", "")).startswith("iqr_nonzero") else "")
        where = (where + " AND " + cond) if where else "WHERE " + cond
        params += [hi_f, lo_f if lo_f is not None else float("-inf")]
        show = [col] + (ds.schema.get("identifier_columns") or [])[:1] + [d["name"] for d in planner.dims[:2]]
        if ds.schema.get("primary_date_column"):
            show.append(ds.schema["primary_date_column"])
        show = list(dict.fromkeys(show))
        sql = f"SELECT {', '.join(quote_ident(c) for c in show)} FROM data {where} ORDER BY ABS({q} - {float(st.get('median') or 0)}) DESC LIMIT 50"
        _, rows = ds.run(sql, params)
        _, cnt = ds.run(f"SELECT COUNT(*) FROM data {where}", params)
        n = int(cnt[0][0])
        med = st.get("median")
        if n == 0:
            out["answer"] = _t(lang, f"No unusual {col} values were found (expected range {fv(lo_f)} to {fv(hi_f)}).",
                               f"{col} में कोई असामान्य मान नहीं मिला (अपेक्षित दायरा {fv(lo_f)} से {fv(hi_f)})।")
        else:
            top = rows[0]
            out["answer"] = _t(lang,
                               f"Found {n:,} unusual record(s) where {col} is outside the expected range {fv(lo_f)} to {fv(hi_f)} (median {fv(med)}). "
                               f"The most extreme is {fv(top[0])}" + (f" ({', '.join(str(x) for x in top[1:] if x is not None)})" if len(top) > 1 else "") + ".",
                               f"{n:,} असामान्य रिकॉर्ड मिले जिनमें {col} अपेक्षित दायरे {fv(lo_f)} से {fv(hi_f)} के बाहर है (माध्यिका {fv(med)})। "
                               f"सबसे असामान्य मान {fv(top[0])} है" + (f" ({', '.join(str(x) for x in top[1:] if x is not None)})" if len(top) > 1 else "") + "।")
        from misgenius.analytics.query import _json

        out["table"] = {"columns": show, "rows": [[_json(v) for v in r] for r in rows]}
        out["derived_numbers"] = [n, hi_f, lo_f, med]
        out["sql"] = sql
        out["explanation"] = (f"Robust outlier rule on {col}: values beyond the fences computed from the data "
                              f"({st.get('outlier_method')}, 3×IQR{' on log scale' if 'log' in str(st.get('outlier_method')) else ''}).")
        return out


def _pretty_filters(filters: list[Filter]) -> str:
    parts = []
    for f in filters:
        if f.op == "in":
            parts.append(f"{f.column} = {' / '.join(str(v) for v in (f.values or []))}")
        elif f.op in ("between", "date_range"):
            a, b = (f.values or [None, None])[:2]
            parts.append(f"{f.column} {a} to {b}")
        elif f.op == "relative":
            parts.append(f"{f.column} in the last {f.value.get('n')} {f.value.get('unit')}(s)")
        else:
            sym = {"eq": "=", "neq": "≠", "gt": ">", "gte": "≥", "lt": "<", "lte": "≤", "contains": "contains"}.get(f.op, f.op)
            parts.append(f"{f.column} {sym} {f.value}")
    return ", ".join(parts)


def _t(lang: str, en: str, hi: str) -> str:
    return hi if lang == "hi" else en


__all__ = ["NLQEngine", "Planner", "detect_language", "datetime"]
