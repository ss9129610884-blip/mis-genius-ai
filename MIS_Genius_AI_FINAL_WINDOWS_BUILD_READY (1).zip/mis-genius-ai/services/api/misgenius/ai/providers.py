"""AI provider abstraction.

`AIProvider` is the only thing the rest of the app talks to. Providers call their
HTTP APIs server-side with httpx; API keys come from server configuration (env or
the encrypted org setting) and are never sent to the browser.

Supported: Anthropic Claude, OpenAI, Google Gemini, and any OpenAI-compatible
endpoint (Ollama, LM Studio, vLLM, Azure-style gateways) for local/offline LLMs.
`NoAIProvider` is used when nothing is configured; every AI feature then falls
back to deterministic analytics.
"""
from __future__ import annotations

import json
import logging
import re
import time
from abc import ABC, abstractmethod
from dataclasses import dataclass
from typing import Any

import httpx

log = logging.getLogger("misgenius.ai")

DEFAULT_MODELS = {
    "anthropic": "claude-sonnet-5",
    "openai": "gpt-4.1-mini",
    "gemini": "gemini-2.5-flash",
    "openai_compatible": "llama3.1",
}


class AIProviderError(Exception):
    pass


@dataclass
class AIConfig:
    provider: str = "none"
    api_key: str | None = None
    model: str | None = None
    base_url: str | None = None
    timeout: float = 60.0


def extract_json(text: str) -> Any:
    """Parse JSON from a model reply, tolerating code fences or leading prose."""
    t = text.strip()
    t = re.sub(r"^```(?:json)?\s*|\s*```$", "", t)
    try:
        return json.loads(t)
    except json.JSONDecodeError:
        pass
    start = min([i for i in (t.find("{"), t.find("[")) if i >= 0], default=-1)
    if start < 0:
        raise AIProviderError("The AI reply did not contain JSON")
    opener = t[start]
    closer = "}" if opener == "{" else "]"
    depth = 0
    in_str = False
    esc = False
    for i in range(start, len(t)):
        ch = t[i]
        if in_str:
            if esc:
                esc = False
            elif ch == "\\":
                esc = True
            elif ch == '"':
                in_str = False
            continue
        if ch == '"':
            in_str = True
        elif ch == opener:
            depth += 1
        elif ch == closer:
            depth -= 1
            if depth == 0:
                return json.loads(t[start: i + 1])
    raise AIProviderError("The AI reply contained malformed JSON")


class AIProvider(ABC):
    name = "base"

    def __init__(self, cfg: AIConfig):
        self.cfg = cfg
        self.model = cfg.model or DEFAULT_MODELS.get(cfg.provider, "")

    @property
    def available(self) -> bool:
        return True

    @property
    def label(self) -> str:
        return f"{self.name}:{self.model}"

    @abstractmethod
    def _complete(self, system: str, user: str, *, json_mode: bool, max_tokens: int) -> str: ...

    def complete_text(self, system: str, user: str, max_tokens: int = 1500) -> str:
        return self._call(system, user, json_mode=False, max_tokens=max_tokens)

    def complete_json(self, system: str, user: str, max_tokens: int = 3000) -> Any:
        text = self._call(system, user + "\n\nReturn ONLY valid JSON. No markdown, no commentary.", json_mode=True, max_tokens=max_tokens)
        return extract_json(text)

    def _call(self, system: str, user: str, *, json_mode: bool, max_tokens: int) -> str:
        t0 = time.monotonic()
        last: Exception | None = None
        for attempt in range(2):
            try:
                out = self._complete(system, user, json_mode=json_mode, max_tokens=max_tokens)
                log.info("ai call ok", extra={"action": "ai_call", "duration_ms": int((time.monotonic() - t0) * 1000)})
                return out
            except httpx.HTTPStatusError as e:
                code = e.response.status_code
                last = AIProviderError(_friendly_status(self.name, code, e.response.text[:300]))
                if code in (429, 500, 502, 503, 529) and attempt == 0:
                    time.sleep(1.5)
                    continue
                break
            except httpx.HTTPError as e:
                last = AIProviderError(f"Could not reach the {self.name} API ({type(e).__name__}). Check the internet connection.")
                if attempt == 0:
                    time.sleep(1.0)
                    continue
        assert last is not None
        raise last

    def test(self) -> dict[str, Any]:
        reply = self.complete_json("You are a connectivity check.", 'Reply with {"ok": true}.', max_tokens=50)
        return {"ok": bool(isinstance(reply, dict) and reply.get("ok")), "provider": self.name, "model": self.model}


def _friendly_status(name: str, code: int, body: str) -> str:
    if code in (401, 403):
        return f"The {name} API rejected the API key (HTTP {code}). Check the key in AI settings."
    if code == 404:
        return f"The {name} model was not found (HTTP 404). Check the model name in AI settings."
    if code == 429:
        return f"The {name} API rate limit or quota was reached (HTTP 429)."
    return f"The {name} API returned an error (HTTP {code})."


class NoAIProvider(AIProvider):
    name = "none"

    @property
    def available(self) -> bool:
        return False

    @property
    def label(self) -> str:
        return "deterministic"

    def _complete(self, system: str, user: str, *, json_mode: bool, max_tokens: int) -> str:
        raise AIProviderError("No AI provider is configured")


class AnthropicProvider(AIProvider):
    name = "anthropic"

    def _complete(self, system: str, user: str, *, json_mode: bool, max_tokens: int) -> str:
        if not self.cfg.api_key:
            raise AIProviderError("Anthropic API key is not configured")
        url = (self.cfg.base_url or "https://api.anthropic.com").rstrip("/") + "/v1/messages"
        with httpx.Client(timeout=self.cfg.timeout) as c:
            r = c.post(url, headers={"x-api-key": self.cfg.api_key, "anthropic-version": "2023-06-01", "content-type": "application/json"},
                       json={"model": self.model, "max_tokens": max_tokens, "system": system,
                             "messages": [{"role": "user", "content": user}], "temperature": 0.2})
            r.raise_for_status()
            data = r.json()
        return "".join(b.get("text", "") for b in data.get("content", []) if b.get("type") == "text")


class OpenAIProvider(AIProvider):
    name = "openai"
    default_base = "https://api.openai.com/v1"

    def _complete(self, system: str, user: str, *, json_mode: bool, max_tokens: int) -> str:
        base = (self.cfg.base_url or self.default_base).rstrip("/")
        headers = {"content-type": "application/json"}
        if self.cfg.api_key:
            headers["authorization"] = f"Bearer {self.cfg.api_key}"
        elif self.name == "openai":
            raise AIProviderError("OpenAI API key is not configured")
        body: dict[str, Any] = {"model": self.model, "messages": [{"role": "system", "content": system}, {"role": "user", "content": user}],
                                "temperature": 0.2, "max_tokens": max_tokens}
        if json_mode:
            body["response_format"] = {"type": "json_object"}
        with httpx.Client(timeout=self.cfg.timeout) as c:
            r = c.post(base + "/chat/completions", headers=headers, json=body)
            if r.status_code == 400 and json_mode and "response_format" in r.text:
                body.pop("response_format", None)  # some compatible servers do not support JSON mode
                r = c.post(base + "/chat/completions", headers=headers, json=body)
            r.raise_for_status()
            data = r.json()
        return data["choices"][0]["message"].get("content") or ""


class OpenAICompatibleProvider(OpenAIProvider):
    name = "openai_compatible"
    default_base = "http://localhost:11434/v1"  # Ollama


class GeminiProvider(AIProvider):
    name = "gemini"

    def _complete(self, system: str, user: str, *, json_mode: bool, max_tokens: int) -> str:
        if not self.cfg.api_key:
            raise AIProviderError("Gemini API key is not configured")
        base = (self.cfg.base_url or "https://generativelanguage.googleapis.com/v1beta").rstrip("/")
        body: dict[str, Any] = {
            "systemInstruction": {"parts": [{"text": system}]},
            "contents": [{"role": "user", "parts": [{"text": user}]}],
            "generationConfig": {"temperature": 0.2, "maxOutputTokens": max_tokens},
        }
        if json_mode:
            body["generationConfig"]["responseMimeType"] = "application/json"
        with httpx.Client(timeout=self.cfg.timeout) as c:
            r = c.post(f"{base}/models/{self.model}:generateContent", headers={"x-goog-api-key": self.cfg.api_key}, json=body)
            r.raise_for_status()
            data = r.json()
        cands = data.get("candidates") or []
        if not cands:
            raise AIProviderError("Gemini returned no answer (it may have been blocked by safety filters)")
        return "".join(p.get("text", "") for p in cands[0].get("content", {}).get("parts", []))


PROVIDERS: dict[str, type[AIProvider]] = {
    "none": NoAIProvider,
    "anthropic": AnthropicProvider,
    "openai": OpenAIProvider,
    "gemini": GeminiProvider,
    "openai_compatible": OpenAICompatibleProvider,
}


def make_provider(cfg: AIConfig) -> AIProvider:
    cls = PROVIDERS.get(cfg.provider or "none", NoAIProvider)
    if cls is not NoAIProvider and cls is not OpenAICompatibleProvider and not cfg.api_key:
        return NoAIProvider(AIConfig())
    return cls(cfg)
