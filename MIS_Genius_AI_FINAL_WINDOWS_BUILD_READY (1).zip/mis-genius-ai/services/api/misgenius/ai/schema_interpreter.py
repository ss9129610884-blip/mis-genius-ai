"""SchemaInterpreter: human-friendly labels / descriptions for columns.

Deterministic descriptions are always produced from types, roles and tags. When an
AI provider is configured it may improve the wording; its output is accepted only
for columns that exist, and it never changes types, roles or data.
"""
from __future__ import annotations

from typing import Any

from misgenius.ai.prompts import prompt_manager
from misgenius.ai.providers import AIProvider, AIProviderError

TYPE_TEXT = {
    "integer": "whole number", "decimal": "number", "currency": "money amount", "percentage": "percentage", "date": "date",
    "datetime": "date and time", "boolean": "yes/no flag", "categorical": "category", "text": "free text",
    "identifier": "identifier (ID/code)", "empty": "empty column",
}
ROLE_TEXT = {
    "measure": "can be summed/averaged in KPIs and charts", "dimension": "used to group and filter", "time": "used for trends over time",
    "identifier": "identifies individual records (counted, not summed)", "attribute": "descriptive detail", "ignore": "not used in analysis",
}


def deterministic_descriptions(schema: dict[str, Any]) -> dict[str, Any]:
    out = []
    for c in schema.get("columns", []):
        st = c.get("stats", {})
        extra = ""
        if c["data_type"] in ("categorical", "boolean") and st.get("distinct"):
            tops = ", ".join(t["value"] for t in st.get("top_values", [])[:3])
            extra = f" {st['distinct']} distinct values (e.g. {tops})."
        elif c["data_type"] in ("date", "datetime") and st.get("min"):
            extra = f" From {st['min'][:10]} to {st['max'][:10]}."
        elif c["role"] == "measure" and st.get("min") is not None:
            extra = f" Range {st['min']:,} to {st['max']:,}."
        out.append({"name": c["name"], "label": c.get("label") or c["name"],
                    "description": f"{TYPE_TEXT.get(c['data_type'], c['data_type']).capitalize()} — {ROLE_TEXT.get(c['role'], '')}.{extra}".strip(),
                    "confidence": c.get("confidence")})
    dom = schema.get("domain", {}).get("guess", "general").replace("_", " ")
    return {"columns": out, "dataset_description": f"{schema.get('row_count', 0):,} rows × {schema.get('column_count', 0)} columns; looks like {dom} data.",
            "generated_by": "deterministic"}


class SchemaInterpreter:
    def __init__(self, provider: AIProvider):
        self.provider = provider

    def describe(self, schema: dict[str, Any]) -> dict[str, Any]:
        base = deterministic_descriptions(schema)
        if not self.provider.available:
            return base
        names = {c["name"] for c in schema.get("columns", [])}
        lines = []
        for c in schema.get("columns", [])[:100]:
            tops = ", ".join(t["value"] for t in c.get("stats", {}).get("top_values", [])[:4])
            lines.append(f"{c['name']} | {c['data_type']} | {c['role']} | {tops}")
        try:
            system, user, _ = prompt_manager.render("schema", columns="\n".join(lines))
            raw = self.provider.complete_json(system, user, max_tokens=2000)
        except (AIProviderError, ValueError) as e:
            base["ai_error"] = str(e)[:200]
            return base
        by_name = {c["name"]: c for c in base["columns"]}
        for item in (raw.get("columns") or []) if isinstance(raw, dict) else []:
            n = item.get("name")
            if n in names and isinstance(item.get("description"), str):
                by_name[n]["description"] = item["description"][:400]
                if isinstance(item.get("label"), str) and 0 < len(item["label"]) <= 80:
                    by_name[n]["label"] = item["label"]
        if isinstance(raw, dict) and isinstance(raw.get("dataset_description"), str):
            base["dataset_description"] = raw["dataset_description"][:500]
        base["generated_by"] = "ai"
        return base
