"""InsightEngine: deterministic facts → (optional) LLM narrative → grounding validation."""
from __future__ import annotations

import logging
from typing import Any

from pydantic import BaseModel, Field, ValidationError

from misgenius.ai.facts import build_fact_sheet, suggestions
from misgenius.ai.prompts import prompt_manager
from misgenius.ai.providers import AIProvider, AIProviderError
from misgenius.ai.validation import check_grounded
from misgenius.analytics.query import DataSource, Filter

log = logging.getLogger("misgenius.ai.insights")

SECTIONS = ["executive_summary", "key_trends", "anomalies", "top_contributors", "bottom_contributors", "period_changes",
            "possible_explanations", "data_quality", "observations"]


class _Item(BaseModel):
    text: str = Field(min_length=3, max_length=600)
    fact_ids: list[str] = Field(default_factory=list)


class _Q(BaseModel):
    text: str = Field(min_length=3, max_length=300)


class _AIInsights(BaseModel):
    executive_summary: list[_Item] = Field(default_factory=list)
    key_trends: list[_Item] = Field(default_factory=list)
    anomalies: list[_Item] = Field(default_factory=list)
    top_contributors: list[_Item] = Field(default_factory=list)
    bottom_contributors: list[_Item] = Field(default_factory=list)
    period_changes: list[_Item] = Field(default_factory=list)
    possible_explanations: list[_Item] = Field(default_factory=list)
    actions: list[_Item] = Field(default_factory=list)
    questions: list[_Q] = Field(default_factory=list)


def _item(f: dict[str, Any], lang: str) -> dict[str, Any]:
    return {"text": f["text"].get(lang) or f["text"]["en"], "fact_ids": [f["id"]], "evidence": f["evidence"], "kind": f["kind"],
            "source": "computed"}


def deterministic_insights(sheet: dict[str, Any], sugg: dict[str, Any], lang: str) -> dict[str, Any]:
    facts = sheet["facts"]
    out: dict[str, Any] = {s: [] for s in SECTIONS}
    for f in sorted(facts, key=lambda x: -x["importance"]):
        sec = f["section"] if f["section"] in out else "observations"
        if sec == "executive_summary" and f["kind"] in ("total", "overview", "status_share"):
            out[sec].append(_item(f, lang))
        elif sec != "executive_summary":
            out[sec].append(_item(f, lang))
    # executive summary = the most important facts overall
    ranked = [f for f in sorted(facts, key=lambda x: -x["importance"]) if f["kind"] not in ("relationship", "overview")]
    headline = [_item(f, lang) for f in ranked[:5]]
    out["executive_summary"] = headline or out["executive_summary"]
    # explanations: connect a period change with the biggest mover (both are computed facts)
    pc = next((f for f in facts if f["kind"] == "period_change"), None)
    mv = next((f for f in facts if f["kind"] == "mover" and f["data"].get("delta", 0) * (pc["data"].get("change_pct", 0) if pc else 0) > 0), None)
    if pc and mv:
        d = mv["data"]
        en = (f"The change in {pc['data']['measure']} in {pc['data']['current_period']} appears to be driven largely by "
              f"{d['dimension']} '{d['value']}', which moved the most in the same direction.")
        hi = (f"{pc['data']['current_period']} में {pc['data']['measure']} में बदलाव मुख्य रूप से {d['dimension']} '{d['value']}' के कारण प्रतीत होता है, "
              f"जिसमें उसी दिशा में सबसे अधिक बदलाव हुआ।")
        out["possible_explanations"].append({"text": hi if lang == "hi" else en, "fact_ids": [pc["id"], mv["id"]], "source": "computed",
                                             "evidence": {"calculation": "Links the period change with the largest group-level change"}})
    out["questions"] = [{"text": q.get(lang) or q["en"], "fact_ids": q.get("fact_ids", [])} for q in sugg["questions"]]
    out["actions"] = [{"text": a.get(lang) or a["en"], "fact_ids": a.get("fact_ids", []), "source": "computed"} for a in sugg["actions"]]
    return out


class InsightEngine:
    def __init__(self, provider: AIProvider):
        self.provider = provider

    def generate(self, ds: DataSource, *, filters: list[Filter] | None = None, quality: dict[str, Any] | None = None,
                 language: str = "en", existing_kpis: list[str] | None = None) -> dict[str, Any]:
        lang = "hi" if language == "hi" else "en"
        sheet = build_fact_sheet(ds, filters=filters, quality=quality)
        sugg = suggestions(ds, sheet["facts"], existing_kpis)
        result = deterministic_insights(sheet, sugg, lang)
        meta: dict[str, Any] = {"generated_by": "deterministic", "provider": None, "language": lang, "grounding": None,
                                "fact_count": len(sheet["facts"]), "context": sheet["context"]}
        if self.provider.available and sheet["facts"] and sheet["context"].get("rows"):
            try:
                ai = self._ai(sheet, lang)
                if ai is not None:
                    result, grounding = ai
                    meta.update({"generated_by": "ai", "provider": self.provider.label, "grounding": grounding})
            except (AIProviderError, ValidationError, ValueError, KeyError, TypeError) as e:
                log.warning("AI insights failed, using deterministic fallback: %s", e)
                meta["ai_error"] = str(e)[:300]
        result["suggested_kpis"] = sugg["suggested_kpis"]
        result["suggested_charts"] = sugg["suggested_charts"]
        result["facts"] = sheet["facts"]
        result["meta"] = meta
        return result

    def _ai(self, sheet: dict[str, Any], lang: str) -> tuple[dict[str, Any], dict[str, Any]] | None:
        facts = sheet["facts"]
        by_id = {f["id"]: f for f in facts}
        compact = [{"id": f["id"], "kind": f["kind"], "text": f["text"][lang], "numbers": f["numbers"][:6],
                    "importance": f["importance"]} for f in facts]
        system, user, version = prompt_manager.render("insights", language=lang, context=sheet["context"], facts=compact)
        raw = self.provider.complete_json(system, user, max_tokens=3000)
        parsed = _AIInsights.model_validate(raw)
        checked = rejected = 0
        rejected_items: list[dict[str, Any]] = []
        out: dict[str, Any] = {s: [] for s in SECTIONS}
        for sec in ("executive_summary", "key_trends", "anomalies", "top_contributors", "bottom_contributors",
                    "period_changes", "possible_explanations", "actions"):
            for it in getattr(parsed, sec):
                checked += 1
                ids = [i for i in it.fact_ids if i in by_id]
                cited = [by_id[i] for i in ids]
                ok, bad = check_grounded(it.text, cited if cited else [])
                if not ids or not ok:
                    rejected += 1
                    rejected_items.append({"section": sec, "text": it.text, "unsupported_numbers": bad, "reason": "no valid fact_ids" if not ids else "numbers not in cited facts"})
                    continue
                entry = {"text": it.text, "fact_ids": ids, "evidence": cited[0]["evidence"] if len(cited) == 1 else {"facts": ids}, "source": "ai"}
                out.setdefault(sec, []).append(entry)
        out["questions"] = [{"text": q.text, "fact_ids": []} for q in parsed.questions[:6]]
        grounding = {"checked": checked, "rejected": rejected, "rejected_items": rejected_items[:10], "prompt_version": version}
        if checked == 0 or not out["executive_summary"] or rejected > checked * 0.5:
            log.warning("AI insights rejected by grounding check (%s/%s)", rejected, checked)
            return None
        # sections the AI left empty keep the computed facts so nothing is lost
        det = deterministic_insights(sheet, {"questions": [], "actions": []}, lang)
        for sec in SECTIONS:
            if not out.get(sec):
                out[sec] = det.get(sec, [])
        return out, grounding
