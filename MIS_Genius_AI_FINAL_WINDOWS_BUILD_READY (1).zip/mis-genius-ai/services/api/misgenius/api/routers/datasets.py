"""Uploads, files/sheets, datasets, versions, schema, explorer, cleaning, exports, connectors."""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile
from fastapi.responses import Response
from sqlalchemy import func, select

from misgenius.api.http_utils import disposition
from misgenius.api.deps import Ctx, require
from misgenius.api.schemas import (
    CleaningIn,
    ColumnOverrideIn,
    ConnectorImportIn,
    ConnectorTestIn,
    CreateFromSheetsIn,
    DatasetUpdateIn,
    DistinctIn,
    ExportIn,
    JoinIn,
    RowsQueryIn,
    dataset_out,
    job_out,
    version_out,
)
from misgenius.billing.plans import check_file_size, check_limit
from misgenius.config import get_settings
from misgenius.db.models import Dashboard, Dataset, DatasetVersion, FileObject, Job, Sheet, utcnow
from misgenius.export.exporters import csv_bytes, excel_bytes
from misgenius.jobs.runner import enqueue
from misgenius.schema.profiler import DATA_TYPES
from misgenius.services import datasets as dsvc
from misgenius.services.audit import audit, record_usage

router = APIRouter(tags=["datasets"])


def get_dataset(ctx: Ctx, dataset_id: str, allow_deleted: bool = False) -> Dataset:
    ds = ctx.db.get(Dataset, dataset_id)
    if ds is None or ds.org_id != ctx.org_id or (ds.deleted_at is not None and not allow_deleted):
        raise HTTPException(404, "Dataset not found")
    return ds


def get_version(ctx: Ctx, ds: Dataset, version_id: str | None = None) -> DatasetVersion:
    if version_id:
        v = ctx.db.get(DatasetVersion, version_id)
        if v is None or v.dataset_id != ds.id:
            raise HTTPException(404, "Version not found")
        return v
    return dsvc.current_version(ctx.db, ds)


def source_for(ctx: Ctx, dataset_id: str, version_id: str | None = None):
    ds = get_dataset(ctx, dataset_id)
    v = get_version(ctx, ds, version_id)
    return ds, v, dsvc.data_source(v)


async def _read_upload(file: UploadFile, limit_bytes: int) -> bytes:
    chunks = []
    total = 0
    while True:
        chunk = await file.read(1024 * 1024)
        if not chunk:
            break
        total += len(chunk)
        if total > limit_bytes:
            raise HTTPException(413, f"File is larger than the {limit_bytes // (1024 * 1024)} MB limit")
        chunks.append(chunk)
    return b"".join(chunks)


# --------------------------------------------------------------------------- uploads / files
@router.post("/uploads")
async def upload(file: UploadFile = File(...), auto_create: bool = Form(True), dataset_id: str | None = Form(None),
                 workspace_id: str | None = Form(None), name: str | None = Form(None), ctx: Ctx = Depends(require("data.write"))) -> dict:
    s = get_settings()
    data = await _read_upload(file, s.MAX_UPLOAD_MB * 1024 * 1024)
    check_file_size(ctx.org, len(data))
    if not dataset_id:
        check_limit(ctx.db, ctx.org, "datasets")
    else:
        get_dataset(ctx, dataset_id)
    f = dsvc.store_upload(ctx.db, ctx.org, ctx.user_id, file.filename or "upload.csv", data)
    record_usage(ctx.db, ctx.org_id, "uploads")
    audit(ctx.db, "file.upload", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="file", entity_id=f.id,
          details={"name": f.original_name, "size": f.size_bytes, "format": f.file_format}, ip=ctx.ip)
    ctx.db.commit()
    job = enqueue(ctx.db, "ingest_file", {"file_id": f.id, "auto_create": auto_create, "dataset_id": dataset_id, "workspace_id": workspace_id,
                                          "name": name}, org_id=ctx.org_id, user_id=ctx.user_id)
    return {"file_id": f.id, "job": job_out(job)}


@router.get("/files")
def list_files(ctx: Ctx = Depends(require("read")), limit: int = Query(50, le=200)) -> list[dict]:
    rows = ctx.db.scalars(select(FileObject).where(FileObject.org_id == ctx.org_id).order_by(FileObject.created_at.desc()).limit(limit)).all()
    return [{"id": f.id, "name": f.original_name, "format": f.file_format, "size": f.size_bytes, "status": f.status, "error": f.error,
             "created_at": f.created_at.isoformat(), "tables": len(f.sheets)} for f in rows]


@router.get("/files/{file_id}")
def get_file(file_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    f = ctx.db.get(FileObject, file_id)
    if f is None or f.org_id != ctx.org_id:
        raise HTTPException(404, "File not found")
    from misgenius.services.job_handlers import _sheet_info

    return {"id": f.id, "name": f.original_name, "format": f.file_format, "size": f.size_bytes, "status": f.status, "error": f.error,
            "workbook": f.workbook, "sheets": _sheet_info(f.sheets)}


@router.get("/files/{file_id}/download")
def download_original(file_id: str, ctx: Ctx = Depends(require("export"))) -> Response:
    from misgenius.storage.base import get_storage

    f = ctx.db.get(FileObject, file_id)
    if f is None or f.org_id != ctx.org_id:
        raise HTTPException(404, "File not found")
    audit(ctx.db, "file.download", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="file", entity_id=f.id, commit=True)
    return Response(get_storage().get_bytes(f.storage_key), media_type="application/octet-stream",
                    headers={"Content-Disposition": disposition(f"{f.original_name}")})


@router.post("/sheets/compare")
def compare_sheets(body: dict, ctx: Ctx = Depends(require("read"))) -> dict:
    ids = body.get("sheet_ids") or []
    if not isinstance(ids, list) or len(ids) < 2:
        raise HTTPException(400, "Select at least two sheets to compare")
    return dsvc.compare_sheets(ctx.db, ctx.org_id, [str(i) for i in ids[:10]])


@router.get("/sheets/{sheet_id}/preview")
def sheet_preview(sheet_id: str, ctx: Ctx = Depends(require("read")), limit: int = Query(50, le=500)) -> dict:
    sh = ctx.db.get(Sheet, sheet_id)
    if sh is None or sh.org_id != ctx.org_id:
        raise HTTPException(404, "Sheet not found")
    raw = dsvc.read_parquet(sh.raw_key).head(limit)
    return {"id": sh.id, "label": sh.label, "columns": list(raw.columns), "rows": raw.astype(object).where(raw.notna(), None).values.tolist(),
            "total_rows": sh.row_count, "header_row": sh.header_row, "notes": sh.message}


@router.post("/datasets/from-sheets")
def create_from_sheets(body: CreateFromSheetsIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    for sid in body.sheet_ids:
        sh = ctx.db.get(Sheet, sid)
        if sh is None or sh.org_id != ctx.org_id:
            raise HTTPException(404, "Sheet not found")
    if body.dataset_id:
        get_dataset(ctx, body.dataset_id)
    else:
        check_limit(ctx.db, ctx.org, "datasets", 1 if body.combine else len(body.sheet_ids))
    job = enqueue(ctx.db, "create_dataset", body.model_dump(), org_id=ctx.org_id, user_id=ctx.user_id)
    return {"job": job_out(job)}


@router.get("/jobs/{job_id}")
def get_job(job_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    j = ctx.db.get(Job, job_id)
    if j is None or j.org_id != ctx.org_id:
        raise HTTPException(404, "Job not found")
    return job_out(j)


# --------------------------------------------------------------------------- datasets
@router.get("/datasets")
def list_datasets(ctx: Ctx = Depends(require("read")), workspace_id: str | None = None, include_deleted: bool = False) -> list[dict]:
    q = select(Dataset).where(Dataset.org_id == ctx.org_id)
    if not include_deleted:
        q = q.where(Dataset.deleted_at.is_(None))
    else:
        q = q.where(Dataset.deleted_at.is_not(None))
    if workspace_id:
        q = q.where(Dataset.workspace_id == workspace_id)
    rows = ctx.db.scalars(q.order_by(Dataset.updated_at.desc())).all()
    vids = [d.current_version_id for d in rows if d.current_version_id]
    versions = {v.id: v for v in ctx.db.scalars(select(DatasetVersion).where(DatasetVersion.id.in_(vids)))} if vids else {}
    dash_counts = dict(ctx.db.execute(select(Dashboard.dataset_id, func.count()).where(Dashboard.org_id == ctx.org_id).group_by(Dashboard.dataset_id)).all())
    return [{**dataset_out(d, versions.get(d.current_version_id)), "dashboards": dash_counts.get(d.id, 0)} for d in rows]


@router.get("/datasets/{dataset_id}")
def dataset_detail(dataset_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    ds = get_dataset(ctx, dataset_id, allow_deleted=True)
    v = dsvc.current_version(ctx.db, ds) if ds.current_version_id else None
    dashes = ctx.db.scalars(select(Dashboard).where(Dashboard.dataset_id == ds.id).order_by(Dashboard.created_at)).all()
    out = dataset_out(ds, v)
    out["dashboards"] = [{"id": d.id, "name": d.name, "auto_generated": d.auto_generated} for d in dashes]
    if v:
        out["schema"] = v.schema_json
        out["quality"] = v.quality
        out["version"] = version_out(v)
    return out


@router.patch("/datasets/{dataset_id}")
def update_dataset(dataset_id: str, body: DatasetUpdateIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    data = body.model_dump(exclude_unset=True)
    for k, v in data.items():
        setattr(ds, k, v)
    audit(ctx.db, "dataset.update", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id, details={"fields": list(data)})
    ctx.db.commit()
    return dataset_out(ds)


@router.delete("/datasets/{dataset_id}")
def delete_dataset(dataset_id: str, purge: bool = False, ctx: Ctx = Depends(require("data.delete"))) -> dict:
    ds = get_dataset(ctx, dataset_id, allow_deleted=True)
    if purge:
        if ds.deleted_at is None:
            raise HTTPException(400, "Move the dataset to trash first, then delete it permanently.")
        audit(ctx.db, "dataset.purge", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id, details={"name": ds.name}, ip=ctx.ip)
        dsvc.purge_dataset(ctx.db, ds)
    else:
        ds.deleted_at = utcnow()
        audit(ctx.db, "dataset.delete", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id, details={"name": ds.name}, ip=ctx.ip)
    ctx.db.commit()
    return {"ok": True, "purged": purge}


@router.post("/datasets/{dataset_id}/restore")
def restore_dataset(dataset_id: str, ctx: Ctx = Depends(require("data.delete"))) -> dict:
    ds = get_dataset(ctx, dataset_id, allow_deleted=True)
    ds.deleted_at = None
    audit(ctx.db, "dataset.restore", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id)
    ctx.db.commit()
    return dataset_out(ds)


@router.post("/datasets/demo")
def create_demo(which: str = Query("sales", pattern="^(sales|attendance)$"), ctx: Ctx = Depends(require("data.write"))) -> dict:
    res = dsvc.create_demo_dataset(ctx.db, ctx.org_id, ctx.user_id, which)
    audit(ctx.db, "dataset.demo", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=res["dataset_id"], commit=True)
    return res


# --------------------------------------------------------------------------- versions
@router.get("/datasets/{dataset_id}/versions")
def list_versions(dataset_id: str, ctx: Ctx = Depends(require("read"))) -> list[dict]:
    ds = get_dataset(ctx, dataset_id)
    return [{**version_out(v), "current": v.id == ds.current_version_id} for v in reversed(ds.versions)]


@router.post("/datasets/{dataset_id}/versions/{version_id}/activate")
def activate_version(dataset_id: str, version_id: str, ctx: Ctx = Depends(require("data.write"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    v = get_version(ctx, ds, version_id)
    ds.current_version_id = v.id
    audit(ctx.db, "dataset.activate_version", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id,
          details={"version": v.version_number})
    ctx.db.commit()
    return {"ok": True, "current_version_id": v.id}


@router.get("/datasets/{dataset_id}/versions/compare")
def compare_versions(dataset_id: str, a: str, b: str, ctx: Ctx = Depends(require("read"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    return dsvc.compare_versions(get_version(ctx, ds, a), get_version(ctx, ds, b))


@router.post("/datasets/{dataset_id}/versions/upload")
async def upload_new_version(dataset_id: str, file: UploadFile = File(...), ctx: Ctx = Depends(require("data.write"))) -> dict:
    get_dataset(ctx, dataset_id)
    return await upload(file=file, auto_create=True, dataset_id=dataset_id, workspace_id=None, name=None, ctx=ctx)


# --------------------------------------------------------------------------- schema
@router.get("/datasets/{dataset_id}/schema")
def get_schema(dataset_id: str, version_id: str | None = None, ctx: Ctx = Depends(require("read"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    v = get_version(ctx, ds, version_id)
    return {"version_id": v.id, "schema": v.schema_json, "overrides": v.overrides, "data_types": DATA_TYPES}


@router.patch("/datasets/{dataset_id}/columns/{column}")
def override_column(dataset_id: str, column: str, body: ColumnOverrideIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    v = dsvc.current_version(ctx.db, ds)
    if column not in {c["name"] for c in (v.schema_json or {}).get("columns", [])}:
        raise HTTPException(404, "Column not found")
    if body.data_type and body.data_type not in DATA_TYPES:
        raise HTTPException(400, f"data_type must be one of {', '.join(DATA_TYPES)}")
    ov = {k: dict(val) for k, val in (v.overrides or {}).items()}
    if body.reset:
        ov.pop(column, None)
    else:
        entry = ov.setdefault(column, {})
        for k, val in body.model_dump(exclude_unset=True, exclude={"reset"}).items():
            if val is None:
                entry.pop(k, None)
            else:
                entry[k] = val
        if not entry:
            ov.pop(column, None)
    dsvc.reprofile_version(ctx.db, v, ov)
    audit(ctx.db, "dataset.schema_override", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id,
          details={"column": column, "override": ov.get(column)})
    ctx.db.commit()
    col = next(c for c in v.schema_json["columns"] if c["name"] == column)
    return {"column": col, "quality": v.quality.get("summary")}


@router.get("/datasets/{dataset_id}/quality")
def get_quality(dataset_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    _, v, _ = source_for(ctx, dataset_id)
    return v.quality


@router.post("/datasets/{dataset_id}/describe-schema")
def describe_schema(dataset_id: str, ctx: Ctx = Depends(require("ai.use"))) -> dict:
    from misgenius.api.routers.ai import ai_service_for

    _, v, _ = source_for(ctx, dataset_id)
    svc = ai_service_for(ctx)
    res = svc.schema.describe(v.schema_json)
    if res.get("generated_by") == "ai":
        record_usage(ctx.db, ctx.org_id, "ai_requests")
        ctx.db.commit()
    return res


# --------------------------------------------------------------------------- explorer
@router.post("/datasets/{dataset_id}/rows")
def rows(dataset_id: str, body: RowsQueryIn, version_id: str | None = None, ctx: Ctx = Depends(require("read"))) -> dict:
    _, _, src = source_for(ctx, dataset_id, version_id)
    return src.rows(columns=body.columns, filters=body.filters, search=body.search, sort=body.sort, limit=body.limit, offset=body.offset,
                    duplicates_only=body.duplicates_only, nulls_in=body.nulls_in)


@router.post("/datasets/{dataset_id}/distinct")
def distinct(dataset_id: str, body: DistinctIn, ctx: Ctx = Depends(require("read"))) -> dict:
    _, _, src = source_for(ctx, dataset_id)
    return src.distinct_values(body.column, filters=body.filters, search=body.search, limit=body.limit)


@router.post("/datasets/{dataset_id}/export")
def export_data(dataset_id: str, body: ExportIn, ctx: Ctx = Depends(require("export"))) -> Response:
    ds, v, src = source_for(ctx, dataset_id)
    filters = body.filters if body.scope == "filtered" else []
    search = body.search if body.scope == "filtered" else None
    df = src.export_frame(columns=body.columns, filters=filters, search=search, sort=body.sort)
    stamp = datetime.now().strftime("%Y%m%d-%H%M")
    base = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in ds.name)[:60].strip() or "data"
    record_usage(ctx.db, ctx.org_id, "exports")
    audit(ctx.db, "export.data", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id,
          details={"format": body.format, "rows": len(df), "scope": body.scope, "filters": len(filters)}, ip=ctx.ip, commit=True)
    if body.format == "csv":
        return Response(csv_bytes(df), media_type="text/csv; charset=utf-8", headers={"Content-Disposition": disposition(f"{base}-{stamp}.csv")})
    from misgenius.ai.nlq import _pretty_filters

    about = {"Dataset": ds.name, "Version": v.version_number, "Rows exported": f"{len(df):,}", "Scope": body.scope,
             "Filters": _pretty_filters(filters) or "None", "Search": search or "—", "Exported at": datetime.now().isoformat(timespec="seconds"),
             "Generated by": "MIS Genius AI"}
    if ds.is_demo:
        about["Note"] = "DEMO DATA — synthetic records, not real business data."
    return Response(excel_bytes(df, schema=v.schema_json, about=about), headers={"Content-Disposition": disposition(f"{base}-{stamp}.xlsx")},
                    media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet")


# --------------------------------------------------------------------------- cleaning / combine / join
@router.post("/datasets/{dataset_id}/clean/preview")
def clean_preview(dataset_id: str, body: CleaningIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    return dsvc.clean_dataset(ctx.db, ds, body.steps, ctx.user_id, preview=True)


@router.post("/datasets/{dataset_id}/clean")
def clean_apply(dataset_id: str, body: CleaningIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    dsvc.apply_transforms(dsvc.raw_to_object(dsvc.read_parquet(dsvc.current_version(ctx.db, ds).raw_key)).head(50), body.steps)  # validate early
    job = enqueue(ctx.db, "clean_dataset", {"dataset_id": ds.id, "steps": body.steps}, org_id=ctx.org_id, user_id=ctx.user_id)
    return {"job": job_out(job)}


@router.post("/datasets/join")
def join(body: JoinIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    check_limit(ctx.db, ctx.org, "datasets")
    res = dsvc.join_datasets(ctx.db, org_id=ctx.org_id, user_id=ctx.user_id, **body.model_dump())
    audit(ctx.db, "dataset.join", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=res["dataset_id"], commit=True)
    return res


# --------------------------------------------------------------------------- connectors
@router.get("/connectors")
def list_connectors(ctx: Ctx = Depends(require("read"))) -> dict:
    from misgenius.connectors.base import PLANNED_CONNECTORS, REGISTRY

    return {"available": [{"type": "file", "label": "Excel / CSV / JSON upload", "admin_only": False}] + [c.describe() for c in REGISTRY.values()],
            "planned": PLANNED_CONNECTORS}


def _check_connector_role(ctx: Ctx, kind: str) -> None:
    from misgenius.auth.permissions import has_permission
    from misgenius.connectors.base import get_connector

    c = get_connector(kind)
    if c.admin_only and not has_permission(ctx.role, "connector.manage"):
        raise HTTPException(403, "Only admins can use this connector")


@router.post("/connectors/test")
def test_connector(body: ConnectorTestIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    from misgenius.connectors.base import get_connector

    _check_connector_role(ctx, body.type)
    return get_connector(body.type).test(body.config)


@router.post("/datasets/from-connector")
def from_connector(body: ConnectorImportIn, ctx: Ctx = Depends(require("data.write"))) -> dict:
    import json

    from misgenius.auth.security import encrypt_secret

    _check_connector_role(ctx, body.type)
    check_limit(ctx.db, ctx.org, "datasets")
    payload = body.model_dump()
    payload["config"] = {"_encrypted": encrypt_secret(json.dumps(body.config))}  # job rows never hold plain credentials
    job = enqueue(ctx.db, "connector_import", payload, org_id=ctx.org_id, user_id=ctx.user_id)
    return {"job": job_out(job)}


@router.post("/datasets/{dataset_id}/refresh")
def refresh(dataset_id: str, ctx: Ctx = Depends(require("data.write"))) -> dict:
    ds = get_dataset(ctx, dataset_id)
    if ds.source_type not in ("http", "google_sheets", "sql"):
        raise HTTPException(400, "Only connector-based datasets can be refreshed. Upload a new file to create a new version.")
    job = enqueue(ctx.db, "refresh_dataset", {"dataset_id": ds.id}, org_id=ctx.org_id, user_id=ctx.user_id)
    return {"job": job_out(job)}
