"""AI endpoints: insights, natural-language questions, AI provider settings."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy import select

from misgenius.ai.providers import AIConfig, AIProviderError, make_provider
from misgenius.ai.service import AIService, resolve_config
from misgenius.api.deps import Ctx, require
from misgenius.api.routers.datasets import get_dataset, source_for
from misgenius.api.schemas import AISettingsIn, AskIn, InsightsIn, iso
from misgenius.auth.security import decrypt_secret, encrypt_secret
from misgenius.billing.plans import LimitExceeded, check_limit
from misgenius.config import get_settings
from misgenius.dashboard.generator import generate_dashboard
from misgenius.db.models import AIInsight, AISetting
from misgenius.services import datasets as dsvc
from misgenius.services.audit import audit, record_usage
from misgenius.services.dashboards import create_dashboard_from_spec

router = APIRouter(tags=["ai"])


def org_ai_setting(ctx: Ctx) -> AISetting | None:
    return ctx.db.scalars(select(AISetting).where(AISetting.org_id == ctx.org_id)).first()


def ai_service_for(ctx: Ctx) -> AIService:
    cfg = resolve_config(get_settings(), org_ai_setting(ctx), decrypt_secret)
    svc = AIService.from_config(cfg)
    if svc.provider.available:
        try:
            check_limit(ctx.db, ctx.org, "ai_requests_month")
        except LimitExceeded:
            return AIService.from_config(AIConfig(provider="none"))  # quota reached: deterministic analytics keep working
    return svc


@router.get("/ai/status")
def ai_status(ctx: Ctx = Depends(require("read"))) -> dict:
    return ai_service_for(ctx).status


@router.post("/datasets/{dataset_id}/insights")
def insights(dataset_id: str, body: InsightsIn, ctx: Ctx = Depends(require("ai.use"))) -> dict:
    ds, v, src = source_for(ctx, dataset_id)
    svc = ai_service_for(ctx)
    res = svc.insights.generate(src, filters=body.filters, quality=v.quality, language=body.language)
    res["meta"]["dataset"] = {"id": ds.id, "name": ds.name, "is_demo": ds.is_demo, "version": v.version_number}
    if res["meta"]["generated_by"] == "ai":
        record_usage(ctx.db, ctx.org_id, "ai_requests")
    row = AIInsight(org_id=ctx.org_id, dataset_id=ds.id, version_id=v.id, kind="insights", provider=res["meta"].get("provider") or "deterministic",
                    content={k: res[k] for k in res if k != "facts"} | {"fact_count": len(res["facts"])}, created_by=ctx.user_id)
    ctx.db.add(row)
    audit(ctx.db, "ai.insights", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id,
          details={"generated_by": res["meta"]["generated_by"], "language": body.language, "filters": len(body.filters)})
    ctx.db.commit()
    res["id"] = row.id
    return res


@router.post("/datasets/{dataset_id}/ask")
def ask(dataset_id: str, body: AskIn, ctx: Ctx = Depends(require("ai.use"))) -> dict:
    ds, v, src = source_for(ctx, dataset_id)
    svc = ai_service_for(ctx)
    res = svc.nlq.ask(src, body.question, filters=body.filters, quality=v.quality, language=None if body.language == "auto" else body.language)
    if res.get("create_dashboard"):
        from misgenius.auth.permissions import has_permission

        if has_permission(ctx.role, "dashboard.write"):
            spec = generate_dashboard(v.schema_json, ds.name)
            d = create_dashboard_from_spec(ctx.db, org_id=ctx.org_id, dataset_id=ds.id, spec=spec, user_id=ctx.user_id, auto_generated=True)
            res["dashboard_id"] = d.id
        else:
            res["answer"] = "Your role cannot create dashboards. Ask an analyst or admin."
    if svc.provider.available:
        record_usage(ctx.db, ctx.org_id, "ai_requests")
    ctx.db.add(AIInsight(org_id=ctx.org_id, dataset_id=ds.id, version_id=v.id, kind="question", provider=svc.provider.label,
                         question=body.question, content={"answer": res.get("answer"), "intent": res.get("intent"), "plan": res.get("plan"),
                                                          "answer_source": res.get("answer_source")}, created_by=ctx.user_id))
    audit(ctx.db, "ai.ask", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dataset", entity_id=ds.id,
          details={"intent": res.get("intent"), "plan_source": (res.get("plan") or {}).get("source")})
    ctx.db.commit()
    return res


@router.get("/datasets/{dataset_id}/questions")
def question_history(dataset_id: str, ctx: Ctx = Depends(require("read"))) -> list[dict]:
    ds = get_dataset(ctx, dataset_id)
    rows = ctx.db.scalars(select(AIInsight).where(AIInsight.dataset_id == ds.id, AIInsight.kind == "question", AIInsight.created_by == ctx.user_id)
                          .order_by(AIInsight.created_at.desc()).limit(30)).all()
    return [{"id": r.id, "question": r.question, "answer": (r.content or {}).get("answer"), "created_at": iso(r.created_at)} for r in rows]


@router.get("/datasets/{dataset_id}/suggestions")
def suggestion_list(dataset_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    from misgenius.ai.facts import suggestions

    _, _, src = source_for(ctx, dataset_id)
    s = suggestions(src, [])
    return {"questions": s["questions"], "suggested_kpis": s["suggested_kpis"], "suggested_charts": s["suggested_charts"]}


# --------------------------------------------------------------------------- settings
def _settings_out(row: AISetting | None) -> dict:
    s = get_settings()
    env = {"provider": s.AI_PROVIDER, "model": s.AI_MODEL, "configured": bool(s.AI_API_KEY) or s.AI_PROVIDER == "openai_compatible"}
    if row is None:
        return {"source": "environment", "provider": s.AI_PROVIDER, "model": s.AI_MODEL, "base_url": s.AI_BASE_URL, "enabled": True,
                "has_api_key": bool(s.AI_API_KEY), "api_key_hint": None, "environment": env}
    return {"source": "organization", "provider": row.provider, "model": row.model, "base_url": row.base_url, "enabled": row.enabled,
            "has_api_key": bool(row.api_key_encrypted), "api_key_hint": f"••••{row.api_key_last4}" if row.api_key_last4 else None,
            "updated_at": iso(row.updated_at), "environment": env}


@router.get("/settings/ai")
def get_ai_settings(ctx: Ctx = Depends(require("settings.manage"))) -> dict:
    return _settings_out(org_ai_setting(ctx))


@router.put("/settings/ai")
def put_ai_settings(body: AISettingsIn, ctx: Ctx = Depends(require("settings.manage"))) -> dict:
    row = org_ai_setting(ctx)
    if row is None:
        row = AISetting(org_id=ctx.org_id)
        ctx.db.add(row)
    row.provider, row.model, row.base_url, row.enabled = body.provider, body.model or None, body.base_url or None, body.enabled
    if body.base_url:
        from misgenius.connectors.base import ConnectorError, _guard_url

        try:
            _guard_url(body.base_url)
        except ConnectorError as e:
            raise HTTPException(400, f"Base URL rejected: {e}") from None
    if body.clear_api_key:
        row.api_key_encrypted, row.api_key_last4 = None, None
    elif body.api_key:
        row.api_key_encrypted = encrypt_secret(body.api_key.strip())
        row.api_key_last4 = body.api_key.strip()[-4:]
    audit(ctx.db, "settings.ai", org_id=ctx.org_id, user_id=ctx.user_id, details={"provider": body.provider, "model": body.model,
                                                                                  "key_changed": bool(body.api_key) or body.clear_api_key})
    ctx.db.commit()
    return _settings_out(row)


@router.post("/settings/ai/test")
def test_ai(ctx: Ctx = Depends(require("settings.manage"))) -> dict:
    cfg = resolve_config(get_settings(), org_ai_setting(ctx), decrypt_secret)
    prov = make_provider(cfg)
    if not prov.available:
        return {"ok": False, "message": "No AI provider is configured. MIS Genius AI works fully with deterministic analytics; add a key to enable AI narratives."}
    try:
        res = prov.test()
        record_usage(ctx.db, ctx.org_id, "ai_requests")
        ctx.db.commit()
        return {**res, "message": "Connected successfully." if res["ok"] else "The provider answered but not as expected."}
    except AIProviderError as e:
        return {"ok": False, "message": str(e)}


__all__ = ["ai_service_for", "dsvc"]
