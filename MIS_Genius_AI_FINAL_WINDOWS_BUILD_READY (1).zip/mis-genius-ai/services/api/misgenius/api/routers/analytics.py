"""Analytics endpoints: structured queries, KPIs, charts, pivots, recommendations."""
from __future__ import annotations

from fastapi import APIRouter, Depends

from misgenius.analytics.charts import build_chart, recommend_charts
from misgenius.analytics.kpi import compute_kpi
from misgenius.analytics.pivot import pivot
from misgenius.api.deps import Ctx, require
from misgenius.api.routers.datasets import source_for
from misgenius.api.schemas import ChartIn, KPIIn, PivotIn, QueryIn, RecommendIn

router = APIRouter(prefix="/datasets/{dataset_id}/analytics", tags=["analytics"])


@router.post("/query")
def query(dataset_id: str, body: QueryIn, ctx: Ctx = Depends(require("read"))) -> dict:
    _, _, src = source_for(ctx, dataset_id)
    return src.aggregate(body)


@router.post("/kpi")
def kpi(dataset_id: str, body: KPIIn, ctx: Ctx = Depends(require("read"))) -> dict:
    _, _, src = source_for(ctx, dataset_id)
    return compute_kpi(src, body.kpi, body.filters)


@router.post("/chart")
def chart(dataset_id: str, body: ChartIn, ctx: Ctx = Depends(require("read"))) -> dict:
    _, _, src = source_for(ctx, dataset_id)
    return build_chart(src, body.chart, body.filters)


@router.post("/pivot")
def pivot_table(dataset_id: str, body: PivotIn, ctx: Ctx = Depends(require("read"))) -> dict:
    _, _, src = source_for(ctx, dataset_id)
    return pivot(src, rows=body.rows, column=body.column, values=body.values, filters=body.filters)


@router.post("/recommend")
def recommend(dataset_id: str, body: RecommendIn, ctx: Ctx = Depends(require("read"))) -> list[dict]:
    _, _, src = source_for(ctx, dataset_id)
    return recommend_charts(src, body.dimensions, body.measures)
