"""Executive reports, notifications and KPI alerts."""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, HTTPException, Query
from fastapi.responses import HTMLResponse, Response
from sqlalchemy import func, select, update

from misgenius.ai.reports import generate_report
from misgenius.analytics.charts import ChartSpec, build_chart
from misgenius.analytics.query import DataSource, Dimension, Measure
from misgenius.api.http_utils import disposition
from misgenius.api.deps import Ctx, require
from misgenius.api.routers.ai import ai_service_for
from misgenius.api.routers.datasets import get_dataset, source_for
from misgenius.api.schemas import AlertIn, ReportIn, alert_out, notification_out, report_out
from misgenius.dashboard.generator import default_agg, rank_dimensions, rank_measures
from misgenius.db.models import AlertRule, Dashboard, Notification, Report, utcnow
from misgenius.export.exporters import chart_png, excel_bytes, has_devanagari, report_html, report_pdf
from misgenius.notifications.service import evaluate_alerts
from misgenius.services.audit import audit, record_usage

router = APIRouter(tags=["reports"])


def _report_charts(src: DataSource, filters) -> list[tuple[str, bytes]]:
    out = []
    ms = rank_measures(src.schema)
    ds_ = rank_dimensions(src.schema)
    m = Measure(column=ms[0]["name"], agg=default_agg(ms[0])) if ms else Measure(agg="count_rows")
    title_m = ms[0]["name"] if ms else "Records"
    try:
        if src.schema.get("primary_date_column"):
            ch = build_chart(src, ChartSpec(type="line", dimension=Dimension(column=src.schema["primary_date_column"]), measures=[m]), filters)
            png = chart_png(ch, f"{title_m} over time")
            if png:
                out.append((f"{title_m} over time", png))
        if ds_:
            ch = build_chart(src, ChartSpec(type="bar" if ds_[0]["_distinct"] <= 15 else "hbar", dimension=Dimension(column=ds_[0]["name"]), measures=[m], top_n=10), filters)
            png = chart_png(ch, f"{title_m} by {ds_[0]['name']}")
            if png:
                out.append((f"{title_m} by {ds_[0]['name']}", png))
    except Exception:  # noqa: BLE001 - charts are optional decoration
        pass
    return out


@router.get("/reports")
def list_reports(ctx: Ctx = Depends(require("read")), dataset_id: str | None = None) -> list[dict]:
    q = select(Report).where(Report.org_id == ctx.org_id)
    if dataset_id:
        q = q.where(Report.dataset_id == dataset_id)
    return [report_out(r) for r in ctx.db.scalars(q.order_by(Report.created_at.desc()).limit(200))]


@router.post("/reports")
def create_report(body: ReportIn, ctx: Ctx = Depends(require("report.write"))) -> dict:
    ds, v, src = source_for(ctx, body.dataset_id)
    kpi_specs = None
    if body.dashboard_id:
        d = ctx.db.get(Dashboard, body.dashboard_id)
        if d is None or d.org_id != ctx.org_id:
            raise HTTPException(404, "Dashboard not found")
        kpi_specs = [w.config["kpi"] for w in d.widgets if w.widget_type == "kpi" and not w.hidden and "kpi" in (w.config or {})]
    svc = ai_service_for(ctx)
    title = body.title or (f"{ds.name} – Executive Report" if body.language == "en" else f"{ds.name} – कार्यकारी रिपोर्ट")
    content = generate_report(src, svc.insights, title=title, dataset_name=ds.name, filters=body.filters, quality=v.quality,
                              language=body.language, kpi_specs=kpi_specs, is_demo=ds.is_demo)
    r = Report(org_id=ctx.org_id, dataset_id=ds.id, version_id=v.id, dashboard_id=body.dashboard_id, title=title[:255], language=body.language,
               content=content, filters=[f.model_dump() for f in body.filters], generated_by=content["generated_by"], created_by=ctx.user_id)
    ctx.db.add(r)
    if content["generated_by"] == "ai":
        record_usage(ctx.db, ctx.org_id, "ai_requests")
    audit(ctx.db, "report.create", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="report", entity_id=r.id,
          details={"dataset": ds.id, "language": body.language, "generated_by": content["generated_by"]})
    ctx.db.commit()
    return report_out(r, full=True)


def get_report(ctx: Ctx, report_id: str) -> Report:
    r = ctx.db.get(Report, report_id)
    if r is None or r.org_id != ctx.org_id:
        raise HTTPException(404, "Report not found")
    return r


@router.get("/reports/{report_id}")
def report_detail(report_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    return report_out(get_report(ctx, report_id), full=True)


@router.delete("/reports/{report_id}")
def delete_report(report_id: str, ctx: Ctx = Depends(require("report.write"))) -> dict:
    r = get_report(ctx, report_id)
    audit(ctx.db, "report.delete", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="report", entity_id=r.id)
    ctx.db.delete(r)
    ctx.db.commit()
    return {"ok": True}


@router.get("/reports/{report_id}/download")
def download_report(report_id: str, format: str = Query("pdf", pattern="^(pdf|html|xlsx|json)$"), ctx: Ctx = Depends(require("export"))):
    import json

    import pandas as pd

    r = get_report(ctx, report_id)
    safe = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in r.title)[:60].strip() or "report"
    charts: list[tuple[str, bytes]] = []
    if format in ("pdf", "html") and r.dataset_id:
        try:
            _, _, src = source_for(ctx, r.dataset_id)
            from misgenius.analytics.query import Filter

            charts = _report_charts(src, [Filter(**f) for f in (r.filters or [])])
        except HTTPException:
            charts = []
    audit(ctx.db, "export.report", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="report", entity_id=r.id, details={"format": format}, commit=True)
    if format == "json":
        return Response(json.dumps(r.content, ensure_ascii=False, default=str, indent=1), media_type="application/json",
                        headers={"Content-Disposition": disposition(f"{safe}.json")})
    if format == "html" or (format == "pdf" and (r.language == "hi" or has_devanagari(r.content.get("sections")))):
        # Devanagari needs complex text shaping, which browsers do perfectly: use "Print → Save as PDF".
        html = report_html(r.content, charts)
        if format == "pdf":
            html = html.replace("</body>", "<script>window.onload=function(){setTimeout(function(){window.print()},400)}</script></body>")
        return HTMLResponse(html, headers={"Content-Disposition": disposition(f"{safe}.html", inline=True),
                                           "Content-Security-Policy": "default-src 'none'; img-src data:; style-src 'unsafe-inline'; script-src 'unsafe-inline'"})
    if format == "xlsx":
        rows = []
        for s in r.content.get("sections", []):
            for k in s.get("kpis", []) or []:
                rows.append({"Section": s["heading"], "Item": k["title"], "Value": k["display"], "Change %": k.get("change_pct"), "Period": k.get("period")})
            for it in s.get("items", []) or []:
                rows.append({"Section": s["heading"], "Item": it["text"], "Value": None, "Change %": None, "Period": None})
        df = pd.DataFrame(rows)
        facts = pd.DataFrame([{"Fact": f["id"], "Kind": f["kind"], "Statement": f["text"].get(r.language) or f["text"]["en"],
                               "Calculation": (f.get("evidence") or {}).get("calculation")} for f in r.content.get("facts", [])])
        about = {"Report": r.title, "Generated": r.content.get("generated_at"), "Generated by": r.content.get("generated_by"),
                 "Scope rows": r.content.get("scope", {}).get("rows"), "Note": r.content.get("disclaimer")}
        return Response(excel_bytes(df, about=about, extra_sheets={"Evidence": facts}, sheet_name="Report"),
                        media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                        headers={"Content-Disposition": disposition(f"{safe}.xlsx")})
    pdf = report_pdf(r.content, charts)
    return Response(pdf, media_type="application/pdf", headers={"Content-Disposition": disposition(f"{safe}-{datetime.now():%Y%m%d}.pdf")})


# --------------------------------------------------------------------------- notifications
@router.get("/notifications")
def notifications(ctx: Ctx = Depends(require("read")), unread_only: bool = False) -> dict:
    q = select(Notification).where(Notification.org_id == ctx.org_id, Notification.user_id == ctx.user_id)
    if unread_only:
        q = q.where(Notification.read_at.is_(None))
    rows = ctx.db.scalars(q.order_by(Notification.created_at.desc()).limit(50)).all()
    unread = ctx.db.scalar(select(func.count()).select_from(Notification).where(Notification.org_id == ctx.org_id, Notification.user_id == ctx.user_id,
                                                                                Notification.read_at.is_(None)))
    return {"unread": unread, "items": [notification_out(n) for n in rows]}


@router.post("/notifications/read-all")
def read_all(ctx: Ctx = Depends(require("read"))) -> dict:
    ctx.db.execute(update(Notification).where(Notification.org_id == ctx.org_id, Notification.user_id == ctx.user_id, Notification.read_at.is_(None))
                   .values(read_at=utcnow()))
    ctx.db.commit()
    return {"ok": True}


@router.post("/notifications/{nid}/read")
def read_one(nid: str, ctx: Ctx = Depends(require("read"))) -> dict:
    n = ctx.db.get(Notification, nid)
    if n is None or n.user_id != ctx.user_id:
        raise HTTPException(404, "Notification not found")
    n.read_at = utcnow()
    ctx.db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- alerts
@router.get("/alerts")
def list_alerts(ctx: Ctx = Depends(require("read")), dataset_id: str | None = None) -> list[dict]:
    q = select(AlertRule).where(AlertRule.org_id == ctx.org_id)
    if dataset_id:
        q = q.where(AlertRule.dataset_id == dataset_id)
    return [alert_out(a) for a in ctx.db.scalars(q.order_by(AlertRule.created_at.desc()))]


@router.post("/alerts")
def create_alert(body: AlertIn, ctx: Ctx = Depends(require("alert.write"))) -> dict:
    get_dataset(ctx, body.dataset_id)
    for ch in body.channels:
        if ch not in ("in_app", "email") and not ch.startswith("webhook:https://"):
            raise HTTPException(400, f"Unsupported channel '{ch}'. Use in_app, email or webhook:https://…")
    a = AlertRule(org_id=ctx.org_id, dataset_id=body.dataset_id, name=body.name, kpi=body.kpi.model_dump(exclude_none=True), operator=body.operator,
                  threshold=body.threshold, channels=body.channels, enabled=body.enabled, created_by=ctx.user_id)
    ctx.db.add(a)
    audit(ctx.db, "alert.create", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="alert", entity_id=a.id)
    ctx.db.commit()
    return alert_out(a)


@router.delete("/alerts/{alert_id}")
def delete_alert(alert_id: str, ctx: Ctx = Depends(require("alert.write"))) -> dict:
    a = ctx.db.get(AlertRule, alert_id)
    if a is None or a.org_id != ctx.org_id:
        raise HTTPException(404, "Alert not found")
    ctx.db.delete(a)
    ctx.db.commit()
    return {"ok": True}


@router.post("/alerts/evaluate/{dataset_id}")
def evaluate(dataset_id: str, ctx: Ctx = Depends(require("alert.write"))) -> dict:
    _, _, src = source_for(ctx, dataset_id)
    fired = evaluate_alerts(ctx.db, dataset_id, src)
    ctx.db.commit()
    return {"fired": fired}
