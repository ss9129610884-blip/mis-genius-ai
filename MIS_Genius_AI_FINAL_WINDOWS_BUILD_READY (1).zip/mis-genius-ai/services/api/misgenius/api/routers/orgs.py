"""Organizations, members, workspaces, API keys, audit log, settings."""
from __future__ import annotations

from fastapi import APIRouter, Depends, HTTPException, Query
from sqlalchemy import func, select

from misgenius.api.deps import Ctx, current_user, get_ctx, require
from misgenius.api.routers.auth import create_org
from misgenius.api.schemas import (
    ApiKeyIn,
    MemberIn,
    MemberRoleIn,
    OrgCreateIn,
    OrgUpdateIn,
    WorkspaceIn,
    iso,
    org_out,
    user_out,
    workspace_out,
)
from misgenius.auth.permissions import can_assign, permissions_for
from misgenius.auth.security import hash_password, new_api_key, password_problems
from misgenius.db.models import ApiKey, AuditLog, Membership, User, Workspace, utcnow
from misgenius.db.session import get_db
from misgenius.services.audit import audit

router = APIRouter(tags=["organizations"])

ALLOWED_ORG_SETTINGS = {"currency", "locale", "date_format", "language", "fiscal_year_start_month", "theme", "logo_text"}


@router.get("/orgs")
def my_orgs(user: User = Depends(current_user), db=Depends(get_db)) -> list[dict]:
    from misgenius.db.models import Organization

    mems = db.scalars(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at)).all()
    return [org_out(db.get(Organization, m.org_id), m.role) for m in mems]


@router.post("/orgs")
def create_organization(body: OrgCreateIn, user: User = Depends(current_user), db=Depends(get_db)) -> dict:
    org = create_org(db, body.name.strip(), user)
    audit(db, "org.create", org_id=org.id, user_id=user.id)
    db.commit()
    return org_out(org, "owner")


@router.get("/orgs/current")
def current_org(ctx: Ctx = Depends(get_ctx)) -> dict:
    return {**org_out(ctx.org, ctx.role), "permissions": permissions_for(ctx.role)}


@router.patch("/orgs/current")
def update_org(body: OrgUpdateIn, ctx: Ctx = Depends(require("settings.manage"))) -> dict:
    if body.name:
        ctx.org.name = body.name.strip()
    if body.settings is not None:
        bad = set(body.settings) - ALLOWED_ORG_SETTINGS
        if bad:
            raise HTTPException(400, f"Unknown settings: {', '.join(sorted(bad))}")
        ctx.org.settings = {**(ctx.org.settings or {}), **body.settings}
    audit(ctx.db, "org.update", org_id=ctx.org_id, user_id=ctx.user_id, details={"fields": [k for k, v in body.model_dump().items() if v is not None]})
    ctx.db.commit()
    return org_out(ctx.org, ctx.role)


# --------------------------------------------------------------------------- members
@router.get("/orgs/current/members")
def list_members(ctx: Ctx = Depends(require("read"))) -> list[dict]:
    rows = ctx.db.execute(select(Membership, User).join(User, User.id == Membership.user_id).where(Membership.org_id == ctx.org_id)
                          .order_by(Membership.created_at)).all()
    return [{"membership_id": m.id, "role": m.role, "joined_at": iso(m.created_at), **user_out(u)} for m, u in rows]


@router.post("/orgs/current/members")
def add_member(body: MemberIn, ctx: Ctx = Depends(require("members.manage"))) -> dict:
    if not can_assign(ctx.role, body.role):
        raise HTTPException(403, "You cannot assign this role")
    from misgenius.billing.plans import check_limit

    check_limit(ctx.db, ctx.org, "users")
    user = ctx.db.scalars(select(User).where(User.email == body.email)).first()
    if user is None:
        if not body.password:
            raise HTTPException(400, "This person has no account yet. Set an initial password for them (they can change it after signing in).")
        probs = password_problems(body.password)
        if probs:
            raise HTTPException(400, "Password needs " + ", ".join(probs))
        user = User(email=body.email, password_hash=hash_password(body.password), full_name=body.full_name)
        ctx.db.add(user)
        ctx.db.flush()
    elif ctx.db.scalars(select(Membership).where(Membership.user_id == user.id, Membership.org_id == ctx.org_id)).first():
        raise HTTPException(409, "This person is already a member")
    m = Membership(user_id=user.id, org_id=ctx.org_id, role=body.role)
    ctx.db.add(m)
    audit(ctx.db, "member.add", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="user", entity_id=user.id, details={"role": body.role})
    ctx.db.commit()
    return {"membership_id": m.id, "role": m.role, **user_out(user)}


def _owners(ctx: Ctx) -> int:
    return ctx.db.scalar(select(func.count()).select_from(Membership).where(Membership.org_id == ctx.org_id, Membership.role == "owner")) or 0


@router.patch("/orgs/current/members/{membership_id}")
def change_role(membership_id: str, body: MemberRoleIn, ctx: Ctx = Depends(require("members.manage"))) -> dict:
    m = ctx.db.get(Membership, membership_id)
    if m is None or m.org_id != ctx.org_id:
        raise HTTPException(404, "Member not found")
    if not can_assign(ctx.role, body.role) or (m.role == "owner" and ctx.role != "owner"):
        raise HTTPException(403, "You cannot change this member's role")
    if m.role == "owner" and body.role != "owner" and _owners(ctx) <= 1:
        raise HTTPException(400, "An organization needs at least one owner")
    old = m.role
    m.role = body.role
    audit(ctx.db, "member.role", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="user", entity_id=m.user_id, details={"from": old, "to": body.role})
    ctx.db.commit()
    return {"membership_id": m.id, "role": m.role}


@router.delete("/orgs/current/members/{membership_id}")
def remove_member(membership_id: str, ctx: Ctx = Depends(require("members.manage"))) -> dict:
    m = ctx.db.get(Membership, membership_id)
    if m is None or m.org_id != ctx.org_id:
        raise HTTPException(404, "Member not found")
    if m.role == "owner" and (ctx.role != "owner" or _owners(ctx) <= 1):
        raise HTTPException(400, "The last owner cannot be removed")
    audit(ctx.db, "member.remove", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="user", entity_id=m.user_id)
    ctx.db.delete(m)
    ctx.db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- workspaces
@router.get("/workspaces")
def list_workspaces(ctx: Ctx = Depends(require("read"))) -> list[dict]:
    return [workspace_out(w) for w in ctx.db.scalars(select(Workspace).where(Workspace.org_id == ctx.org_id).order_by(Workspace.created_at))]


@router.post("/workspaces")
def create_workspace(body: WorkspaceIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    w = Workspace(org_id=ctx.org_id, name=body.name.strip(), description=body.description)
    ctx.db.add(w)
    audit(ctx.db, "workspace.create", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="workspace", entity_id=w.id)
    ctx.db.commit()
    return workspace_out(w)


@router.patch("/workspaces/{wid}")
def update_workspace(wid: str, body: WorkspaceIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    w = ctx.db.get(Workspace, wid)
    if w is None or w.org_id != ctx.org_id:
        raise HTTPException(404, "Workspace not found")
    w.name, w.description = body.name.strip(), body.description
    ctx.db.commit()
    return workspace_out(w)


@router.delete("/workspaces/{wid}")
def delete_workspace(wid: str, ctx: Ctx = Depends(require("settings.manage"))) -> dict:
    w = ctx.db.get(Workspace, wid)
    if w is None or w.org_id != ctx.org_id:
        raise HTTPException(404, "Workspace not found")
    ctx.db.delete(w)  # datasets/dashboards keep existing (workspace_id set to NULL)
    audit(ctx.db, "workspace.delete", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="workspace", entity_id=wid)
    ctx.db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- API keys
@router.get("/api-keys")
def list_keys(ctx: Ctx = Depends(require("apikeys.manage"))) -> list[dict]:
    rows = ctx.db.scalars(select(ApiKey).where(ApiKey.org_id == ctx.org_id).order_by(ApiKey.created_at.desc())).all()
    return [{"id": k.id, "name": k.name, "prefix": k.prefix, "role": k.role, "created_at": iso(k.created_at), "last_used_at": iso(k.last_used_at),
             "revoked": k.revoked_at is not None} for k in rows]


@router.post("/api-keys")
def create_key(body: ApiKeyIn, ctx: Ctx = Depends(require("apikeys.manage"))) -> dict:
    if not can_assign(ctx.role, body.role) and body.role != "viewer":
        raise HTTPException(403, "You cannot create a key with this role")
    raw, prefix, digest = new_api_key()
    k = ApiKey(org_id=ctx.org_id, user_id=ctx.user_id, name=body.name, prefix=prefix, key_hash=digest, role=body.role)
    ctx.db.add(k)
    audit(ctx.db, "apikey.create", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="api_key", entity_id=k.id, details={"role": body.role})
    ctx.db.commit()
    return {"id": k.id, "name": k.name, "prefix": prefix, "role": k.role, "key": raw,
            "note": "Copy this key now. It is stored hashed and cannot be shown again."}


@router.delete("/api-keys/{kid}")
def revoke_key(kid: str, ctx: Ctx = Depends(require("apikeys.manage"))) -> dict:
    k = ctx.db.get(ApiKey, kid)
    if k is None or k.org_id != ctx.org_id:
        raise HTTPException(404, "Key not found")
    k.revoked_at = utcnow()
    audit(ctx.db, "apikey.revoke", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="api_key", entity_id=kid)
    ctx.db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- audit
@router.get("/audit")
def audit_logs(ctx: Ctx = Depends(require("audit.read")), limit: int = Query(100, ge=1, le=500), offset: int = Query(0, ge=0),
               action: str | None = None) -> dict:
    q = select(AuditLog).where(AuditLog.org_id == ctx.org_id)
    if action:
        q = q.where(AuditLog.action.like(action.replace("%", "") + "%"))
    total = ctx.db.scalar(select(func.count()).select_from(q.subquery()))
    rows = ctx.db.scalars(q.order_by(AuditLog.created_at.desc()).limit(limit).offset(offset)).all()
    users = {u.id: u.email for u in ctx.db.scalars(select(User).where(User.id.in_({r.user_id for r in rows if r.user_id})))}
    return {"total": total, "items": [{"id": r.id, "action": r.action, "user": users.get(r.user_id), "entity_type": r.entity_type,
                                       "entity_id": r.entity_id, "details": r.details, "ip": r.ip, "created_at": iso(r.created_at)} for r in rows]}
