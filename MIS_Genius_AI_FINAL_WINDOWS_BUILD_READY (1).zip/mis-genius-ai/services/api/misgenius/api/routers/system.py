"""System endpoints: health, global search, billing/usage, backup."""
from __future__ import annotations

from datetime import datetime

from fastapi import APIRouter, Depends, File, HTTPException, Query, Request, UploadFile
from fastapi.responses import Response
from sqlalchemy import select, text

from misgenius.api.http_utils import disposition
from misgenius.api.deps import Ctx, require
from misgenius.api.schemas import CheckoutIn, PlanIn
from misgenius.billing.payments import PaymentError, get_payment_provider
from misgenius.billing.plans import PLANS, usage_summary
from misgenius.config import get_settings
from misgenius.db.models import Organization, Subscription
from misgenius.db.session import SessionLocal
from misgenius.services import backup as bsvc
from misgenius.services.audit import audit
from misgenius.services.search import search as run_search

router = APIRouter(tags=["system"])


@router.get("/health")
def health() -> dict:
    s = get_settings()
    db_ok = True
    try:
        db = SessionLocal()
        db.execute(text("SELECT 1"))
        db.close()
    except Exception:  # noqa: BLE001
        db_ok = False
    storage_ok = True
    try:
        from misgenius.storage.base import get_storage

        get_storage().exists("health-check")
    except Exception:  # noqa: BLE001
        storage_ok = False
    return {"status": "ok" if db_ok and storage_ok else "degraded", "version": s.APP_VERSION, "mode": s.APP_ENV,
            "database": "ok" if db_ok else "error", "database_kind": s.database_url.split(":", 1)[0].split("+")[0],
            "storage": s.STORAGE_PROVIDER if storage_ok else "error", "ai_provider_env": s.AI_PROVIDER, "max_upload_mb": s.MAX_UPLOAD_MB, "time": datetime.utcnow().isoformat() + "Z"}


@router.get("/search")
def search(q: str = Query(..., min_length=1, max_length=100), ctx: Ctx = Depends(require("read"))) -> dict:
    return run_search(ctx.db, ctx.org_id, q)


# --------------------------------------------------------------------------- billing
@router.get("/billing/plans")
def plans() -> list[dict]:
    from dataclasses import asdict

    return [asdict(p) for p in PLANS.values()]


@router.get("/billing/usage")
def usage(ctx: Ctx = Depends(require("read"))) -> dict:
    sub = ctx.db.scalars(select(Subscription).where(Subscription.org_id == ctx.org_id)).first()
    return {**usage_summary(ctx.db, ctx.org), "subscription": {"plan": sub.plan, "status": sub.status, "provider": sub.provider} if sub else None,
            "payment_provider": get_payment_provider().name}


@router.put("/billing/plan")
def set_plan(body: PlanIn, ctx: Ctx = Depends(require("billing.manage"))) -> dict:
    prov = get_payment_provider()
    if prov.name != "manual" and get_settings().is_production:
        raise HTTPException(400, "Plans are changed through checkout when online payments are enabled.")
    ctx.org.plan = body.plan
    sub = ctx.db.scalars(select(Subscription).where(Subscription.org_id == ctx.org_id)).first()
    if sub:
        sub.plan, sub.status = body.plan, "active"
    audit(ctx.db, "billing.plan", org_id=ctx.org_id, user_id=ctx.user_id, details={"plan": body.plan})
    ctx.db.commit()
    return {"plan": body.plan}


@router.post("/billing/checkout")
def checkout(body: CheckoutIn, ctx: Ctx = Depends(require("billing.manage"))) -> dict:
    try:
        return get_payment_provider().create_checkout(org_id=ctx.org_id, plan=body.plan, success_url=body.success_url,
                                                      cancel_url=body.cancel_url, customer_email=ctx.user.email)
    except PaymentError as e:
        raise HTTPException(400, str(e)) from None


@router.post("/billing/webhook")
async def webhook(request: Request) -> dict:
    payload = await request.body()
    try:
        evt = get_payment_provider().parse_webhook(payload, request.headers.get("stripe-signature"))
    except PaymentError as e:
        raise HTTPException(400, str(e)) from None
    if not evt or not evt.get("org_id"):
        return {"received": True}
    db = SessionLocal()
    try:
        org = db.get(Organization, evt["org_id"])
        if org:
            if evt.get("plan") in PLANS:
                org.plan = evt["plan"]
            sub = db.scalars(select(Subscription).where(Subscription.org_id == org.id)).first() or Subscription(org_id=org.id)
            sub.plan, sub.status, sub.provider = org.plan, evt.get("status", "active"), "stripe"
            sub.external_customer_id = evt.get("customer") or sub.external_customer_id
            sub.external_subscription_id = evt.get("subscription") or sub.external_subscription_id
            db.add(sub)
            audit(db, "billing.webhook", org_id=org.id, user_id=None, details={"plan": org.plan, "status": sub.status})
            db.commit()
    finally:
        db.close()
    return {"received": True}


# --------------------------------------------------------------------------- backup
@router.post("/backup/export")
def export_backup(include_data: bool = True, ctx: Ctx = Depends(require("backup.manage"))) -> Response:
    data = bsvc.export_org(ctx.db, ctx.org_id, include_data=include_data)
    audit(ctx.db, "backup.export", org_id=ctx.org_id, user_id=ctx.user_id, details={"include_data": include_data, "bytes": len(data)}, ip=ctx.ip, commit=True)
    return Response(data, media_type="application/zip",
                    headers={"Content-Disposition": disposition(f"mis-genius-backup-{datetime.now():%Y%m%d-%H%M}.zip")})


@router.post("/backup/import")
async def import_backup(file: UploadFile = File(...), ctx: Ctx = Depends(require("backup.manage"))) -> dict:
    limit = get_settings().MAX_UPLOAD_MB * 1024 * 1024 * 4
    data = await file.read(limit + 1)
    if len(data) > limit:
        raise HTTPException(413, "Backup file is too large for browser import; use scripts/backup.py restore.")
    counts = bsvc.import_org(ctx.db, ctx.org_id, ctx.user_id, data)
    audit(ctx.db, "backup.import", org_id=ctx.org_id, user_id=ctx.user_id, details=counts, ip=ctx.ip, commit=True)
    return counts
