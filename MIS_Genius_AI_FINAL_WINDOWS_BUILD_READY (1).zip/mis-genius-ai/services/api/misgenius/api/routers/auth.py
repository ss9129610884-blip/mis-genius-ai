"""Authentication: register, login, refresh, logout, profile."""
from __future__ import annotations

import re
import secrets
from datetime import datetime, timedelta, timezone

from fastapi import APIRouter, Depends, HTTPException, Request
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from misgenius.api.deps import client_ip, current_user
from misgenius.api.schemas import ChangePasswordIn, LoginIn, ProfileIn, RefreshIn, RegisterIn, org_out, user_out
from misgenius.auth.permissions import permissions_for
from misgenius.auth.security import (
    create_access_token,
    hash_password,
    new_refresh_token,
    password_problems,
    sha256,
    verify_password,
)
from misgenius.config import get_settings
from misgenius.db.models import Membership, Organization, RefreshSession, Subscription, User, Workspace, utcnow
from misgenius.db.session import get_db
from misgenius.services.audit import audit

router = APIRouter(prefix="/auth", tags=["auth"])


def unique_slug(db: Session, name: str) -> str:
    base = re.sub(r"[^a-z0-9]+", "-", name.lower()).strip("-")[:60] or "org"
    slug = base
    while db.scalar(select(func.count()).select_from(Organization).where(Organization.slug == slug)):
        slug = f"{base}-{secrets.token_hex(3)}"
    return slug


def create_org(db: Session, name: str, owner: User) -> Organization:
    s = get_settings()
    plan = "free" if s.is_production else "enterprise"
    org = Organization(name=name, slug=unique_slug(db, name), plan=plan,
                       settings={"currency": "INR", "locale": "en-IN", "date_format": "DD MMM YYYY", "language": owner.language or "en"})
    db.add(org)
    db.flush()
    db.add(Membership(user_id=owner.id, org_id=org.id, role="owner"))
    db.add(Workspace(org_id=org.id, name="General", description="Default workspace"))
    db.add(Subscription(org_id=org.id, plan=plan, status="active", provider="manual"))
    db.flush()
    return org


def _session_payload(db: Session, user: User, request: Request, org_id: str | None = None) -> dict:
    mems = db.scalars(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at)).all()
    orgs = [(db.get(Organization, m.org_id), m.role) for m in mems]
    current = next(((o, r) for o, r in orgs if o.id == org_id), orgs[0] if orgs else (None, None))
    raw, digest = new_refresh_token()
    db.add(RefreshSession(user_id=user.id, token_hash=digest, user_agent=(request.headers.get("user-agent") or "")[:300],
                          expires_at=datetime.now(timezone.utc) + timedelta(days=get_settings().REFRESH_TOKEN_DAYS)))
    access = create_access_token(user.id, current[0].id if current[0] else None, current[1])
    return {
        "access_token": access, "refresh_token": raw, "token_type": "bearer", "expires_in": get_settings().ACCESS_TOKEN_MINUTES * 60,
        "user": user_out(user), "organizations": [org_out(o, r) for o, r in orgs],
        "current_org_id": current[0].id if current[0] else None, "role": current[1],
        "permissions": permissions_for(current[1]) if current[1] else [],
    }


@router.get("/setup-status")
def setup_status(db: Session = Depends(get_db)) -> dict:
    s = get_settings()
    users = db.scalar(select(func.count()).select_from(User)) or 0
    return {"needs_setup": users == 0, "registration_open": s.ALLOW_REGISTRATION or users == 0, "mode": s.APP_ENV, "version": s.APP_VERSION}


@router.post("/register")
def register(body: RegisterIn, request: Request, db: Session = Depends(get_db)) -> dict:
    s = get_settings()
    first = (db.scalar(select(func.count()).select_from(User)) or 0) == 0
    if not s.ALLOW_REGISTRATION and not first:
        raise HTTPException(403, "Registration is closed. Ask an administrator to add you.")
    probs = password_problems(body.password)
    if probs:
        raise HTTPException(400, "Password needs " + ", ".join(probs))
    if db.scalars(select(User).where(User.email == body.email)).first():
        raise HTTPException(409, "An account with this email already exists")
    user = User(email=body.email, password_hash=hash_password(body.password), full_name=body.full_name.strip(), language=body.language,
                last_login_at=utcnow())
    db.add(user)
    db.flush()
    org = create_org(db, body.org_name.strip() or "My Organization", user)
    audit(db, "auth.register", org_id=org.id, user_id=user.id, ip=client_ip(request), details={"first_user": first})
    out = _session_payload(db, user, request, org.id)
    db.commit()
    return out


@router.post("/login")
def login(body: LoginIn, request: Request, db: Session = Depends(get_db)) -> dict:
    user = db.scalars(select(User).where(User.email == body.email)).first()
    if user is None or not verify_password(body.password, user.password_hash):
        audit(db, "auth.login_failed", org_id=None, user_id=user.id if user else None, ip=client_ip(request), details={"email": body.email}, commit=True)
        raise HTTPException(401, "Incorrect email or password")
    if not user.is_active:
        raise HTTPException(403, "This account is disabled")
    user.last_login_at = utcnow()
    out = _session_payload(db, user, request)
    audit(db, "auth.login", org_id=out["current_org_id"], user_id=user.id, ip=client_ip(request))
    db.commit()
    return out


@router.post("/refresh")
def refresh(body: RefreshIn, request: Request, db: Session = Depends(get_db)) -> dict:
    sess = db.scalars(select(RefreshSession).where(RefreshSession.token_hash == sha256(body.refresh_token))).first()
    now = datetime.now(timezone.utc)
    if sess is None or sess.revoked_at is not None:
        raise HTTPException(401, "Session is no longer valid. Please sign in again.")
    exp = sess.expires_at if sess.expires_at.tzinfo else sess.expires_at.replace(tzinfo=timezone.utc)
    if exp < now:
        raise HTTPException(401, "Session expired. Please sign in again.")
    user = db.get(User, sess.user_id)
    if user is None or not user.is_active:
        raise HTTPException(401, "Account not found or disabled")
    sess.revoked_at = utcnow()  # rotate refresh tokens
    out = _session_payload(db, user, request, request.headers.get("x-org-id"))
    db.commit()
    return out


@router.post("/logout")
def logout(body: RefreshIn, db: Session = Depends(get_db)) -> dict:
    sess = db.scalars(select(RefreshSession).where(RefreshSession.token_hash == sha256(body.refresh_token))).first()
    if sess and sess.revoked_at is None:
        sess.revoked_at = utcnow()
        audit(db, "auth.logout", org_id=None, user_id=sess.user_id)
        db.commit()
    return {"ok": True}


@router.get("/me")
def me(request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    mems = db.scalars(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at)).all()
    orgs = [org_out(db.get(Organization, m.org_id), m.role) for m in mems]
    want = request.headers.get("x-org-id") or getattr(request.state, "token_org", None)
    cur = next((o for o in orgs if o["id"] == want), orgs[0] if orgs else None)
    return {"user": user_out(user), "organizations": orgs, "current_org_id": cur["id"] if cur else None,
            "role": cur["role"] if cur else None, "permissions": permissions_for(cur["role"]) if cur else []}


@router.patch("/me")
def update_me(body: ProfileIn, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    if body.full_name is not None:
        user.full_name = body.full_name.strip()
    if body.language is not None:
        user.language = body.language
    db.commit()
    return user_out(user)


@router.post("/change-password")
def change_password(body: ChangePasswordIn, request: Request, user: User = Depends(current_user), db: Session = Depends(get_db)) -> dict:
    if not verify_password(body.current_password, user.password_hash):
        raise HTTPException(400, "Current password is incorrect")
    probs = password_problems(body.new_password)
    if probs:
        raise HTTPException(400, "Password needs " + ", ".join(probs))
    user.password_hash = hash_password(body.new_password)
    for s in db.scalars(select(RefreshSession).where(RefreshSession.user_id == user.id, RefreshSession.revoked_at.is_(None))):
        s.revoked_at = utcnow()
    audit(db, "auth.change_password", org_id=None, user_id=user.id, ip=client_ip(request))
    db.commit()
    return {"ok": True}
