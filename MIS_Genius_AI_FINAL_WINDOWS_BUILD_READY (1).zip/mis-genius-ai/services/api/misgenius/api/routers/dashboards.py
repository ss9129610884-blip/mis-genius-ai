"""Dashboards, widgets, layouts, saved filters, templates and dashboard exports."""
from __future__ import annotations

import json
from datetime import datetime

import pandas as pd
from fastapi import APIRouter, Depends, File, HTTPException, UploadFile
from fastapi.responses import Response
from sqlalchemy import or_, select

from misgenius.api.http_utils import disposition
from misgenius.api.deps import Ctx, require
from misgenius.api.routers.datasets import get_dataset, source_for
from misgenius.api.schemas import (
    DashboardCreateIn,
    DashboardDataIn,
    DashboardExportIn,
    DashboardUpdateIn,
    LayoutIn,
    SavedFilterIn,
    TemplateApplyIn,
    TemplateFromDashboardIn,
    WidgetIn,
    WidgetUpdateIn,
    dashboard_out,
    iso,
    template_out,
    widget_out,
)
from misgenius.analytics.query import Filter
from misgenius.billing.plans import check_limit
from misgenius.dashboard.generator import generate_dashboard
from misgenius.dashboard.templates import apply_template, bind_slots, to_template
from misgenius.db.models import Dashboard, DashboardTemplate, DashboardWidget, SavedFilter
from misgenius.services import datasets as dsvc
from misgenius.services.audit import audit, record_usage
from misgenius.services.dashboards import (
    create_dashboard_from_spec,
    dashboard_spec,
    render_dashboard,
    render_widget,
    replace_widgets,
)

router = APIRouter(tags=["dashboards"])


def get_dashboard(ctx: Ctx, dashboard_id: str) -> Dashboard:
    d = ctx.db.get(Dashboard, dashboard_id)
    if d is None or d.org_id != ctx.org_id:
        raise HTTPException(404, "Dashboard not found")
    return d


def get_widget(ctx: Ctx, d: Dashboard, widget_id: str) -> DashboardWidget:
    w = ctx.db.get(DashboardWidget, widget_id)
    if w is None or w.dashboard_id != d.id:
        raise HTTPException(404, "Widget not found")
    return w


@router.get("/dashboards")
def list_dashboards(ctx: Ctx = Depends(require("read")), dataset_id: str | None = None) -> list[dict]:
    q = select(Dashboard).where(Dashboard.org_id == ctx.org_id)
    if dataset_id:
        q = q.where(Dashboard.dataset_id == dataset_id)
    out = []
    from misgenius.db.models import Dataset

    names = {d.id: (d.name, d.is_demo, d.deleted_at) for d in ctx.db.scalars(select(Dataset).where(Dataset.org_id == ctx.org_id))}
    for d in ctx.db.scalars(q.order_by(Dashboard.updated_at.desc())):
        info = names.get(d.dataset_id, (None, False, None))
        if info[2] is not None:
            continue
        out.append({**dashboard_out(d, full=False), "dataset_name": info[0], "is_demo": info[1]})
    return out


@router.post("/dashboards")
def create_dashboard(body: DashboardCreateIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    ds = get_dataset(ctx, body.dataset_id)
    v = dsvc.current_version(ctx.db, ds)
    check_limit(ctx.db, ctx.org, "dashboards")
    skipped = []
    binding = None
    if body.template_id:
        t = ctx.db.get(DashboardTemplate, body.template_id)
        if t is None or (t.org_id not in (None, ctx.org_id)):
            raise HTTPException(404, "Template not found")
        spec = apply_template(t.spec, v.schema_json, body.binding)
        skipped, binding = spec.pop("skipped_widgets"), spec.pop("binding")
        if not spec["widgets"]:
            raise HTTPException(400, "None of the template's widgets could be matched to this dataset's columns.")
    elif body.auto:
        spec = generate_dashboard(v.schema_json, ds.name)
    else:
        spec = {"name": body.name or f"{ds.name} dashboard", "config": {"filters": []}, "widgets": []}
    if body.name:
        spec["name"] = body.name
    d = create_dashboard_from_spec(ctx.db, org_id=ctx.org_id, dataset_id=ds.id, spec=spec, user_id=ctx.user_id,
                                   auto_generated=body.auto and not body.template_id)
    audit(ctx.db, "dashboard.create", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id,
          details={"template": body.template_id, "auto": body.auto})
    ctx.db.commit()
    ctx.db.refresh(d)
    return {**dashboard_out(d), "skipped_widgets": skipped, "binding": binding}


@router.get("/dashboards/{dashboard_id}")
def dashboard_detail(dashboard_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    out = dashboard_out(d)
    if d.dataset_id:
        ds = get_dataset(ctx, d.dataset_id)
        v = dsvc.current_version(ctx.db, ds)
        out["dataset"] = {"id": ds.id, "name": ds.name, "is_demo": ds.is_demo, "rows": v.row_count, "version_number": v.version_number,
                          "primary_date_column": v.schema_json.get("primary_date_column")}
        out["schema"] = v.schema_json
        out["quality"] = v.quality
        out["saved_filters"] = [{"id": s.id, "name": s.name, "filters": s.filters} for s in
                                ctx.db.scalars(select(SavedFilter).where(SavedFilter.dashboard_id == d.id).order_by(SavedFilter.created_at))]
    return out


@router.patch("/dashboards/{dashboard_id}")
def update_dashboard(dashboard_id: str, body: DashboardUpdateIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    if body.name is not None:
        d.name = body.name
    if body.description is not None:
        d.description = body.description
    if body.config is not None:
        d.config = {**(d.config or {}), **body.config}
    audit(ctx.db, "dashboard.update", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id)
    ctx.db.commit()
    return dashboard_out(d)


@router.delete("/dashboards/{dashboard_id}")
def delete_dashboard(dashboard_id: str, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    audit(ctx.db, "dashboard.delete", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id, details={"name": d.name})
    ctx.db.delete(d)
    ctx.db.commit()
    return {"ok": True}


@router.post("/dashboards/{dashboard_id}/duplicate")
def duplicate_dashboard(dashboard_id: str, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    check_limit(ctx.db, ctx.org, "dashboards")
    spec = dashboard_spec(d)
    spec["name"] = f"{d.name} (copy)"[:255]
    nd = create_dashboard_from_spec(ctx.db, org_id=ctx.org_id, dataset_id=d.dataset_id, spec=spec, user_id=ctx.user_id)
    audit(ctx.db, "dashboard.duplicate", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=nd.id, details={"from": d.id})
    ctx.db.commit()
    ctx.db.refresh(nd)
    return dashboard_out(nd)


@router.post("/dashboards/{dashboard_id}/reset")
def reset_dashboard(dashboard_id: str, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    """Regenerate the dashboard from the current dataset schema (keeps its name)."""
    d = get_dashboard(ctx, dashboard_id)
    ds = get_dataset(ctx, d.dataset_id)
    v = dsvc.current_version(ctx.db, ds)
    spec = generate_dashboard(v.schema_json, ds.name)
    d.config = spec["config"]
    d.auto_generated = True
    replace_widgets(ctx.db, d, spec)
    audit(ctx.db, "dashboard.reset", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id)
    ctx.db.commit()
    ctx.db.refresh(d)
    return dashboard_out(d)


@router.post("/dashboards/{dashboard_id}/data")
def dashboard_data(dashboard_id: str, body: DashboardDataIn, ctx: Ctx = Depends(require("read"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    _, v, src = source_for(ctx, d.dataset_id)
    widgets = render_dashboard(src, d, body.filters, body.widget_ids)
    return {"widgets": widgets, "row_count": src.count(body.filters), "total_rows": v.row_count, "version_id": v.id}


# --------------------------------------------------------------------------- widgets
@router.post("/dashboards/{dashboard_id}/widgets")
def add_widget(dashboard_id: str, body: WidgetIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    bottom = max([(w.layout or {}).get("y", 0) + (w.layout or {}).get("h", 0) for w in d.widgets] or [0])
    default_h = 4 if body.widget_type == "kpi" else 5
    layout = body.layout or {"x": 0, "y": bottom, "w": 3 if body.widget_type == "kpi" else 6, "h": default_h}
    w = DashboardWidget(dashboard_id=d.id, org_id=ctx.org_id, widget_type=body.widget_type, title=body.title, config=body.config,
                        layout=layout, position=len(d.widgets), hidden=body.hidden)
    ctx.db.add(w)
    audit(ctx.db, "widget.add", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id, details={"type": body.widget_type})
    ctx.db.commit()
    return widget_out(w)


@router.patch("/dashboards/{dashboard_id}/widgets/{widget_id}")
def update_widget(dashboard_id: str, widget_id: str, body: WidgetUpdateIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    w = get_widget(ctx, d, widget_id)
    for k, v in body.model_dump(exclude_unset=True).items():
        setattr(w, k, v)
    audit(ctx.db, "widget.update", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id, details={"widget": w.id})
    ctx.db.commit()
    return widget_out(w)


@router.delete("/dashboards/{dashboard_id}/widgets/{widget_id}")
def delete_widget(dashboard_id: str, widget_id: str, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    w = get_widget(ctx, d, widget_id)
    ctx.db.delete(w)
    audit(ctx.db, "widget.delete", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id, details={"widget": widget_id})
    ctx.db.commit()
    return {"ok": True}


@router.post("/dashboards/{dashboard_id}/widgets/{widget_id}/duplicate")
def duplicate_widget(dashboard_id: str, widget_id: str, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    w = get_widget(ctx, d, widget_id)
    lay = dict(w.layout or {})
    lay["y"] = lay.get("y", 0) + lay.get("h", 4)
    nw = DashboardWidget(dashboard_id=d.id, org_id=ctx.org_id, widget_type=w.widget_type, title=f"{w.title} (copy)"[:255],
                         config=json.loads(json.dumps(w.config)), layout=lay, position=len(d.widgets), hidden=False)
    ctx.db.add(nw)
    ctx.db.commit()
    return widget_out(nw)


@router.post("/dashboards/{dashboard_id}/widgets/{widget_id}/data")
def widget_data(dashboard_id: str, widget_id: str, body: DashboardDataIn, ctx: Ctx = Depends(require("read"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    w = get_widget(ctx, d, widget_id)
    _, _, src = source_for(ctx, d.dataset_id)
    return render_widget(src, w.widget_type, w.config or {}, body.filters)


class PreviewWidgetIn(WidgetIn):
    filters: list[Filter] = []


@router.post("/dashboards/{dashboard_id}/preview-widget")
def preview_widget(dashboard_id: str, body: PreviewWidgetIn, ctx: Ctx = Depends(require("read"))) -> dict:
    """Render an unsaved widget configuration (used by the dashboard designer)."""
    d = get_dashboard(ctx, dashboard_id)
    _, _, src = source_for(ctx, d.dataset_id)
    return render_widget(src, body.widget_type, body.config, body.filters)


@router.put("/dashboards/{dashboard_id}/layout")
def save_layout(dashboard_id: str, body: LayoutIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    by_id = {w.id: w for w in d.widgets}
    for i, item in enumerate(sorted(body.items, key=lambda it: (it.y, it.x))):
        w = by_id.get(item.id)
        if w is None:
            continue
        w.layout = {"x": item.x, "y": item.y, "w": item.w, "h": item.h}
        w.position = i
    ctx.db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- saved filters
@router.post("/dashboards/{dashboard_id}/saved-filters")
def save_filter(dashboard_id: str, body: SavedFilterIn, ctx: Ctx = Depends(require("read"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    s = SavedFilter(org_id=ctx.org_id, dashboard_id=d.id, name=body.name, filters=[f.model_dump() for f in body.filters], created_by=ctx.user_id)
    ctx.db.add(s)
    ctx.db.commit()
    return {"id": s.id, "name": s.name, "filters": s.filters}


@router.delete("/dashboards/{dashboard_id}/saved-filters/{filter_id}")
def delete_saved_filter(dashboard_id: str, filter_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    d = get_dashboard(ctx, dashboard_id)
    s = ctx.db.get(SavedFilter, filter_id)
    if s is None or s.dashboard_id != d.id:
        raise HTTPException(404, "Saved filter not found")
    ctx.db.delete(s)
    ctx.db.commit()
    return {"ok": True}


# --------------------------------------------------------------------------- export
@router.post("/dashboards/{dashboard_id}/export")
def export_dashboard(dashboard_id: str, body: DashboardExportIn, ctx: Ctx = Depends(require("export"))) -> Response:
    from misgenius.ai.nlq import _pretty_filters
    from misgenius.ai.reports import kpi_display
    from misgenius.export.exporters import dashboard_pdf, excel_bytes

    d = get_dashboard(ctx, dashboard_id)
    ds, v, src = source_for(ctx, d.dataset_id)
    data = render_dashboard(src, d, body.filters)
    kpis, charts, tables = [], [], []
    for w in d.widgets:
        r = data.get(w.id) or {}
        if w.widget_type == "kpi" and r.get("kpi", {}).get("available"):
            k = r["kpi"]
            c = k.get("comparison") or {}
            kpis.append({"title": w.title, "display": kpi_display(k), "value": k.get("value"),
                         "change_pct": c.get("change_pct") if c.get("available") else None,
                         "period": f"{c.get('current_period')} vs {c.get('previous_period')}" if c.get("available") else None})
        elif "chart" in r and w.widget_type == "chart":
            charts.append((w.title, r["chart"]))
        elif "chart" in r and w.widget_type == "table":
            tables.append((w.title, r["chart"]))
    ftxt = _pretty_filters(body.filters)
    stamp = datetime.now().strftime("%Y%m%d-%H%M")
    safe = "".join(ch if ch.isalnum() or ch in " -_" else "_" for ch in d.name)[:60].strip() or "dashboard"
    record_usage(ctx.db, ctx.org_id, "exports")
    audit(ctx.db, "export.dashboard", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="dashboard", entity_id=d.id,
          details={"format": body.format, "filters": len(body.filters)}, ip=ctx.ip, commit=True)
    subtitle = f"{ds.name} · {src.count(body.filters):,} of {v.row_count:,} records · version {v.version_number}"
    if body.format == "pdf":
        pdf = dashboard_pdf(d.name, subtitle, kpis, charts, tables, ftxt, ds.is_demo)
        return Response(pdf, media_type="application/pdf", headers={"Content-Disposition": disposition(f"{safe}-{stamp}.pdf")})
    sheets: dict[str, pd.DataFrame] = {}
    if kpis:
        sheets["KPIs"] = pd.DataFrame([{"KPI": k["title"], "Value": k["value"], "Display": k["display"], "Change %": k["change_pct"], "Period": k["period"]} for k in kpis])
    for title, ch in charts + tables:
        if ch.get("type") == "table":
            sheets[title[:31]] = pd.DataFrame(ch.get("rows", []), columns=ch.get("columns"))
        elif ch.get("categories") is not None and ch.get("series"):
            frame = {"Category": ch["categories"]}
            for s in ch["series"]:
                frame[str(s["name"])[:60]] = s["data"]
            sheets[title[:31]] = pd.DataFrame(frame)
    df = src.export_frame(filters=body.filters, max_rows=200_000)
    about = {"Dashboard": d.name, "Dataset": ds.name, "Filters": ftxt or "None", "Exported at": datetime.now().isoformat(timespec="seconds")}
    if ds.is_demo:
        about["Note"] = "DEMO DATA — not real business data."
    x = excel_bytes(df, schema=v.schema_json, about=about, extra_sheets=sheets, sheet_name="Filtered data")
    return Response(x, media_type="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
                    headers={"Content-Disposition": disposition(f"{safe}-{stamp}.xlsx")})


# --------------------------------------------------------------------------- templates
@router.get("/templates")
def list_templates(ctx: Ctx = Depends(require("read"))) -> list[dict]:
    rows = ctx.db.scalars(select(DashboardTemplate).where(or_(DashboardTemplate.org_id == ctx.org_id, DashboardTemplate.org_id.is_(None)))
                          .order_by(DashboardTemplate.created_at.desc())).all()
    return [template_out(t) for t in rows]


@router.get("/templates/{template_id}")
def get_template(template_id: str, ctx: Ctx = Depends(require("read"))) -> dict:
    t = ctx.db.get(DashboardTemplate, template_id)
    if t is None or t.org_id not in (None, ctx.org_id):
        raise HTTPException(404, "Template not found")
    return template_out(t, full=True)


@router.post("/templates/from-dashboard")
def template_from_dashboard(body: TemplateFromDashboardIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    d = get_dashboard(ctx, body.dashboard_id)
    ds = get_dataset(ctx, d.dataset_id)
    v = dsvc.current_version(ctx.db, ds)
    spec = to_template(dashboard_spec(d), v.schema_json, body.name, body.description)
    t = DashboardTemplate(org_id=ctx.org_id, name=body.name, description=body.description, source="user", spec=spec, created_by=ctx.user_id)
    ctx.db.add(t)
    audit(ctx.db, "template.create", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="template", entity_id=t.id)
    ctx.db.commit()
    return template_out(t, full=True)


@router.post("/templates/{template_id}/preview-binding")
def preview_binding(template_id: str, body: TemplateApplyIn, ctx: Ctx = Depends(require("read"))) -> dict:
    t = ctx.db.get(DashboardTemplate, template_id)
    if t is None or t.org_id not in (None, ctx.org_id):
        raise HTTPException(404, "Template not found")
    ds = get_dataset(ctx, body.dataset_id)
    v = dsvc.current_version(ctx.db, ds)
    return bind_slots(t.spec, v.schema_json, body.binding)


@router.post("/templates/{template_id}/apply")
def apply(template_id: str, body: TemplateApplyIn, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    return create_dashboard(DashboardCreateIn(dataset_id=body.dataset_id, template_id=template_id, binding=body.binding, name=body.name, auto=False), ctx)


@router.get("/templates/{template_id}/export")
def export_template(template_id: str, ctx: Ctx = Depends(require("read"))) -> Response:
    t = ctx.db.get(DashboardTemplate, template_id)
    if t is None or t.org_id not in (None, ctx.org_id):
        raise HTTPException(404, "Template not found")
    body = json.dumps({**t.spec, "name": t.name, "description": t.description}, ensure_ascii=False, indent=2)
    safe = "".join(ch if ch.isalnum() or ch in "-_" else "_" for ch in t.name)[:60]
    return Response(body, media_type="application/json", headers={"Content-Disposition": disposition(f"{safe}.mis-template.json")})


@router.post("/templates/import")
async def import_template(file: UploadFile = File(...), ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    raw = await file.read(2_000_001)
    if len(raw) > 2_000_000:
        raise HTTPException(413, "Template file is too large")
    try:
        spec = json.loads(raw)
    except json.JSONDecodeError:
        raise HTTPException(400, "Not a valid template file (JSON expected)") from None
    if spec.get("format") != "mis-genius-template/v1" or not isinstance(spec.get("widgets"), list) or not isinstance(spec.get("slots"), list):
        raise HTTPException(400, "Not a MIS Genius AI template")
    from misgenius.api.schemas import WidgetIn as _W

    for w in spec["widgets"]:
        try:
            _W(widget_type=w["widget_type"], title=w.get("title", ""), config={})
        except Exception:  # noqa: BLE001
            raise HTTPException(400, "Template contains an invalid widget") from None
    t = DashboardTemplate(org_id=ctx.org_id, name=str(spec.get("name", "Imported template"))[:255], description=str(spec.get("description", ""))[:2000],
                          source="imported", spec=spec, created_by=ctx.user_id)
    ctx.db.add(t)
    audit(ctx.db, "template.import", org_id=ctx.org_id, user_id=ctx.user_id, entity_type="template", entity_id=t.id)
    ctx.db.commit()
    return template_out(t)


@router.delete("/templates/{template_id}")
def delete_template(template_id: str, ctx: Ctx = Depends(require("dashboard.write"))) -> dict:
    t = ctx.db.get(DashboardTemplate, template_id)
    if t is None or t.org_id != ctx.org_id:
        raise HTTPException(404, "Template not found (built-in templates cannot be deleted)")
    ctx.db.delete(t)
    ctx.db.commit()
    return {"ok": True, "deleted_at": iso(datetime.now())}
