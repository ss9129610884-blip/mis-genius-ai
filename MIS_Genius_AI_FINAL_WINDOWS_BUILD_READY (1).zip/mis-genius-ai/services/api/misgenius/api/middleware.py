"""HTTP middleware: request IDs + structured access logs, security headers, rate limiting."""
from __future__ import annotations

import logging
import threading
import time
import uuid
from collections import defaultdict, deque

from starlette.middleware.base import BaseHTTPMiddleware
from starlette.requests import Request
from starlette.responses import JSONResponse, Response

from misgenius.config import get_settings

log = logging.getLogger("misgenius.http")


class RequestContextMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        rid = request.headers.get("x-request-id") or uuid.uuid4().hex[:16]
        request.state.request_id = rid
        t0 = time.monotonic()
        response = await call_next(request)
        dur = int((time.monotonic() - t0) * 1000)
        response.headers["X-Request-ID"] = rid
        if request.url.path.startswith("/api/"):
            log.info("%s %s %s", request.method, request.url.path, response.status_code,
                     extra={"request_id": rid, "path": request.url.path, "status": response.status_code, "duration_ms": dur,
                            "org_id": getattr(request.state, "org_id", None), "user_id": getattr(request.state, "user_id", None)})
        return response


class SecurityHeadersMiddleware(BaseHTTPMiddleware):
    CSP = ("default-src 'self'; script-src 'self'; style-src 'self' 'unsafe-inline' https://fonts.googleapis.com; "
           "font-src 'self' data: https://fonts.gstatic.com; img-src 'self' data: blob:; connect-src 'self'; "
           "frame-ancestors 'none'; base-uri 'self'; form-action 'self'; object-src 'none'")

    async def dispatch(self, request: Request, call_next) -> Response:
        response = await call_next(request)
        h = response.headers
        h.setdefault("X-Content-Type-Options", "nosniff")
        h.setdefault("X-Frame-Options", "DENY")
        h.setdefault("Referrer-Policy", "strict-origin-when-cross-origin")
        h.setdefault("Permissions-Policy", "camera=(), microphone=(), geolocation=()")
        h.setdefault("Cross-Origin-Opener-Policy", "same-origin")
        if not request.url.path.startswith(("/api/docs", "/api/redoc")):
            h.setdefault("Content-Security-Policy", self.CSP)
        if get_settings().is_production:
            h.setdefault("Strict-Transport-Security", "max-age=31536000; includeSubDomains")
        if request.url.path.startswith("/api/"):
            h.setdefault("Cache-Control", "no-store")
        return response


class RateLimiter:
    """Sliding-window limiter. In-memory per process; swap for Redis in multi-instance cloud setups."""

    def __init__(self) -> None:
        self.hits: dict[str, deque[float]] = defaultdict(deque)
        self.lock = threading.Lock()

    def allow(self, key: str, limit: int, window: float = 60.0) -> tuple[bool, int]:
        now = time.monotonic()
        with self.lock:
            q = self.hits[key]
            while q and now - q[0] > window:
                q.popleft()
            if len(q) >= limit:
                return False, int(window - (now - q[0])) + 1
            q.append(now)
            if len(self.hits) > 50_000:
                for k in list(self.hits)[:10_000]:
                    if not self.hits[k]:
                        del self.hits[k]
            return True, 0


limiter = RateLimiter()


class RateLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        s = get_settings()
        path = request.url.path
        if path.startswith("/api/") and s.APP_ENV != "testing":
            ip = request.client.host if request.client else "unknown"
            if path.startswith(("/api/v1/auth/login", "/api/v1/auth/register", "/api/v1/auth/refresh")):
                ok, retry = limiter.allow(f"auth:{ip}", s.AUTH_RATE_LIMIT_PER_MINUTE)
            else:
                ident = request.headers.get("x-api-key", "")[:14] or ip
                ok, retry = limiter.allow(f"api:{ident}", s.RATE_LIMIT_PER_MINUTE)
            if not ok:
                return JSONResponse({"detail": "Too many requests. Please slow down.", "retry_after": retry}, status_code=429,
                                    headers={"Retry-After": str(retry)})
        return await call_next(request)


class BodySizeLimitMiddleware(BaseHTTPMiddleware):
    async def dispatch(self, request: Request, call_next) -> Response:
        cl = request.headers.get("content-length")
        limit = get_settings().MAX_UPLOAD_MB * 1024 * 1024 + 1024 * 1024
        if cl and cl.isdigit() and int(cl) > limit:
            return JSONResponse({"detail": f"Request is too large (limit {get_settings().MAX_UPLOAD_MB} MB)."}, status_code=413)
        return await call_next(request)
