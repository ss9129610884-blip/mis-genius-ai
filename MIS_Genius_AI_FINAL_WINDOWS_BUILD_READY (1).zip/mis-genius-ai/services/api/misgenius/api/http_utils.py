"""HTTP helpers."""
from __future__ import annotations

import re
from urllib.parse import quote


def disposition(filename: str, inline: bool = False) -> str:
    """RFC 6266/5987 Content-Disposition that works for Hindi and other non-ASCII names."""
    ascii_name = re.sub(r"[^A-Za-z0-9._ -]+", "_", filename).strip() or "download"
    kind = "inline" if inline else "attachment"
    return f"{kind}; filename=\"{ascii_name}\"; filename*=UTF-8''{quote(filename)}"
