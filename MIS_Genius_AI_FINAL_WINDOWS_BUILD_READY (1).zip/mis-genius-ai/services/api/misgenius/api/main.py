"""FastAPI application factory. Serves the REST API (/api/v1) and the web app."""
from __future__ import annotations

import logging
import threading
from contextlib import asynccontextmanager
from pathlib import Path

from fastapi import FastAPI, HTTPException, Request
from fastapi.exceptions import RequestValidationError
from fastapi.middleware.cors import CORSMiddleware
from fastapi.middleware.gzip import GZipMiddleware
from fastapi.responses import FileResponse, JSONResponse
from starlette.middleware.trustedhost import TrustedHostMiddleware

from misgenius.api.middleware import (
    BodySizeLimitMiddleware,
    RateLimitMiddleware,
    RequestContextMiddleware,
    SecurityHeadersMiddleware,
)
from misgenius.config import get_settings
from misgenius.logging_setup import setup_logging

log = logging.getLogger("misgenius.app")
API_PREFIX = "/api/v1"
_stop = threading.Event()


def seed_builtin_templates() -> None:
    from sqlalchemy import select

    from misgenius.dashboard.generator import generate_dashboard
    from misgenius.dashboard.templates import to_template
    from misgenius.db.models import DashboardTemplate
    from misgenius.db.session import session_scope
    from misgenius.demo.demo_data import demo_attendance, demo_sales
    from misgenius.schema.profiler import profile_dataframe

    specs = [("Sales performance", "Revenue, cost, margin, regions, products and customers.", demo_sales),
             ("Attendance overview", "Attendance %, hours, departments and employees.", demo_attendance)]
    with session_scope() as db:
        existing = {t.name for t in db.scalars(select(DashboardTemplate).where(DashboardTemplate.org_id.is_(None)))}
        for name, desc, fn in specs:
            if name in existing:
                continue
            df = fn()
            raw = df.astype(object).map(lambda v: None if v is None else (v.isoformat() if hasattr(v, "isoformat") else str(v)))
            prof = profile_dataframe(raw)
            dash = generate_dashboard(prof.schema, name)
            db.add(DashboardTemplate(org_id=None, name=name, description=desc, source="builtin", spec=to_template(dash, prof.schema, name, desc)))


@asynccontextmanager
async def lifespan(app: FastAPI):
    s = get_settings()
    setup_logging(s.DATA_DIR / "logs", s.LOG_LEVEL, s.LOG_JSON, to_files=s.APP_ENV != "testing")
    from misgenius.db.session import SessionLocal, run_migrations
    from misgenius.jobs.runner import recover_stale

    import misgenius.services.job_handlers  # noqa: F401 - register job handlers

    run_migrations()
    db = SessionLocal()
    try:
        recover_stale(db, older_than_minutes=0 if s.JOB_MODE == "thread" else 30)
        from sqlalchemy import select

        from misgenius.db.models import Job
        from misgenius.jobs.runner import _get_pool, run_job

        if s.JOB_MODE == "thread":
            for j in db.scalars(select(Job).where(Job.status == "queued")):
                _get_pool().submit(run_job, j.id)
    finally:
        db.close()
    try:
        seed_builtin_templates()
    except Exception as e:  # noqa: BLE001
        log.warning("could not seed built-in templates: %s", e)
    if s.JOB_MODE == "thread" and s.APP_ENV != "testing":
        from misgenius.jobs.worker import scheduler_loop

        _stop.clear()
        threading.Thread(target=scheduler_loop, args=(_stop,), daemon=True, name="refresh-scheduler").start()
    log.info("MIS Genius AI %s started in %s mode (db=%s, storage=%s, ai=%s)", s.APP_VERSION, s.APP_ENV,
             s.database_url.split(":", 1)[0], s.STORAGE_PROVIDER, s.AI_PROVIDER)
    yield
    _stop.set()


def create_app() -> FastAPI:
    s = get_settings()
    app = FastAPI(title="MIS Genius AI API", version=s.APP_VERSION, lifespan=lifespan,
                  description="Universal AI-powered MIS & BI platform. All endpoints are tenant-scoped; authenticate with a Bearer token or X-API-Key.",
                  docs_url="/api/docs", redoc_url="/api/redoc", openapi_url="/api/openapi.json")

    app.add_middleware(GZipMiddleware, minimum_size=1024)
    app.add_middleware(RateLimitMiddleware)
    app.add_middleware(BodySizeLimitMiddleware)
    app.add_middleware(SecurityHeadersMiddleware)
    if s.cors_origins:
        app.add_middleware(CORSMiddleware, allow_origins=s.cors_origins, allow_credentials=False, allow_methods=["*"],
                           allow_headers=["Authorization", "Content-Type", "X-Org-Id", "X-API-Key", "X-Request-ID"], max_age=600)
    if s.trusted_hosts:
        app.add_middleware(TrustedHostMiddleware, allowed_hosts=s.trusted_hosts)
    app.add_middleware(RequestContextMiddleware)

    _register_errors(app)

    from misgenius.api.routers import ai, analytics, auth, dashboards, datasets, orgs, reports, system

    for r in (auth.router, orgs.router, datasets.router, analytics.router, dashboards.router, ai.router, reports.router, system.router):
        app.include_router(r, prefix=API_PREFIX)

    @app.get("/api/health", include_in_schema=False)
    def root_health():
        return system.health()

    _mount_web(app)
    return app


def _register_errors(app: FastAPI) -> None:
    from misgenius.analytics.formulas import FormulaError
    from misgenius.analytics.query import QueryError
    from misgenius.billing.plans import LimitExceeded
    from misgenius.cleaning.transforms import TransformError
    from misgenius.connectors.base import ConnectorError
    from misgenius.ingestion.readers import IngestionError
    from misgenius.services.datasets import DatasetError
    from misgenius.storage.base import StorageError

    def rid(request: Request) -> str | None:
        return getattr(request.state, "request_id", None)

    async def friendly(request: Request, exc: Exception):
        code = 402 if isinstance(exc, LimitExceeded) else 400
        return JSONResponse({"detail": str(exc), "request_id": rid(request)}, status_code=code)

    for exc in (QueryError, FormulaError, TransformError, IngestionError, ConnectorError, DatasetError, StorageError, LimitExceeded):
        app.add_exception_handler(exc, friendly)

    @app.exception_handler(RequestValidationError)
    async def validation(request: Request, exc: RequestValidationError):
        errs = []
        for e in exc.errors()[:10]:
            loc = ".".join(str(x) for x in e.get("loc", []) if x != "body")
            errs.append(f"{loc}: {e.get('msg')}" if loc else e.get("msg"))
        return JSONResponse({"detail": "Invalid request: " + "; ".join(errs), "errors": exc.errors()[:10] if get_settings().APP_ENV == "development" else None,
                             "request_id": rid(request)}, status_code=422)

    @app.exception_handler(Exception)
    async def unhandled(request: Request, exc: Exception):
        if isinstance(exc, HTTPException):
            return JSONResponse({"detail": exc.detail}, status_code=exc.status_code)
        log.exception("unhandled error on %s %s", request.method, request.url.path, extra={"request_id": rid(request)})
        body = {"detail": "Something went wrong on the server. The error was logged.", "request_id": rid(request)}
        if get_settings().APP_ENV == "development":
            body["error"] = f"{type(exc).__name__}: {exc}"
        return JSONResponse(body, status_code=500)


def _mount_web(app: FastAPI) -> None:
    s = get_settings()
    dist = s.web_dist_dir
    if not s.SERVE_WEB or dist is None:
        @app.get("/", include_in_schema=False)
        def no_web():
            return JSONResponse({"name": "MIS Genius AI API", "docs": "/api/docs",
                                 "note": "Web app build not found. Run `npm run build` in apps/web or set WEB_DIST_DIR."})
        return
    dist = Path(dist).resolve()

    @app.get("/{full_path:path}", include_in_schema=False)
    def spa(full_path: str):
        if full_path.startswith("api/"):
            raise HTTPException(404, "Not found")
        target = (dist / full_path).resolve()
        if full_path and dist in target.parents and target.is_file():
            headers = {"Cache-Control": "public, max-age=31536000, immutable"} if "/assets/" in f"/{full_path}" else {"Cache-Control": "no-cache"}
            return FileResponse(target, headers=headers)
        return FileResponse(dist / "index.html", headers={"Cache-Control": "no-cache"})


app = create_app()
