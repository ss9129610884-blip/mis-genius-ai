"""Request context: authentication (JWT or API key), tenant resolution and role checks."""
from __future__ import annotations

from dataclasses import dataclass

import jwt
from fastapi import Depends, HTTPException, Request, status
from sqlalchemy import select
from sqlalchemy.orm import Session

from misgenius.auth.permissions import has_permission
from misgenius.auth.security import decode_access_token, sha256
from misgenius.db.models import ApiKey, Membership, Organization, User, utcnow
from misgenius.db.session import get_db


@dataclass
class Ctx:
    db: Session
    user: User
    org: Organization
    role: str
    ip: str | None
    via_api_key: bool = False

    @property
    def org_id(self) -> str:
        return self.org.id

    @property
    def user_id(self) -> str:
        return self.user.id


def client_ip(request: Request) -> str | None:
    return request.client.host if request.client else None


def _bearer(request: Request) -> str | None:
    auth = request.headers.get("authorization", "")
    if auth.lower().startswith("bearer "):
        return auth[7:].strip()
    return None


def current_user(request: Request, db: Session = Depends(get_db)) -> User:
    token = _bearer(request)
    if not token:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Not signed in", headers={"WWW-Authenticate": "Bearer"})
    try:
        payload = decode_access_token(token)
    except jwt.ExpiredSignatureError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Session expired", headers={"WWW-Authenticate": "Bearer"}) from None
    except jwt.InvalidTokenError:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid token", headers={"WWW-Authenticate": "Bearer"}) from None
    user = db.get(User, payload["sub"])
    if user is None or not user.is_active:
        raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Account not found or disabled")
    request.state.token_org = payload.get("org")
    return user


def get_ctx(request: Request, db: Session = Depends(get_db)) -> Ctx:
    key = request.headers.get("x-api-key")
    if key:
        row = db.scalars(select(ApiKey).where(ApiKey.key_hash == sha256(key))).first()
        if row is None or row.revoked_at is not None:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid API key")
        org = db.get(Organization, row.org_id)
        user = db.get(User, row.user_id)
        if org is None or user is None or not user.is_active:
            raise HTTPException(status.HTTP_401_UNAUTHORIZED, "Invalid API key")
        row.last_used_at = utcnow()
        from misgenius.services.audit import record_usage

        record_usage(db, org.id, "api_calls")
        db.commit()
        request.state.org_id, request.state.user_id = org.id, user.id
        return Ctx(db=db, user=user, org=org, role=row.role, ip=client_ip(request), via_api_key=True)
    user = current_user(request, db)
    org_id = request.headers.get("x-org-id") or getattr(request.state, "token_org", None)
    mem = None
    if org_id:
        mem = db.scalars(select(Membership).where(Membership.user_id == user.id, Membership.org_id == org_id)).first()
    if mem is None:
        mem = db.scalars(select(Membership).where(Membership.user_id == user.id).order_by(Membership.created_at)).first()
        if org_id and mem is not None and mem.org_id != org_id:
            raise HTTPException(status.HTTP_403_FORBIDDEN, "You are not a member of this organization")
    if mem is None:
        raise HTTPException(status.HTTP_403_FORBIDDEN, "You are not a member of any organization")
    org = db.get(Organization, mem.org_id)
    request.state.org_id, request.state.user_id = org.id, user.id
    return Ctx(db=db, user=user, org=org, role=mem.role, ip=client_ip(request))


def require(perm: str):
    def dep(ctx: Ctx = Depends(get_ctx)) -> Ctx:
        if not has_permission(ctx.role, perm):
            raise HTTPException(status.HTTP_403_FORBIDDEN, f"Your role ({ctx.role}) does not allow this action")
        return ctx

    return dep
