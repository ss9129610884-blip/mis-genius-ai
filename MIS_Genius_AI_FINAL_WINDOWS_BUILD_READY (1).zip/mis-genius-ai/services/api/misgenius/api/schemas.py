"""Request models (validated by FastAPI / Pydantic) and response serializers."""
from __future__ import annotations

from typing import Any, Literal

from pydantic import BaseModel, Field, field_validator

from misgenius.analytics.charts import ChartSpec
from misgenius.analytics.kpi import KPISpec
from misgenius.analytics.query import Dimension, Filter, Measure, QuerySpec, Sort
from misgenius.db.models import (
    AlertRule,
    Dashboard,
    DashboardTemplate,
    DashboardWidget,
    Dataset,
    DatasetVersion,
    Job,
    Notification,
    Organization,
    Report,
    User,
    Workspace,
)


class _Email(BaseModel):
    email: str = Field(min_length=3, max_length=255)

    @field_validator("email")
    @classmethod
    def _v(cls, v: str) -> str:  # noqa: N805
        v = v.strip().lower()
        if "@" not in v or "." not in v.split("@")[-1] or " " in v:
            raise ValueError("Invalid email address")
        return v


# --------------------------------------------------------------------------- auth / orgs
class RegisterIn(_Email):
    password: str = Field(min_length=8, max_length=200)
    full_name: str = Field(default="", max_length=200)
    org_name: str = Field(default="My Organization", min_length=1, max_length=200)
    language: Literal["en", "hi"] = "en"


class LoginIn(_Email):
    password: str = Field(min_length=1, max_length=200)


class RefreshIn(BaseModel):
    refresh_token: str = Field(min_length=10, max_length=300)


class ChangePasswordIn(BaseModel):
    current_password: str
    new_password: str = Field(min_length=8, max_length=200)


class ProfileIn(BaseModel):
    full_name: str | None = Field(default=None, max_length=200)
    language: Literal["en", "hi"] | None = None


class OrgCreateIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)


class OrgUpdateIn(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=200)
    settings: dict[str, Any] | None = None


class MemberIn(_Email):
    role: Literal["owner", "admin", "analyst", "viewer"] = "viewer"
    full_name: str = Field(default="", max_length=200)
    password: str | None = Field(default=None, min_length=8, max_length=200)


class MemberRoleIn(BaseModel):
    role: Literal["owner", "admin", "analyst", "viewer"]


class WorkspaceIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    description: str = Field(default="", max_length=2000)


class ApiKeyIn(BaseModel):
    name: str = Field(min_length=1, max_length=120)
    role: Literal["viewer", "analyst", "admin"] = "viewer"


# --------------------------------------------------------------------------- datasets
class CreateFromSheetsIn(BaseModel):
    sheet_ids: list[str] = Field(min_length=1, max_length=50)
    name: str | None = Field(default=None, max_length=200)
    workspace_id: str | None = None
    dataset_id: str | None = None
    combine: bool = False


class DatasetUpdateIn(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=5000)
    workspace_id: str | None = None
    refresh_minutes: int | None = Field(default=None, ge=15, le=60 * 24 * 31)


class ColumnOverrideIn(BaseModel):
    data_type: str | None = None
    role: Literal["measure", "dimension", "time", "identifier", "attribute", "ignore"] | None = None
    label: str | None = Field(default=None, max_length=255)
    description: str | None = Field(default=None, max_length=2000)
    dayfirst: bool | None = None
    format: dict[str, Any] | None = None
    reset: bool = False


class RowsQueryIn(BaseModel):
    columns: list[str] | None = None
    filters: list[Filter] = Field(default_factory=list)
    search: str | None = Field(default=None, max_length=200)
    sort: list[Sort] = Field(default_factory=list)
    limit: int = Field(default=100, ge=1, le=5000)
    offset: int = Field(default=0, ge=0)
    duplicates_only: bool = False
    nulls_in: str | None = None


class CleaningIn(BaseModel):
    steps: list[dict[str, Any]] = Field(min_length=1, max_length=50)


class JoinIn(BaseModel):
    left_id: str
    right_id: str
    left_on: str
    right_on: str
    how: Literal["left", "inner"] = "left"
    name: str | None = None


class ExportIn(BaseModel):
    format: Literal["csv", "xlsx"] = "xlsx"
    filters: list[Filter] = Field(default_factory=list)
    columns: list[str] | None = None
    search: str | None = None
    sort: list[Sort] = Field(default_factory=list)
    scope: Literal["filtered", "all"] = "filtered"


class ConnectorImportIn(BaseModel):
    type: str
    config: dict[str, Any]
    name: str = Field(default="Imported data", max_length=200)
    refresh_minutes: int | None = Field(default=None, ge=15, le=60 * 24 * 31)
    workspace_id: str | None = None


class ConnectorTestIn(BaseModel):
    type: str
    config: dict[str, Any]


# --------------------------------------------------------------------------- analytics
class QueryIn(QuerySpec):
    pass


class KPIIn(BaseModel):
    kpi: KPISpec
    filters: list[Filter] = Field(default_factory=list)


class ChartIn(BaseModel):
    chart: ChartSpec
    filters: list[Filter] = Field(default_factory=list)


class PivotIn(BaseModel):
    rows: list[Dimension] = Field(default_factory=list, max_length=3)
    column: Dimension | None = None
    values: list[Measure] = Field(default_factory=list, max_length=6)
    filters: list[Filter] = Field(default_factory=list)


class RecommendIn(BaseModel):
    dimensions: list[str] = Field(default_factory=list)
    measures: list[str] = Field(default_factory=list)


class DistinctIn(BaseModel):
    column: str
    filters: list[Filter] = Field(default_factory=list)
    search: str | None = None
    limit: int = Field(default=200, ge=1, le=5000)


# --------------------------------------------------------------------------- dashboards
class DashboardCreateIn(BaseModel):
    dataset_id: str
    name: str | None = Field(default=None, max_length=255)
    auto: bool = True
    template_id: str | None = None
    binding: dict[str, str] | None = None


class DashboardUpdateIn(BaseModel):
    name: str | None = Field(default=None, min_length=1, max_length=255)
    description: str | None = Field(default=None, max_length=5000)
    config: dict[str, Any] | None = None


class WidgetIn(BaseModel):
    widget_type: Literal["kpi", "chart", "table", "pivot", "quality", "insights", "text", "alert"]
    title: str = Field(default="", max_length=255)
    config: dict[str, Any] = Field(default_factory=dict)
    layout: dict[str, int] | None = None
    hidden: bool = False

    @field_validator("config")
    @classmethod
    def _cfg(cls, v: dict[str, Any], info):  # noqa: N805
        if "kpi" in v:
            KPISpec(**v["kpi"])
        if "chart" in v:
            ChartSpec(**v["chart"])
        return v


class WidgetUpdateIn(BaseModel):
    title: str | None = Field(default=None, max_length=255)
    config: dict[str, Any] | None = None
    layout: dict[str, int] | None = None
    hidden: bool | None = None

    @field_validator("config")
    @classmethod
    def _cfg(cls, v):  # noqa: N805
        if v and "kpi" in v:
            KPISpec(**v["kpi"])
        if v and "chart" in v:
            ChartSpec(**v["chart"])
        return v


class LayoutItem(BaseModel):
    id: str
    x: int = Field(ge=0, le=48)
    y: int = Field(ge=0, le=10000)
    w: int = Field(ge=1, le=12)
    h: int = Field(ge=1, le=60)


class LayoutIn(BaseModel):
    items: list[LayoutItem]


class DashboardDataIn(BaseModel):
    filters: list[Filter] = Field(default_factory=list)
    widget_ids: list[str] | None = None


class SavedFilterIn(BaseModel):
    name: str = Field(min_length=1, max_length=200)
    filters: list[Filter]


class DashboardExportIn(BaseModel):
    format: Literal["pdf", "xlsx"] = "pdf"
    filters: list[Filter] = Field(default_factory=list)


class TemplateFromDashboardIn(BaseModel):
    dashboard_id: str
    name: str = Field(min_length=1, max_length=255)
    description: str = Field(default="", max_length=2000)


class TemplateApplyIn(BaseModel):
    dataset_id: str
    binding: dict[str, str] | None = None
    name: str | None = None


# --------------------------------------------------------------------------- AI / reports
class InsightsIn(BaseModel):
    filters: list[Filter] = Field(default_factory=list)
    language: Literal["en", "hi"] = "en"


class AskIn(BaseModel):
    question: str = Field(min_length=2, max_length=500)
    filters: list[Filter] = Field(default_factory=list)
    language: Literal["en", "hi", "auto"] = "auto"


class AISettingsIn(BaseModel):
    provider: Literal["none", "anthropic", "openai", "gemini", "openai_compatible"]
    model: str | None = Field(default=None, max_length=120)
    base_url: str | None = Field(default=None, max_length=500)
    api_key: str | None = Field(default=None, max_length=500)
    clear_api_key: bool = False
    enabled: bool = True


class ReportIn(BaseModel):
    dataset_id: str
    dashboard_id: str | None = None
    title: str | None = Field(default=None, max_length=255)
    language: Literal["en", "hi"] = "en"
    filters: list[Filter] = Field(default_factory=list)


class AlertIn(BaseModel):
    dataset_id: str
    name: str = Field(min_length=1, max_length=200)
    kpi: KPISpec
    operator: Literal[">", ">=", "<", "<=", "==", "!="]
    threshold: float
    channels: list[str] = Field(default_factory=lambda: ["in_app"])
    enabled: bool = True


class PlanIn(BaseModel):
    plan: Literal["free", "starter", "professional", "business", "enterprise"]


class CheckoutIn(BaseModel):
    plan: Literal["starter", "professional", "business"]
    success_url: str
    cancel_url: str


# --------------------------------------------------------------------------- serializers
def iso(dt) -> str | None:
    return dt.isoformat() if dt else None


def user_out(u: User) -> dict[str, Any]:
    return {"id": u.id, "email": u.email, "full_name": u.full_name, "language": u.language, "created_at": iso(u.created_at),
            "last_login_at": iso(u.last_login_at)}


def org_out(o: Organization, role: str | None = None) -> dict[str, Any]:
    return {"id": o.id, "name": o.name, "slug": o.slug, "plan": o.plan, "settings": o.settings or {}, "role": role, "created_at": iso(o.created_at)}


def workspace_out(w: Workspace) -> dict[str, Any]:
    return {"id": w.id, "name": w.name, "description": w.description, "created_at": iso(w.created_at)}


def dataset_out(d: Dataset, v: DatasetVersion | None = None) -> dict[str, Any]:
    out = {"id": d.id, "name": d.name, "description": d.description, "source_type": d.source_type, "is_demo": d.is_demo,
           "workspace_id": d.workspace_id, "current_version_id": d.current_version_id, "refresh_minutes": d.refresh_minutes,
           "last_refreshed_at": iso(d.last_refreshed_at), "created_at": iso(d.created_at), "updated_at": iso(d.updated_at),
           "deleted_at": iso(d.deleted_at)}
    if v is not None:
        q = (v.quality or {}).get("summary", {})
        out.update({"rows": v.row_count, "columns": v.col_count, "version_number": v.version_number, "quality_score": q.get("score"),
                    "domain": (v.schema_json or {}).get("domain", {}).get("guess"), "primary_date_column": (v.schema_json or {}).get("primary_date_column")})
    return out


def version_out(v: DatasetVersion) -> dict[str, Any]:
    return {"id": v.id, "version_number": v.version_number, "kind": v.kind, "rows": v.row_count, "columns": v.col_count, "status": v.status,
            "note": v.note, "transforms": v.transforms, "parent_version_id": v.parent_version_id, "file_id": v.file_id,
            "created_at": iso(v.created_at), "quality_score": (v.quality or {}).get("summary", {}).get("score")}


def widget_out(w: DashboardWidget) -> dict[str, Any]:
    return {"id": w.id, "widget_type": w.widget_type, "title": w.title, "config": w.config, "layout": w.layout, "position": w.position, "hidden": w.hidden}


def dashboard_out(d: Dashboard, full: bool = True) -> dict[str, Any]:
    out = {"id": d.id, "name": d.name, "description": d.description, "dataset_id": d.dataset_id, "auto_generated": d.auto_generated,
           "created_at": iso(d.created_at), "updated_at": iso(d.updated_at), "widget_count": len(d.widgets)}
    if full:
        out.update({"config": d.config or {}, "widgets": [widget_out(w) for w in d.widgets]})
    return out


def template_out(t: DashboardTemplate, full: bool = False) -> dict[str, Any]:
    out = {"id": t.id, "name": t.name, "description": t.description, "source": t.source, "created_at": iso(t.created_at),
           "slots": (t.spec or {}).get("slots", []), "widget_count": len((t.spec or {}).get("widgets", [])), "builtin": t.org_id is None}
    if full:
        out["spec"] = t.spec
    return out


def job_out(j: Job) -> dict[str, Any]:
    return {"id": j.id, "kind": j.kind, "status": j.status, "progress": j.progress, "result": j.result, "error": j.error,
            "created_at": iso(j.created_at), "finished_at": iso(j.finished_at)}


def report_out(r: Report, full: bool = False) -> dict[str, Any]:
    out = {"id": r.id, "title": r.title, "language": r.language, "dataset_id": r.dataset_id, "dashboard_id": r.dashboard_id,
           "generated_by": r.generated_by, "created_at": iso(r.created_at)}
    if full:
        out["content"] = r.content
        out["filters"] = r.filters
    return out


def notification_out(n: Notification) -> dict[str, Any]:
    return {"id": n.id, "kind": n.kind, "title": n.title, "body": n.body, "link": n.link, "read": n.read_at is not None, "created_at": iso(n.created_at)}


def alert_out(a: AlertRule) -> dict[str, Any]:
    return {"id": a.id, "dataset_id": a.dataset_id, "name": a.name, "kpi": a.kpi, "operator": a.operator, "threshold": a.threshold,
            "channels": a.channels, "enabled": a.enabled, "last_triggered_at": iso(a.last_triggered_at), "created_at": iso(a.created_at)}



