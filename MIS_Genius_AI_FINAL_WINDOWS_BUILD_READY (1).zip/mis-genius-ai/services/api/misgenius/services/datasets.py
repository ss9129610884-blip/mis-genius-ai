"""Dataset lifecycle: upload → inspect → versions → profiling → cleaning → refresh.

The uploaded file and every version's raw table are immutable. Cleaning, type
corrections, refreshes and combined/joined datasets always create or update
*derived* artefacts, never the original upload.
"""
from __future__ import annotations

import hashlib
import io
import logging
import re
from datetime import datetime, timezone
from typing import Any

import pandas as pd
from sqlalchemy import func, select
from sqlalchemy.orm import Session

from misgenius.analytics.query import DataSource
from misgenius.cleaning.transforms import apply_transforms
from misgenius.config import get_settings
from misgenius.db.models import (
    ColumnMeta,
    Dashboard,
    Dataset,
    DatasetVersion,
    FileObject,
    Organization,
    Sheet,
    utcnow,
)
from misgenius.ingestion.pipeline import inspect_workbook, table_summary, table_to_raw
from misgenius.ingestion.readers import IngestionError, RawWorkbook, detect_format, read_file
from misgenius.schema.profiler import profile_dataframe
from misgenius.storage.base import get_storage

log = logging.getLogger("misgenius.datasets")
ALLOWED_EXT = (".xlsx", ".xlsm", ".xls", ".csv", ".tsv", ".txt", ".json")


class DatasetError(Exception):
    pass


def safe_filename(name: str) -> str:
    base = re.sub(r"[^A-Za-z0-9._\- ]+", "_", (name or "file").replace("\\", "/").rsplit("/", 1)[-1]).strip(" .")
    return (base or "file")[:120]


def _write_parquet(key: str, df: pd.DataFrame) -> None:
    buf = io.BytesIO()
    df.to_parquet(buf, index=False, engine="pyarrow", compression="zstd")
    get_storage().put_bytes(key, buf.getvalue())


def read_parquet(key: str) -> pd.DataFrame:
    return pd.read_parquet(get_storage().local_path(key), engine="pyarrow")


def raw_to_object(df: pd.DataFrame) -> pd.DataFrame:
    """Parquet round-trips text as pandas string dtype; profiling wants plain Python objects."""
    return pd.DataFrame({c: pd.Series([None if (v is None or v is pd.NA or (isinstance(v, float) and v != v)) else v
                                       for v in df[c].tolist()], dtype=object) for c in df.columns})


# --------------------------------------------------------------------------- upload + inspect
def validate_upload(filename: str, data: bytes) -> str:
    if not filename or not filename.lower().endswith(ALLOWED_EXT):
        raise IngestionError("Unsupported file type. Upload .xlsx, .xls, .csv or .json files.")
    if not data:
        raise IngestionError("The uploaded file is empty.")
    return detect_format(filename, data)


def store_upload(db: Session, org: Organization, user_id: str | None, filename: str, data: bytes) -> FileObject:
    fmt = validate_upload(filename, data)
    safe = safe_filename(filename)
    f = FileObject(org_id=org.id, uploaded_by=user_id, original_name=safe, file_format=fmt, size_bytes=len(data),
                   sha256=hashlib.sha256(data).hexdigest(), storage_key="", status="pending")
    db.add(f)
    db.flush()
    ext = safe.rsplit(".", 1)[-1].lower() if "." in safe else fmt
    f.storage_key = f"orgs/{org.id}/files/{f.id}/original.{ext}"
    get_storage().put_bytes(f.storage_key, data)
    db.commit()
    return f


def inspect_file(db: Session, f: FileObject, wb: RawWorkbook | None = None) -> list[Sheet]:
    s = get_settings()
    try:
        if wb is None:
            data = get_storage().get_bytes(f.storage_key)
            wb = read_file(f.original_name, data, max_rows=s.MAX_ROWS, max_cols=s.MAX_COLUMNS, max_uncompressed_mb=s.MAX_XLSX_UNCOMPRESSED_MB)
        result = inspect_workbook(wb)
    except IngestionError as e:
        f.status, f.error = "failed", str(e)
        db.commit()
        raise
    for old in list(f.sheets):
        db.delete(old)
    sheets = []
    for i, t in enumerate(result.tables):
        summ = table_summary(t)
        sh = Sheet(file_id=f.id, org_id=f.org_id, sheet_name=t.sheet_name, table_index=t.table_index, position=i, label=t.label,
                   header_row=t.header_row, first_row=t.first_row, last_row=t.last_row, row_count=len(t.rows), col_count=len(t.columns),
                   columns=[{"name": n, "original": o, "format_hint": h} for n, o, h in zip(t.columns, t.original_columns, t.format_hints)],
                   preview=summ["preview"], status="ok", message="; ".join(t.notes) or None, header_confidence=t.header_confidence)
        db.add(sh)
        db.flush()
        raw, _, _ = table_to_raw(t)
        sh.raw_key = f"orgs/{f.org_id}/files/{f.id}/tables/{sh.id}.parquet"
        _write_parquet(sh.raw_key, raw)
        sheets.append(sh)
    f.workbook = {"format": result.file_format, "sheets": result.sheet_summaries, "warnings": result.warnings,
                  "tables": [{"sheet_id": sh.id, "label": sh.label, "rows": sh.row_count, "cols": sh.col_count,
                              "excluded_rows": t.excluded_rows[:20], "title": t.title} for sh, t in zip(sheets, result.tables)]}
    f.status = "parsed"
    db.commit()
    return sheets


def default_selection(sheets: list[Sheet]) -> list[Sheet]:
    """Pick tables to analyse automatically: the single table, or the largest when it dominates."""
    usable = [s for s in sheets if s.row_count > 0]
    if len(usable) == 1:
        return usable
    if not usable:
        return []
    usable.sort(key=lambda s: -s.row_count * max(s.col_count, 1))
    return []  # multiple tables: let the user choose (UI pre-selects the largest)


# --------------------------------------------------------------------------- versions
def _version_prefix(org_id: str, dataset_id: str, n: int) -> str:
    return f"orgs/{org_id}/datasets/{dataset_id}/v{n}"


def create_version(db: Session, dataset: Dataset, raw: pd.DataFrame, *, kind: str, user_id: str | None,
                   hints: dict[str, str | None] | None = None, originals: dict[str, str] | None = None,
                   overrides: dict[str, dict[str, Any]] | None = None, file_id: str | None = None, sheet_id: str | None = None,
                   parent_version_id: str | None = None, transforms: list[dict[str, Any]] | None = None, note: str = "") -> DatasetVersion:
    s = get_settings()
    if raw.shape[1] == 0:
        raise IngestionError("The table has no columns.")
    n = (db.scalar(select(func.max(DatasetVersion.version_number)).where(DatasetVersion.dataset_id == dataset.id)) or 0) + 1
    prof = profile_dataframe(raw, format_hints=hints, overrides=overrides, original_names=originals, dayfirst_default=s.DATE_DAYFIRST)
    prefix = _version_prefix(dataset.org_id, dataset.id, n)
    v = DatasetVersion(dataset_id=dataset.id, org_id=dataset.org_id, version_number=n, kind=kind, file_id=file_id, sheet_id=sheet_id,
                       parent_version_id=parent_version_id, transforms=transforms or [], raw_key=f"{prefix}/raw.parquet",
                       data_key=f"{prefix}/data.parquet", row_count=len(raw), col_count=raw.shape[1], overrides=overrides or {},
                       status="ready", note=note, created_by=user_id)
    prof.schema["format_hints"] = {k: v2 for k, v2 in (hints or {}).items() if v2}
    v.schema_json = prof.schema
    v.quality = prof.quality
    _write_parquet(v.raw_key, raw)
    _write_parquet(v.data_key, prof.typed)
    db.add(v)
    db.flush()
    for p in prof.columns:
        db.add(ColumnMeta(version_id=v.id, org_id=dataset.org_id, position=p.position, name=p.name, original_name=p.original_name,
                          data_type=p.data_type, role=p.role, confidence=p.confidence, semantic_tags=p.semantic_tags, stats=p.stats,
                          label=p.label, description=p.description, user_override=p.user_override))
    dataset.current_version_id = v.id
    dataset.updated_at = utcnow()
    return v


def reprofile_version(db: Session, v: DatasetVersion, overrides: dict[str, dict[str, Any]]) -> DatasetVersion:
    """Apply manual schema corrections to an existing version (re-type from its immutable raw data)."""
    raw = raw_to_object(read_parquet(v.raw_key))
    unknown = [c for c in overrides if c not in raw.columns]
    if unknown:
        raise DatasetError(f"Unknown column(s): {', '.join(unknown)}")
    hints = (v.schema_json or {}).get("format_hints") or {}
    originals = {c["name"]: c.get("original_name", c["name"]) for c in (v.schema_json or {}).get("columns", [])}
    prof = profile_dataframe(raw, format_hints=hints, overrides=overrides, original_names=originals, dayfirst_default=get_settings().DATE_DAYFIRST)
    prof.schema["format_hints"] = hints
    _write_parquet(v.data_key, prof.typed)
    v.schema_json = prof.schema
    v.quality = prof.quality
    v.overrides = overrides
    for c in list(v.columns):
        db.delete(c)
    db.flush()
    for p in prof.columns:
        db.add(ColumnMeta(version_id=v.id, org_id=v.org_id, position=p.position, name=p.name, original_name=p.original_name,
                          data_type=p.data_type, role=p.role, confidence=p.confidence, semantic_tags=p.semantic_tags, stats=p.stats,
                          label=p.label, description=p.description, user_override=p.user_override))
    v.transforms = list(v.transforms or []) + [{"op": "schema_override", "params": overrides, "description": "Manual schema correction",
                                                 "at": datetime.now(timezone.utc).isoformat(timespec="seconds")}]
    return v


def current_version(db: Session, dataset: Dataset) -> DatasetVersion:
    if not dataset.current_version_id:
        raise DatasetError("This dataset has no processed version yet.")
    v = db.get(DatasetVersion, dataset.current_version_id)
    if v is None or v.org_id != dataset.org_id:
        raise DatasetError("Dataset version not found.")
    return v


def data_source(v: DatasetVersion) -> DataSource:
    return DataSource(get_storage().local_path(v.data_key), v.schema_json)


def dataset_name_from(file_name: str, sheet: Sheet | None, multiple: bool) -> str:
    base = file_name.rsplit(".", 1)[0][:80]
    if sheet and multiple:
        return f"{base} – {sheet.label}"[:200]
    return base or "Dataset"


def create_dataset_from_sheets(db: Session, *, org_id: str, user_id: str | None, sheet_ids: list[str], name: str | None = None,
                               workspace_id: str | None = None, dataset_id: str | None = None, combine: bool = False,
                               auto_dashboard: bool = True) -> dict[str, Any]:
    from misgenius.services.dashboards import create_auto_dashboard

    sheets = [db.get(Sheet, sid) for sid in sheet_ids]
    if not sheets or any(s is None or s.org_id != org_id for s in sheets):
        raise DatasetError("Sheet not found.")
    f = db.get(FileObject, sheets[0].file_id)
    created: list[dict[str, Any]] = []
    groups: list[list[Sheet]] = [sheets] if (combine and len(sheets) > 1) else [[s] for s in sheets]
    for grp in groups:
        if len(grp) > 1:
            raw, hints, originals = combine_raw(grp)
            nm = name or f"{f.original_name.rsplit('.', 1)[0]} – combined ({len(grp)} sheets)"
            kind, sheet_id = "combined", None
        else:
            sh = grp[0]
            raw = raw_to_object(read_parquet(sh.raw_key))
            hints = {c["name"]: c.get("format_hint") for c in sh.columns}
            originals = {c["name"]: c.get("original", c["name"]) for c in sh.columns}
            nm = name if (name and len(groups) == 1) else dataset_name_from(f.original_name, sh, len(groups) > 1 or len(f.sheets) > 1)
            kind, sheet_id = "upload", sh.id
        if dataset_id:
            ds = db.get(Dataset, dataset_id)
            if ds is None or ds.org_id != org_id:
                raise DatasetError("Dataset not found.")
            prev = ds.current_version_id
            v = create_version(db, ds, raw, kind="upload", user_id=user_id, hints=hints, originals=originals, file_id=f.id,
                               sheet_id=sheet_id, parent_version_id=prev, note=f"New upload: {f.original_name}")
            db.commit()
            created.append({"dataset_id": ds.id, "version_id": v.id, "dashboard_id": None, "new_version": True})
            continue
        ds = Dataset(org_id=org_id, workspace_id=workspace_id, name=nm[:255], source_type="combined" if kind == "combined" else "upload",
                     source_config={"file_id": f.id, "sheet_ids": [s.id for s in grp]}, created_by=user_id)
        db.add(ds)
        db.flush()
        v = create_version(db, ds, raw, kind=kind, user_id=user_id, hints=hints, originals=originals, file_id=f.id, sheet_id=sheet_id,
                           note=f"Uploaded {f.original_name}")
        dash_id = None
        if auto_dashboard:
            dash = create_auto_dashboard(db, ds, v, user_id)
            dash_id = dash.id
        db.commit()
        created.append({"dataset_id": ds.id, "version_id": v.id, "dashboard_id": dash_id, "new_version": False})
    return {"created": created}


def combine_raw(sheets: list[Sheet]) -> tuple[pd.DataFrame, dict[str, Any], dict[str, str]]:
    """Union structurally compatible tables (matching column names, case-insensitive)."""
    frames = []
    hints: dict[str, Any] = {}
    originals: dict[str, str] = {}
    canon: dict[str, str] = {}
    for sh in sheets:
        raw = raw_to_object(read_parquet(sh.raw_key))
        ren = {}
        for c in raw.columns:
            key = re.sub(r"\s+", " ", c.strip().lower())
            canon.setdefault(key, c)
            ren[c] = canon[key]
        raw = raw.rename(columns=ren)
        raw.insert(0, "Source Sheet", sh.label)
        frames.append(raw)
        for c in sh.columns:
            hints.setdefault(ren.get(c["name"], c["name"]), c.get("format_hint"))
            originals.setdefault(ren.get(c["name"], c["name"]), c.get("original", c["name"]))
    cmp = compare_tables([f.columns.tolist()[1:] for f in frames])
    if cmp["overlap_pct"] < 60:
        raise DatasetError(f"These sheets are not structurally compatible (only {cmp['overlap_pct']}% of columns match), so they were not combined.")
    df = pd.concat(frames, ignore_index=True, sort=False).astype(object)
    df = df.where(pd.notna(df), None)
    return df, hints, originals


def compare_tables(col_lists: list[list[str]]) -> dict[str, Any]:
    norm = [{re.sub(r"\s+", " ", c.strip().lower()) for c in cols} for cols in col_lists]
    common = set.intersection(*norm) if norm else set()
    union = set.union(*norm) if norm else set()
    return {"common_columns": sorted(common), "all_columns": sorted(union),
            "overlap_pct": round(len(common) / max(len(union), 1) * 100, 1),
            "compatible": bool(union) and len(common) / max(len(union), 1) >= 0.6}


def compare_sheets(db: Session, org_id: str, sheet_ids: list[str]) -> dict[str, Any]:
    sheets = [db.get(Sheet, s) for s in sheet_ids]
    if any(s is None or s.org_id != org_id for s in sheets):
        raise DatasetError("Sheet not found.")
    cmp = compare_tables([[c["name"] for c in s.columns] for s in sheets])
    # shared key columns → possible relationships
    keys = []
    for i in range(len(sheets)):
        for j in range(i + 1, len(sheets)):
            a = raw_to_object(read_parquet(sheets[i].raw_key))
            b = raw_to_object(read_parquet(sheets[j].raw_key))
            for c in set(a.columns) & set(b.columns):
                va = set(a[c].dropna().astype(str).str.strip())
                vb = set(b[c].dropna().astype(str).str.strip())
                if len(va) >= 2 and len(vb) >= 2:
                    ov = len(va & vb) / max(1, min(len(va), len(vb)))
                    if ov >= 0.5 and (len(va) >= 0.9 * a[c].notna().sum() or len(vb) >= 0.9 * b[c].notna().sum()):
                        keys.append({"left": sheets[i].label, "right": sheets[j].label, "column": c, "value_overlap_pct": round(ov * 100, 1)})
    return {**cmp, "sheets": [{"id": s.id, "label": s.label, "rows": s.row_count, "cols": s.col_count} for s in sheets],
            "possible_relationships": keys}


def join_datasets(db: Session, *, org_id: str, user_id: str | None, left_id: str, right_id: str, left_on: str, right_on: str,
                  how: str = "left", name: str | None = None) -> dict[str, Any]:
    from misgenius.services.dashboards import create_auto_dashboard

    if how not in ("left", "inner"):
        raise DatasetError("Join type must be left or inner")
    L = db.get(Dataset, left_id)
    R = db.get(Dataset, right_id)
    if not L or not R or L.org_id != org_id or R.org_id != org_id:
        raise DatasetError("Dataset not found.")
    lv, rv = current_version(db, L), current_version(db, R)
    a = raw_to_object(read_parquet(lv.raw_key))
    b = raw_to_object(read_parquet(rv.raw_key))
    if left_on not in a.columns or right_on not in b.columns:
        raise DatasetError("Join column not found.")
    b_unique = b.drop_duplicates(subset=[right_on])
    dup_keys = len(b) - len(b_unique)
    b_unique = b_unique.rename(columns={c: (c if c == right_on or c not in a.columns else f"{c} ({R.name[:20]})") for c in b_unique.columns})
    ak = a[left_on].map(lambda x: str(x).strip() if x is not None else None)
    bk = b_unique[right_on].map(lambda x: str(x).strip() if x is not None else None)
    merged = a.assign(__k=ak).merge(b_unique.assign(__k=bk).drop(columns=[right_on] if right_on != left_on else [right_on]),
                                    on="__k", how=how).drop(columns="__k")
    merged = merged.astype(object).where(pd.notna(merged), None)
    matched = int(ak.isin(set(bk.dropna())).sum())
    ds = Dataset(org_id=org_id, name=(name or f"{L.name} + {R.name}")[:255], source_type="joined", created_by=user_id,
                 source_config={"left": left_id, "right": right_id, "left_on": left_on, "right_on": right_on, "how": how})
    db.add(ds)
    db.flush()
    v = create_version(db, ds, merged, kind="joined", user_id=user_id,
                       note=f"{how} join on {left_on} = {right_on}; {matched:,} of {len(a):,} rows matched"
                            + (f"; {dup_keys:,} duplicate keys on the right side were ignored" if dup_keys else ""))
    dash = create_auto_dashboard(db, ds, v, user_id)
    db.commit()
    return {"dataset_id": ds.id, "version_id": v.id, "dashboard_id": dash.id, "matched_rows": matched, "left_rows": len(a), "duplicate_right_keys": dup_keys}


# --------------------------------------------------------------------------- cleaning
def clean_dataset(db: Session, dataset: Dataset, steps: list[dict[str, Any]], user_id: str | None, preview: bool = False) -> dict[str, Any]:
    from misgenius.services.dashboards import remap_dashboard_columns

    base = current_version(db, dataset)
    raw = raw_to_object(read_parquet(base.raw_key))
    if preview:
        raw = raw.head(2000)
    new_raw, overrides, applied = apply_transforms(raw, steps, base.overrides or {})
    if preview:
        prof = profile_dataframe(new_raw, overrides=overrides, dayfirst_default=get_settings().DATE_DAYFIRST)
        return {"applied": applied, "rows_before": len(raw), "rows_after": len(new_raw), "columns": list(new_raw.columns),
                "sample": new_raw.head(20).astype(object).where(pd.notna(new_raw.head(20)), None).values.tolist(),
                "quality": prof.quality["summary"], "preview_rows": len(raw)}
    hints = (base.schema_json or {}).get("format_hints") or {}
    renames = {s["params"]["column"]: s["params"]["new_name"].strip() for s in steps if s.get("op") == "rename_column"}
    hints = {renames.get(k, k): v for k, v in hints.items()}
    v = create_version(db, dataset, new_raw, kind="cleaned", user_id=user_id, hints=hints, overrides=overrides,
                       parent_version_id=base.id, transforms=applied, file_id=base.file_id, sheet_id=base.sheet_id,
                       note="; ".join(a["description"] for a in applied)[:1000])
    if renames:
        remap_dashboard_columns(db, dataset.id, renames)
    db.commit()
    return {"version_id": v.id, "version_number": v.version_number, "applied": applied, "rows": v.row_count, "quality": v.quality.get("summary")}


def compare_versions(a: DatasetVersion, b: DatasetVersion) -> dict[str, Any]:
    ca = {c["name"]: c for c in (a.schema_json or {}).get("columns", [])}
    cb = {c["name"]: c for c in (b.schema_json or {}).get("columns", [])}
    changed = [{"column": n, "from": ca[n]["data_type"], "to": cb[n]["data_type"]} for n in set(ca) & set(cb) if ca[n]["data_type"] != cb[n]["data_type"]]
    measures = []
    for n in sorted(set(ca) & set(cb)):
        if ca[n]["role"] == "measure" and cb[n]["role"] == "measure":
            sa, sb = ca[n].get("stats", {}).get("sum"), cb[n].get("stats", {}).get("sum")
            if sa is not None and sb is not None:
                measures.append({"column": n, "sum_before": sa, "sum_after": sb, "change": sb - sa,
                                 "change_pct": ((sb - sa) / abs(sa) * 100) if sa else None})
    qa, qb = (a.quality or {}).get("summary", {}), (b.quality or {}).get("summary", {})
    return {
        "from": {"id": a.id, "version": a.version_number, "rows": a.row_count, "created_at": a.created_at.isoformat()},
        "to": {"id": b.id, "version": b.version_number, "rows": b.row_count, "created_at": b.created_at.isoformat()},
        "rows_change": b.row_count - a.row_count,
        "added_columns": sorted(set(cb) - set(ca)), "removed_columns": sorted(set(ca) - set(cb)), "type_changes": changed,
        "measure_totals": measures,
        "quality": {"score_before": qa.get("score"), "score_after": qb.get("score"),
                    "missing_before": qa.get("missing_cells"), "missing_after": qb.get("missing_cells"),
                    "duplicates_before": qa.get("duplicate_rows"), "duplicates_after": qb.get("duplicate_rows")},
    }


# --------------------------------------------------------------------------- connectors / refresh
def create_from_connector(db: Session, *, org_id: str, user_id: str | None, kind: str, config: dict[str, Any], name: str,
                          refresh_minutes: int | None, workspace_id: str | None = None) -> dict[str, Any]:
    from misgenius.auth.security import encrypt_secret
    from misgenius.connectors.base import get_connector
    from misgenius.services.dashboards import create_auto_dashboard

    conn = get_connector(kind)
    src, wb = conn.fetch(config)
    res = inspect_workbook(wb)
    t = max(res.tables, key=lambda x: len(x.rows))
    raw, hints, originals = table_to_raw(t)
    stored = dict(config)
    if kind == "sql" and stored.get("url"):
        stored["url_encrypted"] = encrypt_secret(stored.pop("url"))
    if stored.get("headers"):
        stored["headers_encrypted"] = encrypt_secret(__import__("json").dumps(stored.pop("headers")))
    ds = Dataset(org_id=org_id, workspace_id=workspace_id, name=name[:255] or src, source_type=kind, source_config=stored,
                 created_by=user_id, refresh_minutes=refresh_minutes, last_refreshed_at=utcnow())
    db.add(ds)
    db.flush()
    v = create_version(db, ds, raw, kind="refresh", user_id=user_id, hints=hints, originals=originals, note=f"Imported from {conn.label}")
    dash = create_auto_dashboard(db, ds, v, user_id)
    db.commit()
    return {"dataset_id": ds.id, "version_id": v.id, "dashboard_id": dash.id}


def connector_config(ds: Dataset) -> dict[str, Any]:
    import json as _json

    from misgenius.auth.security import decrypt_secret

    cfg = dict(ds.source_config or {})
    if cfg.get("url_encrypted"):
        cfg["url"] = decrypt_secret(cfg.pop("url_encrypted"))
    if cfg.get("headers_encrypted"):
        cfg["headers"] = _json.loads(decrypt_secret(cfg.pop("headers_encrypted")) or "{}")
    return cfg


def refresh_dataset(db: Session, ds: Dataset, user_id: str | None) -> dict[str, Any]:
    from misgenius.connectors.base import get_connector
    from misgenius.notifications.service import evaluate_alerts, notify

    if ds.source_type not in ("http", "google_sheets", "sql"):
        raise DatasetError("Only connector-based datasets can be refreshed automatically. Upload a new file to create a new version.")
    conn = get_connector(ds.source_type)
    _, wb = conn.fetch(connector_config(ds))
    res = inspect_workbook(wb)
    t = max(res.tables, key=lambda x: len(x.rows))
    raw, hints, originals = table_to_raw(t)
    prev = current_version(db, ds)
    v = create_version(db, ds, raw, kind="refresh", user_id=user_id, hints=hints, originals=originals, overrides=prev.overrides,
                       parent_version_id=prev.id, note="Scheduled refresh" if user_id is None else "Manual refresh")
    ds.last_refreshed_at = utcnow()
    db.flush()
    fired = evaluate_alerts(db, ds.id, data_source(v))
    notify(db, ds.org_id, kind="refresh_done", title=f"Dataset refreshed: {ds.name}", body=f"{v.row_count:,} rows (version {v.version_number}).",
           link=f"/datasets/{ds.id}")
    db.commit()
    return {"dataset_id": ds.id, "version_id": v.id, "rows": v.row_count, "alerts_fired": len(fired)}


# --------------------------------------------------------------------------- demo
def create_demo_dataset(db: Session, org_id: str, user_id: str | None, which: str = "sales") -> dict[str, Any]:
    from misgenius.demo.demo_data import DEMO_NOTICE, demo_attendance, demo_sales
    from misgenius.services.dashboards import create_auto_dashboard

    df = demo_sales() if which == "sales" else demo_attendance()
    raw = pd.DataFrame({c: pd.Series([None if pd.isna(v) else (v.isoformat() if hasattr(v, "isoformat") else (str(int(v)) if isinstance(v, float) and v.is_integer() else str(v)))
                                      for v in df[c].tolist()], dtype=object) for c in df.columns})
    name = "DEMO – Sales (sample data)" if which == "sales" else "DEMO – Attendance (sample data)"
    ds = Dataset(org_id=org_id, name=name, description=DEMO_NOTICE, source_type="demo", is_demo=True, created_by=user_id)
    db.add(ds)
    db.flush()
    v = create_version(db, ds, raw, kind="demo", user_id=user_id, note=DEMO_NOTICE)
    dash = create_auto_dashboard(db, ds, v, user_id)
    db.commit()
    return {"dataset_id": ds.id, "version_id": v.id, "dashboard_id": dash.id}


def purge_dataset(db: Session, ds: Dataset) -> None:
    get_storage().delete_prefix(f"orgs/{ds.org_id}/datasets/{ds.id}")
    for d in db.scalars(select(Dashboard).where(Dashboard.dataset_id == ds.id)):
        db.delete(d)
    db.delete(ds)
