"""Backup / restore.

* Organisation export (API, admin): a ZIP with dashboards, templates, reports, dataset
  metadata and — optionally — every dataset's raw data, importable into any
  MIS Genius AI install (local → cloud migration, or cloud → local).
* Full local backup (CLI `scripts/backup.py`): SQLite database (online backup API)
  plus the storage folder. PostgreSQL deployments use pg_dump (see DEPLOYMENT.md).
Nothing is deleted by an import; imported items get new IDs.
"""
from __future__ import annotations

import io
import json
import sqlite3
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

import pandas as pd
from sqlalchemy import select
from sqlalchemy.orm import Session

from misgenius.config import get_settings
from misgenius.db.models import Dashboard, DashboardTemplate, Dataset, Report
from misgenius.services import datasets as dsvc
from misgenius.services.dashboards import create_dashboard_from_spec, dashboard_spec

FORMAT = "mis-genius-backup/v1"


def export_org(db: Session, org_id: str, include_data: bool = True) -> bytes:
    buf = io.BytesIO()
    manifest: dict[str, Any] = {"format": FORMAT, "created_at": datetime.now(timezone.utc).isoformat(), "datasets": [], "dashboards": [],
                                "templates": [], "reports": []}
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        for ds in db.scalars(select(Dataset).where(Dataset.org_id == org_id, Dataset.deleted_at.is_(None))):
            entry = {"id": ds.id, "name": ds.name, "description": ds.description, "source_type": ds.source_type, "is_demo": ds.is_demo}
            if ds.current_version_id:
                v = dsvc.current_version(db, ds)
                entry.update({"overrides": v.overrides, "format_hints": (v.schema_json or {}).get("format_hints", {}), "rows": v.row_count})
                if include_data:
                    raw = dsvc.read_parquet(v.raw_key)
                    b = io.BytesIO()
                    raw.to_parquet(b, index=False)
                    z.writestr(f"datasets/{ds.id}.parquet", b.getvalue())
                    entry["data_file"] = f"datasets/{ds.id}.parquet"
            manifest["datasets"].append(entry)
        for d in db.scalars(select(Dashboard).where(Dashboard.org_id == org_id)):
            manifest["dashboards"].append({"id": d.id, "dataset_id": d.dataset_id, "spec": dashboard_spec(d)})
        for t in db.scalars(select(DashboardTemplate).where(DashboardTemplate.org_id == org_id)):
            manifest["templates"].append({"name": t.name, "description": t.description, "spec": t.spec})
        for r in db.scalars(select(Report).where(Report.org_id == org_id)):
            manifest["reports"].append({"title": r.title, "dataset_id": r.dataset_id, "language": r.language, "content": r.content,
                                        "created_at": r.created_at.isoformat()})
        z.writestr("manifest.json", json.dumps(manifest, ensure_ascii=False, default=str, indent=1))
    return buf.getvalue()


def import_org(db: Session, org_id: str, user_id: str | None, data: bytes) -> dict[str, Any]:
    try:
        z = zipfile.ZipFile(io.BytesIO(data))
        manifest = json.loads(z.read("manifest.json"))
    except (zipfile.BadZipFile, KeyError, json.JSONDecodeError) as e:
        raise dsvc.DatasetError("This is not a valid MIS Genius AI backup file.") from e
    if manifest.get("format") != FORMAT:
        raise dsvc.DatasetError("Unsupported backup format.")
    total_size = sum(i.file_size for i in z.infolist())
    if total_size > 4 * 1024 ** 3:
        raise dsvc.DatasetError("Backup is too large to import through the browser. Use the command-line restore.")
    id_map: dict[str, str] = {}
    counts = {"datasets": 0, "dashboards": 0, "templates": 0, "reports": 0}
    for e in manifest.get("datasets", []):
        if not e.get("data_file") or e["data_file"] not in z.namelist():
            continue
        raw = dsvc.raw_to_object(pd.read_parquet(io.BytesIO(z.read(e["data_file"]))))
        ds = Dataset(org_id=org_id, name=f"{e['name']} (restored)"[:255], description=e.get("description", ""), source_type="upload",
                     is_demo=bool(e.get("is_demo")), created_by=user_id)
        db.add(ds)
        db.flush()
        dsvc.create_version(db, ds, raw, kind="upload", user_id=user_id, hints=e.get("format_hints"), overrides=e.get("overrides") or {},
                            note="Restored from backup")
        id_map[e["id"]] = ds.id
        counts["datasets"] += 1
    for d in manifest.get("dashboards", []):
        new_ds = id_map.get(d.get("dataset_id"))
        if d.get("dataset_id") and not new_ds:
            continue
        create_dashboard_from_spec(db, org_id=org_id, dataset_id=new_ds, spec=d["spec"], user_id=user_id)
        counts["dashboards"] += 1
    for t in manifest.get("templates", []):
        db.add(DashboardTemplate(org_id=org_id, name=t["name"], description=t.get("description", ""), source="imported", spec=t["spec"], created_by=user_id))
        counts["templates"] += 1
    for r in manifest.get("reports", []):
        db.add(Report(org_id=org_id, dataset_id=id_map.get(r.get("dataset_id")), title=r["title"], language=r.get("language", "en"),
                      content=r.get("content", {}), created_by=user_id))
        counts["reports"] += 1
    db.commit()
    return counts


def full_local_backup(dest_dir: Path) -> Path:
    """Consistent copy of the SQLite database + storage folder (local / LAN installs)."""
    s = get_settings()
    url = s.database_url
    if not url.startswith("sqlite"):
        raise RuntimeError("Full backup here supports SQLite installs. For PostgreSQL use pg_dump (see docs/DEPLOYMENT.md).")
    db_path = Path(url.split("sqlite:///", 1)[1])
    dest_dir.mkdir(parents=True, exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    out = dest_dir / f"mis-genius-backup-{stamp}.zip"
    tmp_db = dest_dir / f".db-{stamp}.sqlite"
    src = sqlite3.connect(db_path)
    dst = sqlite3.connect(tmp_db)
    with dst:
        src.backup(dst)
    src.close()
    dst.close()
    storage = s.DATA_DIR / "storage"
    with zipfile.ZipFile(out, "w", zipfile.ZIP_DEFLATED) as z:
        z.write(tmp_db, "misgenius.db")
        if storage.exists():
            for f in storage.rglob("*"):
                if f.is_file():
                    z.write(f, "storage/" + f.relative_to(storage).as_posix())
        z.writestr("backup.json", json.dumps({"format": "mis-genius-full/v1", "created_at": stamp, "version": s.APP_VERSION}))
    tmp_db.unlink(missing_ok=True)
    return out


def full_local_restore(zip_path: Path, force: bool = False) -> None:
    s = get_settings()
    db_path = Path(s.database_url.split("sqlite:///", 1)[1])
    storage = s.DATA_DIR / "storage"
    if (db_path.exists() or storage.exists()) and not force:
        raise RuntimeError("Existing data found. Re-run with --force to replace it (a safety copy is kept as *.before-restore).")
    stamp = datetime.now().strftime("%Y%m%d-%H%M%S")
    if db_path.exists():
        db_path.rename(db_path.with_suffix(f".before-restore-{stamp}"))
    if storage.exists():
        storage.rename(storage.with_name(f"storage.before-restore-{stamp}"))
    with zipfile.ZipFile(zip_path) as z:
        for name in z.namelist():
            if name.startswith("/") or ".." in Path(name).parts:
                raise RuntimeError("Unsafe path in backup")
        db_path.parent.mkdir(parents=True, exist_ok=True)
        db_path.write_bytes(z.read("misgenius.db"))
        for name in z.namelist():
            if name.startswith("storage/") and not name.endswith("/"):
                target = storage / name[len("storage/"):]
                target.parent.mkdir(parents=True, exist_ok=True)
                target.write_bytes(z.read(name))
