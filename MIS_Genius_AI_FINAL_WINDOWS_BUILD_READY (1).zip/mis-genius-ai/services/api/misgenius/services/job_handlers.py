"""Job handlers (registered with the runner)."""
from __future__ import annotations

from typing import Any

from sqlalchemy.orm import Session

from misgenius.db.models import Dataset, FileObject, Job
from misgenius.jobs.runner import JobError, handler, set_progress
from misgenius.notifications.service import notify
from misgenius.services import datasets as dsvc
from misgenius.services.audit import audit


def _sheet_info(sheets) -> list[dict[str, Any]]:
    return [{"id": s.id, "label": s.label, "sheet_name": s.sheet_name, "rows": s.row_count, "cols": s.col_count,
             "header_row": s.header_row, "header_confidence": s.header_confidence, "columns": [c["name"] for c in s.columns],
             "preview": s.preview, "notes": s.message} for s in sheets]


@handler("ingest_file")
def ingest_file(db: Session, job: Job) -> dict[str, Any]:
    p = job.payload
    f = db.get(FileObject, p["file_id"])
    if f is None or f.org_id != job.org_id:
        raise JobError("File not found")
    set_progress(db, job, 0.1)
    sheets = dsvc.inspect_file(db, f)
    set_progress(db, job, 0.5)
    info = _sheet_info(sheets)
    usable = [s for s in sheets if s.row_count > 0]
    result: dict[str, Any] = {"file_id": f.id, "file_name": f.original_name, "sheets": info, "warnings": (f.workbook or {}).get("warnings", []),
                              "sheet_summaries": (f.workbook or {}).get("sheets", [])}
    if p.get("auto_create", True) and len(usable) == 1:
        res = dsvc.create_dataset_from_sheets(db, org_id=f.org_id, user_id=job.created_by, sheet_ids=[usable[0].id], name=p.get("name"),
                                              workspace_id=p.get("workspace_id"), dataset_id=p.get("dataset_id"))
        result.update({"status": "created", **res})
        c = res["created"][0]
        audit(db, "dataset.create" if not c["new_version"] else "dataset.new_version", org_id=f.org_id, user_id=job.created_by,
              entity_type="dataset", entity_id=c["dataset_id"], details={"file": f.original_name, "rows": usable[0].row_count})
        notify(db, f.org_id, user_id=job.created_by, kind="dataset_ready", title=f"Dataset ready: {f.original_name}",
               body=f"{usable[0].row_count:,} rows analysed.", link=f"/datasets/{c['dataset_id']}")
        db.commit()
    else:
        result["status"] = "needs_selection"
    return result


@handler("create_dataset")
def create_dataset(db: Session, job: Job) -> dict[str, Any]:
    p = job.payload
    res = dsvc.create_dataset_from_sheets(db, org_id=job.org_id, user_id=job.created_by, sheet_ids=p["sheet_ids"], name=p.get("name"),
                                          workspace_id=p.get("workspace_id"), dataset_id=p.get("dataset_id"), combine=bool(p.get("combine")))
    for c in res["created"]:
        audit(db, "dataset.create", org_id=job.org_id, user_id=job.created_by, entity_type="dataset", entity_id=c["dataset_id"],
              details={"sheets": p["sheet_ids"], "combine": bool(p.get("combine"))})
        notify(db, job.org_id, user_id=job.created_by, kind="dataset_ready", title="Dataset ready", link=f"/datasets/{c['dataset_id']}")
    db.commit()
    return {"status": "created", **res}


@handler("clean_dataset")
def clean_dataset(db: Session, job: Job) -> dict[str, Any]:
    ds = db.get(Dataset, job.payload["dataset_id"])
    if ds is None or ds.org_id != job.org_id:
        raise JobError("Dataset not found")
    res = dsvc.clean_dataset(db, ds, job.payload["steps"], job.created_by)
    audit(db, "dataset.clean", org_id=ds.org_id, user_id=job.created_by, entity_type="dataset", entity_id=ds.id,
          details={"steps": [s.get("op") for s in job.payload["steps"]], "version": res["version_number"]}, commit=True)
    return res


@handler("refresh_dataset")
def refresh(db: Session, job: Job) -> dict[str, Any]:
    ds = db.get(Dataset, job.payload["dataset_id"])
    if ds is None or ds.org_id != job.org_id:
        raise JobError("Dataset not found")
    res = dsvc.refresh_dataset(db, ds, job.created_by)
    audit(db, "dataset.refresh", org_id=ds.org_id, user_id=job.created_by, entity_type="dataset", entity_id=ds.id, commit=True)
    return res


@handler("connector_import")
def connector_import(db: Session, job: Job) -> dict[str, Any]:
    p = job.payload
    from misgenius.auth.security import decrypt_secret

    cfg = dict(p["config"])
    if cfg.get("_encrypted"):
        import json

        cfg = json.loads(decrypt_secret(cfg["_encrypted"]) or "{}")
    res = dsvc.create_from_connector(db, org_id=job.org_id, user_id=job.created_by, kind=p["type"], config=cfg, name=p.get("name") or "Imported data",
                                     refresh_minutes=p.get("refresh_minutes"), workspace_id=p.get("workspace_id"))
    audit(db, "dataset.import", org_id=job.org_id, user_id=job.created_by, entity_type="dataset", entity_id=res["dataset_id"],
          details={"type": p["type"]}, commit=True)
    return {"status": "created", **res}
