"""Audit log + usage metering."""
from __future__ import annotations

import logging
from typing import Any

from sqlalchemy.orm import Session

from misgenius.db.models import AuditLog, UsageRecord

audit_log = logging.getLogger("misgenius.audit")


def audit(db: Session, action: str, *, org_id: str | None, user_id: str | None, entity_type: str | None = None,
          entity_id: str | None = None, details: dict[str, Any] | None = None, ip: str | None = None, commit: bool = False) -> None:
    safe = {k: v for k, v in (details or {}).items() if not any(s in k.lower() for s in ("password", "api_key", "secret", "token"))}
    db.add(AuditLog(org_id=org_id, user_id=user_id, action=action, entity_type=entity_type, entity_id=entity_id, details=safe, ip=ip))
    audit_log.info(action, extra={"action": action, "org_id": org_id, "user_id": user_id})
    if commit:
        db.commit()


def record_usage(db: Session, org_id: str, metric: str, quantity: float = 1) -> None:
    db.add(UsageRecord(org_id=org_id, metric=metric, quantity=quantity))
