"""Dashboard persistence helpers and data rendering for all widgets."""
from __future__ import annotations

import copy
import logging
from typing import Any

from sqlalchemy import select
from sqlalchemy.orm import Session

from misgenius.analytics.charts import ChartSpec, build_chart
from misgenius.analytics.kpi import KPISpec, compute_kpi
from misgenius.analytics.query import DataSource, Filter, QueryError
from misgenius.dashboard.generator import generate_dashboard
from misgenius.dashboard.templates import _walk_columns
from misgenius.db.models import Dashboard, DashboardWidget, Dataset, DatasetVersion

log = logging.getLogger("misgenius.dashboards")


def create_dashboard_from_spec(db: Session, *, org_id: str, dataset_id: str | None, spec: dict[str, Any], user_id: str | None,
                               auto_generated: bool = False, workspace_id: str | None = None) -> Dashboard:
    d = Dashboard(org_id=org_id, dataset_id=dataset_id, workspace_id=workspace_id, name=spec.get("name", "Dashboard")[:255],
                  description=spec.get("description", ""), config=spec.get("config", {}), auto_generated=auto_generated, created_by=user_id)
    db.add(d)
    db.flush()
    for i, w in enumerate(spec.get("widgets", [])):
        db.add(DashboardWidget(dashboard_id=d.id, org_id=org_id, widget_type=w["widget_type"], title=w.get("title", "")[:255],
                               config=w.get("config", {}), layout=w.get("layout", {"x": 0, "y": i * 5, "w": 6, "h": 5}),
                               position=w.get("position", i), hidden=bool(w.get("hidden", False))))
    db.flush()
    return d


def create_auto_dashboard(db: Session, ds: Dataset, v: DatasetVersion, user_id: str | None) -> Dashboard:
    spec = generate_dashboard(v.schema_json, ds.name)
    return create_dashboard_from_spec(db, org_id=ds.org_id, dataset_id=ds.id, spec=spec, user_id=user_id, auto_generated=True,
                                      workspace_id=ds.workspace_id)


def dashboard_spec(d: Dashboard) -> dict[str, Any]:
    return {
        "name": d.name, "description": d.description, "config": copy.deepcopy(d.config or {}),
        "widgets": [{"widget_type": w.widget_type, "title": w.title, "config": copy.deepcopy(w.config or {}), "layout": dict(w.layout or {}),
                     "position": w.position, "hidden": w.hidden} for w in d.widgets],
    }


def replace_widgets(db: Session, d: Dashboard, spec: dict[str, Any]) -> None:
    for w in list(d.widgets):
        db.delete(w)
    db.flush()
    for i, w in enumerate(spec.get("widgets", [])):
        db.add(DashboardWidget(dashboard_id=d.id, org_id=d.org_id, widget_type=w["widget_type"], title=w.get("title", "")[:255],
                               config=w.get("config", {}), layout=w.get("layout", {}), position=i, hidden=bool(w.get("hidden", False))))
    db.flush()
    db.refresh(d)


def remap_dashboard_columns(db: Session, dataset_id: str, renames: dict[str, str]) -> None:
    """Keep dashboards working after a column is renamed by a cleaning step."""
    fn = lambda n: renames.get(n, n)  # noqa: E731
    for d in db.scalars(select(Dashboard).where(Dashboard.dataset_id == dataset_id)):
        d.config = _walk_columns(d.config or {}, fn)
        for w in d.widgets:
            w.config = _walk_columns(w.config or {}, fn)


def render_widget(ds: DataSource, widget_type: str, config: dict[str, Any], filters: list[Filter]) -> dict[str, Any]:
    try:
        if widget_type == "kpi":
            return {"kpi": compute_kpi(ds, KPISpec(**config["kpi"]), filters)}
        if widget_type in ("chart", "table", "pivot") and "chart" in config:
            return {"chart": build_chart(ds, ChartSpec(**config["chart"]), filters)}
        return {}
    except QueryError as e:
        return {"error": str(e)}
    except (KeyError, TypeError, ValueError) as e:
        log.warning("widget config invalid: %s", e)
        return {"error": f"This widget's configuration is invalid ({type(e).__name__}). Edit or remove it."}


def render_dashboard(ds: DataSource, d: Dashboard, filters: list[Filter], widget_ids: list[str] | None = None) -> dict[str, Any]:
    out: dict[str, Any] = {}
    for w in d.widgets:
        if w.hidden or (widget_ids and w.id not in widget_ids):
            continue
        out[w.id] = render_widget(ds, w.widget_type, w.config or {}, filters)
    return out
