"""Global search across datasets, dashboards, reports, templates and columns (tenant-scoped)."""
from __future__ import annotations

from typing import Any

from sqlalchemy import func, or_, select
from sqlalchemy.orm import Session

from misgenius.db.models import ColumnMeta, Dashboard, DashboardTemplate, Dataset, Report


def _like(q: str) -> str:
    return "%" + q.replace("\\", "\\\\").replace("%", "\\%").replace("_", "\\_").lower() + "%"


def search(db: Session, org_id: str, q: str, limit: int = 8) -> dict[str, list[dict[str, Any]]]:
    q = (q or "").strip()[:100]
    if len(q) < 2:
        return {"datasets": [], "dashboards": [], "reports": [], "templates": [], "columns": []}
    pat = _like(q)
    ds = db.scalars(select(Dataset).where(Dataset.org_id == org_id, Dataset.deleted_at.is_(None),
                                          or_(func.lower(Dataset.name).like(pat, escape="\\"), func.lower(Dataset.description).like(pat, escape="\\")))
                    .limit(limit)).all()
    dash = db.scalars(select(Dashboard).where(Dashboard.org_id == org_id, func.lower(Dashboard.name).like(pat, escape="\\")).limit(limit)).all()
    reps = db.scalars(select(Report).where(Report.org_id == org_id, func.lower(Report.title).like(pat, escape="\\")).limit(limit)).all()
    tmpl = db.scalars(select(DashboardTemplate).where(or_(DashboardTemplate.org_id == org_id, DashboardTemplate.org_id.is_(None)),
                                                      func.lower(DashboardTemplate.name).like(pat, escape="\\")).limit(limit)).all()
    current_versions = select(Dataset.current_version_id).where(Dataset.org_id == org_id, Dataset.deleted_at.is_(None))
    cols = db.execute(select(ColumnMeta, Dataset).join(Dataset, Dataset.current_version_id == ColumnMeta.version_id)
                      .where(ColumnMeta.org_id == org_id, ColumnMeta.version_id.in_(current_versions),
                             func.lower(ColumnMeta.name).like(pat, escape="\\")).limit(limit * 2)).all()
    return {
        "datasets": [{"id": d.id, "name": d.name, "is_demo": d.is_demo} for d in ds],
        "dashboards": [{"id": d.id, "name": d.name, "dataset_id": d.dataset_id} for d in dash],
        "reports": [{"id": r.id, "title": r.title, "dataset_id": r.dataset_id} for r in reps],
        "templates": [{"id": t.id, "name": t.name} for t in tmpl],
        "columns": [{"name": c.name, "data_type": c.data_type, "dataset_id": d.id, "dataset": d.name} for c, d in cols],
    }
