"""Shared fixtures: an isolated data directory + SQLite database per test session."""
from __future__ import annotations

import io
import os
import sys
import tempfile
from pathlib import Path

import pytest

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))

_TMP = tempfile.mkdtemp(prefix="misgenius-test-")
os.environ.update({
    "APP_ENV": "testing",
    "MIS_DATA_DIR": _TMP,
    "DATA_DIR": _TMP,
    "JOB_MODE": "inline",
    "SECRET_KEY": "test-secret-key-that-is-long-enough-1234567890",
    "AI_PROVIDER": "none",
    "LOG_JSON": "false",
    "SERVE_WEB": "false",
})
if os.environ.get("TEST_DATABASE_URL"):
    os.environ["DATABASE_URL"] = os.environ["TEST_DATABASE_URL"]
else:
    os.environ.pop("DATABASE_URL", None)


@pytest.fixture(scope="session")
def app():
    from misgenius.api.main import create_app

    return create_app()


@pytest.fixture(scope="session")
def client(app):
    from fastapi.testclient import TestClient

    with TestClient(app) as c:
        yield c


_counter = {"n": 0}


def _register(client, org_name="Acme"):
    _counter["n"] += 1
    email = f"user{_counter['n']}@example.com"
    r = client.post("/api/v1/auth/register", json={"email": email, "password": "Passw0rd!x", "full_name": "Test User", "org_name": org_name})
    assert r.status_code == 200, r.text
    data = r.json()
    return {"email": email, "token": data["access_token"], "refresh": data["refresh_token"], "org_id": data["current_org_id"],
            "headers": {"Authorization": f"Bearer {data['access_token']}", "X-Org-Id": data["current_org_id"]}}


@pytest.fixture
def user(client):
    return _register(client)


@pytest.fixture
def other_user(client):
    return _register(client, "Other Org")


@pytest.fixture(scope="session")
def examples_dir():
    from misgenius.demo.demo_data import write_examples

    d = Path(_TMP) / "examples"
    write_examples(d)
    return d


def xlsx_bytes(sheets: dict) -> bytes:
    import pandas as pd

    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as xw:
        for name, df in sheets.items():
            df.to_excel(xw, sheet_name=name, index=False)
    return buf.getvalue()


def upload(client, headers, name: str, data: bytes, **form):
    files = {"file": (name, data, "application/octet-stream")}
    r = client.post("/api/v1/uploads", files=files, data={k: str(v) for k, v in form.items()}, headers=headers)
    assert r.status_code == 200, r.text
    return r.json()
