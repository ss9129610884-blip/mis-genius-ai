"""Schema detection: types, roles, currency/percent, identifiers, dates, relationships, quality."""
import pandas as pd

from misgenius.schema.profiler import profile_dataframe


def raw(d):
    return pd.DataFrame({k: pd.Series(v, dtype=object) for k, v in d.items()})


def cols(p):
    return {c.name: c for c in p.columns}


def test_type_detection_mixed_business_columns():
    n = 60
    df = raw({
        "Invoice No": [f"INV-{1000 + i}" for i in range(n)],
        "Invoice Date": [f"{(i % 28) + 1:02d}/0{(i % 9) + 1}/2025" for i in range(n)],
        "Department": [["Accounts", "HR", "IT"][i % 3] for i in range(n)],
        "Amount (₹)": [f"₹{(i + 1) * 1000:,}" for i in range(n)],
        "Discount %": [f"{i % 20}%" for i in range(n)],
        "Qty": [str(i % 7 + 1) for i in range(n)],
        "Approved": [["Yes", "No"][i % 2] for i in range(n)],
        "Remarks": [f"Long free text remark number {i} " * 4 for i in range(n)],
        "Empty": [None] * n,
    })
    p = profile_dataframe(df)
    c = cols(p)
    assert c["Invoice No"].data_type == "identifier" and c["Invoice No"].role == "identifier"
    assert c["Invoice Date"].data_type == "date" and c["Invoice Date"].role == "time"
    assert c["Department"].data_type == "categorical" and c["Department"].role == "dimension"
    assert c["Amount (₹)"].data_type == "currency" and c["Amount (₹)"].role == "measure"
    assert c["Discount %"].data_type == "percentage"
    assert c["Qty"].data_type == "integer"
    assert c["Approved"].data_type == "boolean"
    assert c["Remarks"].data_type == "text"
    assert c["Empty"].data_type == "empty" and c["Empty"].role == "ignore"
    s = p.schema
    assert "Amount (₹)" in s["measures"] and "Department" in s["dimensions"]
    assert s["primary_date_column"] == "Invoice Date"
    assert "Amount (₹)" in s["possible_currency_columns"] and "Discount %" in s["possible_percentage_columns"]
    for key in ("columns", "dimensions", "measures", "date_columns", "categorical_columns", "numeric_columns", "text_columns",
                "identifier_columns", "possible_currency_columns", "possible_percentage_columns", "data_quality", "relationships", "confidence"):
        assert key in s


def test_numeric_id_is_not_a_measure_and_year_is_time():
    df = raw({"Emp ID": [str(1000 + i) for i in range(30)], "Year": [str(2020 + i % 5) for i in range(30)], "Salary": [str(20000 + i) for i in range(30)]})
    c = cols(profile_dataframe(df))
    assert c["Emp ID"].role == "identifier"
    assert c["Year"].role == "time"
    assert c["Salary"].role == "measure"


def test_text_formatted_negative_and_blank_numbers():
    df = raw({"Balance": ["1,200", "(300)", "", None, "-50", "N/A", "abc", "10", "20", "₹30", "40.5", "7"]})
    p = profile_dataframe(df)
    assert p.typed["Balance"].tolist()[:2] == [1200.0, -300.0]
    c = cols(p)["Balance"]
    assert c.stats["nulls"] == 3 and c.stats["invalid"] == 1
    assert any(i["type"] == "invalid_numbers" for i in p.quality["issues"])


def test_month_first_file_detected():
    df = raw({"Date": ["01/13/2026", "02/14/2026", "03/01/2026"], "V": ["1", "2", "3"]})
    p = profile_dataframe(df)
    assert [d.month for d in p.typed["Date"]] == [1, 2, 3]


def test_ambiguous_dates_reported_and_overridable():
    df = raw({"Date": ["01/02/2026", "03/04/2026", "05/06/2026"], "V": ["1", "2", "3"]})
    p = profile_dataframe(df)
    assert any(i["type"] == "ambiguous_dates" for i in p.quality["issues"])
    assert p.typed["Date"].iloc[0].month == 2  # day-first default
    p2 = profile_dataframe(df, overrides={"Date": {"dayfirst": False}})
    assert p2.typed["Date"].iloc[0].month == 1


def test_duplicates_missing_and_case_variants():
    df = raw({"City": ["Pune", "pune ", "Delhi", "Delhi", None], "Sales": ["1", "1", "2", "2", "3"]})
    p = profile_dataframe(df)
    q = p.quality
    assert q["summary"]["duplicate_rows"] == 1
    assert q["summary"]["missing_cells"] == 1
    kinds = {i["type"] for i in q["issues"]}
    assert {"duplicate_rows", "missing_values", "case_variants", "whitespace"} <= kinds
    assert all("message_hi" in i for i in q["issues"])


def test_relationships_hierarchy_and_derived():
    n = 40
    cities = ["Pune", "Mumbai", "Delhi", "Noida"]
    state = {"Pune": "MH", "Mumbai": "MH", "Delhi": "DL", "Noida": "UP"}
    rev = [str(100 + i * 3) for i in range(n)]
    cost = [str(50 + i) for i in range(n)]
    df = raw({"City": [cities[i % 4] for i in range(n)], "State": [state[cities[i % 4]] for i in range(n)], "Revenue": rev, "Cost": cost,
              "Profit": [str(int(r) - int(c)) for r, c in zip(rev, cost)]})
    rels = profile_dataframe(df).schema["relationships"]
    assert any(r["type"] == "hierarchy" and r["from"] == "City" and r["to"] == "State" for r in rels)
    assert any(r["type"] == "derived" and r["to"] == "Profit" for r in rels)


def test_manual_override_changes_type():
    df = raw({"Code": ["001", "002", "003"], "V": ["1", "2", "3"]})
    p = profile_dataframe(df, overrides={"Code": {"data_type": "categorical", "label": "Branch code"}})
    c = cols(p)["Code"]
    assert c.data_type == "categorical" and c.role == "dimension" and c.label == "Branch code" and c.user_override


def test_domain_guess_is_hint_only():
    hr = profile_dataframe(raw({"Emp Code": ["E1", "E2"], "Department": ["HR", "IT"], "Basic Salary": ["100", "200"]}))
    assert hr.schema["domain"]["guess"] == "hr_payroll"
    generic = profile_dataframe(raw({"foo": ["a", "b"], "bar": ["1", "2"]}))
    assert generic.schema["domain"]["guess"] == "general"
