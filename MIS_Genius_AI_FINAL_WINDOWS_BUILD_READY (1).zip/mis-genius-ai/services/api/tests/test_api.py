"""REST API: auth, roles, tenant isolation, datasets, dashboards, exports, AI, reports, security."""
import io
import json
import zipfile

import pandas as pd
import pytest

from .conftest import _register, upload, xlsx_bytes

API = "/api/v1"


def demo(client, h):
    r = client.post(f"{API}/datasets/demo?which=sales", headers=h)
    assert r.status_code == 200, r.text
    return r.json()


# --------------------------------------------------------------------------- auth
def test_health_and_docs(client):
    assert client.get(f"{API}/health").json()["database"] == "ok"
    assert client.get("/api/openapi.json").status_code == 200


def test_register_login_refresh_logout(client, user):
    r = client.post(f"{API}/auth/login", json={"email": user["email"], "password": "Passw0rd!x"})
    assert r.status_code == 200
    tokens = r.json()
    assert tokens["role"] == "owner" and "data.write" in tokens["permissions"]
    r = client.post(f"{API}/auth/refresh", json={"refresh_token": tokens["refresh_token"]})
    assert r.status_code == 200
    new = r.json()
    assert client.post(f"{API}/auth/refresh", json={"refresh_token": tokens["refresh_token"]}).status_code == 401  # rotated
    client.post(f"{API}/auth/logout", json={"refresh_token": new["refresh_token"]})
    assert client.post(f"{API}/auth/refresh", json={"refresh_token": new["refresh_token"]}).status_code == 401


def test_bad_login_and_weak_password(client, user):
    assert client.post(f"{API}/auth/login", json={"email": user["email"], "password": "wrong"}).status_code == 401
    r = client.post(f"{API}/auth/register", json={"email": "weak@example.com", "password": "password", "org_name": "X"})
    assert r.status_code == 400
    assert client.post(f"{API}/auth/register", json={"email": user["email"], "password": "Passw0rd!x"}).status_code == 409


def test_protected_routes_require_auth(client):
    assert client.get(f"{API}/datasets").status_code == 401
    assert client.get(f"{API}/datasets", headers={"Authorization": "Bearer nope"}).status_code == 401


# --------------------------------------------------------------------------- tenancy + roles
def test_tenant_isolation(client, user, other_user):
    d = demo(client, user["headers"])
    for method, path in [("get", f"/datasets/{d['dataset_id']}"), ("get", f"/dashboards/{d['dashboard_id']}"),
                         ("post", f"/datasets/{d['dataset_id']}/rows"), ("post", f"/dashboards/{d['dashboard_id']}/data"),
                         ("post", f"/datasets/{d['dataset_id']}/ask"), ("delete", f"/dashboards/{d['dashboard_id']}")]:
        kw = {"json": {"question": "total"}} if path.endswith("/ask") else ({"json": {}} if method == "post" else {})
        r = getattr(client, method)(API + path, headers=other_user["headers"], **kw)
        assert r.status_code == 404, (path, r.status_code)
    assert all(x["id"] != d["dataset_id"] for x in client.get(f"{API}/datasets", headers=other_user["headers"]).json())
    # forging the org header does not grant access
    forged = {**other_user["headers"], "X-Org-Id": user["org_id"]}
    assert client.get(f"{API}/datasets", headers=forged).status_code == 403
    assert client.get(f"{API}/search?q=DEMO", headers=other_user["headers"]).json()["datasets"] == []


def test_roles_and_permissions(client, user):
    h = user["headers"]
    r = client.post(f"{API}/orgs/current/members", headers=h, json={"email": "viewer1@example.com", "role": "viewer", "password": "Viewer123x"})
    assert r.status_code == 200
    login = client.post(f"{API}/auth/login", json={"email": "viewer1@example.com", "password": "Viewer123x"}).json()
    vh = {"Authorization": f"Bearer {login['access_token']}", "X-Org-Id": user["org_id"]}
    d = demo(client, h)
    assert client.get(f"{API}/datasets/{d['dataset_id']}", headers=vh).status_code == 200
    assert client.post(f"{API}/datasets/demo", headers=vh).status_code == 403
    assert client.delete(f"{API}/dashboards/{d['dashboard_id']}", headers=vh).status_code == 403
    assert client.get(f"{API}/audit", headers=vh).status_code == 403
    assert client.put(f"{API}/settings/ai", headers=vh, json={"provider": "none"}).status_code == 403
    # viewers can still read, filter, ask and export
    assert client.post(f"{API}/dashboards/{d['dashboard_id']}/data", headers=vh, json={"filters": []}).status_code == 200
    assert client.post(f"{API}/datasets/{d['dataset_id']}/export", headers=vh, json={"format": "csv"}).status_code == 200
    # last owner protection
    members = client.get(f"{API}/orgs/current/members", headers=h).json()
    owner = next(m for m in members if m["role"] == "owner")
    assert client.patch(f"{API}/orgs/current/members/{owner['membership_id']}", headers=h, json={"role": "viewer"}).status_code == 400


def test_api_key_access(client, user):
    h = user["headers"]
    demo(client, h)
    k = client.post(f"{API}/api-keys", headers=h, json={"name": "ci", "role": "viewer"}).json()
    kh = {"X-API-Key": k["key"]}
    assert client.get(f"{API}/datasets", headers=kh).status_code == 200
    assert client.post(f"{API}/datasets/demo", headers=kh).status_code == 403
    client.delete(f"{API}/api-keys/{k['id']}", headers=h)
    assert client.get(f"{API}/datasets", headers=kh).status_code == 401


# --------------------------------------------------------------------------- datasets
def test_upload_csv_creates_dataset_and_dashboard(client, user):
    csv = "Date,Region,Product,Sales Amount,Expenses\n" + "\n".join(
        f"{d:02d}/0{m}/2026,{r},{p},\"₹{1000 + d * 10:,}\",{500 + d}" for m in (1, 2, 3) for d in range(1, 21) for r, p in [("North", "A"), ("South", "B")])
    res = upload(client, user["headers"], "sales.csv", csv.encode())
    job = res["job"]
    assert job["status"] == "done", job
    created = job["result"]["created"][0]
    ds = client.get(f"{API}/datasets/{created['dataset_id']}", headers=user["headers"]).json()
    assert ds["rows"] == 120 and ds["schema"]["primary_date_column"] == "Date"
    types = {c["name"]: c["data_type"] for c in ds["schema"]["columns"]}
    assert types["Sales Amount"] == "currency" and types["Region"] == "categorical"
    data = client.post(f"{API}/dashboards/{created['dashboard_id']}/data", headers=user["headers"], json={"filters": []}).json()
    kpis = [w["kpi"] for w in data["widgets"].values() if "kpi" in w]
    total = next(k for k in kpis if k["title"] == "Total Sales Amount")
    assert total["value"] == pytest.approx(sum(1000 + d * 10 for m in (1, 2, 3) for d in range(1, 21) for _ in range(2)))


def test_multi_sheet_selection_combine_and_compare(client, user):
    a = pd.DataFrame({"Month": ["Jan", "Feb"], "Branch": ["Pune", "Pune"], "Amount": [10, 20]})
    b = pd.DataFrame({"Month": ["Jan", "Feb"], "Branch": ["Delhi", "Delhi"], "Amount": [5, 7]})
    c = pd.DataFrame({"Employee": ["X", "Y"], "Dept": ["HR", "IT"]})
    res = upload(client, user["headers"], "branches.xlsx", xlsx_bytes({"Pune": a, "Delhi": b, "Staff": c}))
    result = res["job"]["result"]
    assert result["status"] == "needs_selection" and len(result["sheets"]) == 3
    ids = {s["label"]: s["id"] for s in result["sheets"]}
    cmp_ = client.post(f"{API}/sheets/compare", headers=user["headers"], json={"sheet_ids": [ids["Pune"], ids["Delhi"]]}).json()
    assert cmp_["compatible"] is True
    bad = client.post(f"{API}/sheets/compare", headers=user["headers"], json={"sheet_ids": [ids["Pune"], ids["Staff"]]}).json()
    assert bad["compatible"] is False
    job = client.post(f"{API}/datasets/from-sheets", headers=user["headers"], json={"sheet_ids": [ids["Pune"], ids["Delhi"]], "combine": True}).json()["job"]
    assert job["status"] == "done", job
    dsid = job["result"]["created"][0]["dataset_id"]
    ds = client.get(f"{API}/datasets/{dsid}", headers=user["headers"]).json()
    assert ds["rows"] == 4 and "Source Sheet" in [c["name"] for c in ds["schema"]["columns"]]
    job = client.post(f"{API}/datasets/from-sheets", headers=user["headers"], json={"sheet_ids": [ids["Pune"], ids["Staff"]], "combine": True}).json()["job"]
    assert job["status"] == "failed" and "not structurally compatible" in job["error"]


def test_bad_upload_rejected_gracefully(client, user):
    r = client.post(f"{API}/uploads", headers=user["headers"], files={"file": ("x.exe", b"MZ", "application/octet-stream")})
    assert r.status_code == 400 and "Unsupported" in r.json()["detail"]
    res = upload(client, user["headers"], "broken.xlsx", b"PK\x03\x04garbage")
    assert res["job"]["status"] == "failed" and "corrupted" in res["job"]["error"].lower()


def test_explorer_filters_and_export(client, user):
    d = demo(client, user["headers"])
    h = user["headers"]
    base = f"{API}/datasets/{d['dataset_id']}"
    rows = client.post(f"{base}/rows", headers=h, json={"filters": [{"column": "Region", "op": "in", "values": ["West"]}],
                                                       "sort": [{"by": "Sales Amount", "desc": True}], "limit": 5}).json()
    assert len(rows["rows"]) == 5 and rows["total"] > 5
    csv = client.post(f"{base}/export", headers=h, json={"format": "csv", "filters": [{"column": "Region", "op": "in", "values": ["West"]}]})
    assert csv.status_code == 200 and csv.content.startswith("﻿".encode())
    df = pd.read_csv(io.BytesIO(csv.content), encoding="utf-8-sig")
    assert len(df) == rows["total"] and set(df["Region"]) == {"West"}
    x = client.post(f"{base}/export", headers=h, json={"format": "xlsx", "scope": "all"})
    wb = pd.read_excel(io.BytesIO(x.content), sheet_name=None)
    assert set(wb) == {"About", "Data"} and len(wb["Data"]) == 1200
    dist = client.post(f"{base}/distinct", headers=h, json={"column": "Channel"}).json()
    assert dist["total_distinct"] == 3


def test_schema_override_and_versions_and_cleaning(client, user):
    h = user["headers"]
    csv = "Code,City,Value\n001,pune ,10\n002,Pune,20\n003,Delhi,30\n003,Delhi,30\n"
    res = upload(client, h, "codes.csv", csv.encode())
    dsid = res["job"]["result"]["created"][0]["dataset_id"]
    r = client.patch(f"{API}/datasets/{dsid}/columns/Value", headers=h, json={"data_type": "currency", "label": "Value (₹)"})
    assert r.status_code == 200 and r.json()["column"]["data_type"] == "currency" and r.json()["column"]["label"] == "Value (₹)"
    prev = client.post(f"{API}/datasets/{dsid}/clean/preview", headers=h, json={"steps": [{"op": "trim_whitespace"}, {"op": "remove_duplicates"}]}).json()
    assert prev["rows_after"] == 3
    job = client.post(f"{API}/datasets/{dsid}/clean", headers=h, json={"steps": [
        {"op": "trim_whitespace"}, {"op": "standardize_case", "params": {"columns": ["City"], "case": "title"}}, {"op": "remove_duplicates"},
        {"op": "rename_column", "params": {"column": "City", "new_name": "Branch City"}}]}).json()["job"]
    assert job["status"] == "done", job
    versions = client.get(f"{API}/datasets/{dsid}/versions", headers=h).json()
    assert [v["version_number"] for v in versions] == [2, 1] and versions[0]["current"]
    cmp_ = client.get(f"{API}/datasets/{dsid}/versions/compare?a={versions[1]['id']}&b={versions[0]['id']}", headers=h).json()
    assert cmp_["rows_change"] == -1 and "Branch City" in cmp_["added_columns"]
    # dashboards were remapped to the renamed column and still render
    dash = client.get(f"{API}/dashboards?dataset_id={dsid}", headers=h).json()[0]
    data = client.post(f"{API}/dashboards/{dash['id']}/data", headers=h, json={"filters": []}).json()
    assert not any("error" in w for w in data["widgets"].values()), data
    # the original upload is untouched: v1 still has 4 rows and can be re-activated
    r = client.post(f"{API}/datasets/{dsid}/rows?version_id={versions[1]['id']}", headers=h, json={})
    assert r.json()["total"] == 4
    assert client.post(f"{API}/datasets/{dsid}/versions/{versions[1]['id']}/activate", headers=h).status_code == 200


def test_soft_delete_restore_purge(client, user):
    h = user["headers"]
    d = demo(client, h)
    assert client.delete(f"{API}/datasets/{d['dataset_id']}", headers=h).status_code == 200
    assert client.get(f"{API}/datasets/{d['dataset_id']}/schema", headers=h).status_code == 404
    assert any(x["id"] == d["dataset_id"] for x in client.get(f"{API}/datasets?include_deleted=true", headers=h).json())
    assert client.post(f"{API}/datasets/{d['dataset_id']}/restore", headers=h).status_code == 200
    client.delete(f"{API}/datasets/{d['dataset_id']}", headers=h)
    assert client.delete(f"{API}/datasets/{d['dataset_id']}?purge=true", headers=h).json()["purged"] is True


# --------------------------------------------------------------------------- dashboards
def test_dashboard_crud_widgets_layout_and_templates(client, user):
    h = user["headers"]
    d = demo(client, h)
    dash = client.get(f"{API}/dashboards/{d['dashboard_id']}", headers=h).json()
    assert dash["widgets"] and dash["config"]["filters"]
    w = client.post(f"{API}/dashboards/{dash['id']}/widgets", headers=h, json={
        "widget_type": "chart", "title": "Profit by channel",
        "config": {"chart": {"type": "bar", "dimension": {"column": "Channel"}, "measures": [{"column": "Profit", "agg": "sum"}]}}}).json()
    assert client.patch(f"{API}/dashboards/{dash['id']}/widgets/{w['id']}", headers=h,
                        json={"config": {"chart": {"type": "donut", "dimension": {"column": "Channel"}, "measures": [{"column": "Profit"}]}}}).status_code == 200
    data = client.post(f"{API}/dashboards/{dash['id']}/widgets/{w['id']}/data", headers=h, json={"filters": []}).json()
    assert data["chart"]["type"] == "donut"
    bad = client.post(f"{API}/dashboards/{dash['id']}/widgets", headers=h, json={"widget_type": "chart", "config": {"chart": {"type": "radar"}}})
    assert bad.status_code == 422
    items = [{"id": x["id"], "x": 0, "y": i * 3, "w": 6, "h": 3} for i, x in enumerate(dash["widgets"][:3])]
    assert client.put(f"{API}/dashboards/{dash['id']}/layout", headers=h, json={"items": items}).status_code == 200
    dup = client.post(f"{API}/dashboards/{dash['id']}/duplicate", headers=h).json()
    assert dup["name"].endswith("(copy)") and dup["widget_count"] == dash["widget_count"] + 1
    reset = client.post(f"{API}/dashboards/{dup['id']}/reset", headers=h).json()
    assert reset["auto_generated"] and reset["widget_count"] == dash["widget_count"]
    t = client.post(f"{API}/templates/from-dashboard", headers=h, json={"dashboard_id": dash["id"], "name": "My sales template"}).json()
    exported = client.get(f"{API}/templates/{t['id']}/export", headers=h)
    imp = client.post(f"{API}/templates/import", headers=h, files={"file": ("t.json", exported.content, "application/json")}).json()
    assert imp["source"] == "imported"
    tmpls = client.get(f"{API}/templates", headers=h).json()
    assert any(x["builtin"] for x in tmpls)
    applied = client.post(f"{API}/templates/{t['id']}/apply", headers=h, json={"dataset_id": d["dataset_id"]}).json()
    assert applied["widget_count"] > 3
    sf = client.post(f"{API}/dashboards/{dash['id']}/saved-filters", headers=h,
                     json={"name": "West", "filters": [{"column": "Region", "op": "in", "values": ["West"]}]}).json()
    assert client.get(f"{API}/dashboards/{dash['id']}", headers=h).json()["saved_filters"][0]["id"] == sf["id"]


def test_dashboard_exports_respect_filters(client, user):
    h = user["headers"]
    d = demo(client, h)
    f = [{"column": "Region", "op": "in", "values": ["East"]}]
    pdf = client.post(f"{API}/dashboards/{d['dashboard_id']}/export", headers=h, json={"format": "pdf", "filters": f})
    assert pdf.status_code == 200 and pdf.content[:4] == b"%PDF"
    x = client.post(f"{API}/dashboards/{d['dashboard_id']}/export", headers=h, json={"format": "xlsx", "filters": f})
    wb = pd.read_excel(io.BytesIO(x.content), sheet_name=None)
    assert set(wb["Filtered data"]["Region"]) == {"East"} and "KPIs" in wb


# --------------------------------------------------------------------------- AI + reports
def test_insights_ask_reports(client, user):
    h = user["headers"]
    d = demo(client, h)
    ins = client.post(f"{API}/datasets/{d['dataset_id']}/insights", headers=h, json={"language": "en"}).json()
    assert ins["meta"]["generated_by"] == "deterministic" and ins["executive_summary"]
    hi = client.post(f"{API}/datasets/{d['dataset_id']}/insights", headers=h, json={"language": "hi"}).json()
    assert any("ऀ" <= c <= "ॿ" for c in hi["executive_summary"][0]["text"])
    ans = client.post(f"{API}/datasets/{d['dataset_id']}/ask", headers=h, json={"question": "Which region has the highest revenue?"}).json()
    assert ans["intent"] == "top_n" and ans["answer"].startswith("West") and ans["sql"]
    mk = client.post(f"{API}/datasets/{d['dataset_id']}/ask", headers=h, json={"question": "Create a dashboard for this dataset"}).json()
    assert mk.get("dashboard_id")
    rep = client.post(f"{API}/reports", headers=h, json={"dataset_id": d["dataset_id"], "dashboard_id": d["dashboard_id"]}).json()
    assert rep["content"]["sections"][0]["items"]
    for fmt, magic in (("pdf", b"%PDF"), ("xlsx", b"PK"), ("json", b"{"), ("html", b"<!doctype")):
        r = client.get(f"{API}/reports/{rep['id']}/download?format={fmt}", headers=h)
        assert r.status_code == 200 and r.content[:len(magic)].lower() == magic.lower(), fmt
    rep_hi = client.post(f"{API}/reports", headers=h, json={"dataset_id": d["dataset_id"], "language": "hi"}).json()
    r = client.get(f"{API}/reports/{rep_hi['id']}/download?format=pdf", headers=h)
    assert r.headers["content-type"].startswith("text/html")  # Hindi → print-ready HTML


def test_ai_settings_never_expose_key(client, user):
    h = user["headers"]
    r = client.put(f"{API}/settings/ai", headers=h, json={"provider": "anthropic", "api_key": "sk-ant-secret-value-1234", "model": "claude-sonnet-5"})
    body = r.json()
    assert "sk-ant-secret-value-1234" not in json.dumps(body) and body["api_key_hint"] == "••••1234"
    assert "sk-ant-secret" not in client.get(f"{API}/settings/ai", headers=h).text
    client.put(f"{API}/settings/ai", headers=h, json={"provider": "none", "clear_api_key": True})


# --------------------------------------------------------------------------- misc
def test_alerts_and_notifications(client, user):
    h = user["headers"]
    d = demo(client, h)
    client.post(f"{API}/alerts", headers=h, json={"dataset_id": d["dataset_id"], "name": "Sales above 1 Cr",
                                                  "kpi": {"title": "Total Sales", "measure": {"column": "Sales Amount", "agg": "sum"}},
                                                  "operator": ">", "threshold": 10_000_000})
    fired = client.post(f"{API}/alerts/evaluate/{d['dataset_id']}", headers=h).json()["fired"]
    assert len(fired) == 1
    n = client.get(f"{API}/notifications", headers=h).json()
    assert n["unread"] >= 1 and any(i["kind"] == "kpi_alert" for i in n["items"])
    client.post(f"{API}/notifications/read-all", headers=h)
    assert client.get(f"{API}/notifications", headers=h).json()["unread"] == 0


def test_search_audit_usage(client, user):
    h = user["headers"]
    demo(client, h)
    s = client.get(f"{API}/search?q=region", headers=h).json()
    assert s["columns"] and s["columns"][0]["name"] == "Region"
    audit = client.get(f"{API}/audit", headers=h).json()
    assert any(a["action"] == "dataset.demo" for a in audit["items"])
    u = client.get(f"{API}/billing/usage", headers=h).json()
    assert u["used"]["datasets"] >= 1


def test_backup_export_import(client, user, other_user):
    h = user["headers"]
    demo(client, h)
    z = client.post(f"{API}/backup/export", headers=h)
    assert z.status_code == 200 and zipfile.ZipFile(io.BytesIO(z.content)).read("manifest.json")
    counts = client.post(f"{API}/backup/import", headers=other_user["headers"], files={"file": ("b.zip", z.content, "application/zip")}).json()
    assert counts["datasets"] >= 1 and counts["dashboards"] >= 1


def test_security_paths(client, user):
    from misgenius.storage.base import StorageError, validate_key

    for bad in ["../etc/passwd", "/abs", "a/../../b", "a\\b", ""]:
        with pytest.raises(StorageError):
            validate_key(bad)
    h = user["headers"]
    r = client.post(f"{API}/connectors/test", headers=h, json={"type": "sql", "config": {"url": "sqlite://", "query": "DELETE FROM x"}})
    assert r.status_code == 400 and "read-only" in r.json()["detail"]
    d = demo(client, h)
    r = client.post(f"{API}/datasets/{d['dataset_id']}/analytics/query", headers=h,
                    json={"measures": [{"formula": "SUM([Sales Amount]); DROP TABLE users"}]})
    assert r.status_code == 400
    r = client.get(f"{API}/datasets/{d['dataset_id']}")
    assert r.status_code == 401
    resp = client.get(f"{API}/health")
    assert resp.headers["x-content-type-options"] == "nosniff" and resp.headers["x-frame-options"] == "DENY"


def test_sql_connector_imports_real_database(client, user, tmp_path):
    import sqlite3

    db = tmp_path / "erp.sqlite"
    con = sqlite3.connect(db)
    con.execute("create table sales (day text, branch text, amount real)")
    con.executemany("insert into sales values (?,?,?)", [(f"2026-01-{i + 1:02d}", ["A", "B"][i % 2], 100.0 + i) for i in range(20)])
    con.commit()
    con.close()
    h = user["headers"]
    cfg = {"url": f"sqlite:///{db}", "query": "SELECT day, branch, amount FROM sales"}
    t = client.post(f"{API}/connectors/test", headers=h, json={"type": "sql", "config": cfg}).json()
    assert t["ok"] and t["sheets"][0]["rows"] == 21
    job = client.post(f"{API}/datasets/from-connector", headers=h, json={"type": "sql", "config": cfg, "name": "ERP sales"}).json()["job"]
    assert job["status"] == "done", job
    dsid = job["result"]["dataset_id"]
    assert client.post(f"{API}/datasets/{dsid}/refresh", headers=h).json()["job"]["status"] == "done"
    assert len(client.get(f"{API}/datasets/{dsid}/versions", headers=h).json()) == 2


def test_org_switching(client, user):
    h = user["headers"]
    org2 = client.post(f"{API}/orgs", headers=h, json={"name": "Second Org"}).json()
    h2 = {**h, "X-Org-Id": org2["id"]}
    assert client.get(f"{API}/datasets", headers=h2).json() == []
    assert client.get(f"{API}/orgs/current", headers=h2).json()["id"] == org2["id"]
    assert len(client.get(f"{API}/orgs", headers=h).json()) == 2


def test_registration_can_be_closed(client, monkeypatch):
    from misgenius.config import get_settings

    monkeypatch.setattr(get_settings(), "ALLOW_REGISTRATION", False)
    r = client.post(f"{API}/auth/register", json={"email": "closed@example.com", "password": "Passw0rd!x", "org_name": "X"})
    assert r.status_code == 403
    monkeypatch.setattr(get_settings(), "ALLOW_REGISTRATION", True)
    _register(client)
