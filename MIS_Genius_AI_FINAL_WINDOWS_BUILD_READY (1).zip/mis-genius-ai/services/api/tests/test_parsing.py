"""Value parsing: numbers (Indian formats, currency, accounting), dates, booleans."""
from datetime import datetime

import pytest

from misgenius.ingestion.parsing import detect_dayfirst, excel_serial_to_datetime, parse_bool, parse_date, parse_number


@pytest.mark.parametrize("raw,expected", [
    ("₹1,00,000.50", 100000.5), ("Rs. 2,500", 2500), ("INR 45", 45), ("$1,000,000", 1_000_000), ("(500)", -500), ("500-", -500),
    ("-₹1,200", -1200), ("  42 ", 42), ("1e3", 1000), ("1.2K", 1200), ("3 lakh", 300_000), ("2.5 Cr", 25_000_000),
    ("1.234,56", 1234.56), ("12,34", 12.34), ("10,00,00,000.25", 100_000_000.25), ("1,234,567", 1_234_567), (1500, 1500), (2.5, 2.5),
    ("12,500 Dr", -12500),
])
def test_numbers(raw, expected):
    pn = parse_number(raw)
    assert pn is not None and pn.value == pytest.approx(expected)


@pytest.mark.parametrize("raw", ["abc", "12,3456", "rsvp", "", None, True, "N/A", datetime(2025, 1, 1)])
def test_not_numbers(raw):
    assert parse_number(raw) is None


def test_percent_and_currency_flags():
    assert parse_number("12.5%").percent is True
    assert parse_number("₹10").currency == "INR"
    assert parse_number("12,500 Cr", drcr=True).value == 12500


@pytest.mark.parametrize("raw,expected", [
    ("2026-05-12", datetime(2026, 5, 12)), ("12/05/2026", datetime(2026, 5, 12)), ("05/13/2026", datetime(2026, 5, 13)),
    ("12 May 2026", datetime(2026, 5, 12)), ("May 12, 2026", datetime(2026, 5, 12)), ("12-May-26", datetime(2026, 5, 12)),
    ("Jan-26", datetime(2026, 1, 1)), ("2026-05", datetime(2026, 5, 1)), ("20260512", datetime(2026, 5, 12)),
    ("2026-05-12 14:30:00", datetime(2026, 5, 12, 14, 30)), ("31/12/25 10:00 PM", datetime(2025, 12, 31, 22, 0)),
])
def test_dates(raw, expected):
    assert parse_date(raw, True)[0] == expected


def test_month_first_when_told():
    assert parse_date("05/06/2026", False)[0] == datetime(2026, 5, 6)
    assert parse_date("05/06/2026", True)[0] == datetime(2026, 6, 5)


def test_dayfirst_detection():
    assert detect_dayfirst(["01/02/2026", "13/02/2026"]) == (True, False)
    assert detect_dayfirst(["01/02/2026", "02/13/2026"]) == (False, False)
    assert detect_dayfirst(["01/02/2026"]) == (None, True)


def test_excel_serial():
    assert excel_serial_to_datetime(45000).date().isoformat() == "2023-03-15"


def test_bool():
    assert parse_bool("Yes") is True and parse_bool("no") is False and parse_bool("maybe") is None
