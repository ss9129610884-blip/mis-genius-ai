"""End-to-end: Upload Excel → schema → dashboard → filter → KPI/chart change → raw data →
AI insight → export filtered data. Then a completely different file adapts everything."""
import io

import numpy as np
import pandas as pd
import pytest

from .conftest import upload, xlsx_bytes

API = "/api/v1"


def _kpi(widgets, title):
    return next(w["kpi"] for w in widgets.values() if "kpi" in w and w["kpi"]["title"] == title)


def test_full_chain(client, user, examples_dir):
    h = user["headers"]
    # 1. upload a multi-sheet Excel workbook
    res = upload(client, h, "demo_sales.xlsx", (examples_dir / "demo_sales.xlsx").read_bytes())
    result = res["job"]["result"]
    assert result["status"] == "needs_selection"
    sales_sheet = next(s for s in result["sheets"] if s["sheet_name"] == "Sales")
    job = client.post(f"{API}/datasets/from-sheets", headers=h, json={"sheet_ids": [sales_sheet["id"]], "name": "Sales FY26"}).json()["job"]
    assert job["status"] == "done", job
    created = job["result"]["created"][0]
    dsid, dashid = created["dataset_id"], created["dashboard_id"]

    # 2. schema detected
    schema = client.get(f"{API}/datasets/{dsid}/schema", headers=h).json()["schema"]
    assert schema["primary_date_column"] == "Order Date" and "Sales Amount" in schema["measures"] and "Region" in schema["dimensions"]

    # 3. dashboard generated
    dash = client.get(f"{API}/dashboards/{dashid}", headers=h).json()
    types = {w["widget_type"] for w in dash["widgets"]}
    assert {"kpi", "chart", "table", "pivot", "insights", "quality"} <= types
    bar = next(w for w in dash["widgets"] if w["title"] == "Total Sales Amount by Region")

    all_data = client.post(f"{API}/dashboards/{dashid}/data", headers=h, json={"filters": []}).json()
    # 4. apply a filter → 5. KPI changes → 6. chart changes
    f = [{"column": "Region", "op": "in", "values": ["North"]}]
    north = client.post(f"{API}/dashboards/{dashid}/data", headers=h, json={"filters": f}).json()
    k_all, k_north = _kpi(all_data["widgets"], "Total Sales Amount"), _kpi(north["widgets"], "Total Sales Amount")
    assert k_north["value"] < k_all["value"] and north["row_count"] < all_data["row_count"]
    assert all_data["widgets"][bar["id"]]["chart"]["categories"] != north["widgets"][bar["id"]]["chart"]["categories"]
    assert north["widgets"][bar["id"]]["chart"]["categories"] == ["North"]

    # 7. raw data explorer with the same filters
    rows = client.post(f"{API}/datasets/{dsid}/rows", headers=h, json={"filters": f, "limit": 50}).json()
    assert rows["total"] == north["row_count"] and {r[rows["columns"].index("Region")] for r in rows["rows"]} == {"North"}
    sum_rows = client.post(f"{API}/datasets/{dsid}/export", headers=h, json={"format": "csv", "filters": f})
    exported = pd.read_csv(io.BytesIO(sum_rows.content), encoding="utf-8-sig")
    assert exported["Sales Amount"].sum() == pytest.approx(k_north["value"])  # KPI == sum of the exported rows

    # 8. AI insight (deterministic fallback, grounded) respects the filter
    ins = client.post(f"{API}/datasets/{dsid}/insights", headers=h, json={"filters": f}).json()
    assert ins["meta"]["context"]["rows"] == north["row_count"]
    assert any("North" in i["text"] for sec in ("executive_summary", "top_contributors") for i in ins[sec]) or ins["executive_summary"]

    # 9. export filtered data as Excel
    x = client.post(f"{API}/datasets/{dsid}/export", headers=h, json={"format": "xlsx", "filters": f})
    data = pd.read_excel(io.BytesIO(x.content), sheet_name="Data")
    assert len(data) == north["row_count"] and set(data["Region"]) == {"North"}


def test_completely_different_file_adapts(client, user):
    """An inventory workbook with nothing in common with sales gets its own KPIs, charts, filters and insights."""
    h = user["headers"]
    rng = np.random.default_rng(3)
    n = 300
    inv = pd.DataFrame({
        "SKU": [f"SKU-{i:04d}" for i in range(n)],
        "Warehouse": rng.choice(["Pune WH", "Chennai WH", "Kolkata WH"], n),
        "Item Category": rng.choice(["Raw Material", "Finished Goods", "Spares"], n),
        "Stock Qty": rng.integers(0, 500, n),
        "Reorder Level": rng.integers(50, 150, n),
        "Stock Value": (rng.random(n) * 50000).round(2),
        "Last Movement": pd.date_range("2026-01-01", periods=n, freq="6h"),
    })
    res = upload(client, h, "inventory.xlsx", xlsx_bytes({"Stock": inv}))
    created = res["job"]["result"]["created"][0]
    dash = client.get(f"{API}/dashboards/{created['dashboard_id']}", headers=h).json()
    titles = " ".join(w["title"] for w in dash["widgets"])
    assert "Sales" not in titles and "Stock" in titles
    assert {f["column"] for f in dash["config"]["filters"] if f["column"]} >= {"Warehouse", "Item Category"}
    data = client.post(f"{API}/dashboards/{created['dashboard_id']}/data", headers=h, json={"filters": []}).json()
    assert not any("error" in w for w in data["widgets"].values())
    ans = client.post(f"{API}/datasets/{created['dataset_id']}/ask", headers=h, json={"question": "Which warehouse has the highest stock value?"}).json()
    assert ans["intent"] == "top_n" and ans["table"]["columns"][0] == "Warehouse"
    expected_top = inv.groupby("Warehouse")["Stock Value"].sum().idxmax()
    assert ans["answer"].startswith(expected_top)
