"""Cleaning transforms are non-destructive and validated."""
import pandas as pd
import pytest

from misgenius.cleaning.transforms import TransformError, apply_transforms


@pytest.fixture
def raw():
    return pd.DataFrame({
        "Name": [" ravi ", "ANU", "ravi", None, " ravi "],
        "City": ["Pune", "pune", "Delhi", None, "Pune"],
        "Amount": ["1,000", "₹2,000", None, "300", "1,000"],
        "Full": ["A-B", "C-D", "E-F", None, "A-B"],
    }).astype(object)


def test_original_is_never_modified(raw):
    before = raw.copy(deep=True)
    apply_transforms(raw, [{"op": "trim_whitespace"}, {"op": "remove_duplicates"}, {"op": "drop_columns", "params": {"columns": ["Full"]}}])
    pd.testing.assert_frame_equal(raw, before)


def test_trim_case_duplicates(raw):
    out, _, steps = apply_transforms(raw, [{"op": "trim_whitespace"}, {"op": "standardize_case", "params": {"columns": ["Name", "City"], "case": "title"}},
                                           {"op": "remove_duplicates"}])
    assert out["Name"].tolist().count("Ravi") == 2 and len(out) == 4
    assert all(s["description"] for s in steps)


def test_fill_missing_strategies(raw):
    out, _, _ = apply_transforms(raw, [{"op": "fill_missing", "params": {"column": "Amount", "strategy": "median"}}])
    assert out["Amount"].iloc[2] == "1000"
    out, _, _ = apply_transforms(raw, [{"op": "fill_missing", "params": {"column": "City", "strategy": "value", "value": "Unknown"}}])
    assert out["City"].iloc[3] == "Unknown"
    with pytest.raises(TransformError):
        apply_transforms(raw, [{"op": "fill_missing", "params": {"column": "City", "strategy": "magic"}}])


def test_split_merge_rename_replace(raw):
    out, _, _ = apply_transforms(raw, [
        {"op": "split_column", "params": {"column": "Full", "delimiter": "-", "into": ["Left", "Right"]}},
        {"op": "merge_columns", "params": {"columns": ["Name", "City"], "new_name": "Name City", "separator": " / "}},
        {"op": "rename_column", "params": {"column": "Amount", "new_name": "Value"}},
        {"op": "replace_values", "params": {"column": "City", "find": "pune", "replace": "Pune"}},
        {"op": "standardize_numbers", "params": {"columns": ["Value"]}},
    ])
    assert out["Left"].iloc[0] == "A" and out["Right"].iloc[1] == "D"
    assert "Value" in out.columns and out["Value"].iloc[1] == "2000"
    assert out["City"].tolist()[:2] == ["Pune", "Pune"]


def test_overrides_and_errors(raw):
    _, ov, _ = apply_transforms(raw, [{"op": "convert_type", "params": {"column": "Amount", "data_type": "currency"}},
                                      {"op": "standardize_dates", "params": {"column": "Name", "dayfirst": False}}])
    assert ov["Amount"]["data_type"] == "currency" and ov["Name"]["dayfirst"] is False
    for bad in ([{"op": "nope"}], [{"op": "rename_column", "params": {"column": "X", "new_name": "Y"}}],
                [{"op": "drop_columns", "params": {"columns": ["Name", "City", "Amount", "Full"]}}],
                [{"op": "convert_type", "params": {"column": "Amount", "data_type": "python"}}]):
        with pytest.raises(TransformError):
            apply_transforms(raw, bad)
