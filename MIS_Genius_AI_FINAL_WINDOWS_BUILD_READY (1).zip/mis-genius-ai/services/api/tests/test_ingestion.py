"""Ingestion: file formats, workbook structure, table/header detection, safety checks."""
import io
import zipfile

import pandas as pd
import pytest

from misgenius.ingestion.pipeline import inspect_bytes, profile_raw, table_to_raw
from misgenius.ingestion.readers import IngestionError, RawSheet
from misgenius.ingestion.tables import detect_tables

from .conftest import xlsx_bytes

LIM = dict(max_rows=100_000, max_cols=200, max_uncompressed_mb=200)


def test_csv_ingestion_with_bom_and_semicolon():
    data = "﻿Date;Region;Amount\n01/04/2025;North;1.200,50\n02/04/2025;South;300\n".encode("utf-8")
    r = inspect_bytes("sales.csv", data, **LIM)
    t = r.tables[0]
    assert t.columns == ["Date", "Region", "Amount"]
    assert len(t.rows) == 2
    raw, h, o = table_to_raw(t)
    p = profile_raw(raw, hints=h, originals=o)
    assert p.typed["Amount"].tolist() == [1200.5, 300.0]


def test_xlsx_multiple_sheets(examples_dir):
    data = (examples_dir / "demo_sales.xlsx").read_bytes()
    r = inspect_bytes("demo_sales.xlsx", data, **LIM)
    assert [s["sheet"] for s in r.sheet_summaries] == ["Sales", "Attendance", "About"]
    assert {t.sheet_name for t in r.tables} == {"Sales", "Attendance", "About"}
    sales = next(t for t in r.tables if t.sheet_name == "Sales")
    assert len(sales.rows) == 1200


def test_xls_ingestion():
    xlwt = pytest.importorskip("xlwt")
    wb = xlwt.Workbook()
    ws = wb.add_sheet("Data")
    for j, h in enumerate(["Item", "Qty"]):
        ws.write(0, j, h)
    ws.write(1, 0, "Pen")
    ws.write(1, 1, 5)
    buf = io.BytesIO()
    wb.save(buf)
    r = inspect_bytes("old.xls", buf.getvalue(), **LIM)
    assert r.tables[0].columns == ["Item", "Qty"]


def test_title_rows_total_rows_repeated_header_and_duplicate_columns():
    grid = [["Company — Sales Report", None, None], [None] * 3, ["Region", "Amount", "Amount"], ["North", 100, 1], ["South", 200, 2],
            ["Region", "Amount", "Amount"], ["East", 50, 3], ["Grand Total", 350, 6]]
    t = detect_tables(RawSheet("S", grid))[0]
    assert t.columns == ["Region", "Amount", "Amount (2)"]
    assert len(t.rows) == 3
    assert {x["reason"] for x in t.excluded_rows} == {"total_row", "repeated_header"}
    assert t.title and "Sales Report" in t.title


def test_missing_headers_named_by_letter():
    t = detect_tables(RawSheet("N", [[1, 2], [3, 4], [5, 6]]))[0]
    assert t.columns == ["Column A", "Column B"] and len(t.rows) == 3


def test_two_row_merged_header():
    grid = [["Region", "Q1", None, "Q2", None], [None, "Sales", "Units", "Sales", "Units"], ["N", 1, 2, 3, 4], ["S", 5, 6, 7, 8]]
    t = detect_tables(RawSheet("M", grid))[0]
    assert t.columns == ["Region", "Q1 Sales", "Q1 Units", "Q2 Sales", "Q2 Units"]


def test_side_by_side_tables_detected():
    grid = [["Name", "Score", None, "Item", "Qty"], ["A", 1, None, "x", 4], ["B", 2, None, "y", 5]]
    ts = detect_tables(RawSheet("S", grid))
    assert [t.columns for t in ts] == [["Name", "Score"], ["Item", "Qty"]]


def test_empty_and_header_only_files():
    with pytest.raises(IngestionError):
        inspect_bytes("e.csv", b"", **LIM)
    with pytest.raises(IngestionError):
        inspect_bytes("h.csv", b"A,B,C\n", **LIM)


def test_corrupted_and_fake_files():
    with pytest.raises(IngestionError):
        inspect_bytes("bad.xlsx", b"this is not excel", **LIM)
    with pytest.raises(IngestionError):
        inspect_bytes("x.exe", b"MZ....", **LIM)
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w") as z:
        z.writestr("hello.txt", "hi")
    with pytest.raises(IngestionError):
        inspect_bytes("zip.xlsx", buf.getvalue(), **LIM)


def test_zip_bomb_guard():
    buf = io.BytesIO()
    with zipfile.ZipFile(buf, "w", zipfile.ZIP_DEFLATED) as z:
        z.writestr("xl/workbook.xml", "<x/>")
        z.writestr("xl/worksheets/sheet1.xml", "0" * (3 * 1024 * 1024))
    with pytest.raises(IngestionError):
        inspect_bytes("bomb.xlsx", buf.getvalue(), max_rows=10, max_cols=10, max_uncompressed_mb=1)


def test_excel_native_types_and_percent_format():
    df = pd.DataFrame({"Date": pd.to_datetime(["2025-01-05", "2025-02-06"]), "Rate": [0.125, 0.5], "Qty": [1, 2]})
    buf = io.BytesIO()
    with pd.ExcelWriter(buf, engine="xlsxwriter") as xw:
        df.to_excel(xw, index=False, sheet_name="S")
        xw.sheets["S"].set_column(1, 1, 10, xw.book.add_format({"num_format": "0.0%"}))
    r = inspect_bytes("p.xlsx", buf.getvalue(), **LIM)
    raw, h, o = table_to_raw(r.tables[0])
    p = profile_raw(raw, hints=h, originals=o)
    cols = {c.name: c for c in p.columns}
    assert cols["Date"].data_type == "date"
    assert cols["Rate"].data_type == "percentage"
    assert p.typed["Rate"].tolist() == [12.5, 50.0]


def test_json_records():
    data = b'{"data": [{"city": "Pune", "sales": 10, "meta": {"x": 1}}, {"city": "Delhi", "sales": 5, "meta": {"x": 2}}]}'
    r = inspect_bytes("api.json", data, **LIM)
    assert r.tables[0].columns == ["city", "sales", "meta.x"]


def test_one_bad_sheet_does_not_fail_workbook():
    data = xlsx_bytes({"Good": pd.DataFrame({"A": [1, 2], "B": ["x", "y"]}), "Empty": pd.DataFrame()})
    r = inspect_bytes("mixed.xlsx", data, **LIM)
    assert any(s["status"] == "empty" and "Unable to detect a valid data table" in s["message"] for s in r.sheet_summaries)
    assert r.tables[0].sheet_name == "Good"
