"""Auto-dashboard generation adapts to completely different datasets; templates use semantic slots."""
import pandas as pd

from misgenius.analytics.charts import ChartSpec, build_chart
from misgenius.analytics.kpi import KPISpec, compute_kpi
from misgenius.analytics.query import DataSource
from misgenius.dashboard.generator import generate_dashboard
from misgenius.dashboard.templates import apply_template, to_template
from misgenius.demo.demo_data import demo_attendance, demo_sales
from misgenius.schema.profiler import profile_dataframe


def build(df, tmp_path, name):
    raw = df.astype(object).map(lambda v: None if v is None else (v.isoformat() if hasattr(v, "isoformat") else str(v)))
    p = profile_dataframe(raw)
    path = tmp_path / f"{name}.parquet"
    p.typed.to_parquet(path, index=False)
    return DataSource(path, p.schema), p.schema


def render_all(ds, dash):
    for w in dash["widgets"]:
        if w["widget_type"] == "kpi":
            k = compute_kpi(ds, KPISpec(**w["config"]["kpi"]))
            assert k["available"], (w["title"], k.get("reason"))
        elif "chart" in w["config"]:
            build_chart(ds, ChartSpec(**w["config"]["chart"]))


def test_sales_dashboard(tmp_path):
    ds, schema = build(demo_sales(), tmp_path, "s")
    d = generate_dashboard(schema, "Sales")
    titles = [w["title"] for w in d["widgets"]]
    assert any("Sales Amount" in t for t in titles)
    assert any(w["widget_type"] == "insights" for w in d["widgets"]) and any(w["widget_type"] == "quality" for w in d["widgets"])
    assert {f["type"] for f in d["config"]["filters"]} >= {"date_range", "multi_select", "numeric_range", "search"}
    render_all(ds, d)


def test_attendance_dashboard_is_not_sales(tmp_path):
    ds, schema = build(demo_attendance(), tmp_path, "a")
    d = generate_dashboard(schema, "Attendance")
    titles = " ".join(w["title"] for w in d["widgets"])
    assert "Sales" not in titles and "Revenue" not in titles
    assert "Present %" in titles
    render_all(ds, d)


def test_dataset_without_measures(tmp_path):
    df = pd.DataFrame({"Certificate No": [f"C{i}" for i in range(50)], "Issued On": pd.date_range("2025-01-01", periods=50, freq="W"),
                       "District": [["Pune", "Nashik", "Nagpur"][i % 3] for i in range(50)], "Type": [["A", "B"][i % 2] for i in range(50)]})
    ds, schema = build(df, tmp_path, "c")
    d = generate_dashboard(schema, "Certificates")
    kpis = [w for w in d["widgets"] if w["widget_type"] == "kpi"]
    assert kpis and all("Total " not in w["title"] or "Certificate" in w["title"] or "Records" in w["title"] for w in kpis)
    render_all(ds, d)


def test_medical_dataset(tmp_path):
    df = pd.DataFrame({"Patient ID": [f"P{i}" for i in range(80)], "Admission Date": pd.date_range("2025-06-01", periods=80, freq="D"),
                       "Ward": [["ICU", "General", "Pediatrics"][i % 3] for i in range(80)], "Length of Stay (days)": [i % 9 + 1 for i in range(80)],
                       "Bill Amount": [5000 + i * 250 for i in range(80)]})
    ds, schema = build(df, tmp_path, "m")
    d = generate_dashboard(schema, "Hospital")
    render_all(ds, d)
    assert schema["domain"]["guess"] == "medical"


def test_template_from_one_dataset_applies_to_another(tmp_path):
    ds1, s1 = build(demo_sales(), tmp_path, "s1")
    t = to_template(generate_dashboard(s1, "Sales"), s1, "Sales template")
    assert all("{{slot" in str(w["config"]) or w["widget_type"] in ("insights", "quality") for w in t["widgets"])
    df = pd.DataFrame({"Bill Date": pd.date_range("2025-01-01", periods=200, freq="D"), "Zone": [["A", "B", "C"][i % 3] for i in range(200)],
                       "Item": [f"I{i % 6}" for i in range(200)], "Net Revenue": [1000 + i for i in range(200)],
                       "Expense": [600 + i for i in range(200)], "Bill No": [f"B{i}" for i in range(200)]})
    ds2, s2 = build(df, tmp_path, "s2")
    applied = apply_template(t, s2)
    bound = {d["label"]: d["column"] for d in applied["binding"]["details"]}
    assert bound["Sales Amount"] == "Net Revenue" and bound["Order Date"] == "Bill Date" and bound["Cost"] == "Expense"
    assert bound["Profit"] is None  # never bound to an unrelated numeric column
    render_all(ds2, applied)
