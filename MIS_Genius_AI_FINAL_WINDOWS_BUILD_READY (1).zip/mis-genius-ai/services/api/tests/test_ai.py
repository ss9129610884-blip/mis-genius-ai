"""AI layer: grounding validation, insight fallback, NL analytics (EN/HI), provider adapters."""
import json

import httpx
import pytest

from misgenius.ai import providers as P
from misgenius.ai.insights import InsightEngine
from misgenius.ai.nlq import NLQEngine, detect_language
from misgenius.ai.providers import AIConfig, AIProvider, NoAIProvider, extract_json, make_provider
from misgenius.ai.validation import check_grounded, extract_numbers
from misgenius.analytics.query import DataSource
from misgenius.demo.demo_data import demo_attendance, demo_sales
from misgenius.schema.profiler import profile_dataframe


def _ds(df, tmp_path, name):
    raw = df.astype(object).map(lambda v: None if v is None else (v.isoformat() if hasattr(v, "isoformat") else str(v)))
    p = profile_dataframe(raw)
    path = tmp_path / f"{name}.parquet"
    p.typed.to_parquet(path, index=False)
    return DataSource(path, p.schema), p.quality


@pytest.fixture(scope="module")
def sales(tmp_path_factory):
    return _ds(demo_sales(), tmp_path_factory.mktemp("ai"), "sales")


@pytest.fixture(scope="module")
def attendance(tmp_path_factory):
    return _ds(demo_attendance(), tmp_path_factory.mktemp("ai2"), "att")


class FakeProvider(AIProvider):
    name = "fake"

    def __init__(self, replies):
        super().__init__(AIConfig(provider="fake", model="fake-1"))
        self.replies = list(replies)
        self.calls = []

    def _complete(self, system, user, *, json_mode, max_tokens):
        self.calls.append(user)
        r = self.replies.pop(0) if self.replies else "{}"
        return r(user) if callable(r) else r


# --------------------------------------------------------------------------- grounding
def test_extract_numbers_understands_indian_units():
    nums = extract_numbers("Sales were ₹6.65 Cr in Mar 2026, up 104.3% vs ₹39.63 L (SO-25668), 1,200 orders")
    assert 6.65e7 in nums and 104.3 in nums and pytest.approx(3.963e6) == [n for n in nums if 3e6 < n < 5e6][0] and 1200 in nums
    assert 2026 not in nums and 25668 not in nums


def test_grounding_accepts_facts_and_rejects_invented_numbers():
    facts = [{"numbers": [66471224.18, 104.3], "text": {"en": "Total Sales Amount is ₹6.65 Cr."}}]
    assert check_grounded("Sales reached ₹6.65 crore (+104.3%).", facts)[0]
    ok, bad = check_grounded("Sales reached ₹7.2 Cr, up 18.4%.", facts)
    assert not ok and 18.4 in bad


# --------------------------------------------------------------------------- insights
def test_deterministic_insights_without_ai(sales):
    ds, q = sales
    res = InsightEngine(NoAIProvider(AIConfig())).generate(ds, quality=q)
    assert res["meta"]["generated_by"] == "deterministic"
    assert res["executive_summary"] and res["top_contributors"] and res["anomalies"]
    assert all(i["fact_ids"] for i in res["executive_summary"])
    assert res["suggested_kpis"] and res["suggested_charts"] and res["questions"]
    for f in res["facts"]:
        assert f["evidence"].get("calculation")


def test_hindi_insights(attendance):
    ds, q = attendance
    res = InsightEngine(NoAIProvider(AIConfig())).generate(ds, quality=q, language="hi")
    assert any("ऀ" <= ch <= "ॿ" for ch in res["executive_summary"][0]["text"])


def test_ai_insights_grounded_output_is_used(sales):
    ds, q = sales

    def reply(user):
        facts = json.loads(user.split("Facts (computed from the data):\n", 1)[1].split("\n\nReturn JSON", 1)[0])
        top = next(f for f in facts if f["kind"] == "top_contributor")
        pc = next(f for f in facts if f["kind"] == "period_change")
        return json.dumps({"executive_summary": [{"text": pc["text"], "fact_ids": [pc["id"]]}, {"text": top["text"], "fact_ids": [top["id"]]}],
                           "key_trends": [], "questions": [{"text": "What drove March?"}]})

    prov = FakeProvider([reply])
    res = InsightEngine(prov).generate(ds, quality=q)
    assert res["meta"]["generated_by"] == "ai" and res["meta"]["grounding"]["rejected"] == 0
    assert res["executive_summary"][0]["source"] == "ai"


def test_ai_hallucinations_are_rejected_and_fallback_used(sales):
    ds, q = sales
    bad = json.dumps({"executive_summary": [{"text": "Revenue grew 37.9% because of Diwali demand, reaching ₹9.99 Cr.", "fact_ids": ["F2"]},
                                            {"text": "Customer churn is 12%.", "fact_ids": []}]})
    res = InsightEngine(FakeProvider([bad])).generate(ds, quality=q)
    assert res["meta"]["generated_by"] == "deterministic"
    assert "9.99" not in json.dumps(res["executive_summary"])


def test_ai_invalid_json_falls_back(sales):
    ds, q = sales
    res = InsightEngine(FakeProvider(["not json at all"])).generate(ds, quality=q)
    assert res["meta"]["generated_by"] == "deterministic" and "ai_error" in res["meta"]


# --------------------------------------------------------------------------- NL questions
@pytest.mark.parametrize("question,intent,check", [
    ("Which region has the highest revenue?", "top_n", lambda r: r["answer"].startswith("West")),
    ("Show top 10 customers", "top_n", lambda r: len(r["table"]["rows"]) == 10),
    ("इस महीने सबसे ज्यादा बिक्री किस क्षेत्र में हुई?", "top_n", lambda r: r["language"] == "hi" and "Region" in r["answer"]),
    ("Last month की तुलना में क्या बदला?", "compare_periods", lambda r: "%" in r["answer"]),
    ("Find unusual transactions", "anomalies", lambda r: r["table"]["rows"]),
    ("Which KPIs should I track?", "kpi_suggestions", lambda r: r["kpis"]),
    ("Create a dashboard for this dataset", "create_dashboard", lambda r: r.get("create_dashboard")),
    ("What is the total profit in North?", "aggregate", lambda r: "North" in r["answer"]),
    ("monthly trend of sales", "trend", lambda r: r["chart"]["type"] == "line"),
    ("What is the total salary?", "unsupported", lambda r: "cannot be determined" in r["answer"]),
])
def test_nlq_rules(sales, question, intent, check):
    ds, q = sales
    r = NLQEngine(NoAIProvider(AIConfig())).ask(ds, question, quality=q)
    assert r["intent"] == intent, r["plan"]
    assert check(r), r["answer"]


def test_nlq_attendance_filters_and_counts(attendance):
    ds, q = attendance
    r = NLQEngine(NoAIProvider(AIConfig())).ask(ds, "How many absent in IT department?")
    expected = ds.count([__import__("misgenius.analytics.query", fromlist=["Filter"]).Filter(column="Status", op="in", values=["Absent"]),
                         __import__("misgenius.analytics.query", fromlist=["Filter"]).Filter(column="Department", op="in", values=["IT"])])
    assert str(expected) in r["answer"]
    r = NLQEngine(NoAIProvider(AIConfig())).ask(ds, "इस महीने सबसे ज्यादा खर्च किस department ने किया?")
    assert r["intent"] == "unsupported"


def test_nlq_ai_plan_is_validated_and_answer_grounded(sales):
    ds, q = sales
    plan = json.dumps({"intent": "top_n", "measure": {"column": "sales amount", "agg": "sum"}, "dimension": "Region", "n": 2, "filters": [],
                       "time_scope": "all"})
    answer = json.dumps({"answer": "West leads with ₹2.58 Cr."})
    r = NLQEngine(FakeProvider([plan, answer])).ask(ds, "best regions?")
    assert r["plan"]["source"] == "ai" and r["plan"]["measure"]["column"] == "Sales Amount"
    assert r["answer_source"] == "ai"
    bad_plan = json.dumps({"intent": "top_n", "measure": {"column": "Revenue Imaginary", "agg": "sum"}, "dimension": "Region"})
    hallucinated = json.dumps({"answer": "West leads with ₹9.1 Cr, 44% share."})
    r2 = NLQEngine(FakeProvider([bad_plan, hallucinated])).ask(ds, "Which region has the highest revenue?")
    assert r2["plan"]["source"] == "rules" and r2["answer_source"] == "computed" and "ai_answer_rejected" in r2


def test_detect_language():
    assert detect_language("कुल बिक्री") == "hi" and detect_language("total sales") == "en"


# --------------------------------------------------------------------------- providers (HTTP mocked)
def _mock_client(monkeypatch, handler):
    real = httpx.Client

    def factory(*a, **kw):
        kw["transport"] = httpx.MockTransport(handler)
        return real(*a, **kw)

    monkeypatch.setattr(P.httpx, "Client", factory)


def test_anthropic_adapter(monkeypatch):
    seen = {}

    def handler(req: httpx.Request):
        seen["url"] = str(req.url)
        seen["key"] = req.headers.get("x-api-key")
        return httpx.Response(200, json={"content": [{"type": "text", "text": '{"ok": true}'}]})

    _mock_client(monkeypatch, handler)
    prov = make_provider(AIConfig(provider="anthropic", api_key="sk-ant-test"))
    assert prov.test()["ok"] and seen["url"].endswith("/v1/messages") and seen["key"] == "sk-ant-test"


def test_openai_and_gemini_adapters(monkeypatch):
    def handler(req: httpx.Request):
        if "generativelanguage" in str(req.url):
            return httpx.Response(200, json={"candidates": [{"content": {"parts": [{"text": '{"ok": true}'}]}}]})
        return httpx.Response(200, json={"choices": [{"message": {"content": '{"ok": true}'}}]})

    _mock_client(monkeypatch, handler)
    assert make_provider(AIConfig(provider="openai", api_key="sk-x")).test()["ok"]
    assert make_provider(AIConfig(provider="gemini", api_key="AIza-x")).test()["ok"]
    assert make_provider(AIConfig(provider="openai_compatible", base_url="http://localhost:11434/v1")).test()["ok"]


def test_provider_errors_are_friendly(monkeypatch):
    _mock_client(monkeypatch, lambda req: httpx.Response(401, json={"error": "bad key"}))
    with pytest.raises(P.AIProviderError, match="rejected the API key"):
        make_provider(AIConfig(provider="openai", api_key="sk-bad")).test()


def test_no_key_means_no_ai():
    assert make_provider(AIConfig(provider="anthropic", api_key=None)).available is False


def test_extract_json_tolerates_fences():
    assert extract_json('```json\n{"a": [1, {"b": "}"}]}\n```') == {"a": [1, {"b": "}"}]}
