"""Query engine, filters, formulas, KPIs, charts and pivots against a real Parquet file."""
import pandas as pd
import pytest

from misgenius.analytics.charts import ChartSpec, build_chart, recommend_charts
from misgenius.analytics.formulas import FormulaError, compile_formula
from misgenius.analytics.kpi import KPIComparison, KPIRatio, KPISpec, compute_kpi
from misgenius.analytics.pivot import pivot
from misgenius.analytics.query import DataSource, Dimension, Filter, Measure, QueryError, QuerySpec, Sort
from misgenius.schema.profiler import profile_dataframe


@pytest.fixture(scope="module")
def ds(tmp_path_factory):
    rows = []
    regions = ["North", "South", "East"]
    for i in range(90):
        month = i // 30 + 1  # Jan, Feb, Mar 2026
        day = i % 28 + 1
        rows.append({"Date": f"2026-{month:02d}-{day:02d}", "Region": regions[i % 3], "Product": f"P{i % 5}",
                     "Status": "Paid" if i % 4 else "Due", "Sales": str(100 + i), "Cost": str(50 + i // 2)})
    raw = pd.DataFrame(rows).astype(object)
    p = profile_dataframe(raw)
    path = tmp_path_factory.mktemp("q") / "data.parquet"
    p.typed.to_parquet(path, index=False)
    return DataSource(path, p.schema)


def test_aggregate_group_and_filters(ds):
    r = ds.aggregate(QuerySpec(dimensions=[Dimension(column="Region")], measures=[Measure(column="Sales", agg="sum")],
                               sort=[Sort(by="Region", desc=False)]))
    totals = dict(r["rows"])
    expected = {reg: sum(100 + i for i in range(90) if ["North", "South", "East"][i % 3] == reg) for reg in ("North", "South", "East")}
    assert totals == expected
    assert ds.count([Filter(column="Region", op="in", values=["North"])]) == 30
    assert ds.count([Filter(column="Sales", op="between", values=[100, 109])]) == 10
    assert ds.count([Filter(column="Date", op="date_range", values=["2026-02-01", "2026-02-28"])]) == 30
    assert ds.count([Filter(column="Product", op="contains", value="p1")]) == 18
    assert ds.count([Filter(column="Status", op="neq", value="Paid")]) == 23
    assert ds.count([Filter(column="Region", op="not_in", values=["North", "South"])]) == 30
    assert ds.count(search="East") == 30


@pytest.mark.parametrize("agg", ["sum", "avg", "min", "max", "median", "count", "count_distinct", "stddev", "variance"])
def test_all_aggregations(ds, agg):
    v = ds.scalar(Measure(column="Sales", agg=agg))
    s = pd.Series([100 + i for i in range(90)], dtype=float)
    exp = {"sum": s.sum(), "avg": s.mean(), "min": s.min(), "max": s.max(), "median": s.median(), "count": 90, "count_distinct": 90,
           "stddev": s.std(), "variance": s.var()}[agg]
    assert v == pytest.approx(exp, rel=1e-6)


def test_time_granularities(ds):
    r = ds.aggregate(QuerySpec(dimensions=[Dimension(column="Date", granularity="month")], measures=[Measure(agg="count_rows")]))
    assert [x[1] for x in r["rows"]] == [30, 30, 30]
    fy = ds.aggregate(QuerySpec(dimensions=[Dimension(column="Date", granularity="fy")], measures=[Measure(agg="count_rows")]))
    assert fy["rows"] == [["FY2025-26", 90]]


def test_formulas_safe_and_correct(ds):
    v = ds.scalar(Measure(formula="(SUM([Sales]) - SUM([Cost])) / SUM([Sales]) * 100"))
    s = sum(100 + i for i in range(90))
    c = sum(50 + i // 2 for i in range(90))
    assert v == pytest.approx((s - c) / s * 100)
    assert ds.scalar(Measure(formula="[Sales] - [Cost]", agg="sum")) == pytest.approx(s - c)
    assert ds.scalar(Measure(formula="SUM([Sales]) / 0")) is None  # NULL-safe division
    for bad in ["SUM([Sales]) - [Cost]", "__import__('os')", "SUM([Nope])", "SUM([Sales]); DROP TABLE x", "EXEC(1)"]:
        with pytest.raises(QueryError):
            ds.scalar(Measure(formula=bad))


def test_formula_parser_rejects_everything_else():
    with pytest.raises(FormulaError):
        compile_formula("1 ; 2", {"A"}, {"A"})
    comp = compile_formula("ROUND(AVG([A]), 2)", {"A"}, {"A"})
    assert comp.is_aggregate and "ROUND" in comp.sql


def test_sql_injection_via_column_names_and_values(ds):
    with pytest.raises(QueryError):
        ds.aggregate(QuerySpec(dimensions=[Dimension(column='Region" ; DROP TABLE data; --')]))
    assert ds.count([Filter(column="Region", op="eq", value="North'; DROP TABLE data; --")]) == 0
    assert ds.count() == 90


def test_conditional_measures_and_kpi_ratio(ds):
    k = compute_kpi(ds, KPISpec(title="Paid %", ratio=KPIRatio(numerator=Measure(agg="count_rows", filters=[Filter(column="Status", op="eq", value="Paid")]),
                                                                   denominator=Measure(agg="count_rows"))))
    assert k["value"] == pytest.approx(67 / 90 * 100)
    assert "÷" in k["evidence"]["calculation"]


def test_kpi_period_comparison_and_unavailable(ds):
    jan = sum(100 + i for i in range(0, 30))
    feb = sum(100 + i for i in range(30, 60))
    mar = sum(100 + i for i in range(60, 90))
    k = compute_kpi(ds, KPISpec(title="Sales", measure=Measure(column="Sales"),
                                comparison=KPIComparison(date_column="Date", granularity="month", mode="latest")))
    c = k["comparison"]
    assert c["available"] and c["previous_value"] == pytest.approx(feb) and c["current_value"] == pytest.approx(mar)
    assert c["change_pct"] == pytest.approx((mar - feb) / feb * 100)
    # data ends on 28 Mar, so by default the last *complete* month (Feb) is compared with Jan — and the UI is told why
    k = compute_kpi(ds, KPISpec(title="Sales", measure=Measure(column="Sales"), comparison=KPIComparison(date_column="Date", granularity="month")))
    c = k["comparison"]
    assert c["current_value"] == pytest.approx(feb) and c["previous_value"] == pytest.approx(jan) and c["latest_period_partial"] and c["note"]
    bad = compute_kpi(ds, KPISpec(title="x", measure=Measure(column="Missing")))
    assert bad["available"] is False and bad["value"] is None and "does not exist" in bad["reason"]


def test_filters_change_kpis(ds):
    all_v = compute_kpi(ds, KPISpec(title="s", measure=Measure(column="Sales")))["value"]
    north = compute_kpi(ds, KPISpec(title="s", measure=Measure(column="Sales")), [Filter(column="Region", op="in", values=["North"])])["value"]
    assert north < all_v


@pytest.mark.parametrize("t", ["bar", "hbar", "line", "area", "pie", "donut", "combo", "stacked_bar", "stacked_bar_100", "heatmap", "table", "pivot",
                               "histogram", "scatter", "kpi"])
def test_every_chart_type(ds, t):
    spec = ChartSpec(type=t, dimension=Dimension(column="Region"), series_dimension=Dimension(column="Status"),
                     measures=[Measure(column="Sales"), Measure(column="Cost")], histogram_column="Sales",
                     x_measure=Measure(column="Sales"), y_measure=Measure(column="Cost"))
    if t in ("line", "area", "combo"):
        spec.dimension = Dimension(column="Date")
        spec.series_dimension = None
    out = build_chart(ds, spec)
    assert out["type"] in (t, "stacked_bar", "kpi")


def test_top_n_with_other_bucket_sums_to_total(ds):
    out = build_chart(ds, ChartSpec(type="bar", dimension=Dimension(column="Product"), measures=[Measure(column="Sales")], top_n=3))
    assert out["categories"][-1] == "Other"
    assert sum(out["series"][0]["data"]) == pytest.approx(ds.scalar(Measure(column="Sales")))


def test_running_total_and_contribution(ds):
    out = build_chart(ds, ChartSpec(type="line", dimension=Dimension(column="Date", granularity="month"), measures=[Measure(column="Sales")],
                                    transform="running_total"))
    assert out["series"][0]["data"][-1] == pytest.approx(ds.scalar(Measure(column="Sales")))
    out = build_chart(ds, ChartSpec(type="bar", dimension=Dimension(column="Region"), measures=[Measure(column="Sales")], transform="contribution"))
    assert sum(out["series"][0]["data"]) == pytest.approx(100)


def test_pivot_totals_are_exact_for_averages(ds):
    p = pivot(ds, rows=[Dimension(column="Region")], column=Dimension(column="Status"), values=[Measure(column="Sales", agg="avg")])
    assert p["grand_total"][0] == pytest.approx(ds.scalar(Measure(column="Sales", agg="avg")))
    north = next(r for r in p["rows"] if r["keys"] == ["North"])
    assert north["total"][0] == pytest.approx(ds.scalar(Measure(column="Sales", agg="avg"), [Filter(column="Region", op="in", values=["North"])]))


def test_recommendations(ds):
    assert recommend_charts(ds, ["Date"], ["Sales"])[0]["type"] == "line"
    assert recommend_charts(ds, ["Region"], ["Sales"])[0]["type"] in ("donut", "bar")
    assert recommend_charts(ds, [], ["Sales", "Cost"])[0]["type"] == "scatter"


def test_explorer_rows_duplicates_and_nulls(ds):
    r = ds.rows(columns=["Region", "Sales"], sort=[Sort(by="Sales", desc=True)], limit=5, offset=5)
    assert r["total"] == 90 and len(r["rows"]) == 5 and r["rows"][0][1] == 184
    assert ds.rows(duplicates_only=True)["total"] == 0
    assert ds.rows(nulls_in="Region")["total"] == 0
