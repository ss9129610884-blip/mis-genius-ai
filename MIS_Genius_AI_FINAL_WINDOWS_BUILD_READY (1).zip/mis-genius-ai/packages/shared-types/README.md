# shared-types

`openapi.json` is the machine-readable contract of the REST API (97 paths), generated with
`python scripts/export_openapi.py`. Generate typed clients from it, e.g.
`npx openapi-typescript openapi.json -o api.d.ts` (TypeScript) or `openapi-generator` (Kotlin/Swift/Java).
The web app's hand-written types live in `apps/web/src/lib/types.ts`.
