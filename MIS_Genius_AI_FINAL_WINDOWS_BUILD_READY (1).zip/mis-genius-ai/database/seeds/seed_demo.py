"""Create a demo owner account with both demo datasets (clearly labelled DEMO) for trials and screenshots.

  MIS_DATA_DIR=./data python database/seeds/seed_demo.py --email demo@example.com --password Demo12345
"""
import argparse
import sys
from pathlib import Path

sys.path.insert(0, str(Path(__file__).resolve().parents[2] / "services" / "api"))
from sqlalchemy import select  # noqa: E402

from misgenius.api.routers.auth import create_org  # noqa: E402
from misgenius.auth.security import hash_password  # noqa: E402
from misgenius.db.models import User  # noqa: E402
from misgenius.db.session import SessionLocal, run_migrations  # noqa: E402
from misgenius.services.datasets import create_demo_dataset  # noqa: E402

p = argparse.ArgumentParser()
p.add_argument("--email", default="demo@example.com")
p.add_argument("--password", default="Demo12345")
a = p.parse_args()
run_migrations()
db = SessionLocal()
if db.scalars(select(User).where(User.email == a.email)).first():
    sys.exit(f"{a.email} already exists")
u = User(email=a.email, password_hash=hash_password(a.password), full_name="Demo User")
db.add(u)
db.flush()
org = create_org(db, "Demo Company", u)
db.commit()
for which in ("sales", "attendance"):
    print(create_demo_dataset(db, org.id, u.id, which))
print(f"Sign in with {a.email} / {a.password}")
