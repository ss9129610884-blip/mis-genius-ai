# Database

* Schema: SQLAlchemy models in `services/api/misgenius/db/models.py`.
* Migrations: Alembic, in `services/api/migrations/versions/` (kept next to the code so the desktop
  build and Docker image ship them). They run automatically at startup in every mode.
  Manual use: `cd services/api && DATABASE_URL=... alembic upgrade head`.
* New migration after changing models: `alembic revision --autogenerate -m "describe change"`.
* Seeds: `database/seeds/seed_demo.py` creates a demo account with the two demo datasets.

See `docs/DATABASE.md` for the entity reference.
